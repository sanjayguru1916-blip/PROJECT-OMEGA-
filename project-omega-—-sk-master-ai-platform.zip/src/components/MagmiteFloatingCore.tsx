import { useEffect, useRef, useState } from 'react';
import { AnimationQuality, AssistantRegistryEntry, VoiceState } from '../types/omega';

export type MagmiteCoreVisualState =
  | 'IDLE'
  | 'LISTENING'
  | 'THINKING'
  | 'SPEAKING'
  | 'ACTIVATING'
  | 'OFFLINE';

interface MagmiteFloatingCoreProps {
  activeIdentity: AssistantRegistryEntry;
  isRouting: boolean;
  isExecuting: boolean;
  pendingCount: number;
  voiceState?: VoiceState;
  voiceRmsLevel?: number;
  speaking?: boolean;
  animationQuality?: AnimationQuality;
  onReturnToSk?: () => void;
  onCheckStatus?: () => void;
}

interface FloatingParticle {
  angle: number;
  orbitRadiusFactor: number;
  speed: number;
  verticalPhase: number;
  verticalAmp: number;
  tilt: number;
  size: number;
  baseAlpha: number;
}

function createParticlePool(count: number): FloatingParticle[] {
  const pool: FloatingParticle[] = [];
  for (let i = 0; i < count; i += 1) {
    const seed = (i * 1.61803398875) % 1;
    const seed2 = ((i * 2.718281828) % 1);
    pool.push({
      angle: (i / count) * Math.PI * 2 + seed * 0.5,
      orbitRadiusFactor: 0.42 + seed * 0.54,
      speed: (i % 2 === 0 ? 1 : -1) * (0.28 + seed2 * 0.52),
      verticalPhase: i * 0.85,
      verticalAmp: 8 + seed * 18,
      tilt: (seed2 - 0.5) * 0.9,
      size: 1.1 + seed * 2.1,
      baseAlpha: 0.28 + seed2 * 0.55,
    });
  }
  return pool;
}

function drawTiltedEllipseArc(
  ctx: CanvasRenderingContext2D,
  cx: number,
  cy: number,
  rx: number,
  ry: number,
  tiltRad: number,
  startAngle: number,
  endAngle: number,
  strokeStyle: string,
  lineWidth: number,
  dashPattern: number[] = []
) {
  ctx.save();
  ctx.translate(cx, cy);
  ctx.rotate(tiltRad);
  ctx.strokeStyle = strokeStyle;
  ctx.lineWidth = lineWidth;
  ctx.lineCap = 'round';
  ctx.setLineDash(dashPattern);
  ctx.beginPath();
  ctx.ellipse(0, 0, rx, ry, 0, startAngle, endAngle);
  ctx.stroke();
  ctx.restore();
}

export function MagmiteFloatingCore({
  activeIdentity,
  isRouting,
  isExecuting,
  pendingCount,
  voiceState = 'IDLE',
  voiceRmsLevel = 0,
  speaking = false,
  animationQuality = 'HIGH_60FPS',
  onReturnToSk,
  onCheckStatus,
}: MagmiteFloatingCoreProps) {
  const stageRef = useRef<HTMLDivElement | null>(null);
  const canvasRef = useRef<HTMLCanvasElement | null>(null);

  const [activating, setActivating] = useState(true);

  const visualStateRef = useRef<MagmiteCoreVisualState>('ACTIVATING');
  const voiceRmsRef = useRef(0);
  const pendingCountRef = useRef(0);
  const animQualityRef = useRef<AnimationQuality>(animationQuality);
  const pointerOffsetRef = useRef({ x: 0, y: 0, targetX: 0, targetY: 0 });
  const stageSizeRef = useRef({ width: 320, height: 290 });
  const particlesRef = useRef<FloatingParticle[]>(createParticlePool(32));
  const activationStartRef = useRef<number>(performance.now());

  const computedVisualState: MagmiteCoreVisualState = !activeIdentity.isEnabled || activeIdentity.status === 'DISABLED'
    ? 'OFFLINE'
    : activating
      ? 'ACTIVATING'
      : speaking || voiceState === 'SPEAKING'
        ? 'SPEAKING'
        : voiceState === 'LISTENING'
          ? 'LISTENING'
          : isRouting || isExecuting || voiceState === 'PROCESSING' || voiceState === 'RESPONDING'
            ? 'THINKING'
            : 'IDLE';

  visualStateRef.current = computedVisualState;
  voiceRmsRef.current = voiceRmsLevel;
  pendingCountRef.current = pendingCount;
  animQualityRef.current = animationQuality;

  // Brief holographic activation pulse when MAGMITE core opens
  useEffect(() => {
    activationStartRef.current = performance.now();
    setActivating(true);
    const timer = window.setTimeout(() => {
      setActivating(false);
    }, 1350);
    return () => window.clearTimeout(timer);
  }, []);

  // Responsive viewport-aware sizing without enclosing card constraints
  useEffect(() => {
    const stage = stageRef.current;
    if (!stage) return;

    const updateSize = () => {
      const rect = stage.getBoundingClientRect();
      const width = Math.max(240, Math.round(rect.width));
      const height = Math.max(220, Math.round(rect.height));
      stageSizeRef.current = { width, height };
    };

    updateSize();
    const observer = typeof ResizeObserver !== 'undefined' ? new ResizeObserver(updateSize) : null;
    observer?.observe(stage);
    window.addEventListener('resize', updateSize);
    return () => {
      observer?.disconnect();
      window.removeEventListener('resize', updateSize);
    };
  }, []);

  // Continuous lifecycle-safe Canvas holographic renderer
  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    const prefersReducedMotion =
      typeof window !== 'undefined' &&
      window.matchMedia('(prefers-reduced-motion: reduce)').matches;

    let frameId = 0;
    let isDisposed = false;
    let isHidden = typeof document !== 'undefined' && document.hidden;
    let lastDrawTime = performance.now();
    let simTime = 0;
    let pulseWave = 0;

    const renderFrame = (now: number) => {
      if (isDisposed || isHidden) return;

      const quality = animQualityRef.current;
      const minFrameMs = quality === 'BATTERY_SAVER_30FPS' ? 32 : quality === 'REDUCED_MOTION' ? 95 : 15;
      const elapsedMs = now - lastDrawTime;
      if (elapsedMs < minFrameMs && simTime > 0) {
        frameId = requestAnimationFrame(renderFrame);
        return;
      }

      const dt = Math.min(0.05, Math.max(0.008, elapsedMs / 1000));
      lastDrawTime = now;

      const { width, height } = stageSizeRef.current;
      const dpr = Math.min(window.devicePixelRatio || 1, 2);
      const targetW = Math.round(width * dpr);
      const targetH = Math.round(height * dpr);
      if (canvas.width !== targetW || canvas.height !== targetH) {
        canvas.width = targetW;
        canvas.height = targetH;
      }

      const currentState = visualStateRef.current;
      const rms = voiceRmsRef.current;
      const activationProgress = Math.min(1, Math.max(0, (now - activationStartRef.current) / 1350));

      const speedFactor =
        prefersReducedMotion || quality === 'REDUCED_MOTION'
          ? 0.25
          : currentState === 'OFFLINE'
            ? 0.28
            : currentState === 'THINKING'
              ? 2.25
              : currentState === 'SPEAKING'
                ? 1.65 + rms * 0.9
                : currentState === 'LISTENING'
                  ? 1.45 + rms * 0.7
                  : currentState === 'ACTIVATING'
                    ? 2.6 * (1 - activationProgress * 0.45)
                    : 1.0;

      simTime += dt * speedFactor;
      pulseWave = (pulseWave + dt * (currentState === 'OFFLINE' ? 0.18 : currentState === 'THINKING' ? 0.95 : currentState === 'SPEAKING' ? 0.85 : 0.42)) % 1;

      // Damped subtle 3D parallax (ambient sway + pointer target)
      const p = pointerOffsetRef.current;
      p.x += (p.targetX - p.x) * 0.08;
      p.y += (p.targetY - p.y) * 0.08;
      const ambientTiltX = Math.sin(simTime * 0.7) * 3.5;
      const ambientTiltY = Math.cos(simTime * 0.55) * 2.5;
      const parallaxX = p.x * 9 + ambientTiltX;
      const parallaxY = p.y * 7 + ambientTiltY;

      ctx.save();
      ctx.scale(dpr, dpr);
      ctx.clearRect(0, 0, width, height);

      const minDim = Math.min(width, height);
      const levitationY =
        currentState === 'OFFLINE' || prefersReducedMotion
          ? 0
          : Math.sin(simTime * 1.45) * (minDim * 0.022);

      const cx = width / 2 + parallaxX * 0.4;
      const cy = height / 2 + levitationY + parallaxY * 0.4;
      const baseRadius = minDim * 0.34;
      const sphereRadius =
        baseRadius *
        0.41 *
        (currentState === 'ACTIVATING'
          ? 0.35 + 0.65 * Math.sin(activationProgress * (Math.PI / 2))
          : currentState === 'SPEAKING'
            ? 1 + 0.05 * Math.sin(simTime * 6) + rms * 0.14
            : currentState === 'LISTENING'
              ? 1 + 0.03 * Math.sin(simTime * 4) + rms * 0.09
              : currentState === 'OFFLINE'
                ? 0.92
                : 1 + 0.026 * Math.sin(simTime * 2.1));

      // Preserved MAGMITE amber/gold identity palette
      const isOffline = currentState === 'OFFLINE';
      const isListening = currentState === 'LISTENING';
      const isThinking = currentState === 'THINKING';
      const isSpeaking = currentState === 'SPEAKING';

      const primaryRgb = isOffline ? '100, 116, 139' : '245, 158, 11'; // #F59E0B
      const goldRgb = isOffline ? '120, 113, 108' : '251, 191, 36'; // #FBBF24
      const coreRgb = isOffline ? '148, 163, 184' : '254, 243, 199'; // #FEF3C7
      const listenRgb = '56, 189, 248'; // subtle acoustic highlight when mic active

      // 1. Open-Space Unbounded Volumetric Field Aura (fades cleanly to transparent)
      const auraRadius = minDim * 0.49;
      const auraGrad = ctx.createRadialGradient(cx, cy, sphereRadius * 0.2, cx, cy, auraRadius);
      auraGrad.addColorStop(0, `rgba(${coreRgb}, ${isOffline ? 0.14 : isSpeaking ? 0.42 : 0.28})`);
      auraGrad.addColorStop(0.32, `rgba(${primaryRgb}, ${isOffline ? 0.08 : isThinking ? 0.26 : 0.18})`);
      auraGrad.addColorStop(0.68, `rgba(${goldRgb}, ${isOffline ? 0.02 : isListening ? 0.08 : 0.06})`);
      auraGrad.addColorStop(1, 'rgba(5, 6, 8, 0)');
      ctx.fillStyle = auraGrad;
      ctx.beginPath();
      ctx.arc(cx, cy, auraRadius, 0, Math.PI * 2);
      ctx.fill();

      // 2. Dynamic Concentric Light Pulse Ripples
      if (!isOffline) {
        const waveCount = isSpeaking || currentState === 'ACTIVATING' ? 2 : 1;
        for (let w = 0; w < waveCount; w += 1) {
          const pPhase = (pulseWave + w * 0.5) % 1;
          const waveR = sphereRadius * 1.1 + pPhase * (baseRadius * 1.25 - sphereRadius);
          const waveAlpha = (1 - pPhase) * (currentState === 'ACTIVATING' ? 0.48 : isSpeaking ? 0.34 : 0.22);
          ctx.strokeStyle = isListening
            ? `rgba(${listenRgb}, ${waveAlpha})`
            : `rgba(${goldRgb}, ${waveAlpha})`;
          ctx.lineWidth = 1.6 - pPhase * 0.9;
          ctx.beginPath();
          ctx.arc(cx, cy, waveR, 0, Math.PI * 2);
          ctx.stroke();
        }
      }

      // 3. Back-Plane 3D Foreshortened Orbital Rings (behind sphere for depth)
      const ringExpand = currentState === 'ACTIVATING' ? 0.45 + 0.55 * activationProgress : 1;
      const orbitConfigs = [
        { rx: baseRadius * 1.08 * ringExpand, ry: baseRadius * 0.42 * ringExpand, tilt: 0.44 + parallaxY * 0.008, rotSpeed: 0.72, color: primaryRgb, width: 1.5, dash: [14, 9] },
        { rx: baseRadius * 0.96 * ringExpand, ry: baseRadius * 0.38 * ringExpand, tilt: -0.62 - parallaxX * 0.008, rotSpeed: -0.95, color: goldRgb, width: 1.35, dash: [8, 8] },
        { rx: baseRadius * 0.84 * ringExpand, ry: baseRadius * 0.32 * ringExpand, tilt: 1.18, rotSpeed: 1.15, color: isListening ? listenRgb : primaryRgb, width: 1.2, dash: [] },
      ];

      orbitConfigs.forEach((cfg) => {
        drawTiltedEllipseArc(
          ctx,
          cx - parallaxX * 0.22,
          cy - parallaxY * 0.22,
          cfg.rx,
          cfg.ry,
          cfg.tilt + Math.sin(simTime * 0.4) * 0.05,
          Math.PI,
          Math.PI * 2,
          `rgba(${cfg.color}, ${isOffline ? 0.14 : 0.28})`,
          cfg.width,
          cfg.dash
        );
      });

      // 4. Outer Flat Containment Harmonic Ring (MAGMITE energy halo, subtle & borderless)
      ctx.save();
      ctx.translate(cx, cy);
      ctx.rotate(simTime * 0.32);
      ctx.strokeStyle = `rgba(${primaryRgb}, ${isOffline ? 0.16 : isThinking ? 0.52 : 0.34})`;
      ctx.lineWidth = 1.25;
      ctx.setLineDash([20, 14, 5, 14]);
      ctx.beginPath();
      ctx.arc(0, 0, baseRadius * 1.16 * ringExpand, 0, Math.PI * 2);
      ctx.stroke();
      ctx.restore();

      // 5. Central Floating Volumetric Energy Sphere
      ctx.save();
      const sphereGrad = ctx.createRadialGradient(
        cx - sphereRadius * 0.28,
        cy - sphereRadius * 0.28,
        sphereRadius * 0.08,
        cx,
        cy,
        sphereRadius
      );
      sphereGrad.addColorStop(0, `rgba(${coreRgb}, ${isOffline ? 0.38 : 0.95})`);
      sphereGrad.addColorStop(0.45, `rgba(${goldRgb}, ${isOffline ? 0.26 : 0.82})`);
      sphereGrad.addColorStop(0.82, `rgba(${primaryRgb}, ${isOffline ? 0.18 : 0.62})`);
      sphereGrad.addColorStop(1, `rgba(180, 83, 9, ${isOffline ? 0.08 : 0.22})`);

      ctx.fillStyle = sphereGrad;
      ctx.beginPath();
      ctx.arc(cx, cy, sphereRadius, 0, Math.PI * 2);
      ctx.fill();

      // Clip internal magnetic plasma waves inside the floating sphere
      ctx.beginPath();
      ctx.arc(cx, cy, sphereRadius * 0.94, 0, Math.PI * 2);
      ctx.clip();

      if (!isOffline) {
        const waveAmp = sphereRadius * (isSpeaking ? 0.22 + rms * 0.18 : isThinking ? 0.18 : 0.12);
        for (let line = 0; line < 2; line += 1) {
          ctx.beginPath();
          ctx.strokeStyle = `rgba(${coreRgb}, ${line === 0 ? 0.55 : 0.32})`;
          ctx.lineWidth = line === 0 ? 1.5 : 1.0;
          const phaseOffset = line * 1.7 + simTime * (line === 0 ? 3.2 : -2.4);
          for (let x = -sphereRadius; x <= sphereRadius; x += 4) {
            const norm = x / sphereRadius;
            const envelope = Math.sqrt(Math.max(0, 1 - norm * norm));
            const y = Math.sin(norm * 4.5 + phaseOffset) * waveAmp * envelope;
            if (x === -sphereRadius) ctx.moveTo(cx + x, cy + y);
            else ctx.lineTo(cx + x, cy + y);
          }
          ctx.stroke();
        }
      }
      ctx.restore();

      // Specular Fresnel rim highlight on sphere
      ctx.strokeStyle = `rgba(${coreRgb}, ${isOffline ? 0.18 : isSpeaking ? 0.85 : 0.52})`;
      ctx.lineWidth = 1.4;
      ctx.beginPath();
      ctx.arc(cx, cy, sphereRadius, 0, Math.PI * 2);
      ctx.stroke();

      // 6. Inner Rotating 6-Node Magnetic Hex Lattice (MAGMITE structural signature)
      const nodes = activeIdentity.visualIdentity.orbitalNodes || 6;
      ctx.save();
      ctx.translate(cx, cy);
      ctx.rotate(-simTime * 0.58);
      ctx.strokeStyle = `rgba(${goldRgb}, ${isOffline ? 0.16 : isThinking ? 0.65 : 0.38})`;
      ctx.lineWidth = 1.1;
      ctx.beginPath();
      const hexR = sphereRadius * 1.38 * ringExpand;
      for (let i = 0; i <= nodes; i += 1) {
        const theta = (i * Math.PI * 2) / nodes;
        const px = Math.cos(theta) * hexR;
        const py = Math.sin(theta) * hexR;
        if (i === 0) ctx.moveTo(px, py);
        else ctx.lineTo(px, py);
      }
      ctx.stroke();
      ctx.restore();

      // 7. Front-Plane 3D Rings (in front of sphere)
      orbitConfigs.forEach((cfg) => {
        drawTiltedEllipseArc(
          ctx,
          cx + parallaxX * 0.22,
          cy + parallaxY * 0.22,
          cfg.rx,
          cfg.ry,
          cfg.tilt + Math.sin(simTime * 0.4) * 0.05,
          0,
          Math.PI,
          `rgba(${cfg.color}, ${isOffline ? 0.24 : isThinking || isSpeaking ? 0.88 : 0.68})`,
          cfg.width * 1.15,
          cfg.dash
        );
      });

      // 8. Six Glowing Orbital Nodes with Subtle Plasma Trails
      const nodeOrbitA = orbitConfigs[0];
      const nodeOrbitB = orbitConfigs[1];
      const trailSteps = isOffline ? 2 : 7;

      for (let i = 0; i < nodes; i += 1) {
        const useOrbitA = i % 2 === 0;
        const cfg = useOrbitA ? nodeOrbitA : nodeOrbitB;
        const tilt = cfg.tilt + Math.sin(simTime * 0.4) * 0.05;
        const baseTheta = (i * Math.PI * 2) / nodes + simTime * cfg.rotSpeed;

        // Subtle plasma trail behind each orbital node
        for (let s = trailSteps; s >= 1; s -= 1) {
          const lagTheta = baseTheta - s * 0.075 * Math.sign(cfg.rotSpeed);
          const lx = Math.cos(lagTheta) * cfg.rx;
          const ly = Math.sin(lagTheta) * cfg.ry;
          const tx = cx + lx * Math.cos(tilt) - ly * Math.sin(tilt);
          const ty = cy + lx * Math.sin(tilt) + ly * Math.cos(tilt);
          const frac = 1 - s / (trailSteps + 1);
          ctx.fillStyle = `rgba(${primaryRgb}, ${(isOffline ? 0.08 : 0.45) * frac * frac})`;
          ctx.beginPath();
          ctx.arc(tx, ty, 2.4 * frac, 0, Math.PI * 2);
          ctx.fill();
        }

        const lx = Math.cos(baseTheta) * cfg.rx;
        const ly = Math.sin(baseTheta) * cfg.ry;
        const nx = cx + lx * Math.cos(tilt) - ly * Math.sin(tilt);
        const ny = cy + lx * Math.sin(tilt) + ly * Math.cos(tilt);
        const isFront = Math.sin(baseTheta) >= 0;
        const nodeRadius = (isFront ? 3.8 : 2.7) + (isSpeaking ? rms * 1.6 : 0);

        // Node halo
        const nodeGlow = ctx.createRadialGradient(nx, ny, 0.5, nx, ny, nodeRadius * 3.1);
        nodeGlow.addColorStop(0, `rgba(${coreRgb}, ${isOffline ? 0.25 : 0.92})`);
        nodeGlow.addColorStop(0.45, `rgba(${primaryRgb}, ${isOffline ? 0.12 : 0.55})`);
        nodeGlow.addColorStop(1, 'rgba(5, 6, 8, 0)');
        ctx.fillStyle = nodeGlow;
        ctx.beginPath();
        ctx.arc(nx, ny, nodeRadius * 3.1, 0, Math.PI * 2);
        ctx.fill();

        ctx.fillStyle = isOffline
          ? `rgba(${primaryRgb}, 0.5)`
          : isFront
            ? `rgba(${coreRgb}, 0.98)`
            : `rgba(${goldRgb}, 0.8)`;
        ctx.beginPath();
        ctx.arc(nx, ny, nodeRadius, 0, Math.PI * 2);
        ctx.fill();
      }

      // 9. Audio-Reactive Floating Harmonic Filaments (LISTENING & SPEAKING)
      if (isListening || isSpeaking) {
        const filaments = 36;
        const ringBaseR = baseRadius * 1.24;
        ctx.save();
        ctx.lineCap = 'round';
        ctx.lineWidth = 1.9;
        for (let i = 0; i < filaments; i += 1) {
          const theta = (i * Math.PI * 2) / filaments + simTime * 0.45;
          const harmonic = 0.4 + 0.6 * Math.abs(Math.sin(simTime * 4.8 + i * 0.65));
          const amp = (4 + 16 * Math.max(0.18, rms)) * harmonic;
          ctx.strokeStyle = isListening
            ? `rgba(${listenRgb}, ${0.38 + 0.42 * harmonic})`
            : `rgba(${goldRgb}, ${0.42 + 0.45 * harmonic})`;
          ctx.beginPath();
          ctx.moveTo(cx + Math.cos(theta) * ringBaseR, cy + Math.sin(theta) * ringBaseR);
          ctx.lineTo(cx + Math.cos(theta) * (ringBaseR + amp), cy + Math.sin(theta) * (ringBaseR + amp));
          ctx.stroke();
        }
        ctx.restore();
      }

      // 10. Floating 3D Energy Particles in Open Space
      const particles = particlesRef.current;
      for (let i = 0; i < particles.length; i += 1) {
        const pt = particles[i];
        const theta = pt.angle + simTime * pt.speed;
        const pull = currentState === 'ACTIVATING'
          ? 1.55 - 0.55 * activationProgress
          : isThinking
            ? 0.84
            : isSpeaking
              ? 1.06 + rms * 0.14
              : 1.0;

        const r = minDim * 0.48 * pt.orbitRadiusFactor * pull;
        const pxLocal = Math.cos(theta) * r;
        const pzDepth = Math.sin(theta); // -1 (far) .. +1 (near)
        const pyLocal =
          Math.sin(theta + pt.tilt) * r * 0.36 +
          Math.sin(simTime * 1.3 + pt.verticalPhase) * pt.verticalAmp;

        const px = cx + pxLocal + parallaxX * (0.35 + pzDepth * 0.25);
        const py = cy + pyLocal + parallaxY * (0.35 + pzDepth * 0.25);
        const depthScale = 0.68 + (pzDepth + 1) * 0.32;
        const twinkle = 0.6 + 0.4 * Math.sin(simTime * 2.8 + pt.verticalPhase);
        const alpha =
          pt.baseAlpha *
          twinkle *
          (isOffline ? 0.22 : pendingCountRef.current > 0 ? 1.0 : 0.85) *
          (0.55 + (pzDepth + 1) * 0.225);

        ctx.fillStyle =
          i % 5 === 0 && isListening
            ? `rgba(${listenRgb}, ${Math.min(1, alpha)})`
            : i % 3 === 0
              ? `rgba(${coreRgb}, ${Math.min(1, alpha)})`
              : `rgba(${goldRgb}, ${Math.min(1, alpha)})`;
        ctx.beginPath();
        ctx.arc(px, py, pt.size * depthScale, 0, Math.PI * 2);
        ctx.fill();
      }

      ctx.restore();
      frameId = requestAnimationFrame(renderFrame);
    };

    const handleVisibility = () => {
      isHidden = document.hidden;
      if (!isHidden && !isDisposed) {
        lastDrawTime = performance.now();
        frameId = requestAnimationFrame(renderFrame);
      }
    };

    document.addEventListener('visibilitychange', handleVisibility);
    frameId = requestAnimationFrame(renderFrame);

    return () => {
      isDisposed = true;
      document.removeEventListener('visibilitychange', handleVisibility);
      cancelAnimationFrame(frameId);
    };
  }, [activeIdentity.isEnabled, activeIdentity.visualIdentity.orbitalNodes]);

  const statusLabel = (() => {
    switch (computedVisualState) {
      case 'OFFLINE':
        return 'OFFLINE';
      case 'ACTIVATING':
        return 'ACTIVATING';
      case 'LISTENING':
        return 'LISTENING';
      case 'THINKING':
        return isExecuting ? 'EXECUTING' : 'THINKING';
      case 'SPEAKING':
        return 'SPEAKING';
      default:
        return activeIdentity.status || 'IDLE';
    }
  })();

  const hasNonIdleActivity =
    activeIdentity.metrics &&
    (activeIdentity.metrics.activeTaskCount > 0 ||
      activeIdentity.metrics.pendingTaskCount > 0 ||
      activeIdentity.metrics.currentActivity !== 'Idle' ||
      Boolean(activeIdentity.metrics.recentError));

  return (
    <div
      className="relative w-full flex flex-col items-center justify-center py-1 select-none"
      onPointerMove={(e) => {
        const rect = e.currentTarget.getBoundingClientRect();
        if (rect.width <= 0 || rect.height <= 0) return;
        const nx = ((e.clientX - rect.left) / rect.width - 0.5) * 2;
        const ny = ((e.clientY - rect.top) / rect.height - 0.5) * 2;
        pointerOffsetRef.current.targetX = Math.max(-1, Math.min(1, nx));
        pointerOffsetRef.current.targetY = Math.max(-1, Math.min(1, ny));
      }}
      onPointerLeave={() => {
        pointerOffsetRef.current.targetX = 0;
        pointerOffsetRef.current.targetY = 0;
      }}
    >
      {/* Borderless Open-Space Floating Core Canvas Stage */}
      <div
        ref={stageRef}
        className="relative w-full max-w-[440px] h-[clamp(235px,36vh,340px)] flex items-center justify-center overflow-visible"
      >
        <canvas
          ref={canvasRef}
          className="w-full h-full pointer-events-none"
          aria-label={`MAGMITE Open Floating Holographic Core (${statusLabel})`}
        />

        {/* Centered Core Identity Overlay (no box, floats directly over sphere) */}
        <div className="absolute inset-0 flex flex-col items-center justify-center text-center pointer-events-none px-4">
          <span className="font-mono text-[9px] tracking-[0.22em] text-amber-200/80 uppercase drop-shadow-[0_1px_4px_rgba(0,0,0,0.9)]">
            {statusLabel}
          </span>
          <span className="font-display text-lg sm:text-xl font-bold tracking-wider text-white mt-0.5 drop-shadow-[0_2px_10px_rgba(0,0,0,0.95)]">
            MAGMITE
          </span>
          <span className="font-mono text-[10px] tracking-widest text-amber-300/90 mt-0.5 drop-shadow-[0_1px_6px_rgba(0,0,0,0.95)]">
            {activeIdentity.visualIdentity.emblemLabel}
          </span>
        </div>
      </div>

      {/* Minimal Floating HUD Footer (unboxed, avoids overlapping command bar) */}
      <div className="w-full flex flex-wrap items-center justify-between gap-2 px-1 pt-1 text-[11px] font-mono">
        <span className="text-slate-400 truncate max-w-[65%]">
          {hasNonIdleActivity
            ? activeIdentity.metrics.recentError || activeIdentity.metrics.currentActivity
            : `MAGMITE Core · ${statusLabel} · SK Supervised`}
        </span>
        <div className="flex items-center gap-3 shrink-0">
          {onCheckStatus && (
            <button
              type="button"
              onClick={onCheckStatus}
              className="text-amber-300/90 hover:text-amber-200 transition-colors whitespace-nowrap"
            >
              Status
            </button>
          )}
          {onReturnToSk && (
            <button
              type="button"
              onClick={onReturnToSk}
              className="text-slate-300 hover:text-white transition-colors whitespace-nowrap"
            >
              SK Master
            </button>
          )}
        </div>
      </div>
    </div>
  );
}
