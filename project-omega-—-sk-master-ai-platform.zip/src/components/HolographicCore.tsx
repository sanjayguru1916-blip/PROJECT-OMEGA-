import { useEffect, useRef, useState } from 'react';
import { AnimationQuality, AssistantRegistryEntry, VoiceState } from '../types/omega';

export type CoreVisualState =
  | 'IDLE'
  | 'LISTENING'
  | 'THINKING'
  | 'SPEAKING'
  | 'ACTIVATING'
  | 'OFFLINE';

interface HolographicCoreProps {
  activeIdentity: AssistantRegistryEntry;
  isRouting: boolean;
  isExecuting: boolean;
  pendingCount: number;
  voiceState?: VoiceState;
  voiceRmsLevel?: number;
  speaking?: boolean;
  animationQuality?: AnimationQuality;
  onReturnToSk?: () => void;
  onCheckStatus?: () => void;
}

interface FloatingParticle {
  angle: number;
  orbitRadiusFactor: number;
  speed: number;
  verticalPhase: number;
  verticalAmp: number;
  tilt: number;
  size: number;
  baseAlpha: number;
}

function createParticlePool(count: number): FloatingParticle[] {
  const pool: FloatingParticle[] = [];
  for (let i = 0; i < count; i += 1) {
    const seed = (i * 1.61803398875) % 1;
    const seed2 = (i * 2.718281828) % 1;
    pool.push({
      angle: (i / count) * Math.PI * 2 + seed * 0.5,
      orbitRadiusFactor: 0.44 + seed * 0.52,
      speed: (i % 2 === 0 ? 1 : -1) * (0.26 + seed2 * 0.48),
      verticalPhase: i * 0.9,
      verticalAmp: 7 + seed * 16,
      tilt: (seed2 - 0.5) * 0.95,
      size: 1.0 + seed * 2.0,
      baseAlpha: 0.28 + seed2 * 0.52,
    });
  }
  return pool;
}

function hexToRgbTuple(hex: string): string {
  const clean = hex.replace('#', '');
  if (clean.length !== 6) return '59, 130, 246';
  const r = parseInt(clean.slice(0, 2), 16);
  const g = parseInt(clean.slice(2, 4), 16);
  const b = parseInt(clean.slice(4, 6), 16);
  if (Number.isNaN(r) || Number.isNaN(g) || Number.isNaN(b)) return '59, 130, 246';
  return `${r}, ${g}, ${b}`;
}

function drawTiltedEllipseArc(
  ctx: CanvasRenderingContext2D,
  cx: number,
  cy: number,
  rx: number,
  ry: number,
  tiltRad: number,
  startAngle: number,
  endAngle: number,
  strokeStyle: string,
  lineWidth: number,
  dashPattern: number[] = []
) {
  ctx.save();
  ctx.translate(cx, cy);
  ctx.rotate(tiltRad);
  ctx.strokeStyle = strokeStyle;
  ctx.lineWidth = lineWidth;
  ctx.lineCap = 'round';
  ctx.setLineDash(dashPattern);
  ctx.beginPath();
  ctx.ellipse(0, 0, rx, ry, 0, startAngle, endAngle);
  ctx.stroke();
  ctx.restore();
}

export function HolographicCore({
  activeIdentity,
  isRouting,
  isExecuting,
  pendingCount,
  voiceState = 'IDLE',
  voiceRmsLevel = 0,
  speaking = false,
  animationQuality = 'HIGH_60FPS',
  onReturnToSk,
  onCheckStatus,
}: HolographicCoreProps) {
  const stageRef = useRef<HTMLDivElement | null>(null);
  const canvasRef = useRef<HTMLCanvasElement | null>(null);

  const [activating, setActivating] = useState(true);

  const visualStateRef = useRef<CoreVisualState>('ACTIVATING');
  const voiceRmsRef = useRef(0);
  const pendingCountRef = useRef(0);
  const animQualityRef = useRef<AnimationQuality>(animationQuality);
  const pointerOffsetRef = useRef({ x: 0, y: 0, targetX: 0, targetY: 0 });
  const stageSizeRef = useRef({ width: 320, height: 280 });
  const particlesRef = useRef<FloatingParticle[]>(createParticlePool(28));
  const activationStartRef = useRef<number>(performance.now());

  const computedVisualState: CoreVisualState =
    !activeIdentity.isEnabled || activeIdentity.status === 'DISABLED'
      ? 'OFFLINE'
      : activating
        ? 'ACTIVATING'
        : speaking || voiceState === 'SPEAKING'
          ? 'SPEAKING'
          : voiceState === 'LISTENING'
            ? 'LISTENING'
            : isRouting || isExecuting || voiceState === 'PROCESSING' || voiceState === 'RESPONDING'
              ? 'THINKING'
              : 'IDLE';

  visualStateRef.current = computedVisualState;
  voiceRmsRef.current = voiceRmsLevel;
  pendingCountRef.current = pendingCount;
  animQualityRef.current = animationQuality;

  // Holographic activation sequence whenever switching to this core
  useEffect(() => {
    activationStartRef.current = performance.now();
    setActivating(true);
    const timer = window.setTimeout(() => {
      setActivating(false);
    }, 1250);
    return () => window.clearTimeout(timer);
  }, [activeIdentity.id]);

  // Responsive viewport-aware sizing without rectangular card bounds
  useEffect(() => {
    const stage = stageRef.current;
    if (!stage) return;

    const updateSize = () => {
      const rect = stage.getBoundingClientRect();
      stageSizeRef.current = {
        width: Math.max(240, Math.round(rect.width)),
        height: Math.max(220, Math.round(rect.height)),
      };
    };

    updateSize();
    const observer = typeof ResizeObserver !== 'undefined' ? new ResizeObserver(updateSize) : null;
    observer?.observe(stage);
    window.addEventListener('resize', updateSize);
    return () => {
      observer?.disconnect();
      window.removeEventListener('resize', updateSize);
    };
  }, []);

  // Lifecycle-safe open-space Canvas holographic renderer preserving each identity
  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    const prefersReducedMotion =
      typeof window !== 'undefined' &&
      window.matchMedia('(prefers-reduced-motion: reduce)').matches;

    let frameId = 0;
    let isDisposed = false;
    let isHidden = typeof document !== 'undefined' && document.hidden;
    let lastDrawTime = performance.now();
    let simTime = 0;
    let pulseWave = 0;

    const primaryRgbBase = hexToRgbTuple(activeIdentity.visualIdentity.primaryColor);
    const secondaryRgbBase = hexToRgbTuple(activeIdentity.visualIdentity.secondaryColor);
    const identityId = activeIdentity.id;
    const nodeCount = Math.max(3, activeIdentity.visualIdentity.orbitalNodes || 4);

    const renderFrame = (now: number) => {
      if (isDisposed || isHidden) return;

      const quality = animQualityRef.current;
      const minFrameMs = quality === 'BATTERY_SAVER_30FPS' ? 32 : quality === 'REDUCED_MOTION' ? 95 : 15;
      const elapsedMs = now - lastDrawTime;
      if (elapsedMs < minFrameMs && simTime > 0) {
        frameId = requestAnimationFrame(renderFrame);
        return;
      }

      const dt = Math.min(0.05, Math.max(0.008, elapsedMs / 1000));
      lastDrawTime = now;

      const { width, height } = stageSizeRef.current;
      const dpr = Math.min(window.devicePixelRatio || 1, 2);
      const targetW = Math.round(width * dpr);
      const targetH = Math.round(height * dpr);
      if (canvas.width !== targetW || canvas.height !== targetH) {
        canvas.width = targetW;
        canvas.height = targetH;
      }

      const currentState = visualStateRef.current;
      const rms = voiceRmsRef.current;
      const activationProgress = Math.min(1, Math.max(0, (now - activationStartRef.current) / 1250));

      const speedFactor =
        prefersReducedMotion || quality === 'REDUCED_MOTION'
          ? 0.25
          : currentState === 'OFFLINE'
            ? 0.2
            : currentState === 'THINKING'
              ? 2.2
              : currentState === 'SPEAKING'
                ? 1.65 + rms * 0.85
                : currentState === 'LISTENING'
                  ? 1.45 + rms * 0.7
                  : currentState === 'ACTIVATING'
                    ? 2.5 * (1 - activationProgress * 0.4)
                    : identityId === 'ULTRON'
                      ? 1.15
                      : identityId === 'FRIDAY'
                        ? 0.9
                        : 1.0;

      simTime += dt * speedFactor;
      pulseWave =
        (pulseWave +
          dt *
            (currentState === 'OFFLINE'
              ? 0.14
              : currentState === 'THINKING'
                ? 0.92
                : currentState === 'SPEAKING'
                  ? 0.85
                  : 0.42)) %
        1;

      const p = pointerOffsetRef.current;
      p.x += (p.targetX - p.x) * 0.08;
      p.y += (p.targetY - p.y) * 0.08;
      const ambientTiltX = Math.sin(simTime * 0.65) * 3.2;
      const ambientTiltY = Math.cos(simTime * 0.5) * 2.4;
      const parallaxX = p.x * 8 + ambientTiltX;
      const parallaxY = p.y * 6 + ambientTiltY;

      ctx.save();
      ctx.scale(dpr, dpr);
      ctx.clearRect(0, 0, width, height);

      const minDim = Math.min(width, height);
      const levitationY =
        currentState === 'OFFLINE' || prefersReducedMotion
          ? 0
          : Math.sin(simTime * 1.4) * (minDim * 0.021);

      const cx = width / 2 + parallaxX * 0.4;
      const cy = height / 2 + levitationY + parallaxY * 0.4;
      const baseRadius = minDim * 0.34;
      const coreRadius =
        baseRadius *
        0.38 *
        (currentState === 'ACTIVATING'
          ? 0.35 + 0.65 * Math.sin(activationProgress * (Math.PI / 2))
          : currentState === 'SPEAKING'
            ? 1 + 0.055 * Math.sin(simTime * 6) + rms * 0.14
            : currentState === 'LISTENING'
              ? 1 + 0.032 * Math.sin(simTime * 4) + rms * 0.09
              : currentState === 'OFFLINE'
                ? 0.9
                : 1 + 0.025 * Math.sin(simTime * 2.0));

      const isOffline = currentState === 'OFFLINE';
      const isListening = currentState === 'LISTENING';
      const isThinking = currentState === 'THINKING';
      const isSpeaking = currentState === 'SPEAKING';

      const primaryRgb = isOffline ? '100, 116, 139' : primaryRgbBase;
      const secondaryRgb = isOffline ? '148, 163, 184' : secondaryRgbBase;
      const coreHighlightRgb = isOffline
        ? '203, 213, 225'
        : identityId === 'JARVIS'
          ? '219, 234, 254'
          : identityId === 'ULTRON'
            ? '254, 202, 202'
            : '209, 250, 229';
      const listenRgb = '56, 189, 248';

      // 1. Open-Space Unbounded Volumetric Field Aura (fades seamlessly to transparent)
      const auraR = minDim * 0.49;
      const auraGrad = ctx.createRadialGradient(cx, cy, coreRadius * 0.15, cx, cy, auraR);
      auraGrad.addColorStop(0, `rgba(${coreHighlightRgb}, ${isOffline ? 0.12 : isSpeaking ? 0.38 : 0.24})`);
      auraGrad.addColorStop(0.35, `rgba(${primaryRgb}, ${isOffline ? 0.06 : isThinking ? 0.24 : 0.16})`);
      auraGrad.addColorStop(0.7, `rgba(${secondaryRgb}, ${isOffline ? 0.02 : 0.06})`);
      auraGrad.addColorStop(1, 'rgba(5, 6, 8, 0)');
      ctx.fillStyle = auraGrad;
      ctx.beginPath();
      ctx.arc(cx, cy, auraR, 0, Math.PI * 2);
      ctx.fill();

      // 2. Dynamic Light Pulse Ripples
      if (!isOffline) {
        const waveCount = isSpeaking || currentState === 'ACTIVATING' ? 2 : 1;
        for (let w = 0; w < waveCount; w += 1) {
          const pPhase = (pulseWave + w * 0.5) % 1;
          const waveR = coreRadius * 1.15 + pPhase * (baseRadius * 1.24 - coreRadius);
          const waveAlpha = (1 - pPhase) * (currentState === 'ACTIVATING' ? 0.46 : isSpeaking ? 0.32 : 0.2);
          ctx.strokeStyle = isListening
            ? `rgba(${listenRgb}, ${waveAlpha})`
            : `rgba(${secondaryRgb}, ${waveAlpha})`;
          ctx.lineWidth = Math.max(0.6, 1.5 - pPhase * 0.8);
          ctx.beginPath();
          ctx.arc(cx, cy, waveR, 0, Math.PI * 2);
          ctx.stroke();
        }
      }

      // 3. Identity-Tuned 3D Orbital Ring Architecture (Back-Plane)
      const ringExpand = currentState === 'ACTIVATING' ? 0.45 + 0.55 * activationProgress : 1;
      const orbitConfigs =
        identityId === 'JARVIS'
          ? [
              { rx: baseRadius * 1.08 * ringExpand, ry: baseRadius * 0.46 * ringExpand, tilt: 0.36, rotSpeed: 0.68, rgb: primaryRgb, width: 1.5, dash: [18, 8] },
              { rx: baseRadius * 0.94 * ringExpand, ry: baseRadius * 0.4 * ringExpand, tilt: -0.78, rotSpeed: -0.92, rgb: secondaryRgb, width: 1.35, dash: [6, 8] },
              { rx: baseRadius * 0.82 * ringExpand, ry: baseRadius * 0.34 * ringExpand, tilt: 1.25, rotSpeed: 1.05, rgb: isListening ? listenRgb : primaryRgb, width: 1.15, dash: [] },
            ]
          : identityId === 'ULTRON'
            ? [
                { rx: baseRadius * 1.06 * ringExpand, ry: baseRadius * 0.36 * ringExpand, tilt: 0.52, rotSpeed: 0.88, rgb: primaryRgb, width: 1.75, dash: [12, 6, 4, 6] },
                { rx: baseRadius * 0.95 * ringExpand, ry: baseRadius * 0.34 * ringExpand, tilt: -0.52, rotSpeed: -1.12, rgb: secondaryRgb, width: 1.5, dash: [10, 6] },
                { rx: baseRadius * 0.82 * ringExpand, ry: baseRadius * 0.3 * ringExpand, tilt: 1.57, rotSpeed: 0.95, rgb: isListening ? listenRgb : primaryRgb, width: 1.3, dash: [8, 8] },
              ]
            : [
                { rx: baseRadius * 1.07 * ringExpand, ry: baseRadius * 0.48 * ringExpand, tilt: 0.32, rotSpeed: 0.62, rgb: primaryRgb, width: 1.5, dash: [] },
                { rx: baseRadius * 0.94 * ringExpand, ry: baseRadius * 0.42 * ringExpand, tilt: -0.68, rotSpeed: -0.78, rgb: secondaryRgb, width: 1.35, dash: [16, 10] },
                { rx: baseRadius * 0.82 * ringExpand, ry: baseRadius * 0.36 * ringExpand, tilt: 0.95, rotSpeed: 0.9, rgb: isListening ? listenRgb : primaryRgb, width: 1.15, dash: [6, 10] },
              ];

      orbitConfigs.forEach((cfg) => {
        drawTiltedEllipseArc(
          ctx,
          cx - parallaxX * 0.22,
          cy - parallaxY * 0.22,
          cfg.rx,
          cfg.ry,
          cfg.tilt + Math.sin(simTime * 0.4) * 0.05,
          Math.PI,
          Math.PI * 2,
          `rgba(${cfg.rgb}, ${isOffline ? 0.14 : 0.28})`,
          cfg.width,
          cfg.dash
        );
      });

      // 4. Outer Identity Harmonic Ring (preserves each core's distinct signature)
      ctx.save();
      ctx.translate(cx, cy);
      ctx.rotate(simTime * (identityId === 'ULTRON' ? -0.46 : 0.36));
      ctx.strokeStyle = `rgba(${primaryRgb}, ${isOffline ? 0.16 : isThinking ? 0.56 : 0.38})`;
      ctx.lineWidth = identityId === 'ULTRON' ? 1.8 : 1.4;
      ctx.setLineDash(
        identityId === 'ULTRON'
          ? [14, 7, 4, 7]
          : identityId === 'JARVIS'
            ? [24, 10]
            : [32, 12]
      );
      ctx.beginPath();
      ctx.arc(0, 0, baseRadius * 1.14 * ringExpand, 0, Math.PI * 2);
      ctx.stroke();
      ctx.restore();

      // 5. Identity-Specific Central Holographic Energy Core
      ctx.save();
      const sphereGrad = ctx.createRadialGradient(
        cx - coreRadius * 0.24,
        cy - coreRadius * 0.24,
        coreRadius * 0.08,
        cx,
        cy,
        coreRadius
      );
      sphereGrad.addColorStop(0, `rgba(${coreHighlightRgb}, ${isOffline ? 0.32 : 0.92})`);
      sphereGrad.addColorStop(0.48, `rgba(${secondaryRgb}, ${isOffline ? 0.22 : 0.72})`);
      sphereGrad.addColorStop(0.84, `rgba(${primaryRgb}, ${isOffline ? 0.14 : 0.48})`);
      sphereGrad.addColorStop(1, `rgba(${primaryRgb}, ${isOffline ? 0.05 : 0.12})`);

      ctx.fillStyle = sphereGrad;
      ctx.beginPath();
      ctx.arc(cx, cy, coreRadius, 0, Math.PI * 2);
      ctx.fill();

      // Clipped Identity Internal Energy Field
      ctx.beginPath();
      ctx.arc(cx, cy, coreRadius * 0.94, 0, Math.PI * 2);
      ctx.clip();

      if (!isOffline) {
        if (identityId === 'JARVIS') {
          // Analytical precision meridian arcs
          for (let ring = 0; ring < 2; ring += 1) {
            ctx.strokeStyle = `rgba(${coreHighlightRgb}, ${ring === 0 ? 0.52 : 0.32})`;
            ctx.lineWidth = 1.2;
            ctx.beginPath();
            ctx.ellipse(
              cx,
              cy,
              coreRadius * (0.45 + ring * 0.24),
              coreRadius * 0.9,
              simTime * (ring === 0 ? 0.9 : -0.7),
              0,
              Math.PI * 2
            );
            ctx.stroke();
          }
        } else if (identityId === 'ULTRON') {
          // Angular high-tension tactical core bars
          ctx.strokeStyle = `rgba(${coreHighlightRgb}, 0.5)`;
          ctx.lineWidth = 1.4;
          for (let bar = -2; bar <= 2; bar += 1) {
            const offset = bar * (coreRadius * 0.28);
            const pulseX = Math.sin(simTime * 3.4 + bar) * coreRadius * 0.14;
            ctx.beginPath();
            ctx.moveTo(cx - coreRadius * 0.7 + pulseX, cy + offset);
            ctx.lineTo(cx + coreRadius * 0.7 + pulseX, cy + offset);
            ctx.stroke();
          }
        } else {
          // FRIDAY smooth flowing harmonic ribbons
          const waveAmp = coreRadius * (isSpeaking ? 0.24 + rms * 0.16 : 0.14);
          for (let line = 0; line < 2; line += 1) {
            ctx.beginPath();
            ctx.strokeStyle = `rgba(${coreHighlightRgb}, ${line === 0 ? 0.56 : 0.34})`;
            ctx.lineWidth = 1.35;
            const phaseOffset = line * 1.9 + simTime * (line === 0 ? 2.8 : -2.1);
            for (let x = -coreRadius; x <= coreRadius; x += 4) {
              const norm = x / coreRadius;
              const env = Math.sqrt(Math.max(0, 1 - norm * norm));
              const y = Math.sin(norm * 4.0 + phaseOffset) * waveAmp * env;
              if (x === -coreRadius) ctx.moveTo(cx + x, cy + y);
              else ctx.lineTo(cx + x, cy + y);
            }
            ctx.stroke();
          }
        }
      }
      ctx.restore();

      // Core Rim Highlight
      ctx.strokeStyle = `rgba(${coreHighlightRgb}, ${isOffline ? 0.18 : isSpeaking ? 0.85 : 0.52})`;
      ctx.lineWidth = 1.35;
      ctx.beginPath();
      ctx.arc(cx, cy, coreRadius, 0, Math.PI * 2);
      ctx.stroke();

      // 6. Identity Geometric Lattice Signature (JARVIS 3-triangle, ULTRON 4-angular, FRIDAY 4-petal)
      ctx.save();
      ctx.translate(cx, cy);
      ctx.rotate(simTime * (identityId === 'ULTRON' ? 0.48 : -0.45));
      ctx.strokeStyle = `rgba(${secondaryRgb}, ${isOffline ? 0.16 : isThinking ? 0.72 : 0.46})`;
      ctx.lineWidth = identityId === 'ULTRON' ? 1.5 : 1.15;
      const latticeR = coreRadius * 1.44 * ringExpand;

      ctx.beginPath();
      for (let i = 0; i <= nodeCount; i += 1) {
        const theta = (i * Math.PI * 2) / nodeCount;
        const px = Math.cos(theta) * latticeR;
        const py = Math.sin(theta) * latticeR;
        if (i === 0) ctx.moveTo(px, py);
        else ctx.lineTo(px, py);
      }
      ctx.stroke();

      if (identityId === 'FRIDAY') {
        // Secondary rotated counter-diamond creating an 8-point bio-resonance star
        ctx.rotate(Math.PI / 4);
        ctx.strokeStyle = `rgba(${primaryRgb}, ${isOffline ? 0.12 : 0.34})`;
        ctx.beginPath();
        for (let i = 0; i <= nodeCount; i += 1) {
          const theta = (i * Math.PI * 2) / nodeCount;
          const px = Math.cos(theta) * (latticeR * 0.92);
          const py = Math.sin(theta) * (latticeR * 0.92);
          if (i === 0) ctx.moveTo(px, py);
          else ctx.lineTo(px, py);
        }
        ctx.stroke();
      } else if (identityId === 'JARVIS') {
        // Analytical vertex tick spokes for JARVIS
        for (let i = 0; i < nodeCount; i += 1) {
          const theta = (i * Math.PI * 2) / nodeCount;
          ctx.beginPath();
          ctx.moveTo(Math.cos(theta) * coreRadius * 1.05, Math.sin(theta) * coreRadius * 1.05);
          ctx.lineTo(Math.cos(theta) * latticeR, Math.sin(theta) * latticeR);
          ctx.stroke();
        }
      }
      ctx.restore();

      // 7. Front-Plane 3D Rings
      orbitConfigs.forEach((cfg) => {
        drawTiltedEllipseArc(
          ctx,
          cx + parallaxX * 0.22,
          cy + parallaxY * 0.22,
          cfg.rx,
          cfg.ry,
          cfg.tilt + Math.sin(simTime * 0.4) * 0.05,
          0,
          Math.PI,
          `rgba(${cfg.rgb}, ${isOffline ? 0.22 : isThinking || isSpeaking ? 0.88 : 0.68})`,
          cfg.width * 1.15,
          cfg.dash
        );
      });

      // 8. Identity Orbital Nodes with Subtle Energy Trails
      const nodeOrbitA = orbitConfigs[0];
      const nodeOrbitB = orbitConfigs[1];
      const trailSteps = isOffline ? 2 : 6;

      for (let i = 0; i < nodeCount; i += 1) {
        const cfg = i % 2 === 0 ? nodeOrbitA : nodeOrbitB;
        const tilt = cfg.tilt + Math.sin(simTime * 0.4) * 0.05;
        const baseTheta = (i * Math.PI * 2) / nodeCount + simTime * cfg.rotSpeed;

        for (let s = trailSteps; s >= 1; s -= 1) {
          const lagTheta = baseTheta - s * 0.08 * Math.sign(cfg.rotSpeed);
          const lx = Math.cos(lagTheta) * cfg.rx;
          const ly = Math.sin(lagTheta) * cfg.ry;
          const tx = cx + lx * Math.cos(tilt) - ly * Math.sin(tilt);
          const ty = cy + lx * Math.sin(tilt) + ly * Math.cos(tilt);
          const frac = 1 - s / (trailSteps + 1);
          ctx.fillStyle = `rgba(${primaryRgb}, ${(isOffline ? 0.08 : 0.45) * frac * frac})`;
          ctx.beginPath();
          ctx.arc(tx, ty, 2.3 * frac, 0, Math.PI * 2);
          ctx.fill();
        }

        const lx = Math.cos(baseTheta) * cfg.rx;
        const ly = Math.sin(baseTheta) * cfg.ry;
        const nx = cx + lx * Math.cos(tilt) - ly * Math.sin(tilt);
        const ny = cy + lx * Math.sin(tilt) + ly * Math.cos(tilt);
        const isFront = Math.sin(baseTheta) >= 0;
        const nodeR = (isFront ? 3.7 : 2.6) + (isSpeaking ? rms * 1.5 : 0);

        const nodeGlow = ctx.createRadialGradient(nx, ny, 0.5, nx, ny, nodeR * 3.0);
        nodeGlow.addColorStop(0, `rgba(${coreHighlightRgb}, ${isOffline ? 0.25 : 0.92})`);
        nodeGlow.addColorStop(0.45, `rgba(${primaryRgb}, ${isOffline ? 0.12 : 0.52})`);
        nodeGlow.addColorStop(1, 'rgba(5, 6, 8, 0)');
        ctx.fillStyle = nodeGlow;
        ctx.beginPath();
        ctx.arc(nx, ny, nodeR * 3.0, 0, Math.PI * 2);
        ctx.fill();

        ctx.fillStyle = isOffline
          ? `rgba(${primaryRgb}, 0.5)`
          : isFront
            ? `rgba(${coreHighlightRgb}, 0.98)`
            : `rgba(${secondaryRgb}, 0.84)`;
        ctx.beginPath();
        ctx.arc(nx, ny, nodeR, 0, Math.PI * 2);
        ctx.fill();
      }

      // 9. Audio-Reactive Radial Harmonic Filaments (LISTENING & SPEAKING)
      if (isListening || isSpeaking) {
        const filaments = 32;
        const ringBaseR = baseRadius * 1.22;
        ctx.save();
        ctx.lineCap = 'round';
        ctx.lineWidth = 1.9;
        for (let i = 0; i < filaments; i += 1) {
          const theta = (i * Math.PI * 2) / filaments + simTime * 0.45;
          const harmonic = 0.4 + 0.6 * Math.abs(Math.sin(simTime * 4.6 + i * 0.65));
          const amp = (4 + 15 * Math.max(0.18, rms)) * harmonic;
          ctx.strokeStyle = isListening
            ? `rgba(${listenRgb}, ${0.38 + 0.42 * harmonic})`
            : `rgba(${secondaryRgb}, ${0.42 + 0.45 * harmonic})`;
          ctx.beginPath();
          ctx.moveTo(cx + Math.cos(theta) * ringBaseR, cy + Math.sin(theta) * ringBaseR);
          ctx.lineTo(cx + Math.cos(theta) * (ringBaseR + amp), cy + Math.sin(theta) * (ringBaseR + amp));
          ctx.stroke();
        }
        ctx.restore();
      }

      // 10. Floating 3D Energy Particles in Open Space
      const particles = particlesRef.current;
      for (let i = 0; i < particles.length; i += 1) {
        const pt = particles[i];
        const theta = pt.angle + simTime * pt.speed;
        const pull =
          currentState === 'ACTIVATING'
            ? 1.5 - 0.5 * activationProgress
            : isThinking
              ? 0.84
              : isSpeaking
                ? 1.06 + rms * 0.14
                : 1.0;

        const r = minDim * 0.47 * pt.orbitRadiusFactor * pull;
        const pxLocal = Math.cos(theta) * r;
        const pzDepth = Math.sin(theta);
        const pyLocal =
          Math.sin(theta + pt.tilt) * r * 0.36 +
          Math.sin(simTime * 1.3 + pt.verticalPhase) * pt.verticalAmp;

        const px = cx + pxLocal + parallaxX * (0.35 + pzDepth * 0.25);
        const py = cy + pyLocal + parallaxY * (0.35 + pzDepth * 0.25);
        const depthScale = 0.68 + (pzDepth + 1) * 0.32;
        const twinkle = 0.6 + 0.4 * Math.sin(simTime * 2.8 + pt.verticalPhase);
        const alpha =
          pt.baseAlpha *
          twinkle *
          (isOffline ? 0.2 : pendingCountRef.current > 0 ? 1.0 : 0.85) *
          (0.55 + (pzDepth + 1) * 0.225);

        ctx.fillStyle =
          i % 5 === 0 && isListening
            ? `rgba(${listenRgb}, ${Math.min(1, alpha)})`
            : i % 3 === 0
              ? `rgba(${coreHighlightRgb}, ${Math.min(1, alpha)})`
              : `rgba(${secondaryRgb}, ${Math.min(1, alpha)})`;
        ctx.beginPath();
        ctx.arc(px, py, pt.size * depthScale, 0, Math.PI * 2);
        ctx.fill();
      }

      ctx.restore();
      frameId = requestAnimationFrame(renderFrame);
    };

    const handleVisibility = () => {
      isHidden = document.hidden;
      if (!isHidden && !isDisposed) {
        lastDrawTime = performance.now();
        frameId = requestAnimationFrame(renderFrame);
      }
    };

    document.addEventListener('visibilitychange', handleVisibility);
    frameId = requestAnimationFrame(renderFrame);

    return () => {
      isDisposed = true;
      document.removeEventListener('visibilitychange', handleVisibility);
      cancelAnimationFrame(frameId);
    };
  }, [
    activeIdentity.id,
    activeIdentity.isEnabled,
    activeIdentity.visualIdentity.primaryColor,
    activeIdentity.visualIdentity.secondaryColor,
    activeIdentity.visualIdentity.orbitalNodes,
  ]);

  const statusLabel = (() => {
    switch (computedVisualState) {
      case 'OFFLINE':
        return 'OFFLINE';
      case 'ACTIVATING':
        return 'ACTIVATING';
      case 'LISTENING':
        return 'LISTENING';
      case 'THINKING':
        return isExecuting ? 'EXECUTING' : 'THINKING';
      case 'SPEAKING':
        return 'SPEAKING';
      default:
        return activeIdentity.status || 'IDLE';
    }
  })();

  const hasNonIdleActivity =
    activeIdentity.metrics &&
    (activeIdentity.metrics.activeTaskCount > 0 ||
      activeIdentity.metrics.pendingTaskCount > 0 ||
      activeIdentity.metrics.currentActivity !== 'Idle' ||
      Boolean(activeIdentity.metrics.recentError));

  return (
    <div
      className="relative w-full flex flex-col items-center justify-center py-1 select-none"
      onPointerMove={(e) => {
        const rect = e.currentTarget.getBoundingClientRect();
        if (rect.width <= 0 || rect.height <= 0) return;
        const nx = ((e.clientX - rect.left) / rect.width - 0.5) * 2;
        const ny = ((e.clientY - rect.top) / rect.height - 0.5) * 2;
        pointerOffsetRef.current.targetX = Math.max(-1, Math.min(1, nx));
        pointerOffsetRef.current.targetY = Math.max(-1, Math.min(1, ny));
      }}
      onPointerLeave={() => {
        pointerOffsetRef.current.targetX = 0;
        pointerOffsetRef.current.targetY = 0;
      }}
    >
      {/* Borderless Open-Space Floating Core Canvas Stage */}
      <div
        ref={stageRef}
        className="relative w-full max-w-[440px] h-[clamp(235px,36vh,340px)] flex items-center justify-center overflow-visible"
      >
        <canvas
          ref={canvasRef}
          className="w-full h-full pointer-events-none"
          aria-label={`${activeIdentity.displayName} Open Floating Holographic Core (${statusLabel})`}
        />

        {/* Unboxed Centered Core Identity Overlay */}
        <div className="absolute inset-0 flex flex-col items-center justify-center text-center pointer-events-none px-4">
          <span
            className="font-mono text-[9px] tracking-[0.22em] uppercase drop-shadow-[0_1px_4px_rgba(0,0,0,0.95)]"
            style={{ color: activeIdentity.isEnabled ? activeIdentity.visualIdentity.secondaryColor : '#94A3B8' }}
          >
            {statusLabel}
          </span>
          <span className="font-display text-lg sm:text-xl font-bold tracking-wider text-white mt-0.5 drop-shadow-[0_2px_10px_rgba(0,0,0,0.95)]">
            {activeIdentity.displayName}
          </span>
          <span
            className="font-mono text-[10px] tracking-widest mt-0.5 drop-shadow-[0_1px_6px_rgba(0,0,0,0.95)]"
            style={{ color: activeIdentity.isEnabled ? activeIdentity.visualIdentity.primaryColor : '#64748B' }}
          >
            {activeIdentity.visualIdentity.emblemLabel}
          </span>
        </div>
      </div>

      {/* Minimal Unboxed Floating HUD Footer */}
      <div className="w-full flex flex-wrap items-center justify-between gap-2 px-1 pt-1 text-[11px] font-mono">
        <span className="text-slate-400 truncate max-w-[65%]">
          {hasNonIdleActivity
            ? activeIdentity.metrics.recentError || activeIdentity.metrics.currentActivity
            : `${activeIdentity.displayName} Core · ${statusLabel} · SK Supervised`}
        </span>
        <div className="flex items-center gap-3 shrink-0">
          {onCheckStatus && (
            <button
              type="button"
              onClick={onCheckStatus}
              className="hover:text-white transition-colors whitespace-nowrap"
              style={{ color: activeIdentity.visualIdentity.secondaryColor }}
            >
              Status
            </button>
          )}
          {onReturnToSk && (
            <button
              type="button"
              onClick={onReturnToSk}
              className="text-amber-300/90 hover:text-amber-200 transition-colors whitespace-nowrap"
            >
              SK Master
            </button>
          )}
        </div>
      </div>
    </div>
  );
}
