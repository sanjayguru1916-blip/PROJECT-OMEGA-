import { useEffect, useState } from 'react';
import { Check, Copy, Download, FileCode2, FolderTree, Terminal } from 'lucide-react';
import { AndroidFileMeta } from '../types/omega';

export function AndroidProjectExplorer() {
  const [files, setFiles] = useState<AndroidFileMeta[]>([]);
  const [selectedPath, setSelectedPath] = useState<string>(
    'app/src/main/java/com/projectomega/sk/sk/router/SkMasterCore.kt'
  );
  const [content, setContent] = useState<string>('');
  const [loading, setLoading] = useState<boolean>(true);
  const [copied, setCopied] = useState<boolean>(false);
  const [categoryFilter, setCategoryFilter] = useState<string>('All');

  useEffect(() => {
    fetch('/api/android/files')
      .then((r) => r.json())
      .then((data: { files: AndroidFileMeta[] }) => {
        setFiles(data.files ?? []);
        if (data.files?.length && !data.files.some((f) => f.path === selectedPath)) {
          setSelectedPath(data.files[0].path);
        }
      })
      .finally(() => setLoading(false));
  }, []);

  useEffect(() => {
    if (!selectedPath) return;
    fetch(`/api/android/file?path=${encodeURIComponent(selectedPath)}`)
      .then((r) => r.json())
      .then((data: { content?: string; error?: string }) => {
        setContent(data.content ?? data.error ?? '');
      });
  }, [selectedPath]);

  const categories = ['All', 'SK Master Core', 'Assistant Modules', 'Core Architecture', 'Compose UI & DI', 'Gradle Build', 'Manifest & Docs'];
  const filteredFiles = categoryFilter === 'All'
    ? files
    : files.filter((f) => f.category === categoryFilter);

  const handleCopy = async () => {
    await navigator.clipboard.writeText(content);
    setCopied(true);
    setTimeout(() => setCopied(false), 1800);
  };

  return (
    <div className="space-y-6">
      <div className="flex flex-col lg:flex-row lg:items-center lg:justify-between gap-4 border-b border-white/10 pb-5">
        <div>
          <h2 className="font-display text-xl font-semibold text-white">
            Android Kotlin Project & APK Build Specification
          </h2>
          <p className="text-sm text-slate-400 mt-1">
            Complete Clean Architecture + MVVM Jetpack Compose codebase under com.projectomega.sk with Room, DataStore, WorkManager, and Retrofit proxy.
          </p>
        </div>
        <a
          href="/api/android/download"
          className="inline-flex items-center gap-2 px-4 py-2 text-sm font-medium bg-sky-400 text-slate-950 rounded-lg hover:bg-sky-300 transition-colors whitespace-nowrap shrink-0"
        >
          <Download className="w-4 h-4" />
          Download Android Project (.zip)
        </a>
      </div>

      {/* APK Build & Integration Instructions */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
        <div className="bg-[#111827] border border-white/10 rounded-xl p-4">
          <div className="flex items-center gap-2 text-xs font-mono text-sky-400 mb-2">
            <Terminal className="w-3.5 h-3.5" />
            <span>01. Configure Backend Proxy</span>
          </div>
          <p className="text-sm text-slate-300 leading-relaxed">
            Set <code className="font-mono text-xs text-sky-300">OMEGA_BACKEND_URL</code> in <code className="font-mono text-xs text-slate-200">local.properties</code> to <code className="font-mono text-xs text-slate-200">http://10.0.2.2:3000</code> for Emulator or your Cloud Run HTTPS URL. Zero API keys live in client source.
          </p>
        </div>

        <div className="bg-[#111827] border border-white/10 rounded-xl p-4">
          <div className="flex items-center gap-2 text-xs font-mono text-sky-400 mb-2">
            <FolderTree className="w-3.5 h-3.5" />
            <span>02. Sync Gradle & KSP</span>
          </div>
          <p className="text-sm text-slate-300 leading-relaxed">
            Open the extracted <code className="font-mono text-xs text-slate-200">ProjectOmegaSK/</code> folder in Android Studio Ladybug (JDK 17, compileSdk 35, minSdk 26) and sync <code className="font-mono text-xs text-slate-200">libs.versions.toml</code>.
          </p>
        </div>

        <div className="bg-[#111827] border border-white/10 rounded-xl p-4">
          <div className="flex items-center gap-2 text-xs font-mono text-sky-400 mb-2">
            <FileCode2 className="w-3.5 h-3.5" />
            <span>03. Build Installable APK</span>
          </div>
          <p className="text-sm text-slate-300 leading-relaxed">
            Run <code className="font-mono text-xs text-sky-300">./gradlew :app:assembleDebug</code> to produce <code className="font-mono text-xs text-slate-200">app-debug.apk</code>, or configure release signing for <code className="font-mono text-xs text-slate-200">assembleRelease</code>.
          </p>
        </div>
      </div>

      {/* Category Filter */}
      <div className="flex flex-wrap items-center gap-1 p-1 bg-[#111827] border border-white/10 rounded-lg w-fit">
        {categories.map((cat) => (
          <button
            key={cat}
            onClick={() => setCategoryFilter(cat)}
            className={`px-3 py-1.5 text-xs font-medium rounded-md transition-colors whitespace-nowrap shrink-0 ${
              categoryFilter === cat
                ? 'bg-sky-400/15 text-sky-300'
                : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            {cat}
          </button>
        ))}
      </div>

      {/* Split Source Browser */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-4 items-stretch">
        <div className="lg:col-span-4 bg-[#111827] border border-white/10 rounded-xl overflow-hidden flex flex-col max-h-[640px]">
          <div className="px-4 py-3 border-b border-white/10 flex items-center justify-between text-xs text-slate-400">
            <span className="font-medium text-slate-200">Source Files</span>
            <span className="font-mono tabular-nums">{filteredFiles.length} files</span>
          </div>
          <div className="overflow-y-auto divide-y divide-white/5">
            {loading ? (
              <div className="p-4 text-xs text-slate-400">Loading Android project tree...</div>
            ) : (
              filteredFiles.map((file) => {
                const active = file.path === selectedPath;
                const fileName = file.path.split('/').pop();
                return (
                  <button
                    key={file.path}
                    onClick={() => setSelectedPath(file.path)}
                    className={`w-full text-left px-4 py-2.5 transition-colors ${
                      active ? 'bg-sky-400/10' : 'hover:bg-white/5'
                    }`}
                  >
                    <div className={`text-xs font-mono truncate ${active ? 'text-sky-300 font-medium' : 'text-slate-200'}`}>
                      {fileName}
                    </div>
                    <div className="text-[11px] text-slate-500 truncate mt-0.5 font-mono">
                      {file.category} · {(file.size / 1024).toFixed(1)} KB
                    </div>
                  </button>
                );
              })
            )}
          </div>
        </div>

        <div className="lg:col-span-8 bg-[#0D131F] border border-white/10 rounded-xl overflow-hidden flex flex-col max-h-[640px]">
          <div className="px-4 py-3 border-b border-white/10 flex items-center justify-between gap-4 bg-[#111827]">
            <span className="font-mono text-xs text-slate-300 truncate">{selectedPath}</span>
            <button
              onClick={handleCopy}
              className="inline-flex items-center gap-1.5 px-3 py-1 text-xs font-medium text-slate-200 bg-white/5 hover:bg-white/10 rounded-md transition-colors whitespace-nowrap shrink-0"
            >
              {copied ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
              {copied ? 'Copied' : 'Copy'}
            </button>
          </div>
          <pre className="p-4 overflow-auto text-xs leading-relaxed font-mono text-slate-200 flex-1">
            <code>{content}</code>
          </pre>
        </div>
      </div>
    </div>
  );
}
