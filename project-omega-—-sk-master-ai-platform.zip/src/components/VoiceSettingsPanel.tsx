import { useEffect, useState } from 'react';
import { Mic, MicOff, Play, RotateCcw, Square, Volume2, VolumeX } from 'lucide-react';
import {
  AssistantId,
  AssistantRegistryEntry,
  BrowserMicPermissionState,
  VoiceProviderMode,
  VoiceState,
} from '../types/omega';

interface VoiceSettingsPanelProps {
  registry: Record<AssistantId, AssistantRegistryEntry>;
  voiceEnabled: boolean;
  voiceProviderMode: VoiceProviderMode;
  voiceState: VoiceState;
  micPermissionState: BrowserMicPermissionState;
  permissionsApiSupported: boolean;
  speechRecognitionSupported: boolean;
  isMicRequesting: boolean;
  speakingAssistant: AssistantId | null;
  recognizedCommand: string | null;
  voiceDiagnostics: string | null;
  browserVoices: Array<{ name: string; lang: string; localService: boolean }>;
  onToggleVoiceEnabled: (enabled: boolean) => void;
  onChangeProviderMode: (mode: VoiceProviderMode) => void;
  onUpdateVoiceTuning: (id: AssistantId, pitch: number, speechRate: number) => Promise<void>;
  onPreviewVoice: (id: AssistantId) => void;
  onStopSpeaking: () => void;
  onToggleMicrophone: () => void;
  onRetryMicrophone: () => void;
}

const ASSISTANT_ORDER: AssistantId[] = ['SK', 'JARVIS', 'MAGMITE', 'ULTRON', 'FRIDAY'];

const PREVIEW_SCRIPTS: Record<AssistantId, string> = {
  SK: 'SK Master Controller online. All four assistant cores stand ready for supervised task authorization.',
  JARVIS: 'Good evening. JARVIS reasoning module is calibrated for structured analysis and knowledge synthesis.',
  MAGMITE: 'MAGMITE hardware control core active. Device sensors, audio streams, and connectivity await your approval.',
  ULTRON: 'ULTRON diagnostic engine operational. Deep system telemetry and fault detection protocols engaged.',
  FRIDAY: 'Hi there, FRIDAY scheduling core is ready. Let me know whenever you need a reminder or timeline plan.',
};

export function VoiceSettingsPanel({
  registry,
  voiceEnabled,
  voiceProviderMode,
  voiceState,
  micPermissionState,
  permissionsApiSupported,
  speechRecognitionSupported,
  isMicRequesting,
  speakingAssistant,
  recognizedCommand,
  voiceDiagnostics,
  browserVoices,
  onToggleVoiceEnabled,
  onChangeProviderMode,
  onUpdateVoiceTuning,
  onPreviewVoice,
  onStopSpeaking,
  onToggleMicrophone,
  onRetryMicrophone,
}: VoiceSettingsPanelProps) {
  const [selectedId, setSelectedId] = useState<AssistantId>('SK');
  const selected = registry[selectedId];

  const [pitch, setPitch] = useState<number>(selected.voiceConfig.pitch);
  const [speechRate, setSpeechRate] = useState<number>(selected.voiceConfig.speechRate);
  const [saving, setSaving] = useState(false);

  useEffect(() => {
    setPitch(selected.voiceConfig.pitch);
    setSpeechRate(selected.voiceConfig.speechRate);
  }, [selectedId, selected.voiceConfig.pitch, selected.voiceConfig.speechRate]);

  const handleSaveTuning = async () => {
    setSaving(true);
    try {
      await onUpdateVoiceTuning(selectedId, pitch, speechRate);
    } finally {
      setSaving(false);
    }
  };

  return (
    <div className="space-y-8">
      <div className="border-b border-white/10 pb-5 flex flex-wrap items-start justify-between gap-4">
        <div>
          <h2 className="font-display text-xl font-semibold text-white">
            Voice Control & Five-Core Voice Identities
          </h2>
          <p className="text-sm text-slate-400 mt-1">
            Configure distinct male and female voice profiles for SK, JARVIS, MAGMITE, ULTRON, and FRIDAY, tune pitch and speaking rate, and test speech recognition.
          </p>
        </div>

        <div className="flex items-center gap-3">
          <button
            type="button"
            onClick={() => onToggleVoiceEnabled(!voiceEnabled)}
            className={`inline-flex items-center gap-2 px-4 py-2 text-xs font-medium rounded-lg border transition-colors whitespace-nowrap shrink-0 ${
              voiceEnabled
                ? 'bg-amber-500/15 border-amber-400 text-amber-200'
                : 'bg-[#0D1017] border-white/10 text-slate-400 hover:text-white'
            }`}
          >
            {voiceEnabled ? <Volume2 className="w-4 h-4" /> : <VolumeX className="w-4 h-4" />}
            {voiceEnabled ? 'Voice System Enabled' : 'Voice System Muted'}
          </button>

          {voiceState === 'SPEAKING' && (
            <button
              type="button"
              onClick={onStopSpeaking}
              className="inline-flex items-center gap-1.5 px-3.5 py-2 text-xs font-medium bg-red-500/20 border border-red-400 text-red-200 rounded-lg hover:bg-red-500/30 transition-colors whitespace-nowrap shrink-0"
            >
              <Square className="w-3.5 h-3.5" />
              SK Stop
            </button>
          )}
        </div>
      </div>

      {/* Voice Engine & Live Microphone Recognition Test */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        <div className="lg:col-span-5 bg-[#0D1017] border border-white/10 rounded-xl p-5 space-y-4">
          <h3 className="font-display text-base font-semibold text-white">
            Synthesis Engine & Mic Verification
          </h3>

          <div className="space-y-2">
            <label className="block text-xs text-slate-400">Active TTS Voice Provider</label>
            <div className="grid grid-cols-1 gap-2">
              <button
                type="button"
                onClick={() => onChangeProviderMode('NEURAL_GEMINI_TTS')}
                className={`text-left p-3 rounded-lg border transition-colors ${
                  voiceProviderMode === 'NEURAL_GEMINI_TTS'
                    ? 'bg-amber-500/15 border-amber-400 text-white'
                    : 'bg-[#050608] border-white/10 text-slate-300 hover:border-white/25'
                }`}
              >
                <div className="text-xs font-semibold">Neural Server TTS (Recommended · 5 Distinct Voices)</div>
                <div className="text-[11px] text-slate-400 mt-0.5">
                  Uses server-side Gemini 3.8 Neural Audio profiles (Fenrir, Puck, Kore, Charon, Zephyr) with zero exposed keys.
                </div>
              </button>

              <button
                type="button"
                onClick={() => onChangeProviderMode('BROWSER_SYSTEM_TTS')}
                className={`text-left p-3 rounded-lg border transition-colors ${
                  voiceProviderMode === 'BROWSER_SYSTEM_TTS'
                    ? 'bg-sky-500/15 border-sky-400 text-white'
                    : 'bg-[#050608] border-white/10 text-slate-300 hover:border-white/25'
                }`}
              >
                <div className="text-xs font-semibold">Browser Local System TTS</div>
                <div className="text-[11px] text-slate-400 mt-0.5">
                  Uses OS SpeechSynthesis voices ({browserVoices.length} installed locally) with per-assistant pitch and speed.
                </div>
              </button>
            </div>
          </div>

          <div className="border-t border-white/10 pt-4 space-y-3">
            <div className="flex items-center justify-between gap-2">
              <span className="text-xs text-slate-400">Browser Microphone & Recognition</span>
              <span
                className={`text-xs font-mono ${
                  voiceState === 'ERROR' || voiceState === 'PERMISSION_REQUIRED' || micPermissionState === 'denied' || micPermissionState === 'unavailable'
                    ? 'text-red-300'
                    : voiceState === 'LISTENING'
                      ? 'text-sky-300'
                      : micPermissionState === 'granted'
                        ? 'text-emerald-300'
                        : 'text-amber-300'
                }`}
              >
                {isMicRequesting && voiceState !== 'LISTENING'
                  ? 'Requesting Access...'
                  : `State: ${voiceState.replace('_', ' ')} · Mic: ${micPermissionState}`}
              </span>
            </div>

            <div className="flex flex-wrap items-center justify-between gap-2 text-[11px] font-mono text-slate-400 bg-[#050608] border border-white/10 rounded-lg px-3 py-2">
              <span>
                Permissions API: {permissionsApiSupported ? 'Supported' : 'Fallback (direct getUserMedia)'}
              </span>
              <span>
                Speech API: {speechRecognitionSupported ? 'Available' : 'Unsupported'}
              </span>
            </div>

            <div className="flex gap-2">
              <button
                type="button"
                onClick={onToggleMicrophone}
                disabled={isMicRequesting && voiceState !== 'LISTENING'}
                className={`flex-1 inline-flex items-center justify-center gap-2 px-4 py-2.5 text-sm font-medium rounded-lg border transition-colors disabled:opacity-60 ${
                  voiceState === 'LISTENING'
                    ? 'bg-red-500/20 border-red-400 text-red-200'
                    : 'bg-amber-400 text-slate-950 border-amber-300 hover:bg-amber-300'
                }`}
              >
                {voiceState === 'LISTENING' ? (
                  <>
                    <MicOff className="w-4 h-4" />
                    Stop Listening Test
                  </>
                ) : isMicRequesting ? (
                  <>
                    <Mic className="w-4 h-4 animate-pulse" />
                    Requesting Browser Microphone...
                  </>
                ) : (
                  <>
                    <Mic className="w-4 h-4" />
                    Test Voice Recognition
                  </>
                )}
              </button>

              {(micPermissionState === 'denied' || micPermissionState === 'unavailable' || voiceState === 'PERMISSION_REQUIRED' || voiceState === 'ERROR') && (
                <button
                  type="button"
                  onClick={onRetryMicrophone}
                  disabled={isMicRequesting}
                  className="inline-flex items-center gap-1.5 px-3.5 py-2.5 text-xs font-medium bg-white/10 hover:bg-white/15 text-amber-200 border border-amber-400/40 rounded-lg disabled:opacity-50 transition-colors whitespace-nowrap shrink-0"
                >
                  <RotateCcw className="w-3.5 h-3.5" />
                  Retry
                </button>
              )}
            </div>

            {(micPermissionState === 'denied' || voiceState === 'PERMISSION_REQUIRED') && (
              <div className="text-xs bg-red-950/40 border border-red-500/35 rounded-lg p-3 space-y-1.5 text-red-100">
                <div className="font-semibold text-red-200">Browser Microphone Permission Blocked</div>
                <ol className="list-decimal list-inside space-y-0.5 text-red-200/90">
                  <li>Click the lock or site-settings icon in your browser&apos;s address bar.</li>
                  <li>Set <strong>Microphone</strong> to <strong>Allow</strong> for this Google AI Studio preview origin.</li>
                  <li>Click <strong>Retry</strong> above to re-request audio capture and initialize recognition.</li>
                </ol>
              </div>
            )}

            <div className="bg-[#050608] border border-white/10 rounded-lg p-3 text-xs space-y-1">
              <div className="text-slate-500 font-mono">Last Recognized Speech</div>
              <div className="text-slate-200">
                {recognizedCommand ?? 'Tap Test Voice Recognition and say "SK ASSEMBLE ALL", "What about JARVIS?", or "Hey SK, how are you?".'}
              </div>
            </div>

            {voiceDiagnostics && (
              <div
                className={`text-xs font-mono rounded-lg px-3 py-2 border ${
                  voiceState === 'ERROR' || voiceState === 'PERMISSION_REQUIRED'
                    ? 'text-red-200 bg-red-500/10 border-red-500/30'
                    : 'text-amber-300 bg-amber-500/10 border-amber-500/25'
                }`}
              >
                {voiceDiagnostics}
              </div>
            )}
          </div>
        </div>

        {/* Five Assistant Voice Selector & Tuning */}
        <div className="lg:col-span-7 bg-[#0D1017] border border-white/10 rounded-xl p-5 space-y-5">
          <div className="space-y-2">
            <div className="text-xs text-slate-400">Select AI Assistant Voice Profile</div>
            <div className="grid grid-cols-5 gap-2">
              {ASSISTANT_ORDER.map((id) => {
                const entry = registry[id];
                const isSelected = selectedId === id;
                const isSpeaking = speakingAssistant === id;
                return (
                  <button
                    key={id}
                    type="button"
                    onClick={() => setSelectedId(id)}
                    className={`p-2.5 rounded-lg border text-left transition-colors ${
                      isSelected
                        ? 'bg-white/10 border-amber-400 text-white'
                        : 'bg-[#050608] border-white/10 text-slate-300 hover:border-white/25'
                    }`}
                  >
                    <div className="text-xs font-semibold truncate">{entry.displayName}</div>
                    <div
                      className="text-[10px] font-mono mt-0.5 truncate"
                      style={{ color: entry.visualIdentity.primaryColor }}
                    >
                      {isSpeaking ? 'SPEAKING' : entry.voiceConfig.gender}
                    </div>
                  </button>
                );
              })}
            </div>
          </div>

          <div className="bg-[#050608] border border-white/10 rounded-xl p-4 space-y-4">
            <div className="flex flex-wrap items-start justify-between gap-3">
              <div>
                <div className="text-xs font-mono" style={{ color: selected.visualIdentity.primaryColor }}>
                  {selected.displayName} · {selected.voiceConfig.gender} · Neural Voice: {selected.voiceConfig.neuralVoiceName} · Locale: {selected.voiceConfig.localeTag}
                </div>
                <h4 className="font-display text-base font-semibold text-white mt-0.5">
                  {selected.voiceConfig.voiceTone}
                </h4>
              </div>

              <button
                type="button"
                onClick={() => onPreviewVoice(selectedId)}
                disabled={!voiceEnabled}
                className="inline-flex items-center gap-1.5 px-3.5 py-2 text-xs font-medium bg-amber-400 text-slate-950 rounded-lg hover:bg-amber-300 disabled:opacity-40 transition-colors whitespace-nowrap shrink-0"
              >
                <Play className="w-3.5 h-3.5" />
                Preview {selectedId} Voice
              </button>
            </div>

            <div className="text-xs text-slate-300">
              Style Direction: <span className="text-slate-400">{selected.voiceConfig.stylePrompt}</span>
            </div>

            <div className="text-xs text-slate-400 italic">
              Sample utterance: "{PREVIEW_SCRIPTS[selectedId]}"
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-5 pt-2 border-t border-white/10">
              <div className="space-y-1.5">
                <div className="flex justify-between text-xs font-mono">
                  <span className="text-slate-400">Pitch Calibration</span>
                  <span className="text-amber-300 tabular-nums">{pitch.toFixed(2)}</span>
                </div>
                <input
                  type="range"
                  min={0.5}
                  max={1.6}
                  step={0.02}
                  value={pitch}
                  onChange={(e) => setPitch(Number(e.target.value))}
                  className="w-full accent-amber-400"
                />
              </div>

              <div className="space-y-1.5">
                <div className="flex justify-between text-xs font-mono">
                  <span className="text-slate-400">Speaking Speed</span>
                  <span className="text-amber-300 tabular-nums">{speechRate.toFixed(2)}x</span>
                </div>
                <input
                  type="range"
                  min={0.5}
                  max={1.6}
                  step={0.02}
                  value={speechRate}
                  onChange={(e) => setSpeechRate(Number(e.target.value))}
                  className="w-full accent-amber-400"
                />
              </div>
            </div>

            <div className="flex items-center justify-between pt-1">
              <span className="text-[11px] font-mono text-slate-500">
                Changes persist on the server and apply to both Web HUD and Android clients.
              </span>
              <button
                type="button"
                onClick={handleSaveTuning}
                disabled={saving}
                className="px-3.5 py-1.5 text-xs font-medium bg-white/10 hover:bg-white/15 text-white rounded-lg transition-colors whitespace-nowrap shrink-0"
              >
                {saving ? 'Saving...' : 'Save Voice Tuning'}
              </button>
            </div>
          </div>
        </div>
      </div>

      {/* Diagnostic Overview of All 5 Identities + Browser Voice Inventory */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <div className="bg-[#0D1017] border border-white/10 rounded-xl p-5 space-y-3">
          <h3 className="font-display text-base font-semibold text-white">
            Five-Core Voice Differentiation Matrix
          </h3>
          <div className="divide-y divide-white/10">
            {ASSISTANT_ORDER.map((id) => {
              const entry = registry[id];
              return (
                <div key={id} className="py-2.5 first:pt-0 last:pb-0 flex items-center justify-between gap-4 text-xs">
                  <div>
                    <span className="font-semibold text-white">{entry.displayName}</span>
                    <span className="text-slate-400"> · {entry.voiceConfig.gender} · {entry.voiceConfig.voiceTone}</span>
                  </div>
                  <span className="font-mono text-slate-400 shrink-0 tabular-nums">
                    {entry.voiceConfig.neuralVoiceName} · {entry.voiceConfig.localeTag} · P{entry.voiceConfig.pitch.toFixed(2)} · {entry.voiceConfig.speechRate.toFixed(2)}x
                  </span>
                </div>
              );
            })}
          </div>
        </div>

        <div className="bg-[#0D1017] border border-white/10 rounded-xl p-5 space-y-3">
          <div className="flex items-center justify-between">
            <h3 className="font-display text-base font-semibold text-white">
              Local Browser SpeechSynthesis Voices
            </h3>
            <span className="text-xs font-mono text-slate-400 tabular-nums">
              {browserVoices.length} detected
            </span>
          </div>
          {browserVoices.length === 0 ? (
            <p className="text-xs text-slate-400">
              No local OS speech synthesis voices were enumerated by this browser engine. Neural Server TTS remains recommended for 5 distinct voices.
            </p>
          ) : (
            <div className="max-h-44 overflow-y-auto divide-y divide-white/10 pr-1">
              {browserVoices.slice(0, 24).map((v) => (
                <div key={`${v.name}-${v.lang}`} className="py-1.5 flex items-center justify-between gap-2 text-xs">
                  <span className="text-slate-200 truncate">{v.name}</span>
                  <span className="font-mono text-slate-500 shrink-0">
                    {v.lang} · {v.localService ? 'Local' : 'Cloud'}
                  </span>
                </div>
              ))}
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
