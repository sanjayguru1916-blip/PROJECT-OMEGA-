import { Mic, MicOff, RotateCcw, Send, Square } from 'lucide-react';
import { AssistantId, BrowserMicPermissionState, VoiceState } from '../types/omega';

interface CompactCommandBarProps {
  commandInput: string;
  onChangeInput: (value: string) => void;
  onSubmit: () => void;
  voiceState: VoiceState;
  micPermissionState: BrowserMicPermissionState;
  isMicRequesting: boolean;
  voiceRmsLevel: number;
  recognizedCommand: string | null;
  speechError: string | null;
  isRouting: boolean;
  speakingAssistant: AssistantId | null;
  onToggleMicrophone: () => void;
  onRetryMicrophone: () => void;
  onStopSpeaking: () => void;
}

const WAVE_HEIGHTS = [0.42, 0.78, 1.0, 0.65, 0.9, 0.55, 0.38];

export function CompactCommandBar({
  commandInput,
  onChangeInput,
  onSubmit,
  voiceState,
  micPermissionState,
  isMicRequesting,
  voiceRmsLevel,
  recognizedCommand,
  speechError,
  isRouting,
  speakingAssistant,
  onToggleMicrophone,
  onRetryMicrophone,
  onStopSpeaking,
}: CompactCommandBarProps) {
  const isListening = voiceState === 'LISTENING';
  const isSpeaking = voiceState === 'SPEAKING';
  const isBlocked =
    micPermissionState === 'denied' ||
    micPermissionState === 'unavailable' ||
    voiceState === 'PERMISSION_REQUIRED';
  const hasVoiceIssue = isBlocked || voiceState === 'ERROR' || Boolean(speechError);

  const statusLabel = (() => {
    if (isMicRequesting && !isListening) return 'Requesting mic';
    switch (voiceState) {
      case 'LISTENING':
        return 'Listening';
      case 'PROCESSING':
        return 'Processing';
      case 'RESPONDING':
        return 'Responding';
      case 'SPEAKING':
        return speakingAssistant ? `Speaking · ${speakingAssistant}` : 'Speaking';
      case 'PERMISSION_REQUIRED':
        return 'Permission required';
      case 'ERROR':
        return 'Mic error';
      default:
        return micPermissionState === 'granted' ? 'Mic ready' : micPermissionState === 'denied' ? 'Mic blocked' : 'Idle';
    }
  })();

  const statusTone =
    voiceState === 'LISTENING'
      ? 'text-sky-300'
      : voiceState === 'PROCESSING' || voiceState === 'RESPONDING' || isMicRequesting
        ? 'text-amber-300'
        : voiceState === 'SPEAKING'
          ? 'text-amber-400'
          : hasVoiceIssue
            ? 'text-red-300'
            : 'text-slate-400';

  const showWaveform = isListening || isSpeaking;

  return (
    <div className="w-full space-y-2">
      <form
        onSubmit={(e) => {
          e.preventDefault();
          onSubmit();
        }}
        className="bg-[#0D1017] border border-white/10 rounded-xl p-2 sm:p-2.5 space-y-2"
      >
        <div className="flex items-center gap-2">
          {/* Prominent Interactive Microphone Control (min 44x44 touch target) */}
          <button
            type="button"
            onClick={onToggleMicrophone}
            disabled={isMicRequesting && !isListening}
            aria-label={isListening ? 'Stop listening' : 'Start voice control'}
            title={isListening ? 'Tap to stop listening' : 'Tap to speak command'}
            className={`relative w-11 h-11 min-w-[44px] min-h-[44px] rounded-full border inline-flex items-center justify-center transition-colors shrink-0 disabled:opacity-60 ${
              isListening
                ? 'bg-sky-500/20 border-sky-400 text-sky-200 shadow-[0_0_16px_rgba(56,189,248,0.3)]'
                : hasVoiceIssue
                  ? 'bg-red-500/15 border-red-400/60 text-red-200 hover:bg-red-500/25'
                  : 'bg-amber-500/15 border-amber-400/60 text-amber-300 hover:bg-amber-500/25'
            }`}
          >
            {isListening ? (
              <MicOff className="w-4 h-4 animate-pulse" />
            ) : (
              <Mic className={`w-4 h-4 ${isMicRequesting ? 'animate-pulse' : ''}`} />
            )}
          </button>

          {/* Compact Text Command Input */}
          <input
            type="text"
            value={commandInput}
            onChange={(e) => onChangeInput(e.target.value)}
            placeholder="Type a command..."
            aria-label="Command input"
            className="flex-1 min-w-0 h-11 bg-[#050608] border border-white/10 rounded-lg px-3.5 text-sm text-white placeholder:text-slate-500 focus:outline-none focus:border-amber-400"
          />

          {/* Compact Send / Execute Button */}
          <button
            type="submit"
            disabled={isRouting || !commandInput.trim()}
            className="h-11 min-h-[44px] inline-flex items-center justify-center gap-1.5 px-4 text-xs sm:text-sm font-medium bg-amber-400 text-slate-950 rounded-lg hover:bg-amber-300 disabled:opacity-45 transition-colors whitespace-nowrap shrink-0"
          >
            <Send className="w-3.5 h-3.5" />
            <span>{isRouting ? 'Routing' : 'Send'}</span>
          </button>
        </div>

        {/* Compact Mic Status, Minimal Waveform & Recognized Speech Line */}
        <div className="flex flex-wrap items-center justify-between gap-2 px-1 text-[11px] font-mono">
          <div className="flex items-center gap-2.5 min-w-0">
            <span className={`inline-flex items-center gap-1.5 ${statusTone}`}>
              <span
                className={`w-1.5 h-1.5 rounded-full shrink-0 ${
                  isListening
                    ? 'bg-sky-400 animate-pulse'
                    : isSpeaking
                      ? 'bg-amber-400'
                      : hasVoiceIssue
                        ? 'bg-red-400'
                        : micPermissionState === 'granted'
                          ? 'bg-emerald-400'
                          : 'bg-slate-500'
                }`}
                aria-hidden="true"
              />
              <span>{statusLabel}</span>
            </span>

            {showWaveform && (
              <div className="inline-flex items-end gap-0.5 h-3.5" aria-label="Audio activity waveform">
                {WAVE_HEIGHTS.map((factor, idx) => {
                  const pct = Math.max(22, Math.min(100, Math.round((0.18 + voiceRmsLevel * 0.95) * factor * 100)));
                  return (
                    <span
                      key={idx}
                      className={`w-0.5 rounded-full transition-[height] duration-75 ${
                        isListening ? 'bg-sky-400' : 'bg-amber-400'
                      }`}
                      style={{ height: `${pct}%` }}
                    />
                  );
                })}
              </div>
            )}

            {isSpeaking && (
              <button
                type="button"
                onClick={onStopSpeaking}
                className="inline-flex items-center gap-1 px-2 py-0.5 rounded border border-red-400/50 bg-red-500/15 text-red-200 hover:bg-red-500/25 transition-colors"
              >
                <Square className="w-2.5 h-2.5" />
                Stop
              </button>
            )}
          </div>

          {recognizedCommand ? (
            <span className="text-slate-300 truncate max-w-[65%]">
              &ldquo;{recognizedCommand}&rdquo;
            </span>
          ) : (
            <span className="text-slate-500 hidden sm:inline">
              Try &ldquo;SK ASSEMBLE ALL&rdquo; or &ldquo;JARVIS&rdquo;
            </span>
          )}
        </div>
      </form>

      {/* Browser Preview Microphone Permission / Recovery Guidance (Shown Only When Blocked/Error) */}
      {hasVoiceIssue && (
        <div className="bg-red-950/35 border border-red-500/35 rounded-xl px-3.5 py-2.5 space-y-1.5 text-xs">
          <div className="flex items-center justify-between gap-3">
            <span className="font-mono text-red-200 truncate">
              {speechError || 'Browser microphone access is blocked for this preview.'}
            </span>
            <button
              type="button"
              onClick={onRetryMicrophone}
              disabled={isMicRequesting}
              className="inline-flex items-center gap-1 px-3 py-1.5 min-h-[34px] rounded-lg bg-white/10 hover:bg-white/15 text-amber-200 border border-amber-400/40 whitespace-nowrap shrink-0 disabled:opacity-50"
            >
              <RotateCcw className="w-3 h-3" />
              Retry
            </button>
          </div>
          {isBlocked && (
            <p className="text-[11px] text-red-200/85">
              Site settings: Click the lock or tune icon next to the browser address bar, set{' '}
              <strong>Microphone</strong> to <strong>Allow</strong>, then click <strong>Retry</strong>.
            </p>
          )}
        </div>
      )}
    </div>
  );
}
