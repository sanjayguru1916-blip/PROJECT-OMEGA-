import { useEffect, useState } from 'react';
import {
  Activity,
  CheckCircle2,
  Cpu,
  Download,
  Flame,
  History,
  Layers,
  Lock,
  RotateCcw,
  ShieldAlert,
  ShieldCheck,
  Smartphone,
  Volume2,
  VolumeX,
  Wrench,
  X,
  XCircle,
} from 'lucide-react';
import {
  AnimationQuality,
  AssistantId,
  BrowserMicPermissionState,
  InterfaceMode,
  OmegaPlatformState,
  VoiceProviderMode,
  VoiceState,
} from '../types/omega';
import { OperationsSectionId } from './AssistantSidebar';
import { AndroidProjectExplorer } from './AndroidProjectExplorer';
import { AuditReportsPanel } from './AuditReportsPanel';
import { VoiceSettingsPanel } from './VoiceSettingsPanel';

export interface CommandResultRecord {
  id: string;
  speaker: AssistantId;
  text: string;
  timestamp: number;
}

interface ExpandableOperationsDrawerProps {
  state: OmegaPlatformState;
  activeSection: OperationsSectionId | null;
  requestedDiagTab?: 'voice' | 'audit' | 'android';
  commandResults: CommandResultRecord[];
  onToggleSection: (section: OperationsSectionId) => void;
  onClose: () => void;
  interfaceMode: InterfaceMode;
  animationQuality: AnimationQuality;
  voiceEnabled: boolean;
  voiceProviderMode: VoiceProviderMode;
  voiceState: VoiceState;
  micPermissionState: BrowserMicPermissionState;
  permissionsApiSupported: boolean;
  speechRecognitionSupported: boolean;
  isMicRequesting: boolean;
  speakingAssistant: AssistantId | null;
  recognizedCommand: string | null;
  voiceDiagnostics: string | null;
  browserVoices: Array<{ name: string; lang: string; localService: boolean }>;
  isExecuting: boolean;
  generatingReport: boolean;
  onSelectMode: (mode: 'NORMAL' | 'PHOENIX' | 'ASSEMBLED' | 'DISASSEMBLE') => void;
  onChangeAnimationQuality: (q: AnimationQuality) => void;
  onToggleVoiceEnabled: (enabled: boolean) => void;
  onChangeProviderMode: (mode: VoiceProviderMode) => void;
  onUpdateVoiceTuning: (id: AssistantId, pitch: number, speechRate: number) => Promise<void>;
  onPreviewVoice: (id: AssistantId) => void;
  onStopSpeaking: () => void;
  onToggleMicrophone: () => void;
  onRetryMicrophone: () => void;
  onApproveProposal: (proposalId: string, payloadHash: string) => void;
  onRejectProposal: (proposalId: string) => void;
  onToggleAssistant: (id: AssistantId, enabled: boolean) => void;
  onCheckAssistantStatus: (id: AssistantId) => void;
  onTogglePermission: (permission: string, granted: boolean) => void;
  onToggleReminder: (id: string) => void;
  onGenerateReport: () => void;
  onAcknowledgeAlert: (alertId: string) => void;
}

const ASSISTANT_ORDER: AssistantId[] = ['SK', 'JARVIS', 'MAGMITE', 'ULTRON', 'FRIDAY'];

type DiagnosticsTab = 'voice' | 'audit' | 'android';

export function ExpandableOperationsDrawer({
  state,
  activeSection,
  requestedDiagTab = 'voice',
  commandResults,
  onToggleSection,
  onClose,
  interfaceMode,
  animationQuality,
  voiceEnabled,
  voiceProviderMode,
  voiceState,
  micPermissionState,
  permissionsApiSupported,
  speechRecognitionSupported,
  isMicRequesting,
  speakingAssistant,
  recognizedCommand,
  voiceDiagnostics,
  browserVoices,
  isExecuting,
  generatingReport,
  onSelectMode,
  onChangeAnimationQuality,
  onToggleVoiceEnabled,
  onChangeProviderMode,
  onUpdateVoiceTuning,
  onPreviewVoice,
  onStopSpeaking,
  onToggleMicrophone,
  onRetryMicrophone,
  onApproveProposal,
  onRejectProposal,
  onToggleAssistant,
  onCheckAssistantStatus,
  onTogglePermission,
  onToggleReminder,
  onGenerateReport,
  onAcknowledgeAlert,
}: ExpandableOperationsDrawerProps) {
  const [diagTab, setDiagTab] = useState<DiagnosticsTab>(requestedDiagTab);
  const [criticalConfirmedIds, setCriticalConfirmedIds] = useState<Record<string, boolean>>({});

  useEffect(() => {
    setDiagTab(requestedDiagTab);
  }, [requestedDiagTab]);

  useEffect(() => {
    if (!activeSection) return;
    const onKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'Escape') onClose();
    };
    window.addEventListener('keydown', onKeyDown);
    return () => window.removeEventListener('keydown', onKeyDown);
  }, [activeSection, onClose]);

  if (!activeSection) return null;

  const unackAlerts = state.alerts.filter((a) => !a.acknowledged);
  const pendingCount = state.pendingProposals.length;

  const sections: Array<{
    id: OperationsSectionId;
    title: string;
    meta: string;
    icon: typeof ShieldCheck;
  }> = [
    {
      id: 'system',
      title: 'System & Mission',
      meta: `${ASSISTANT_ORDER.filter((id) => state.registry[id].isEnabled).length}/5 online`,
      icon: Cpu,
    },
    {
      id: 'activity',
      title: 'Five Assistants',
      meta: `${state.taskHistory.length} logged`,
      icon: Activity,
    },
    {
      id: 'approvals',
      title: 'Approvals',
      meta: pendingCount > 0 ? `${pendingCount} pending` : 'Clear',
      icon: Lock,
    },
    {
      id: 'device',
      title: 'Device Telemetry',
      meta: `Torch ${state.deviceState.torchEnabled ? 'ON' : 'OFF'} · Vol ${state.deviceState.mediaVolumePercent}%`,
      icon: Smartphone,
    },
    {
      id: 'history',
      title: 'Results & History',
      meta: `${commandResults.length + state.taskHistory.length}`,
      icon: History,
    },
    {
      id: 'diagnostics',
      title: 'Voice · Audit · Code',
      meta: unackAlerts.length > 0 ? `${unackAlerts.length} alerts` : 'Settings & Logs',
      icon: Wrench,
    },
  ];

  return (
    <div
      className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-6 bg-black/75 backdrop-blur-sm"
      role="dialog"
      aria-modal="true"
      aria-label="SK Master Operations & System Details"
      onClick={(e) => {
        if (e.target === e.currentTarget) onClose();
      }}
    >
      <div className="w-full max-w-[940px] max-h-[86vh] bg-[#090B10] border border-white/15 rounded-2xl shadow-2xl flex flex-col overflow-hidden">
        {/* Panel Top Header & Navigation Tabs */}
        <div className="px-4 py-3 border-b border-white/10 flex items-center justify-between gap-3 shrink-0">
          <div className="flex items-center gap-1.5 overflow-x-auto no-scrollbar">
            {sections.map(({ id, title, meta, icon: Icon }) => {
              const isOpen = activeSection === id;
              const highlightPending = id === 'approvals' && pendingCount > 0;
              return (
                <button
                  key={id}
                  type="button"
                  onClick={() => onToggleSection(id)}
                  className={`min-h-[36px] px-2.5 py-1.5 rounded-lg border text-left transition-colors inline-flex items-center gap-1.5 whitespace-nowrap shrink-0 ${
                    isOpen
                      ? 'bg-amber-500/15 border-amber-400/60 text-white'
                      : highlightPending
                        ? 'bg-amber-500/10 border-amber-400/40 text-amber-100 hover:bg-amber-500/15'
                        : 'bg-white/[0.03] border-white/10 text-slate-300 hover:border-white/25'
                  }`}
                >
                  <Icon className={`w-3.5 h-3.5 shrink-0 ${highlightPending || isOpen ? 'text-amber-400' : 'text-slate-400'}`} />
                  <span className="text-xs font-medium">{title}</span>
                  <span className="text-[10px] font-mono text-slate-400 tabular-nums">· {meta}</span>
                </button>
              );
            })}
          </div>
          <button
            type="button"
            onClick={onClose}
            aria-label="Close details panel"
            className="w-9 h-9 inline-flex items-center justify-center rounded-lg text-slate-400 hover:text-white hover:bg-white/10 transition-colors shrink-0"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Scrollable Panel Content */}
        <div className="p-4 sm:p-5 overflow-y-auto space-y-4">
          {/* Controlled Details Body */}
      {activeSection === 'approvals' && (
        <div className="bg-[#0D1017] border border-white/10 rounded-xl p-4 sm:p-5 space-y-4">
          <div className="flex items-center justify-between">
            <h2 className="font-display text-sm font-semibold text-white">
              Task-Specific Approval Center
            </h2>
            <span className="text-xs font-mono text-slate-400 tabular-nums">
              {pendingCount} awaiting approval
            </span>
          </div>

          {unackAlerts.length > 0 && (
            <div className="space-y-2">
              {unackAlerts.map((alert) => (
                <div
                  key={alert.alertId}
                  className="bg-red-950/30 border border-red-500/40 rounded-lg px-3.5 py-2.5 flex items-center justify-between gap-3 text-xs"
                >
                  <div className="min-w-0">
                    <div className="font-mono text-red-300">
                      {alert.severity} · {alert.source} · {alert.title}
                    </div>
                    <div className="text-slate-200 mt-0.5">{alert.message}</div>
                  </div>
                  <button
                    type="button"
                    onClick={() => onAcknowledgeAlert(alert.alertId)}
                    className="px-2.5 py-1.5 rounded bg-white/10 hover:bg-white/15 text-red-200 whitespace-nowrap shrink-0"
                  >
                    Dismiss
                  </button>
                </div>
              ))}
            </div>
          )}

          {state.pendingProposals.length === 0 ? (
            <p className="text-xs sm:text-sm text-slate-400">
              No delegated tasks awaiting approval. Every command routed by SK pauses here with its exact operation, parameters, required permissions, and SHA-256 payload hash before execution.
            </p>
          ) : (
            <div className="space-y-3">
              {state.pendingProposals.map((proposal) => {
                const targetMeta = state.registry[proposal.targetAssistant];
                const isCritical = proposal.riskLevel === 'CRITICAL';
                const criticalConfirmed = Boolean(criticalConfirmedIds[proposal.proposalId]);
                return (
                  <div
                    key={proposal.proposalId}
                    className="bg-[#050608] border rounded-xl p-4 space-y-2.5"
                    style={{ borderColor: `${targetMeta.visualIdentity.primaryColor}66` }}
                  >
                    <div className="flex flex-wrap items-center justify-between gap-2 text-xs font-mono">
                      <span style={{ color: targetMeta.visualIdentity.primaryColor }}>
                        {proposal.targetAssistant} · {proposal.exactOperation}
                      </span>
                      <span className={isCritical ? 'text-red-400 font-semibold' : 'text-amber-400'}>
                        Risk: {proposal.riskLevel}
                      </span>
                    </div>
                    <div className="text-sm font-medium text-white">{proposal.actionSummary}</div>
                    <div className="text-xs font-mono text-slate-300 space-y-1">
                      <div className="break-all">Parameters: {JSON.stringify(proposal.parameters)}</div>
                      <div>
                        Permissions:{' '}
                        {proposal.requiredPermissions.length > 0
                          ? proposal.requiredPermissions.join(', ')
                          : 'None'}
                      </div>
                      <div className="text-slate-500 break-all">SHA-256: {proposal.payloadHash}</div>
                    </div>
                    {isCritical && (
                      <label className="flex items-start gap-2 rounded-lg bg-red-950/35 border border-red-500/40 px-3 py-2 text-xs text-red-200 cursor-pointer">
                        <input
                          type="checkbox"
                          checked={criticalConfirmed}
                          onChange={(e) =>
                            setCriticalConfirmedIds((prev) => ({
                              ...prev,
                              [proposal.proposalId]: e.target.checked,
                            }))
                          }
                          className="mt-0.5 accent-red-500"
                        />
                        <span>
                          Strong Confirmation Required: I verified the parameters and authorize this irreversible CRITICAL action.
                        </span>
                      </label>
                    )}
                    <div className="flex items-center gap-2.5 pt-1">
                      <button
                        type="button"
                        onClick={() => onApproveProposal(proposal.proposalId, proposal.payloadHash)}
                        disabled={isExecuting || (isCritical && !criticalConfirmed)}
                        className="min-h-[40px] inline-flex items-center gap-1.5 px-4 py-2 text-xs font-medium bg-emerald-500 text-slate-950 rounded-lg hover:bg-emerald-400 disabled:opacity-50 transition-colors whitespace-nowrap shrink-0"
                      >
                        <CheckCircle2 className="w-3.5 h-3.5" />
                        {isExecuting ? 'Executing...' : isCritical ? 'Confirm Critical Action' : 'Approve & Execute'}
                      </button>
                      <button
                        type="button"
                        onClick={() => onRejectProposal(proposal.proposalId)}
                        disabled={isExecuting}
                        className="min-h-[40px] inline-flex items-center gap-1.5 px-4 py-2 text-xs font-medium text-slate-200 bg-white/5 hover:bg-white/10 rounded-lg transition-colors whitespace-nowrap shrink-0"
                      >
                        <XCircle className="w-3.5 h-3.5" />
                        Reject Task
                      </button>
                    </div>
                  </div>
                );
              })}
            </div>
          )}
        </div>
      )}

      {activeSection === 'system' && (
        <div className="bg-[#0D1017] border border-white/10 rounded-xl p-4 sm:p-5 space-y-4">
          <div className="flex flex-wrap items-center justify-between gap-3">
            <h2 className="font-display text-sm font-semibold text-white">
              System Status & Core Controls
            </h2>
            <div className="flex flex-wrap items-center gap-2">
              <button
                type="button"
                onClick={() => onToggleVoiceEnabled(!voiceEnabled)}
                className="min-h-[36px] inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-[#050608] border border-white/10 text-xs text-slate-200 hover:border-white/25 whitespace-nowrap shrink-0"
              >
                {voiceEnabled ? <Volume2 className="w-3.5 h-3.5 text-amber-400" /> : <VolumeX className="w-3.5 h-3.5" />}
                {voiceEnabled ? 'Voice On' : 'Voice Muted'}
              </button>
              <select
                aria-label="Animation performance mode"
                value={animationQuality}
                onChange={(e) => onChangeAnimationQuality(e.target.value as AnimationQuality)}
                className="min-h-[36px] bg-[#050608] border border-white/10 rounded-lg px-2.5 py-1.5 text-xs font-mono text-slate-300 focus:outline-none focus:border-amber-400"
              >
                <option value="HIGH_60FPS">60 FPS Smooth</option>
                <option value="BATTERY_SAVER_30FPS">30 FPS Eco</option>
                <option value="REDUCED_MOTION">Reduced Motion</option>
              </select>
            </div>
          </div>

          <div className="flex flex-wrap gap-2">
            <button
              type="button"
              onClick={() => onSelectMode('NORMAL')}
              className={`min-h-[38px] inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-medium rounded-lg border transition-colors whitespace-nowrap shrink-0 ${
                interfaceMode === 'NORMAL'
                  ? 'bg-amber-500/20 border-amber-400 text-amber-200'
                  : 'bg-[#050608] border-white/10 text-slate-300 hover:border-white/25'
              }`}
            >
              <RotateCcw className="w-3.5 h-3.5" />
              SK Normal
            </button>
            <button
              type="button"
              onClick={() => onSelectMode('PHOENIX')}
              className={`min-h-[38px] inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-medium rounded-lg border transition-colors whitespace-nowrap shrink-0 ${
                interfaceMode === 'PHOENIX'
                  ? 'bg-orange-500/20 border-orange-400 text-orange-200'
                  : 'bg-[#050608] border-white/10 text-slate-300 hover:border-orange-400/50'
              }`}
            >
              <Flame className="w-3.5 h-3.5 text-orange-400" />
              Phoenix Mode
            </button>
            <button
              type="button"
              onClick={() => onSelectMode(interfaceMode === 'ASSEMBLED' ? 'DISASSEMBLE' : 'ASSEMBLED')}
              className={`min-h-[38px] inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-medium rounded-lg border transition-colors whitespace-nowrap shrink-0 ${
                interfaceMode === 'ASSEMBLED'
                  ? 'bg-sky-500/20 border-sky-400 text-sky-200'
                  : 'bg-[#050608] border-white/10 text-slate-300 hover:border-sky-400/50'
              }`}
            >
              <Layers className="w-3.5 h-3.5 text-sky-400" />
              {interfaceMode === 'ASSEMBLED' ? 'Disassemble All' : 'Assemble All'}
            </button>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-3 gap-2.5 text-xs font-mono">
            <div className="bg-[#050608] border border-white/10 rounded-lg px-3 py-2">
              <div className="text-[10px] text-slate-500 uppercase">Mission Mode</div>
              <div className="text-amber-300 mt-0.5">{interfaceMode}</div>
            </div>
            <div className="bg-[#050608] border border-white/10 rounded-lg px-3 py-2">
              <div className="text-[10px] text-slate-500 uppercase">Voice Pipeline</div>
              <div className="text-sky-300 mt-0.5">{voiceState} · {micPermissionState.toUpperCase()}</div>
            </div>
            <div className="bg-[#050608] border border-white/10 rounded-lg px-3 py-2">
              <div className="text-[10px] text-slate-500 uppercase">Latest Output</div>
              <div className="text-slate-200 truncate mt-0.5">{commandResults[0]?.text || 'Standby'}</div>
            </div>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-5 gap-2.5">
            {ASSISTANT_ORDER.map((id) => {
              const entry = state.registry[id];
              return (
                <div
                  key={id}
                  className="bg-[#050608] border border-white/10 rounded-lg p-3 flex flex-col justify-between gap-2.5"
                >
                  <div>
                    <div className="flex items-center justify-between gap-2">
                      <span className="text-xs font-semibold text-white">{entry.displayName}</span>
                      <span
                        className="text-[10px] font-mono"
                        style={{ color: entry.isEnabled ? entry.visualIdentity.primaryColor : '#64748B' }}
                      >
                        {entry.status}
                      </span>
                    </div>
                    <div className="text-[11px] text-slate-400 truncate mt-0.5">{entry.roleTitle}</div>
                  </div>
                  <div className="flex items-center gap-1.5">
                    <button
                      type="button"
                      onClick={() => onCheckAssistantStatus(id)}
                      className="flex-1 min-h-[34px] px-2 py-1 text-[11px] font-mono bg-white/5 hover:bg-white/10 text-amber-300 rounded border border-white/10 whitespace-nowrap"
                    >
                      Report
                    </button>
                    {!entry.isMasterController && (
                      <button
                        type="button"
                        onClick={() => onToggleAssistant(id, !entry.isEnabled)}
                        className={`min-h-[34px] px-2 py-1 text-[11px] rounded whitespace-nowrap ${
                          entry.isEnabled
                            ? 'bg-emerald-500/15 text-emerald-300 hover:bg-emerald-500/25'
                            : 'bg-white/5 text-slate-300 hover:bg-white/10'
                        }`}
                      >
                        {entry.isEnabled ? 'Disable' : 'Enable'}
                      </button>
                    )}
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      )}

      {activeSection === 'activity' && (
        <div className="bg-[#0D1017] border border-white/10 rounded-xl p-4 sm:p-5 space-y-3">
          <div className="flex items-center justify-between">
            <h2 className="font-display text-sm font-semibold text-white">
              Real-Time Assistant Activity & Runtime Telemetry
            </h2>
            <span className="text-xs font-mono text-slate-400">Live runtime counters</span>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-3">
            {ASSISTANT_ORDER.map((id) => {
              const entry = state.registry[id];
              const m = entry.metrics;
              return (
                <div
                  key={id}
                  className="bg-[#050608] border border-white/10 rounded-lg p-3 text-xs font-mono space-y-1.5"
                >
                  <div className="flex items-center justify-between">
                    <span className="font-semibold text-white">{entry.displayName}</span>
                    <span style={{ color: entry.visualIdentity.primaryColor }}>{m.communicationState}</span>
                  </div>
                  <div className="text-slate-300 truncate" title={m.currentActivity}>
                    {m.currentActivity}
                  </div>
                  <div className="flex items-center justify-between text-slate-400 tabular-nums">
                    <span>Active/Done/Pending</span>
                    <span className="text-amber-300">
                      {m.activeTaskCount} / {m.completedTaskCount} / {m.pendingTaskCount}
                    </span>
                  </div>
                  <div className="flex items-center justify-between text-slate-400 tabular-nums">
                    <span>Latency</span>
                    <span>{m.lastResponseMs !== null ? `${m.lastResponseMs} ms` : 'Not available'}</span>
                  </div>
                  {m.recentError && (
                    <div className="text-red-300 truncate" title={m.recentError}>
                      Error: {m.recentError}
                    </div>
                  )}
                </div>
              );
            })}
          </div>
        </div>
      )}

      {activeSection === 'device' && (
        <div className="bg-[#0D1017] border border-white/10 rounded-xl p-4 sm:p-5 space-y-4">
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div className="bg-[#050608] border border-white/10 rounded-lg p-3.5 space-y-2">
              <div className="text-xs font-medium text-white">MAGMITE Device Controls</div>
              <div className="space-y-1 text-xs font-mono text-slate-300 tabular-nums">
                <div className="flex justify-between">
                  <span className="text-slate-400">Torch</span>
                  <span>{state.deviceState.torchEnabled ? 'ON' : 'OFF'}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-slate-400">Media Volume</span>
                  <span>{state.deviceState.mediaVolumePercent}%</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-slate-400">Ringer Mode</span>
                  <span>{state.deviceState.ringerMode.toUpperCase()}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-slate-400">Music State</span>
                  <span>{state.deviceState.musicStatus || 'IDLE'}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-slate-400">Last App</span>
                  <span className="truncate max-w-[140px]">{state.deviceState.lastLaunchedApp || 'None'}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-slate-400">Last Alarm</span>
                  <span className="truncate max-w-[140px]">{state.deviceState.lastAlarmLabel || 'None'}</span>
                </div>
              </div>
            </div>

            <div className="bg-[#050608] border border-white/10 rounded-lg p-3.5 space-y-2">
              <div className="text-xs font-medium text-white">FRIDAY Reminders</div>
              {state.reminders.length === 0 ? (
                <p className="text-xs text-slate-400">No reminders scheduled.</p>
              ) : (
                <div className="space-y-1.5 max-h-28 overflow-y-auto">
                  {state.reminders.map((rem) => (
                    <button
                      key={rem.id}
                      type="button"
                      onClick={() => onToggleReminder(rem.id)}
                      className="w-full text-left flex justify-between gap-2 text-xs"
                    >
                      <span className={rem.completed ? 'line-through text-slate-500' : 'text-slate-200'}>
                        {rem.title}
                      </span>
                      <span className="font-mono text-emerald-400 shrink-0 tabular-nums">
                        +{rem.delayMinutes}m
                      </span>
                    </button>
                  ))}
                </div>
              )}
            </div>
          </div>

          <div className="space-y-2">
            <div className="text-xs font-medium text-white">Android Runtime Permissions</div>
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-2">
              {Object.entries(state.deviceState.grantedPermissions).map(([perm, granted]) => (
                <div
                  key={perm}
                  className="bg-[#050608] border border-white/10 rounded-lg px-3 py-2 flex items-center justify-between gap-2"
                >
                  <span className="text-xs font-mono text-slate-300 truncate" title={perm}>
                    {perm.replace('android.permission.', '')}
                  </span>
                  <button
                    type="button"
                    onClick={() => onTogglePermission(perm, !granted)}
                    className={`min-h-[32px] px-2.5 py-1 text-[11px] font-mono rounded whitespace-nowrap shrink-0 ${
                      granted ? 'bg-emerald-500/15 text-emerald-300' : 'bg-red-500/15 text-red-300'
                    }`}
                  >
                    {granted ? 'GRANTED' : 'DENIED'}
                  </button>
                </div>
              ))}
            </div>
          </div>
        </div>
      )}

      {activeSection === 'history' && (
        <div className="space-y-4">
          <div className="bg-[#0D1017] border border-white/10 rounded-xl p-4 sm:p-5 space-y-3">
            <div className="flex items-center justify-between">
              <h2 className="font-display text-sm font-semibold text-white">
                Previous Command Results & Replies
              </h2>
              <span className="text-xs font-mono text-slate-400 tabular-nums">
                {commandResults.length} recent
              </span>
            </div>
            {commandResults.length === 0 ? (
              <p className="text-xs sm:text-sm text-slate-400">
                No recent command replies recorded yet.
              </p>
            ) : (
              <div className="divide-y divide-white/10 max-h-48 overflow-y-auto pr-1">
                {commandResults.map((resItem) => (
                  <div key={resItem.id} className="py-2 first:pt-0 last:pb-0 space-y-0.5">
                    <div className="flex justify-between gap-2 text-[11px] font-mono">
                      <span className="text-sky-300">{resItem.speaker}</span>
                      <span className="text-slate-500 tabular-nums">
                        {new Date(resItem.timestamp).toLocaleTimeString()}
                      </span>
                    </div>
                    <p className="text-xs sm:text-sm text-slate-200">{resItem.text}</p>
                  </div>
                ))}
              </div>
            )}
          </div>

          <div className="bg-[#0D1017] border border-white/10 rounded-xl p-4 sm:p-5 space-y-3">
            <div className="flex items-center justify-between">
              <h2 className="font-display text-sm font-semibold text-white">
                Delegated Task History
              </h2>
              <span className="text-xs font-mono text-slate-400 tabular-nums">
                {state.taskHistory.length} total
              </span>
            </div>
            {state.taskHistory.length === 0 ? (
              <p className="text-xs sm:text-sm text-slate-400">
                No tasks executed yet. Issue and approve a delegated command to record telemetry.
              </p>
            ) : (
              <div className="divide-y divide-white/10 max-h-64 overflow-y-auto pr-1">
                {state.taskHistory.map((item) => (
                  <div key={item.proposalId} className="py-2.5 first:pt-0 last:pb-0 space-y-1">
                    <div className="flex justify-between gap-2 text-xs font-mono">
                      <span className="text-amber-400">
                        {item.targetAssistant} · {item.exactOperation} · {item.status}
                      </span>
                      <span className="text-slate-500 tabular-nums shrink-0">
                        {new Date(item.timestampEpochMs).toLocaleTimeString()}
                      </span>
                    </div>
                    <p className="text-xs sm:text-sm text-slate-200">{item.resultSummary}</p>
                  </div>
                ))}
              </div>
            )}
          </div>
        </div>
      )}

      {activeSection === 'diagnostics' && (
        <div className="bg-[#0D1017] border border-white/10 rounded-xl p-4 sm:p-5 space-y-5">
          <div className="flex flex-wrap items-center justify-between gap-3 border-b border-white/10 pb-3">
            <div className="flex items-center gap-1 p-1 bg-[#050608] border border-white/10 rounded-lg">
              {(
                [
                  ['voice', 'Voice Calibration'],
                  ['audit', `Audit & Reports${unackAlerts.length > 0 ? ` (${unackAlerts.length})` : ''}`],
                  ['android', 'Kotlin Android Project'],
                ] as Array<[DiagnosticsTab, string]>
              ).map(([tabId, label]) => (
                <button
                  key={tabId}
                  type="button"
                  onClick={() => setDiagTab(tabId)}
                  className={`px-3 py-1.5 text-xs font-medium rounded-md transition-colors whitespace-nowrap shrink-0 ${
                    diagTab === tabId ? 'bg-amber-400/15 text-amber-200' : 'text-slate-400 hover:text-white'
                  }`}
                >
                  {label}
                </button>
              ))}
            </div>

            <a
              href="/api/android/download"
              className="inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-medium bg-amber-400 text-slate-950 rounded-lg hover:bg-amber-300 transition-colors whitespace-nowrap shrink-0"
            >
              <Download className="w-3.5 h-3.5" />
              Export Android ZIP
            </a>
          </div>

          {diagTab === 'voice' && (
            <VoiceSettingsPanel
              registry={state.registry}
              voiceEnabled={voiceEnabled}
              voiceProviderMode={voiceProviderMode}
              voiceState={voiceState}
              micPermissionState={micPermissionState}
              permissionsApiSupported={permissionsApiSupported}
              speechRecognitionSupported={speechRecognitionSupported}
              isMicRequesting={isMicRequesting}
              speakingAssistant={speakingAssistant}
              recognizedCommand={recognizedCommand}
              voiceDiagnostics={voiceDiagnostics}
              browserVoices={browserVoices}
              onToggleVoiceEnabled={onToggleVoiceEnabled}
              onChangeProviderMode={onChangeProviderMode}
              onUpdateVoiceTuning={onUpdateVoiceTuning}
              onPreviewVoice={onPreviewVoice}
              onStopSpeaking={onStopSpeaking}
              onToggleMicrophone={onToggleMicrophone}
              onRetryMicrophone={onRetryMicrophone}
            />
          )}

          {diagTab === 'audit' && (
            <AuditReportsPanel
              state={state}
              generatingReport={generatingReport}
              onGenerateReport={onGenerateReport}
              onAcknowledgeAlert={onAcknowledgeAlert}
            />
          )}

          {diagTab === 'android' && <AndroidProjectExplorer />}
        </div>
      )}

      {unackAlerts.length > 0 && activeSection !== 'approvals' && activeSection !== 'diagnostics' && (
        <div className="flex items-center justify-between gap-2 px-3 py-2 rounded-lg bg-red-950/25 border border-red-500/30 text-xs text-red-200">
          <span className="inline-flex items-center gap-1.5 truncate">
            <ShieldAlert className="w-3.5 h-3.5 text-red-400 shrink-0" />
            <span>{unackAlerts[0].title}</span>
          </span>
          <button
            type="button"
            onClick={() => onToggleSection('approvals')}
            className="font-mono text-amber-300 hover:text-amber-200 whitespace-nowrap shrink-0"
          >
            Review ({unackAlerts.length})
          </button>
        </div>
      )}
        </div>
      </div>
    </div>
  );
}
