import {
  Activity,
  ChevronLeft,
  ChevronRight,
  Cpu,
  History,
  ShieldCheck,
  SlidersHorizontal,
  Smartphone,
  Wrench,
  X,
} from 'lucide-react';
import { AssistantId, AssistantRegistryEntry } from '../types/omega';

export type OperationsSectionId =
  | 'approvals'
  | 'system'
  | 'activity'
  | 'device'
  | 'history'
  | 'diagnostics';

interface AssistantSidebarProps {
  registry: Record<AssistantId, AssistantRegistryEntry>;
  activeId: AssistantId;
  speakingAssistant: AssistantId | null;
  collapsed: boolean;
  mobileOpen: boolean;
  pendingCount: number;
  activeSection: OperationsSectionId | null;
  onToggleCollapse: () => void;
  onCloseMobile: () => void;
  onSelectAssistant: (id: AssistantId) => void;
  onSelectSection: (section: OperationsSectionId) => void;
}

const ASSISTANT_ORDER: AssistantId[] = ['SK', 'JARVIS', 'MAGMITE', 'ULTRON', 'FRIDAY'];

function MiniCoreEmblem({
  color,
  active,
  speaking,
  disabled,
}: {
  color: string;
  active: boolean;
  speaking: boolean;
  disabled: boolean;
}) {
  const strokeColor = disabled ? '#475569' : color;
  return (
    <span className="relative inline-flex items-center justify-center w-8 h-8 shrink-0">
      <svg viewBox="0 0 36 36" className="w-8 h-8" aria-hidden="true">
        <circle
          cx="18"
          cy="18"
          r="15"
          fill={active ? `${strokeColor}22` : '#050608'}
          stroke={strokeColor}
          strokeOpacity={active ? 0.95 : 0.45}
          strokeWidth={active ? 1.75 : 1.25}
        />
        <circle
          cx="18"
          cy="18"
          r="10.5"
          fill="none"
          stroke={strokeColor}
          strokeOpacity={speaking ? 0.95 : 0.55}
          strokeWidth="1.25"
          strokeDasharray="6 4"
        />
        <circle
          cx="18"
          cy="18"
          r={speaking ? 4.8 : 3.8}
          fill={strokeColor}
          fillOpacity={disabled ? 0.35 : active || speaking ? 0.95 : 0.7}
        />
      </svg>
    </span>
  );
}

const DRAWER_SECTIONS: Array<{
  id: OperationsSectionId;
  label: string;
  icon: typeof ShieldCheck;
}> = [
  { id: 'approvals', label: 'Approval Center', icon: ShieldCheck },
  { id: 'system', label: 'System Status', icon: Cpu },
  { id: 'activity', label: 'Assistant Activity', icon: Activity },
  { id: 'device', label: 'Device Info', icon: Smartphone },
  { id: 'history', label: 'Task History', icon: History },
  { id: 'diagnostics', label: 'Diagnostics & Tools', icon: Wrench },
];

export function AssistantSidebar({
  registry,
  activeId,
  speakingAssistant,
  collapsed,
  mobileOpen,
  pendingCount,
  activeSection,
  onToggleCollapse,
  onCloseMobile,
  onSelectAssistant,
  onSelectSection,
}: AssistantSidebarProps) {
  const renderNavBody = (isMobileDrawer: boolean) => {
    const compact = !isMobileDrawer && collapsed;

    return (
      <div className="flex flex-col h-full bg-[#090B10] border-r border-white/10 select-none">
        {/* Sidebar Top Strip */}
        <div className="h-14 px-3 border-b border-white/10 flex items-center justify-between gap-2 shrink-0">
          {!compact && (
            <span className="font-mono text-[11px] tracking-wider text-amber-400 uppercase truncate">
              AI Cores
            </span>
          )}
          {isMobileDrawer ? (
            <button
              type="button"
              onClick={onCloseMobile}
              aria-label="Close navigation drawer"
              className="w-9 h-9 inline-flex items-center justify-center rounded-lg text-slate-400 hover:text-white hover:bg-white/5 transition-colors ml-auto"
            >
              <X className="w-4 h-4" />
            </button>
          ) : (
            <button
              type="button"
              onClick={onToggleCollapse}
              aria-label={collapsed ? 'Expand sidebar' : 'Collapse sidebar'}
              title={collapsed ? 'Expand sidebar' : 'Collapse sidebar'}
              className={`w-9 h-9 inline-flex items-center justify-center rounded-lg text-slate-400 hover:text-white hover:bg-white/5 transition-colors ${
                compact ? 'mx-auto' : ''
              }`}
            >
              {collapsed ? <ChevronRight className="w-4 h-4" /> : <ChevronLeft className="w-4 h-4" />}
            </button>
          )}
        </div>

        {/* Five Assistant Cores */}
        <div className="p-2 space-y-1">
          {ASSISTANT_ORDER.map((id) => {
            const entry = registry[id];
            const isSelected = activeId === id;
            const isSpeaking = speakingAssistant === id;
            const disabled = !entry.isEnabled;
            const color = entry.visualIdentity.primaryColor;

            return (
              <button
                key={id}
                type="button"
                onClick={() => {
                  onSelectAssistant(id);
                  if (isMobileDrawer) onCloseMobile();
                }}
                title={`${entry.displayName} — ${entry.status}`}
                className={`w-full min-h-[44px] flex items-center gap-2.5 rounded-lg px-2 py-1.5 transition-colors border text-left ${
                  isSelected
                    ? 'bg-white/[0.08] border-white/20 text-white'
                    : 'border-transparent text-slate-400 hover:bg-white/[0.04] hover:text-slate-200'
                } ${compact ? 'justify-center px-1' : ''}`}
              >
                <MiniCoreEmblem
                  color={color}
                  active={isSelected}
                  speaking={isSpeaking}
                  disabled={disabled}
                />

                {!compact && (
                  <div className="min-w-0 flex-1">
                    <div className="flex items-center justify-between gap-1.5">
                      <span className="text-xs font-semibold tracking-wide truncate text-slate-100">
                        {entry.displayName}
                      </span>
                      <span
                        className={`w-1.5 h-1.5 rounded-full shrink-0 ${
                          disabled
                            ? 'bg-slate-600'
                            : isSpeaking
                              ? 'bg-amber-400'
                              : entry.status === 'ONLINE'
                                ? 'bg-emerald-400'
                                : 'bg-amber-300'
                        }`}
                        aria-hidden="true"
                      />
                    </div>
                    <div
                      className="text-[10px] font-mono truncate"
                      style={{ color: disabled ? '#64748B' : color }}
                    >
                      {isSpeaking ? 'SPEAKING' : entry.isMasterController ? `MASTER · ${entry.status}` : entry.status}
                    </div>
                  </div>
                )}
              </button>
            );
          })}
        </div>

        {/* Progressive Disclosure Section Jumps */}
        <div className="mt-auto border-t border-white/10 p-2 space-y-1">
          {!compact && (
            <div className="px-2 py-1 flex items-center gap-1.5 text-[10px] font-mono uppercase tracking-wider text-slate-500">
              <SlidersHorizontal className="w-3 h-3" />
              <span>Operations</span>
            </div>
          )}
          {DRAWER_SECTIONS.map(({ id, label, icon: Icon }) => {
            const isOpen = activeSection === id;
            const showPendingCount = id === 'approvals' && pendingCount > 0;
            return (
              <button
                key={id}
                type="button"
                onClick={() => {
                  onSelectSection(id);
                  if (isMobileDrawer) onCloseMobile();
                }}
                title={label}
                className={`w-full min-h-[40px] flex items-center gap-2.5 rounded-lg px-2.5 py-1.5 text-xs transition-colors ${
                  isOpen
                    ? 'bg-amber-500/15 text-amber-200 border border-amber-400/30'
                    : 'text-slate-400 hover:text-slate-200 hover:bg-white/[0.04] border border-transparent'
                } ${compact ? 'justify-center px-1' : ''}`}
              >
                <Icon className="w-4 h-4 shrink-0" />
                {!compact && (
                  <>
                    <span className="truncate flex-1 text-left">{label}</span>
                    {showPendingCount && (
                      <span className="font-mono text-[11px] text-amber-300 tabular-nums shrink-0">
                        {pendingCount}
                      </span>
                    )}
                  </>
                )}
              </button>
            );
          })}
        </div>
      </div>
    );
  };

  return (
    <>
      {/* Desktop Collapsible Sidebar */}
      <aside
        className={`hidden lg:block shrink-0 transition-[width] duration-200 ${
          collapsed ? 'w-[72px]' : 'w-56'
        }`}
      >
        <div className="sticky top-14 h-[calc(100vh-3.5rem)]">
          {renderNavBody(false)}
        </div>
      </aside>

      {/* Mobile Slide-Over Drawer */}
      {mobileOpen && (
        <div className="fixed inset-0 z-50 lg:hidden flex">
          <div
            className="fixed inset-0 bg-black/70 backdrop-blur-xs"
            onClick={onCloseMobile}
            aria-hidden="true"
          />
          <div className="relative w-64 max-w-[82vw] h-full z-10 shadow-2xl">
            {renderNavBody(true)}
          </div>
        </div>
      )}
    </>
  );
}
