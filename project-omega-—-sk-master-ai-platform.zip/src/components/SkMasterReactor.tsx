import { useEffect, useRef, useState } from 'react';
import {
  AnimationQuality,
  AssemblyStage,
  AssistantId,
  AssistantRegistryEntry,
  InterfaceMode,
  VoiceState,
} from '../types/omega';

interface SkMasterReactorProps {
  interfaceMode: InterfaceMode;
  assemblyStage: AssemblyStage;
  activeIdentity: AssistantId;
  speakingAssistant: AssistantId | null;
  voiceState: VoiceState;
  voiceRmsLevel: number;
  animationQuality: AnimationQuality;
  registry: Record<AssistantId, AssistantRegistryEntry>;
  isRouting: boolean;
  isExecuting: boolean;
  onSelectCore: (id: AssistantId) => void;
}

const STAGE_LABELS: Record<AssemblyStage, string> = {
  IDLE: 'STANDBY',
  SYSTEM_INITIALIZING: 'SYSTEM INITIALIZING',
  CORE_DEPLOYMENT: 'CORE DEPLOYMENT',
  HOLOGRAPHIC_ASSEMBLY: 'HOLOGRAPHIC ASSEMBLY',
  CORE_SYNCHRONIZATION: 'CORE SYNCHRONIZATION',
  OMEGA_ONLINE: 'OMEGA ONLINE',
  DISASSEMBLING: 'DISASSEMBLING CORES',
};

const SATELLITE_LAYOUT: Array<{ id: Exclude<AssistantId, 'SK'>; rx: number; ry: number }> = [
  { id: 'JARVIS', rx: -0.32, ry: -0.29 },
  { id: 'MAGMITE', rx: 0.32, ry: -0.29 },
  { id: 'ULTRON', rx: -0.32, ry: 0.29 },
  { id: 'FRIDAY', rx: 0.32, ry: 0.29 },
];

interface FieldParticle {
  angle: number;
  radiusFactor: number;
  speed: number;
  verticalPhase: number;
  size: number;
  alpha: number;
  isBlue: boolean;
}

function createFieldParticles(count: number): FieldParticle[] {
  const list: FieldParticle[] = [];
  for (let i = 0; i < count; i += 1) {
    const s1 = (i * 1.61803398875) % 1;
    const s2 = (i * 2.718281828) % 1;
    list.push({
      angle: (i / count) * Math.PI * 2 + s1 * 0.4,
      radiusFactor: 0.38 + s1 * 0.56,
      speed: (i % 2 === 0 ? 1 : -1) * (0.24 + s2 * 0.46),
      verticalPhase: i * 0.85,
      size: 1.0 + s1 * 1.9,
      alpha: 0.26 + s2 * 0.5,
      isBlue: i % 2 === 0,
    });
  }
  return list;
}

function hexToRgb(hex: string): string {
  const clean = hex.replace('#', '');
  if (clean.length !== 6) return '56, 189, 248';
  const r = parseInt(clean.slice(0, 2), 16);
  const g = parseInt(clean.slice(2, 4), 16);
  const b = parseInt(clean.slice(4, 6), 16);
  if (Number.isNaN(r) || Number.isNaN(g) || Number.isNaN(b)) return '56, 189, 248';
  return `${r}, ${g}, ${b}`;
}

function drawTiltedEllipseRing(
  ctx: CanvasRenderingContext2D,
  cx: number,
  cy: number,
  rx: number,
  ry: number,
  tiltRad: number,
  startAngle: number,
  endAngle: number,
  strokeStyle: string,
  lineWidth: number,
  dashPattern: number[] = []
) {
  ctx.save();
  ctx.translate(cx, cy);
  ctx.rotate(tiltRad);
  ctx.strokeStyle = strokeStyle;
  ctx.lineWidth = lineWidth;
  ctx.lineCap = 'round';
  ctx.setLineDash(dashPattern);
  ctx.beginPath();
  ctx.ellipse(0, 0, rx, ry, 0, startAngle, endAngle);
  ctx.stroke();
  ctx.restore();
}

export function SkMasterReactor({
  interfaceMode,
  assemblyStage,
  activeIdentity,
  speakingAssistant,
  voiceState,
  voiceRmsLevel,
  animationQuality,
  registry,
  isRouting,
  isExecuting,
  onSelectCore,
}: SkMasterReactorProps) {
  const stageRef = useRef<HTMLDivElement | null>(null);
  const canvasRef = useRef<HTMLCanvasElement | null>(null);
  const [activating, setActivating] = useState(true);

  const phoenixWeightRef = useRef(0);
  const assemblyWeightRef = useRef(0);
  const angleRef = useRef(0);
  const simTimeRef = useRef(0);
  const voiceRmsRef = useRef(0);
  const voiceStateRef = useRef<VoiceState>('IDLE');
  const pointerRef = useRef({ x: 0, y: 0, targetX: 0, targetY: 0 });
  const particlesRef = useRef<FieldParticle[]>(createFieldParticles(34));
  const activationStartRef = useRef<number>(performance.now());
  const activatingRef = useRef(true);
  const sizeRef = useRef({ width: 620, height: 370 });

  voiceRmsRef.current = voiceRmsLevel;
  voiceStateRef.current = voiceState;
  activatingRef.current = activating;

  useEffect(() => {
    activationStartRef.current = performance.now();
    setActivating(true);
    const timer = window.setTimeout(() => setActivating(false), 1200);
    return () => window.clearTimeout(timer);
  }, []);

  useEffect(() => {
    const stage = stageRef.current;
    if (!stage) return;
    const updateSize = () => {
      const rect = stage.getBoundingClientRect();
      sizeRef.current = {
        width: Math.max(280, Math.round(rect.width)),
        height: Math.max(260, Math.round(rect.height)),
      };
    };
    updateSize();
    const observer = typeof ResizeObserver !== 'undefined' ? new ResizeObserver(updateSize) : null;
    observer?.observe(stage);
    window.addEventListener('resize', updateSize);
    return () => {
      observer?.disconnect();
      window.removeEventListener('resize', updateSize);
    };
  }, []);

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    const systemReducedMotion = window.matchMedia('(prefers-reduced-motion: reduce)').matches;
    let rafId = 0;
    let isDisposed = false;
    let isHidden = typeof document !== 'undefined' && document.hidden;
    let lastDrawTime = performance.now();

    const targetAssemblyWeight = () => {
      if (interfaceMode === 'ASSEMBLED') {
        switch (assemblyStage) {
          case 'SYSTEM_INITIALIZING':
            return 0.16;
          case 'CORE_DEPLOYMENT':
            return 0.48;
          case 'HOLOGRAPHIC_ASSEMBLY':
            return 0.8;
          case 'CORE_SYNCHRONIZATION':
            return 0.95;
          case 'OMEGA_ONLINE':
            return 1.0;
          case 'DISASSEMBLING':
            return 0.12;
          default:
            return 1.0;
        }
      }
      if (assemblyStage === 'DISASSEMBLING') return 0.12;
      return 0;
    };

    const draw = (timestamp: number) => {
      if (isDisposed || isHidden) return;

      const frameBudget =
        systemReducedMotion || animationQuality === 'REDUCED_MOTION'
          ? 120
          : animationQuality === 'BATTERY_SAVER_30FPS'
            ? 33
            : 16;

      const elapsed = timestamp - lastDrawTime;
      if (elapsed < frameBudget && simTimeRef.current > 0) {
        rafId = requestAnimationFrame(draw);
        return;
      }
      const dt = Math.min(0.05, Math.max(0.008, elapsed / 1000));
      lastDrawTime = timestamp;

      const dpr = Math.min(window.devicePixelRatio || 1, 2);
      const { width, height } = sizeRef.current;
      if (canvas.width !== Math.round(width * dpr) || canvas.height !== Math.round(height * dpr)) {
        canvas.width = Math.round(width * dpr);
        canvas.height = Math.round(height * dpr);
      }

      // Smoothly interpolate Phoenix Wings & Five-Core Assembly weights
      const phoenixTarget = interfaceMode === 'PHOENIX' ? 1 : 0;
      phoenixWeightRef.current += (phoenixTarget - phoenixWeightRef.current) * 0.095;

      const asmTarget = targetAssemblyWeight();
      assemblyWeightRef.current += (asmTarget - assemblyWeightRef.current) * 0.1;

      const pw = phoenixWeightRef.current;
      const aw = assemblyWeightRef.current;
      const currentVoice = voiceStateRef.current;
      const rms = voiceRmsRef.current;
      const isThinking = isRouting || isExecuting || currentVoice === 'PROCESSING' || currentVoice === 'RESPONDING';
      const isSpeaking = currentVoice === 'SPEAKING' || speakingAssistant === 'SK';
      const isListening = currentVoice === 'LISTENING';
      const skEnabled = registry.SK?.isEnabled ?? true;

      const speed =
        systemReducedMotion || animationQuality === 'REDUCED_MOTION'
          ? 0.004
          : !skEnabled
            ? 0.002
            : isThinking || interfaceMode === 'PHOENIX'
              ? 0.024
              : isSpeaking || isListening
                ? 0.017 + rms * 0.014
                : 0.011;

      angleRef.current += speed;
      simTimeRef.current += dt * (isThinking ? 1.8 : isSpeaking ? 1.5 : 1.0);
      const angle = angleRef.current;
      const simTime = simTimeRef.current;
      const pulse = 0.84 + 0.16 * Math.sin(angle * 2.2);
      const actProgress = Math.min(1, Math.max(0, (timestamp - activationStartRef.current) / 1200));
      const actScale = activatingRef.current ? 0.52 + 0.48 * Math.sin(actProgress * (Math.PI / 2)) : 1;

      const ptr = pointerRef.current;
      ptr.x += (ptr.targetX - ptr.x) * 0.08;
      ptr.y += (ptr.targetY - ptr.y) * 0.08;
      const parallaxX = ptr.x * 8 + Math.sin(simTime * 0.55) * 2.6;
      const parallaxY = ptr.y * 5.5 + Math.cos(simTime * 0.45) * 2.0;
      const levitationY =
        systemReducedMotion || animationQuality === 'REDUCED_MOTION' || interfaceMode === 'ASSEMBLED'
          ? 0
          : Math.sin(simTime * 1.25) * 4.5;

      ctx.save();
      ctx.scale(dpr, dpr);
      ctx.clearRect(0, 0, width, height);

      const cx = width / 2 + parallaxX * 0.35;
      const cy = height / 2 + levitationY + parallaxY * 0.35;
      const baseR = Math.min(width, height) * (aw > 0.2 ? 0.23 : 0.27) * actScale;

      // 1. Cinematic Blue + Orange-Gold Open-Space Volumetric Atmospheric Lighting
      const auraR = Math.min(width, height) * 0.56;
      const goldAura = ctx.createRadialGradient(cx, cy, baseR * 0.15, cx, cy, auraR);
      goldAura.addColorStop(0, `rgba(255, 168, 48, ${0.26 + 0.1 * pw})`);
      goldAura.addColorStop(0.32, `rgba(56, 189, 248, ${0.15 + 0.08 * pw})`);
      goldAura.addColorStop(0.65, `rgba(255, 140, 26, ${0.06 + 0.06 * pw})`);
      goldAura.addColorStop(1, 'rgba(5, 6, 8, 0)');
      ctx.fillStyle = goldAura;
      ctx.beginPath();
      ctx.arc(cx, cy, auraR, 0, Math.PI * 2);
      ctx.fill();

      // Symmetrical horizontal blue/amber wing glow halo behind core ONLY in Phoenix Mode
      if (pw > 0.02) {
        const wingGlowR = Math.min(width * 0.48, baseR * 3.1);
        const wingBack = ctx.createRadialGradient(cx, cy - baseR * 0.12, baseR * 0.4, cx, cy, wingGlowR);
        wingBack.addColorStop(0, `rgba(56, 189, 248, ${0.22 * pw})`);
        wingBack.addColorStop(0.45, `rgba(255, 140, 26, ${0.14 * pw})`);
        wingBack.addColorStop(1, 'rgba(5, 6, 8, 0)');
        ctx.fillStyle = wingBack;
        ctx.beginPath();
        ctx.ellipse(cx, cy - baseR * 0.1, wingGlowR, baseR * 1.65, 0, 0, Math.PI * 2);
        ctx.fill();
      }

      // 2. PHOENIX WINGS LAYER (ONLY rendered when Phoenix Mode active/transitioning — ZERO wings in Normal Mode)
      if (pw > 0.02) {
        const wingBreath = 1 + 0.045 * Math.sin(simTime * 2.6);
        const spanScale = Math.min((width * 0.47) / (baseR * 2.85), 1.18) * pw * wingBreath;

        for (const side of [-1, 1]) {
          // Outer Blue & Orange-Gold Primary Pinion Feathers (6 layered luminous wing plumes)
          for (let f = 0; f < 6; f += 1) {
            const reach = (1.68 + f * 0.21) * spanScale;
            const archY = baseR * (1.28 - f * 0.17) * wingBreath;
            const tipY = cy - baseR * (0.88 - f * 0.27) * pw;
            const rootX = cx + side * baseR * 0.88;
            const rootY = cy + (f - 2.2) * (baseR * 0.11);
            const ctrlX = cx + side * baseR * (1.42 + f * 0.14) * spanScale;
            const ctrlY = cy - archY + Math.sin(simTime * 3.1 + f * 0.55) * (4 * pw);
            const tipX = cx + side * baseR * (reach + 0.82);

            const isCyanFeather = f === 0 || f === 2 || f === 4;
            const grad = ctx.createLinearGradient(rootX, rootY, tipX, tipY);
            if (isCyanFeather) {
              grad.addColorStop(0, `rgba(255, 198, 92, ${0.88 * pw})`);
              grad.addColorStop(0.42, `rgba(56, 189, 248, ${0.92 * pw})`);
              grad.addColorStop(1, `rgba(186, 230, 253, ${0.18 * pw})`);
            } else {
              grad.addColorStop(0, `rgba(56, 189, 248, ${0.75 * pw})`);
              grad.addColorStop(0.38, `rgba(255, 140, 26, ${0.92 * pw})`);
              grad.addColorStop(1, `rgba(255, 223, 142, ${0.15 * pw})`);
            }

            // Soft outer plasma glow stroke
            ctx.save();
            ctx.strokeStyle = isCyanFeather
              ? `rgba(56, 189, 248, ${0.28 * pw * pulse})`
              : `rgba(255, 140, 26, ${0.32 * pw * pulse})`;
            ctx.lineWidth = Math.max(4, 11 - f * 1.1);
            ctx.lineCap = 'round';
            ctx.beginPath();
            ctx.moveTo(rootX, rootY);
            ctx.quadraticCurveTo(ctrlX, ctrlY, tipX, tipY);
            ctx.stroke();

            // Crisp plasma feather vein core
            ctx.strokeStyle = grad;
            ctx.lineWidth = Math.max(1.8, 4.4 - f * 0.42);
            ctx.beginPath();
            ctx.moveTo(rootX, rootY);
            ctx.quadraticCurveTo(ctrlX, ctrlY, tipX, tipY);
            ctx.stroke();

            // Swept trailing secondary plasma barbule
            if (f < 4) {
              ctx.strokeStyle = isCyanFeather
                ? `rgba(125, 211, 252, ${0.42 * pw})`
                : `rgba(255, 184, 48, ${0.45 * pw})`;
              ctx.lineWidth = 1.2;
              ctx.beginPath();
              ctx.moveTo((rootX + ctrlX) * 0.5, (rootY + ctrlY) * 0.5);
              ctx.quadraticCurveTo(
                ctrlX + side * baseR * 0.16,
                ctrlY + baseR * 0.28,
                tipX - side * baseR * 0.18,
                tipY + baseR * 0.24
              );
              ctx.stroke();
            }
            ctx.restore();
          }

          // Lower Symmetrical Tail Plumes
          for (let t = 0; t < 2; t += 1) {
            const tx = cx + side * baseR * (1.28 + t * 0.36) * spanScale;
            const ty = cy + baseR * (0.92 + t * 0.22) * pw;
            ctx.strokeStyle = t === 0 ? `rgba(56, 189, 248, ${0.58 * pw})` : `rgba(255, 168, 48, ${0.55 * pw})`;
            ctx.lineWidth = 2.1;
            ctx.lineCap = 'round';
            ctx.beginPath();
            ctx.moveTo(cx + side * baseR * 0.7, cy + baseR * 0.4);
            ctx.quadraticCurveTo(cx + side * baseR * 1.15 * spanScale, cy + baseR * 0.72, tx, ty);
            ctx.stroke();
          }
        }

        // Dual Cyan + Orange-Gold Expanding Phoenix Shockwaves
        for (let s = 0; s < 2; s += 1) {
          const wave = (simTime * 0.42 + s * 0.5) % 1;
          ctx.strokeStyle =
            s === 0
              ? `rgba(56, 189, 248, ${(1 - wave) * 0.42 * pw})`
              : `rgba(255, 140, 26, ${(1 - wave) * 0.46 * pw})`;
          ctx.lineWidth = 2.0 - wave * 0.8;
          ctx.beginPath();
          ctx.arc(cx, cy, baseR * (1.12 + wave * 1.05), 0, Math.PI * 2);
          ctx.stroke();
        }
      }

      // 3. Open-Space Blue & Orange-Gold Rotating 3D Orbital Rings (Shared by Normal & Phoenix Modes!)
      if (aw < 0.2) {
        // Back-plane 3D blue + gold rings behind SK reactor
        drawTiltedEllipseRing(
          ctx,
          cx - parallaxX * 0.2,
          cy - parallaxY * 0.2,
          baseR * 1.54,
          baseR * 0.58,
          0.36 + Math.sin(simTime * 0.4) * 0.05,
          Math.PI,
          Math.PI * 2,
          'rgba(56, 189, 248, 0.34)',
          1.75,
          [22, 10]
        );
        drawTiltedEllipseRing(
          ctx,
          cx - parallaxX * 0.2,
          cy - parallaxY * 0.2,
          baseR * 1.42,
          baseR * 0.52,
          -0.44 - Math.cos(simTime * 0.35) * 0.05,
          Math.PI,
          Math.PI * 2,
          'rgba(255, 184, 48, 0.32)',
          1.55,
          [14, 9]
        );

        // Dual-tone outer circular holographic reticle rings
        ctx.save();
        ctx.translate(cx, cy);
        ctx.rotate(simTime * 0.32);
        ctx.strokeStyle = isListening ? 'rgba(56, 189, 248, 0.72)' : 'rgba(56, 189, 248, 0.48)';
        ctx.lineWidth = 1.6;
        ctx.setLineDash([28, 14, 6, 14]);
        ctx.beginPath();
        ctx.arc(0, 0, baseR * 1.24, 0, Math.PI * 2);
        ctx.stroke();
        ctx.restore();

        ctx.save();
        ctx.translate(cx, cy);
        ctx.rotate(-simTime * 0.26);
        ctx.strokeStyle = 'rgba(255, 168, 48, 0.42)';
        ctx.lineWidth = 1.25;
        ctx.setLineDash([18, 18]);
        ctx.beginPath();
        ctx.arc(0, 0, baseR * 1.38, 0, Math.PI * 2);
        ctx.stroke();
        ctx.restore();
      }

      // Floating Dual-Tone Energy Particles (Blue + Orange-Gold, plus rising Phoenix embers)
      const particles = particlesRef.current;
      for (let i = 0; i < particles.length; i += 1) {
        const pt = particles[i];
        const theta = pt.angle + simTime * pt.speed;
        const convergePull =
          activatingRef.current
            ? 1.45 - 0.45 * actProgress
            : assemblyStage === 'SYSTEM_INITIALIZING'
              ? 1.3 - aw
              : 1.0;
        const pr = Math.min(width, height) * 0.46 * pt.radiusFactor * convergePull;
        const px = cx + Math.cos(theta) * pr + parallaxX * 0.3;
        const pyRise = pw > 0.05 ? ((simTime * 22 + i * 19) % (baseR * 2.1)) * pw * 0.35 : 0;
        const py =
          cy +
          Math.sin(theta) * pr * 0.62 +
          Math.sin(simTime * 1.4 + pt.verticalPhase) * 6 -
          pyRise;
        const twinkle = 0.55 + 0.45 * Math.sin(simTime * 2.5 + pt.verticalPhase);
        ctx.fillStyle = pt.isBlue
          ? `rgba(56, 189, 248, ${(pt.alpha + 0.14 * pw) * twinkle})`
          : `rgba(255, 184, 48, ${(pt.alpha + 0.14 * pw) * twinkle})`;
        ctx.beginPath();
        ctx.arc(px, py, pt.size + 0.4 * pw, 0, Math.PI * 2);
        ctx.fill();
      }

      // 4. Five-Core Open Floating Assembly (SK ASSEMBLE ALL / DISASSEMBLE)
      if (aw > 0.02) {
        if (assemblyStage === 'CORE_SYNCHRONIZATION' || assemblyStage === 'OMEGA_ONLINE') {
          const syncWave = (simTime * 0.55) % 1;
          ctx.strokeStyle = `rgba(56, 189, 248, ${(1 - syncWave) * 0.34 * aw})`;
          ctx.lineWidth = 1.6;
          ctx.beginPath();
          ctx.arc(cx, cy, baseR + syncWave * Math.min(width, height) * 0.42, 0, Math.PI * 2);
          ctx.stroke();
        }

        SATELLITE_LAYOUT.forEach((sat, idx) => {
          const entry = registry[sat.id];
          const enabled = Boolean(entry?.isEnabled && entry?.status !== 'DISABLED');
          const accent = enabled ? entry.visualIdentity.primaryColor : '#475569';
          const accentRgb = enabled ? hexToRgb(accent) : '71, 85, 105';
          const floatOffset = enabled ? Math.sin(simTime * 1.6 + idx * 1.3) * 3.5 : 0;
          const sx = cx + sat.rx * width * aw + parallaxX * 0.2;
          const sy = cy + sat.ry * height * aw + floatOffset + parallaxY * 0.2;

          if (aw > 0.52 && enabled) {
            ctx.save();
            ctx.strokeStyle = `rgba(56, 189, 248, ${0.58 * aw})`;
            ctx.lineWidth = 1.65;
            ctx.setLineDash([10, 6]);
            ctx.lineDashOffset = -angle * 40;
            ctx.beginPath();
            ctx.moveTo(cx, cy);
            ctx.lineTo(sx, sy);
            ctx.stroke();
            ctx.restore();

            if (assemblyStage === 'CORE_SYNCHRONIZATION' || assemblyStage === 'OMEGA_ONLINE') {
              const t = (angle * 0.4 + idx * 0.25) % 1;
              const px = cx + (sx - cx) * t;
              const py = cy + (sy - cy) * t;
              ctx.fillStyle = speakingAssistant === sat.id ? accent : '#38BDF8';
              ctx.beginPath();
              ctx.arc(px, py, 3.6, 0, Math.PI * 2);
              ctx.fill();
            }
          }

          const nodeR = 30 * Math.max(0.45, aw);
          const highlighted = activeIdentity === sat.id || speakingAssistant === sat.id;

          const satAura = ctx.createRadialGradient(sx, sy, nodeR * 0.15, sx, sy, nodeR * 1.45);
          satAura.addColorStop(0, `rgba(${accentRgb}, ${enabled ? (speakingAssistant === sat.id ? 0.5 : 0.34) : 0.12})`);
          satAura.addColorStop(0.55, `rgba(${accentRgb}, ${enabled ? 0.14 : 0.04})`);
          satAura.addColorStop(1, 'rgba(5, 6, 8, 0)');
          ctx.fillStyle = satAura;
          ctx.beginPath();
          ctx.arc(sx, sy, nodeR * 1.45, 0, Math.PI * 2);
          ctx.fill();

          ctx.save();
          ctx.translate(sx, sy);
          if (enabled) ctx.rotate(angle * (idx % 2 === 0 ? 1.2 : -1.2));
          ctx.strokeStyle = accent;
          ctx.globalAlpha = enabled ? (highlighted ? 1 : 0.8) : 0.38;
          ctx.lineWidth = highlighted && enabled ? 2.4 : 1.5;
          ctx.setLineDash(sat.id === 'ULTRON' ? [8, 5] : [14, 7]);
          ctx.beginPath();
          ctx.arc(0, 0, nodeR, 0, Math.PI * 2);
          ctx.stroke();

          if (enabled) {
            ctx.rotate(idx * 0.7 + simTime * 0.45);
            ctx.strokeStyle = `rgba(${accentRgb}, 0.55)`;
            ctx.lineWidth = 1.1;
            ctx.setLineDash([]);
            ctx.beginPath();
            ctx.ellipse(0, 0, nodeR * 0.88, nodeR * 0.36, 0.35, 0, Math.PI * 2);
            ctx.stroke();
          }

          const satNodes = entry?.visualIdentity.orbitalNodes ?? 4;
          ctx.strokeStyle = `rgba(${accentRgb}, ${enabled ? 0.58 : 0.22})`;
          ctx.lineWidth = 1;
          ctx.beginPath();
          for (let k = 0; k <= satNodes; k += 1) {
            const kTheta = (k * Math.PI * 2) / satNodes + (sat.id === 'FRIDAY' ? Math.PI / 4 : 0);
            const kx = Math.cos(kTheta) * (nodeR * 0.62);
            const ky = Math.sin(kTheta) * (nodeR * 0.62);
            if (k === 0) ctx.moveTo(kx, ky);
            else ctx.lineTo(kx, ky);
          }
          ctx.stroke();

          if (enabled) {
            for (let k = 0; k < satNodes; k += 1) {
              const kTheta = (k * Math.PI * 2) / satNodes + simTime * (idx % 2 === 0 ? 1.1 : -1.1);
              ctx.fillStyle = accent;
              ctx.beginPath();
              ctx.arc(Math.cos(kTheta) * nodeR, Math.sin(kTheta) * nodeR, 2.2, 0, Math.PI * 2);
              ctx.fill();
            }
          }
          ctx.restore();

          if (aw > 0.55 && enabled) {
            ctx.strokeStyle = `rgba(56, 189, 248, ${0.34 * aw})`;
            ctx.lineWidth = 1;
            ctx.beginPath();
            ctx.arc(sx, sy, nodeR + 6, 0, Math.PI * 2);
            ctx.stroke();
          }

          ctx.globalAlpha = 1;
          ctx.fillStyle = enabled ? '#F8FAFC' : '#64748B';
          ctx.font = '600 10px "JetBrains Mono", monospace';
          ctx.textAlign = 'center';
          ctx.textBaseline = 'middle';
          ctx.fillText(sat.id, sx, sy - 4);
          ctx.fillStyle = accent;
          ctx.font = '500 8px "JetBrains Mono", monospace';
          ctx.fillText(
            !enabled ? 'OFFLINE' : speakingAssistant === sat.id ? 'SPEAKING' : entry.status,
            sx,
            sy + 8
          );
        });
      }

      // 5. LOCKED SK MASTER MECHANICAL REACTOR (Exact Centered Identity Preserved in Both Normal & Phoenix Modes)
      ctx.fillStyle = '#0B1018';
      ctx.beginPath();
      ctx.arc(cx, cy, baseR, 0, Math.PI * 2);
      ctx.fill();

      // Subtle blue-tinted outer rim + warm bronze mechanical ring
      ctx.strokeStyle = 'rgba(56, 189, 248, 0.55)';
      ctx.lineWidth = 2;
      ctx.beginPath();
      ctx.arc(cx, cy, baseR + 2, 0, Math.PI * 2);
      ctx.stroke();

      ctx.strokeStyle = '#5B3110';
      ctx.lineWidth = 7;
      ctx.beginPath();
      ctx.arc(cx, cy, baseR, 0, Math.PI * 2);
      ctx.stroke();

      // 12-Notch Mechanical Stator Arcs
      ctx.save();
      ctx.translate(cx, cy);
      ctx.rotate(angle * 0.45);
      for (let i = 0; i < 12; i += 1) {
        const start = (i * Math.PI * 2) / 12;
        ctx.strokeStyle = i % 2 === 0 ? '#FF8C1A' : i % 4 === 1 ? '#38BDF8' : 'rgba(255, 184, 48, 0.75)';
        ctx.lineWidth = 4;
        ctx.beginPath();
        ctx.arc(0, 0, baseR * 0.87, start, start + 0.28);
        ctx.stroke();
      }
      ctx.restore();

      // Counter-Rotating Inner Turbine Ring + 8 Radial Cooling Fins
      ctx.save();
      ctx.translate(cx, cy);
      ctx.rotate(-angle * 0.85);
      ctx.strokeStyle = 'rgba(255, 184, 48, 0.88)';
      ctx.lineWidth = 2;
      ctx.setLineDash([22, 10]);
      ctx.beginPath();
      ctx.arc(0, 0, baseR * 0.71, 0, Math.PI * 2);
      ctx.stroke();
      ctx.setLineDash([]);

      for (let i = 0; i < 8; i += 1) {
        const rad = (i * Math.PI) / 4;
        ctx.strokeStyle = i % 2 === 0 ? 'rgba(255, 140, 26, 0.82)' : 'rgba(56, 189, 248, 0.65)';
        ctx.lineWidth = 2;
        ctx.beginPath();
        ctx.moveTo(Math.cos(rad) * baseR * 0.5, Math.sin(rad) * baseR * 0.5);
        ctx.lineTo(Math.cos(rad) * baseR * 0.68, Math.sin(rad) * baseR * 0.68);
        ctx.stroke();
      }
      ctx.restore();

      // Molten Gold + Cyan Core Aperture
      const activeGlow = speakingAssistant === 'SK' || isRouting || isExecuting ? 1 : pulse;
      const coreGrad = ctx.createRadialGradient(cx, cy, 4, cx, cy, baseR * 0.47);
      coreGrad.addColorStop(0, `rgba(255, 223, 142, ${0.92 * activeGlow})`);
      coreGrad.addColorStop(0.55, `rgba(255, 140, 26, ${0.68 + 0.22 * pw})`);
      coreGrad.addColorStop(1, '#140E08');
      ctx.fillStyle = coreGrad;
      ctx.beginPath();
      ctx.arc(cx, cy, baseR * 0.46, 0, Math.PI * 2);
      ctx.fill();

      ctx.strokeStyle = '#FFB830';
      ctx.lineWidth = 2;
      ctx.beginPath();
      ctx.arc(cx, cy, baseR * 0.46, 0, Math.PI * 2);
      ctx.stroke();

      // Front-Plane 3D Tilted Blue + Orange-Gold Rings Passing Across Reactor Depth
      if (aw < 0.2) {
        drawTiltedEllipseRing(
          ctx,
          cx + parallaxX * 0.2,
          cy + parallaxY * 0.2,
          baseR * 1.54,
          baseR * 0.58,
          0.36 + Math.sin(simTime * 0.4) * 0.05,
          0,
          Math.PI,
          'rgba(56, 189, 248, 0.78)',
          1.85,
          [22, 10]
        );
        drawTiltedEllipseRing(
          ctx,
          cx + parallaxX * 0.2,
          cy + parallaxY * 0.2,
          baseR * 1.42,
          baseR * 0.52,
          -0.44 - Math.cos(simTime * 0.35) * 0.05,
          0,
          Math.PI,
          'rgba(255, 184, 48, 0.74)',
          1.6,
          [14, 9]
        );
      }

      // Live 36-Bar Radial Audio Waveform Ring during Voice Interaction
      if (
        currentVoice === 'LISTENING' ||
        currentVoice === 'SPEAKING' ||
        currentVoice === 'PROCESSING' ||
        currentVoice === 'RESPONDING'
      ) {
        const waveColor =
          currentVoice === 'LISTENING'
            ? '#38BDF8'
            : currentVoice === 'PROCESSING' || currentVoice === 'RESPONDING'
              ? '#FBBF24'
              : speakingAssistant
                ? registry[speakingAssistant]?.visualIdentity.primaryColor || '#FFB830'
                : '#FFB830';
        const bars = 36;
        const innerR = baseR + 14;
        ctx.save();
        ctx.strokeStyle = waveColor;
        ctx.lineWidth = 2.2;
        ctx.lineCap = 'round';
        ctx.globalAlpha = 0.86;
        for (let i = 0; i < bars; i += 1) {
          const theta = (i * Math.PI * 2) / bars + angle * 0.6;
          const harmonic = 0.45 + 0.55 * Math.abs(Math.sin(angle * 4.5 + i * 0.65));
          const amplitude =
            currentVoice === 'PROCESSING' || currentVoice === 'RESPONDING'
              ? 6 + 6 * harmonic
              : currentVoice === 'LISTENING'
                ? 5 + (6 + 18 * Math.max(0.14, rms)) * harmonic
                : 4 + (8 + 20 * Math.max(0.18, rms)) * harmonic;
          ctx.beginPath();
          ctx.moveTo(cx + Math.cos(theta) * innerR, cy + Math.sin(theta) * innerR);
          ctx.lineTo(
            cx + Math.cos(theta) * (innerR + amplitude),
            cy + Math.sin(theta) * (innerR + amplitude)
          );
          ctx.stroke();
        }
        ctx.restore();
      }

      ctx.restore();
      rafId = requestAnimationFrame(draw);
    };

    const handleVisibility = () => {
      isHidden = document.hidden;
      if (!isHidden && !isDisposed) {
        lastDrawTime = performance.now();
        rafId = requestAnimationFrame(draw);
      }
    };

    document.addEventListener('visibilitychange', handleVisibility);
    rafId = requestAnimationFrame(draw);
    return () => {
      isDisposed = true;
      document.removeEventListener('visibilitychange', handleVisibility);
      cancelAnimationFrame(rafId);
    };
  }, [interfaceMode, assemblyStage, activeIdentity, speakingAssistant, animationQuality, registry, isRouting, isExecuting]);

  const handleCanvasClick = (e: React.MouseEvent<HTMLCanvasElement>) => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const rect = canvas.getBoundingClientRect();
    const x = e.clientX - rect.left;
    const y = e.clientY - rect.top;
    const cx = rect.width / 2;
    const cy = rect.height / 2;

    if (interfaceMode === 'ASSEMBLED') {
      for (const sat of SATELLITE_LAYOUT) {
        const sx = cx + sat.rx * rect.width;
        const sy = cy + sat.ry * rect.height;
        if (Math.hypot(x - sx, y - sy) <= 38) {
          onSelectCore(sat.id);
          return;
        }
      }
    }
    if (Math.hypot(x - cx, y - cy) <= 95) {
      onSelectCore('SK');
    }
  };

  // Minimal centered identity label only (clean open-space display without perimeter dashboard strips)
  const centerSubtitle = activating
    ? 'ACTIVATING'
    : voiceState === 'LISTENING'
      ? 'LISTENING'
      : isRouting || isExecuting || voiceState === 'PROCESSING' || voiceState === 'RESPONDING'
        ? 'THINKING'
        : voiceState === 'SPEAKING' && speakingAssistant
          ? speakingAssistant
          : assemblyStage !== 'IDLE' && assemblyStage !== 'OMEGA_ONLINE'
            ? STAGE_LABELS[assemblyStage]
            : interfaceMode === 'PHOENIX'
              ? 'PHOENIX'
              : interfaceMode === 'ASSEMBLED'
                ? 'OMEGA ONLINE'
                : 'MASTER';

  return (
    <div
      className="relative w-full flex flex-col items-center justify-center select-none"
      onPointerMove={(e) => {
        const rect = e.currentTarget.getBoundingClientRect();
        if (rect.width <= 0 || rect.height <= 0) return;
        pointerRef.current.targetX = Math.max(-1, Math.min(1, ((e.clientX - rect.left) / rect.width - 0.5) * 2));
        pointerRef.current.targetY = Math.max(-1, Math.min(1, ((e.clientY - rect.top) / rect.height - 0.5) * 2));
      }}
      onPointerLeave={() => {
        pointerRef.current.targetX = 0;
        pointerRef.current.targetY = 0;
      }}
    >
      {/* Pure Open-Space Floating SK Master Reactor Stage (Zero Rectangular Framing) */}
      <div
        ref={stageRef}
        className="relative w-full h-[clamp(275px,44vh,395px)] flex items-center justify-center overflow-visible"
      >
        <canvas
          ref={canvasRef}
          onClick={handleCanvasClick}
          className="w-full h-full cursor-pointer block"
          aria-label={
            interfaceMode === 'PHOENIX'
              ? 'SK Master Phoenix Floating Holographic Core'
              : 'SK Master Normal Floating Holographic Core'
          }
        />

        {/* Centered SK Master Identity */}
        <div className="absolute inset-0 flex flex-col items-center justify-center pointer-events-none">
          <span className="font-display text-lg sm:text-xl font-bold tracking-wider text-amber-100 drop-shadow-[0_2px_10px_rgba(0,0,0,0.95)]">
            SK
          </span>
          <span className="font-mono text-[9px] tracking-[0.22em] text-sky-300/95 mt-0.5 drop-shadow-[0_1px_6px_rgba(0,0,0,0.95)]">
            {centerSubtitle}
          </span>
        </div>
      </div>
    </div>
  );
}
