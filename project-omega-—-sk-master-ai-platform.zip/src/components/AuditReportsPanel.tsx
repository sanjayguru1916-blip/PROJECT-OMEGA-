import { AlertTriangle, FileBarChart2, ShieldCheck } from 'lucide-react';
import { OmegaPlatformState } from '../types/omega';

interface AuditReportsPanelProps {
  state: OmegaPlatformState;
  generatingReport: boolean;
  onGenerateReport: () => void;
  onAcknowledgeAlert: (alertId: string) => void;
}

export function AuditReportsPanel({
  state,
  generatingReport,
  onGenerateReport,
  onAcknowledgeAlert,
}: AuditReportsPanelProps) {
  const unacknowledged = state.alerts.filter((a) => !a.acknowledged);
  const completedCount = state.taskHistory.filter((t) => t.status === 'COMPLETED').length;
  const rejectedCount = state.taskHistory.filter((t) => t.status === 'REJECTED' || t.status === 'DENIED').length;

  return (
    <div className="space-y-8">
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4 border-b border-white/10 pb-5">
        <div>
          <h2 className="font-display text-xl font-semibold text-white">
            Monitoring, Periodic System Reports & Audit Trail
          </h2>
          <p className="text-sm text-slate-400 mt-1">
            SK tracks every command proposal, explicit user decision, permission block, and execution outcome in a SHA-256 hash-chained log.
          </p>
        </div>
        <button
          onClick={onGenerateReport}
          disabled={generatingReport}
          className="inline-flex items-center gap-2 px-4 py-2 text-sm font-medium bg-sky-400 text-slate-950 rounded-lg hover:bg-sky-300 disabled:opacity-50 transition-colors whitespace-nowrap shrink-0"
        >
          <FileBarChart2 className="w-4 h-4" />
          {generatingReport ? 'Synthesizing Report...' : 'Generate System Report'}
        </button>
      </div>

      {/* Real Telemetry Summary Strip */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
        <div className="bg-[#111827] border border-white/10 rounded-xl p-4">
          <div className="text-xs text-slate-400">Pending Approvals</div>
          <div className="text-2xl font-display font-semibold text-white mt-1 tabular-nums">
            {state.pendingProposals.length}
          </div>
        </div>
        <div className="bg-[#111827] border border-white/10 rounded-xl p-4">
          <div className="text-xs text-slate-400">Approved & Executed</div>
          <div className="text-2xl font-display font-semibold text-emerald-400 mt-1 tabular-nums">
            {completedCount}
          </div>
        </div>
        <div className="bg-[#111827] border border-white/10 rounded-xl p-4">
          <div className="text-xs text-slate-400">Rejected / Denied</div>
          <div className="text-2xl font-display font-semibold text-amber-400 mt-1 tabular-nums">
            {rejectedCount}
          </div>
        </div>
        <div className="bg-[#111827] border border-white/10 rounded-xl p-4">
          <div className="text-xs text-slate-400">Chained Audit Records</div>
          <div className="text-2xl font-display font-semibold text-sky-400 mt-1 tabular-nums">
            {state.auditLogs.length}
          </div>
        </div>
      </div>

      {/* System Alerts */}
      <section className="space-y-3">
        <h3 className="font-display text-base font-semibold text-white">
          System Alerts ({unacknowledged.length} active)
        </h3>
        {unacknowledged.length === 0 ? (
          <div className="bg-[#111827] border border-white/10 rounded-xl p-4 text-sm text-slate-400 flex items-center gap-2.5">
            <ShieldCheck className="w-4 h-4 text-emerald-400 shrink-0" />
            <span>No unacknowledged errors or security alerts. All active assistants nominal.</span>
          </div>
        ) : (
          <div className="space-y-2">
            {unacknowledged.map((alert) => (
              <div
                key={alert.alertId}
                className="bg-[#111827] border border-red-500/40 rounded-xl p-4 flex flex-col sm:flex-row sm:items-center justify-between gap-3"
              >
                <div className="space-y-1">
                  <div className="flex items-center gap-2 text-xs font-mono text-red-400">
                    <AlertTriangle className="w-3.5 h-3.5" />
                    <span>{alert.severity}</span>
                    <span aria-hidden="true">·</span>
                    <span>{alert.source}</span>
                    <span aria-hidden="true">·</span>
                    <span className="tabular-nums">{new Date(alert.createdAtEpochMs).toLocaleTimeString()}</span>
                  </div>
                  <div className="text-sm font-medium text-white">{alert.title}</div>
                  <div className="text-sm text-slate-300">{alert.message}</div>
                </div>
                <button
                  onClick={() => onAcknowledgeAlert(alert.alertId)}
                  className="px-3 py-1.5 text-xs font-medium text-slate-200 bg-white/5 hover:bg-white/10 rounded-lg transition-colors whitespace-nowrap shrink-0"
                >
                  Acknowledge
                </button>
              </div>
            ))}
          </div>
        )}
      </section>

      {/* Periodic SK System Reports */}
      <section className="space-y-3">
        <h3 className="font-display text-base font-semibold text-white">
          Periodic SK System Reports
        </h3>
        {state.reports.length === 0 ? (
          <div className="bg-[#111827] border border-white/10 rounded-xl p-6 text-sm text-slate-400">
            No system reports generated yet. Click "Generate System Report" above to trigger SK telemetry synthesis via Gemini.
          </div>
        ) : (
          <div className="space-y-3">
            {state.reports.map((report) => (
              <div key={report.reportId} className="bg-[#111827] border border-white/10 rounded-xl p-4 space-y-2">
                <div className="flex flex-wrap items-center justify-between gap-2 text-xs font-mono text-slate-400">
                  <span className="text-sky-400">{report.reportId} · {report.periodLabel}</span>
                  <span className="tabular-nums">
                    {new Date(report.generatedAtEpochMs).toLocaleString()} · {report.approvedTasks}/{report.totalCommands} approved · {report.rejectedTasks} rejected · {report.failedTasks} failed
                  </span>
                </div>
                <p className="text-sm text-slate-200 leading-relaxed">{report.narrativeSummary}</p>
                <div className="text-xs text-slate-400 font-mono">
                  Online Assistants: {report.activeAssistants.join(' · ') || 'None'}
                </div>
              </div>
            ))}
          </div>
        )}
      </section>

      {/* Hash-Chained Audit Log */}
      <section className="space-y-3">
        <h3 className="font-display text-base font-semibold text-white">
          Immutable SHA-256 Chained Audit Log
        </h3>
        <div className="bg-[#111827] border border-white/10 rounded-xl overflow-hidden">
          <div className="overflow-x-auto">
            <table className="w-full text-left border-collapse">
              <thead>
                <tr className="border-b border-white/10 text-xs text-slate-400 font-mono">
                  <th className="py-2.5 px-4 font-medium">Time</th>
                  <th className="py-2.5 px-4 font-medium">Event</th>
                  <th className="py-2.5 px-4 font-medium">Actor</th>
                  <th className="py-2.5 px-4 font-medium">Summary</th>
                  <th className="py-2.5 px-4 font-medium text-right">Entry Hash</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-white/5 text-xs">
                {state.auditLogs.map((log) => (
                  <tr key={log.id} className="hover:bg-white/[0.02]">
                    <td className="py-2.5 px-4 font-mono text-slate-400 tabular-nums whitespace-nowrap">
                      {new Date(log.timestampEpochMs).toLocaleTimeString()}
                    </td>
                    <td className="py-2.5 px-4 font-mono text-sky-300 whitespace-nowrap">{log.eventType}</td>
                    <td className="py-2.5 px-4 font-mono text-slate-200 whitespace-nowrap">{log.actor}</td>
                    <td className="py-2.5 px-4 text-slate-300">{log.summary}</td>
                    <td className="py-2.5 px-4 font-mono text-slate-500 text-right tabular-nums whitespace-nowrap">
                      {log.entryHash.slice(0, 14)}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      </section>
    </div>
  );
}
