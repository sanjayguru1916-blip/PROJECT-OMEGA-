export type AssistantId = 'SK' | 'JARVIS' | 'MAGMITE' | 'ULTRON' | 'FRIDAY';
export type AssistantStatus = 'ONLINE' | 'STANDBY' | 'BUSY' | 'DEGRADED' | 'DISABLED';
export type RiskLevel = 'LOW' | 'MEDIUM' | 'HIGH' | 'CRITICAL';

export type InterfaceMode = 'NORMAL' | 'PHOENIX' | 'ASSEMBLED' | 'ASSISTANT_ACTIVE';

export type AssemblyStage =
  | 'IDLE'
  | 'SYSTEM_INITIALIZING'
  | 'CORE_DEPLOYMENT'
  | 'HOLOGRAPHIC_ASSEMBLY'
  | 'CORE_SYNCHRONIZATION'
  | 'OMEGA_ONLINE'
  | 'DISASSEMBLING';

export type AnimationQuality = 'HIGH_60FPS' | 'BATTERY_SAVER_30FPS' | 'REDUCED_MOTION';

export type VoiceState =
  | 'IDLE'
  | 'PERMISSION_REQUIRED'
  | 'LISTENING'
  | 'PROCESSING'
  | 'RESPONDING'
  | 'SPEAKING'
  | 'ERROR';
export type VoiceGender = 'MALE' | 'FEMALE';
export type VoiceProviderMode = 'NEURAL_GEMINI_TTS' | 'BROWSER_SYSTEM_TTS';
export type BrowserMicPermissionState = 'prompt' | 'granted' | 'denied' | 'unavailable';

export type IntentCategory =
  | 'GENERAL_CONVERSATION'
  | 'INFORMATION_QA'
  | 'ASSISTANT_SELECTION'
  | 'ASSISTANT_STATUS'
  | 'PHONE_CONTROL'
  | 'APP_LAUNCH'
  | 'COMMUNICATION'
  | 'DEVICE_SETTINGS'
  | 'SYSTEM_INFO'
  | 'RESTRICTED_OR_SENSITIVE';

export interface AssistantRuntimeMetrics {
  currentActivity: string;
  activeTaskCount: number;
  completedTaskCount: number;
  pendingTaskCount: number;
  lastResponseMs: number | null;
  recentError: string | null;
  communicationState: 'IDLE' | 'BUSY' | 'SPEAKING' | 'OFFLINE';
}

export interface AssistantRegistryEntry {
  id: AssistantId;
  displayName: string;
  roleTitle: string;
  personality: string;
  capabilities: string[];
  declaredPermissions: string[];
  voiceConfig: {
    gender: VoiceGender;
    pitch: number;
    speechRate: number;
    voiceTone: string;
    localeTag: string;
    neuralVoiceName: string;
    stylePrompt: string;
  };
  visualIdentity: {
    primaryColor: string;
    secondaryColor: string;
    emblemLabel: string;
    orbitalNodes: number;
  };
  metrics: AssistantRuntimeMetrics;
  isMasterController: boolean;
  isEnabled: boolean;
  status: AssistantStatus;
  lastHeartbeatMs: number;
}

export interface TaskProposal {
  proposalId: string;
  commandId: string;
  rawInput: string;
  targetAssistant: Exclude<AssistantId, 'SK'>;
  actionSummary: string;
  exactOperation: string;
  parameters: Record<string, string>;
  requiredPermissions: string[];
  riskLevel: RiskLevel;
  rationale: string;
  payloadHash: string;
  createdAtEpochMs: number;
  expiresAtEpochMs: number;
}

export interface TaskHistoryItem {
  proposalId: string;
  targetAssistant: AssistantId;
  rawInput: string;
  exactOperation: string;
  status: 'COMPLETED' | 'REJECTED' | 'DENIED' | 'FAILED' | 'PERMISSION_MISSING';
  resultSummary: string;
  outputPayload: Record<string, string>;
  timestampEpochMs: number;
}

export interface AuditLogEntry {
  id: number;
  eventType: string;
  actor: AssistantId;
  proposalId: string | null;
  summary: string;
  prevHash: string;
  entryHash: string;
  timestampEpochMs: number;
}

export interface SystemAlert {
  alertId: string;
  severity: 'INFO' | 'WARNING' | 'ERROR' | 'CRITICAL';
  source: AssistantId;
  title: string;
  message: string;
  createdAtEpochMs: number;
  acknowledged: boolean;
}

export interface SystemReport {
  reportId: string;
  generatedAtEpochMs: number;
  periodLabel: string;
  totalCommands: number;
  approvedTasks: number;
  rejectedTasks: number;
  failedTasks: number;
  activeAssistants: AssistantId[];
  narrativeSummary: string;
}

export interface ReminderItem {
  id: string;
  title: string;
  notes: string;
  delayMinutes: number;
  triggerAtEpochMs: number;
  completed: boolean;
  createdByProposalId: string;
}

export interface DeviceSandboxState {
  torchEnabled: boolean;
  mediaVolumePercent: number;
  ringerMode: 'normal' | 'vibrate' | 'silent';
  musicStatus: 'IDLE' | 'PLAYING' | 'PAUSED' | 'STOPPED';
  musicTrackLabel: string;
  lastLaunchedApp: string | null;
  lastAlarmLabel: string | null;
  wifiPanelRequested: boolean;
  bluetoothPanelRequested: boolean;
  grantedPermissions: Record<string, boolean>;
}

export interface OmegaPlatformState {
  registry: Record<AssistantId, AssistantRegistryEntry>;
  pendingProposals: TaskProposal[];
  taskHistory: TaskHistoryItem[];
  auditLogs: AuditLogEntry[];
  alerts: SystemAlert[];
  reports: SystemReport[];
  reminders: ReminderItem[];
  deviceState: DeviceSandboxState;
}

export interface AndroidFileMeta {
  path: string;
  size: number;
  category: string;
}
