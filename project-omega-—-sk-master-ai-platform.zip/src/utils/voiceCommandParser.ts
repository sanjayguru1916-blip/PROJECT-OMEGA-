import { OperationsSectionId } from '../components/AssistantSidebar';
import { AssistantId, InterfaceMode } from '../types/omega';

export type ParsedVoiceIntent =
  | { type: 'ACTIVATE_MASTER' }
  | { type: 'SET_MODE'; mode: InterfaceMode }
  | { type: 'ASSEMBLE_ALL' }
  | { type: 'DISASSEMBLE_ALL' }
  | { type: 'STOP_SPEECH' }
  | { type: 'SET_VOICE_ENABLED'; enabled: boolean }
  | {
      type: 'OPEN_DETAILS_VIEW';
      section: OperationsSectionId;
      diagTab?: 'voice' | 'audit' | 'android';
      spokenSummary: string;
    }
  | { type: 'CLOSE_DETAILS_VIEW' }
  | { type: 'ACTIVATE_ASSISTANT'; assistantId: Exclude<AssistantId, 'SK'>; trailingCommand: string | null }
  | { type: 'ROUTE_COMMAND'; commandText: string };

const SATELLITES: Array<Exclude<AssistantId, 'SK'>> = ['JARVIS', 'MAGMITE', 'ULTRON', 'FRIDAY'];

export function parseSkVoiceCommand(rawInput: string): ParsedVoiceIntent {
  const trimmed = rawInput.trim();
  const normalized = trimmed.toUpperCase().replace(/\s+/g, ' ');

  switch (normalized) {
    case 'SK':
    case 'HEY SK':
      return { type: 'ACTIVATE_MASTER' };
    case 'SK NORMAL MODE':
    case 'NORMAL MODE':
    case 'SK DEACTIVATE PHOENIX MODE':
    case 'DEACTIVATE PHOENIX MODE':
    case 'SK EXIT PHOENIX MODE':
    case 'EXIT PHOENIX MODE':
      return { type: 'SET_MODE', mode: 'NORMAL' };
    case 'SK PHOENIX MODE':
    case 'PHOENIX MODE':
    case 'SK ACTIVATE PHOENIX MODE':
    case 'ACTIVATE PHOENIX MODE':
      return { type: 'SET_MODE', mode: 'PHOENIX' };
    case 'SK ASSEMBLE ALL':
    case 'ASSEMBLE ALL':
      return { type: 'ASSEMBLE_ALL' };
    case 'SK DISASSEMBLE ALL':
    case 'DISASSEMBLE ALL':
      return { type: 'DISASSEMBLE_ALL' };
    case 'SK STOP':
    case 'STOP SPEAKING':
    case 'STOP':
      return { type: 'STOP_SPEECH' };
    case 'SK VOICE OFF':
    case 'VOICE OFF':
      return { type: 'SET_VOICE_ENABLED', enabled: false };
    case 'SK VOICE ON':
    case 'VOICE ON':
      return { type: 'SET_VOICE_ENABLED', enabled: true };
    case 'SK STATUS REPORT':
    case 'STATUS REPORT':
    case 'SK SHOW SYSTEM DETAILS':
    case 'SHOW SYSTEM DETAILS':
    case 'SK SHOW SYSTEM STATUS':
    case 'SHOW SYSTEM STATUS':
    case 'SK SHOW SYSTEM INFORMATION':
    case 'SHOW SYSTEM INFORMATION':
    case 'SK SHOW MISSION STATUS':
    case 'SHOW MISSION STATUS':
      return {
        type: 'OPEN_DETAILS_VIEW',
        section: 'system',
        spokenSummary: 'Displaying SK Master system and mission status.',
      };
    case 'SK SHOW ASSISTANT STATUS':
    case 'SHOW ASSISTANT STATUS':
    case 'SK SHOW ASSISTANTS':
    case 'SHOW ASSISTANTS':
    case 'SK SHOW FIVE ASSISTANTS':
      return {
        type: 'OPEN_DETAILS_VIEW',
        section: 'activity',
        spokenSummary: 'Displaying five-assistant operational telemetry.',
      };
    case 'SK SHOW AUDIT LOG':
    case 'SHOW AUDIT LOG':
    case 'SK SHOW AUDIT LOGS':
    case 'SHOW AUDIT LOGS':
    case 'SK SHOW DIAGNOSTICS':
      return {
        type: 'OPEN_DETAILS_VIEW',
        section: 'diagnostics',
        diagTab: 'audit',
        spokenSummary: 'Opening SK Master audit logs and security reports.',
      };
    case 'SK SHOW DEVICE INFORMATION':
    case 'SHOW DEVICE INFORMATION':
    case 'SK SHOW DEVICE INFO':
    case 'SHOW DEVICE INFO':
    case 'SK SHOW TELEMETRY':
    case 'SHOW TELEMETRY':
      return {
        type: 'OPEN_DETAILS_VIEW',
        section: 'device',
        spokenSummary: 'Opening hardware and device telemetry details.',
      };
    case 'SK SHOW APPROVALS':
    case 'SHOW APPROVALS':
    case 'SK SHOW APPROVAL REQUESTS':
      return {
        type: 'OPEN_DETAILS_VIEW',
        section: 'approvals',
        spokenSummary: 'Opening SK Master approval requests.',
      };
    case 'SK SHOW VOICE SETTINGS':
    case 'SHOW VOICE SETTINGS':
    case 'SK VOICE SETTINGS':
      return {
        type: 'OPEN_DETAILS_VIEW',
        section: 'diagnostics',
        diagTab: 'voice',
        spokenSummary: 'Opening five-assistant voice calibration settings.',
      };
    case 'SK SHOW HISTORY':
    case 'SK SHOW COMMAND RESULTS':
    case 'SHOW COMMAND RESULTS':
    case 'SK SHOW PREVIOUS RESULTS':
      return {
        type: 'OPEN_DETAILS_VIEW',
        section: 'history',
        spokenSummary: 'Opening previous command results and task history.',
      };
    case 'SK CLOSE DETAILS':
    case 'CLOSE DETAILS':
    case 'SK HIDE DETAILS':
    case 'HIDE DETAILS':
      return { type: 'CLOSE_DETAILS_VIEW' };
    case 'JARVIS':
    case 'MAGMITE':
    case 'ULTRON':
    case 'FRIDAY':
      return { type: 'ACTIVATE_ASSISTANT', assistantId: normalized, trailingCommand: null };
    default: {
      for (const id of SATELLITES) {
        if (normalized.startsWith(`${id} `) || normalized.startsWith(`${id},`) || normalized.startsWith(`${id}:`)) {
          const remainder = trimmed.slice(id.length).replace(/^[,:\s]+/, '').trim();
          return {
            type: 'ACTIVATE_ASSISTANT',
            assistantId: id,
            trailingCommand: remainder.length > 0 ? remainder : null,
          };
        }
      }
      return { type: 'ROUTE_COMMAND', commandText: trimmed };
    }
  }
}
