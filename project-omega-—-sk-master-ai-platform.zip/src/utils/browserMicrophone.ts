import { BrowserMicPermissionState } from '../types/omega';

export interface BrowserSpeechRecognitionAlternative {
  transcript: string;
}

export interface BrowserSpeechRecognitionResult extends ArrayLike<BrowserSpeechRecognitionAlternative> {
  isFinal?: boolean;
}

export interface BrowserSpeechRecognitionEvent {
  results: ArrayLike<BrowserSpeechRecognitionResult>;
}

export interface BrowserSpeechRecognitionErrorEvent {
  error: string;
  message?: string;
}

export interface BrowserSpeechRecognition {
  continuous: boolean;
  interimResults: boolean;
  lang: string;
  onstart: (() => void) | null;
  onresult: ((ev: BrowserSpeechRecognitionEvent) => void) | null;
  onerror: ((ev: BrowserSpeechRecognitionErrorEvent) => void) | null;
  onend: (() => void) | null;
  start: () => void;
  stop: () => void;
  abort?: () => void;
}

export type SpeechRecognitionCtor = new () => BrowserSpeechRecognition;

export interface MicrophoneProbeResult {
  permission: BrowserMicPermissionState;
  permissionsApiSupported: boolean;
  speechRecognitionSupported: boolean;
  permissionStatus: PermissionStatus | null;
  message: string | null;
}

export const BROWSER_MIC_SITE_SETTINGS_HELP =
  'Browser microphone access is blocked. Open the browser site settings (click the lock or settings icon next to the page URL -> Microphone -> Allow), ensure embedded preview permissions allow Microphone, and click Retry.';

export function getSpeechRecognitionCtor(win: Window = window): SpeechRecognitionCtor | null {
  const recWin = win as unknown as {
    SpeechRecognition?: SpeechRecognitionCtor;
    webkitSpeechRecognition?: SpeechRecognitionCtor;
  };
  return recWin.SpeechRecognition || recWin.webkitSpeechRecognition || null;
}

export async function probeBrowserMicrophone(
  nav: Navigator = navigator,
  win: Window = window
): Promise<MicrophoneProbeResult> {
  const speechRecognitionSupported = Boolean(getSpeechRecognitionCtor(win));
  const hasMediaDevices = Boolean(nav?.mediaDevices && typeof nav.mediaDevices.getUserMedia === 'function');
  const secure = win.isSecureContext !== false;

  if (!hasMediaDevices || !secure) {
    return {
      permission: 'unavailable',
      permissionsApiSupported: false,
      speechRecognitionSupported,
      permissionStatus: null,
      message: !secure
        ? 'Browser microphone access requires a secure HTTPS or localhost origin.'
        : 'Browser MediaDevices.getUserMedia audio capture API is unavailable in this browser.',
    };
  }

  if (nav.permissions && typeof nav.permissions.query === 'function') {
    try {
      const status = await nav.permissions.query({ name: 'microphone' as PermissionName });
      const mapped: BrowserMicPermissionState =
        status.state === 'granted'
          ? 'granted'
          : status.state === 'denied'
            ? 'denied'
            : 'prompt';
      return {
        permission: mapped,
        permissionsApiSupported: true,
        speechRecognitionSupported,
        permissionStatus: status,
        message: mapped === 'denied' ? BROWSER_MIC_SITE_SETTINGS_HELP : null,
      };
    } catch {
      // Browsers such as Safari or restricted frames throw TypeError for 'microphone' query
      return {
        permission: 'prompt',
        permissionsApiSupported: false,
        speechRecognitionSupported,
        permissionStatus: null,
        message: null,
      };
    }
  }

  return {
    permission: 'prompt',
    permissionsApiSupported: false,
    speechRecognitionSupported,
    permissionStatus: null,
    message: null,
  };
}

export function classifyGetUserMediaError(err: unknown): {
  permission: BrowserMicPermissionState;
  isPermissionDenied: boolean;
  message: string;
} {
  const name = err instanceof Error ? err.name : '';
  const rawMessage = err instanceof Error ? err.message : String(err ?? '');

  if (
    name === 'NotAllowedError' ||
    name === 'PermissionDeniedError' ||
    name === 'SecurityError' ||
    /permission denied|not allowed|blocked by permissions policy/i.test(rawMessage)
  ) {
    return {
      permission: 'denied',
      isPermissionDenied: true,
      message: BROWSER_MIC_SITE_SETTINGS_HELP,
    };
  }

  if (name === 'NotFoundError' || name === 'DevicesNotFoundError') {
    return {
      permission: 'unavailable',
      isPermissionDenied: false,
      message: 'No microphone hardware was detected by the browser. Connect a microphone and click Retry.',
    };
  }

  if (name === 'NotReadableError' || name === 'TrackStartError' || name === 'AbortError') {
    return {
      permission: 'unavailable',
      isPermissionDenied: false,
      message: 'Microphone could not be opened because it is in use by another application or tab. Release it and click Retry.',
    };
  }

  return {
    permission: 'unavailable',
    isPermissionDenied: false,
    message: rawMessage || 'Unable to access browser microphone.',
  };
}

export function stopAndReleaseMediaStream(stream: MediaStream | null): void {
  if (!stream) return;
  for (const track of stream.getTracks()) {
    try {
      track.stop();
    } catch {
      // Ignore track already stopped
    }
    try {
      stream.removeTrack(track);
    } catch {
      // Ignore track removal errors
    }
  }
}

export function classifySpeechRecognitionError(errorCode: string): {
  permission: BrowserMicPermissionState | null;
  requiresPermissionState: boolean;
  message: string;
} {
  switch (errorCode) {
    case 'not-allowed':
    case 'service-not-allowed':
      return {
        permission: 'denied',
        requiresPermissionState: true,
        message: BROWSER_MIC_SITE_SETTINGS_HELP,
      };
    case 'audio-capture':
      return {
        permission: null,
        requiresPermissionState: false,
        message: 'Speech recognition could not capture audio from the browser microphone. Verify input device settings and click Retry.',
      };
    case 'no-speech':
      return {
        permission: null,
        requiresPermissionState: false,
        message: 'No speech detected. Check your microphone input and tap Retry.',
      };
    case 'network':
      return {
        permission: null,
        requiresPermissionState: false,
        message: 'Browser speech recognition service encountered a network error. Check connectivity or type your command.',
      };
    case 'language-not-supported':
      return {
        permission: null,
        requiresPermissionState: false,
        message: 'Configured speech recognition language is not supported by this browser.',
      };
    case 'aborted':
      return {
        permission: null,
        requiresPermissionState: false,
        message: 'Speech recognition session was interrupted.',
      };
    default:
      return {
        permission: null,
        requiresPermissionState: false,
        message: `Browser speech recognition error: ${errorCode}`,
      };
  }
}

export interface MicSessionControllerCallbacks {
  onRequesting: () => void;
  onPermissionChange: (permission: BrowserMicPermissionState, permissionsApiSupported: boolean) => void;
  onListeningStarted: () => void;
  onInterimTranscript: (transcript: string) => void;
  onFinalTranscript: (transcript: string) => void;
  onRmsLevel: (level: number) => void;
  onStopped: () => void;
  onPermissionDenied: (message: string) => void;
  onError: (message: string) => void;
}

export class BrowserMicrophoneController {
  private activeStream: MediaStream | null = null;
  private recognition: BrowserSpeechRecognition | null = null;
  private micAudioCtx: AudioContext | null = null;
  private micSourceNode: MediaStreamAudioSourceNode | null = null;
  private micAnalyserNode: AnalyserNode | null = null;
  private meterRafId = 0;
  private requestInFlight = false;
  private listeningStarted = false;
  private intentionalStop = false;
  private sessionCounter = 0;

  constructor(
    private readonly callbacks: MicSessionControllerCallbacks,
    private readonly win: Window = window,
    private readonly nav: Navigator = navigator
  ) {}

  isActive(): boolean {
    return this.requestInFlight || this.listeningStarted || this.activeStream !== null;
  }

  isRequesting(): boolean {
    return this.requestInFlight;
  }

  async refreshPermissionStatus(): Promise<MicrophoneProbeResult> {
    const probe = await probeBrowserMicrophone(this.nav, this.win);
    this.callbacks.onPermissionChange(probe.permission, probe.permissionsApiSupported);
    return probe;
  }

  async startOrRetry(): Promise<void> {
    // Prevent duplicate microphone streams or overlapping acquisition requests
    if (this.requestInFlight) {
      return;
    }

    // Tear down any previous stream, analyser, or recognizer before creating a fresh session
    this.teardownMediaAndRecognizer(false);

    const sessionId = ++this.sessionCounter;
    this.intentionalStop = false;
    this.listeningStarted = false;
    this.requestInFlight = true;
    this.callbacks.onRequesting();

    try {
      const probe = await probeBrowserMicrophone(this.nav, this.win);
      if (sessionId !== this.sessionCounter || this.intentionalStop) {
        return;
      }

      this.callbacks.onPermissionChange(probe.permission, probe.permissionsApiSupported);

      if (probe.permission === 'unavailable') {
        this.callbacks.onError(probe.message || 'Browser microphone is unavailable.');
        return;
      }

      // Explicitly invoke getUserMedia({ audio: true }) so prompt/retry always requests real browser access
      let stream: MediaStream;
      try {
        stream = await this.nav.mediaDevices.getUserMedia({ audio: true });
      } catch (err) {
        if (sessionId !== this.sessionCounter || this.intentionalStop) {
          return;
        }
        const classified = classifyGetUserMediaError(err);
        this.callbacks.onPermissionChange(classified.permission, probe.permissionsApiSupported);
        if (classified.isPermissionDenied) {
          this.callbacks.onPermissionDenied(classified.message);
        } else {
          this.callbacks.onError(classified.message);
        }
        return;
      }

      // If stopped or superseded while awaiting user permission prompt, release tracks immediately
      if (sessionId !== this.sessionCounter || this.intentionalStop) {
        stopAndReleaseMediaStream(stream);
        return;
      }

      const liveTracks = stream.getAudioTracks().filter((t) => t.readyState === 'live');
      if (liveTracks.length === 0) {
        stopAndReleaseMediaStream(stream);
        this.callbacks.onPermissionChange('unavailable', probe.permissionsApiSupported);
        this.callbacks.onError('Browser granted stream without an active live audio track. Please check your microphone and click Retry.');
        return;
      }

      this.activeStream = stream;
      this.callbacks.onPermissionChange('granted', probe.permissionsApiSupported);

      const SpeechRec = getSpeechRecognitionCtor(this.win);
      if (!SpeechRec) {
        // Release mic immediately since recognition engine is unsupported; NEVER enter LISTENING
        this.teardownMediaAndRecognizer(false);
        this.callbacks.onError(
          'Microphone permission succeeded, but this browser does not support SpeechRecognition (Web Speech API). Use Google Chrome or Microsoft Edge for voice input, or type commands below.'
        );
        return;
      }

      this.attachAudioCaptureMeter(stream);

      const rec = new SpeechRec();
      rec.continuous = false;
      rec.interimResults = true;
      rec.lang = 'en-US';
      this.recognition = rec;

      rec.onstart = () => {
        if (sessionId !== this.sessionCounter || this.intentionalStop || !this.activeStream) {
          try {
            rec.stop();
          } catch {
            // Ignore
          }
          this.teardownMediaAndRecognizer(false);
          return;
        }
        this.requestInFlight = false;
        this.listeningStarted = true;
        this.startMeterLoop();
        // LISTENING is ONLY emitted after BOTH getUserMedia({ audio: true }) AND recognition.onstart succeeded
        this.callbacks.onListeningStarted();
      };

      rec.onresult = (event) => {
        if (sessionId !== this.sessionCounter) return;
        const lastIdx = event.results.length - 1;
        if (lastIdx < 0) return;
        const resultItem = event.results[lastIdx];
        const transcript = resultItem?.[0]?.transcript?.trim() ?? '';
        if (!transcript) return;

        this.callbacks.onInterimTranscript(transcript);
        if (resultItem.isFinal === false) {
          return;
        }

        this.teardownMediaAndRecognizer(false);
        this.callbacks.onFinalTranscript(transcript);
      };

      rec.onerror = (event) => {
        if (sessionId !== this.sessionCounter) return;
        const wasIntentional = this.intentionalStop;
        this.teardownMediaAndRecognizer(false);
        if (wasIntentional && event.error === 'aborted') {
          this.callbacks.onStopped();
          return;
        }
        const classified = classifySpeechRecognitionError(event.error);
        if (classified.permission) {
          this.callbacks.onPermissionChange(classified.permission, probe.permissionsApiSupported);
        }
        if (classified.requiresPermissionState) {
          this.callbacks.onPermissionDenied(classified.message);
        } else {
          this.callbacks.onError(classified.message);
        }
      };

      rec.onend = () => {
        if (sessionId !== this.sessionCounter) return;
        const wasListening = this.listeningStarted;
        const wasIntentional = this.intentionalStop;
        const wasRequesting = this.requestInFlight;
        this.teardownMediaAndRecognizer(false);
        if (wasListening || wasIntentional || wasRequesting) {
          this.callbacks.onStopped();
        }
      };

      try {
        rec.start();
        // Leave requestInFlight cleared once onstart/onerror resolves; unlock only if start throws
      } catch (startErr) {
        this.teardownMediaAndRecognizer(false);
        this.callbacks.onError(
          startErr instanceof Error
            ? `Failed to start speech recognition: ${startErr.message}`
            : 'Failed to start browser speech recognition.'
        );
      }
    } finally {
      // Ensure requestInFlight never gets permanently stuck if synchronous setup returned early before rec.start
      if (!this.recognition) {
        this.requestInFlight = false;
      }
    }
  }

  stop(): void {
    this.sessionCounter += 1;
    this.intentionalStop = true;
    this.requestInFlight = false;
    this.teardownMediaAndRecognizer(false);
    this.callbacks.onStopped();
  }

  dispose(): void {
    this.sessionCounter += 1;
    this.intentionalStop = true;
    this.requestInFlight = false;
    this.teardownMediaAndRecognizer(false);
    if (this.micAudioCtx && this.micAudioCtx.state !== 'closed') {
      void this.micAudioCtx.close().catch(() => {});
    }
    this.micAudioCtx = null;
  }

  async retry(): Promise<void> {
    this.stop();
    if (this.micAudioCtx && this.micAudioCtx.state !== 'closed') {
      try {
        await this.micAudioCtx.close();
      } catch {
        // Ignore close error
      }
    }
    this.micAudioCtx = null;
    await this.startOrRetry();
  }

  private attachAudioCaptureMeter(stream: MediaStream): void {
    try {
      const audioWin = this.win as unknown as {
        AudioContext?: typeof AudioContext;
        webkitAudioContext?: typeof AudioContext;
      };
      const AudioCtx = audioWin.AudioContext || audioWin.webkitAudioContext;
      if (!AudioCtx) return;

      if (!this.micAudioCtx || this.micAudioCtx.state === 'closed') {
        this.micAudioCtx = new AudioCtx();
      }
      const ctx = this.micAudioCtx;
      if (ctx.state === 'suspended') {
        void ctx.resume().catch(() => {});
      }

      const source = ctx.createMediaStreamSource(stream);
      const analyser = ctx.createAnalyser();
      analyser.fftSize = 128;
      source.connect(analyser);
      this.micSourceNode = source;
      this.micAnalyserNode = analyser;
    } catch {
      // Keep recognition functional even if Web Audio RMS meter is unavailable
      this.micSourceNode = null;
      this.micAnalyserNode = null;
    }
  }

  private startMeterLoop(): void {
    if (this.meterRafId) {
      this.win.cancelAnimationFrame(this.meterRafId);
      this.meterRafId = 0;
    }
    const analyser = this.micAnalyserNode;
    if (!analyser) return;

    const samples = new Uint8Array(analyser.frequencyBinCount);
    const tick = () => {
      if (!this.listeningStarted || !this.micAnalyserNode) return;
      analyser.getByteTimeDomainData(samples);
      let sumSq = 0;
      for (let i = 0; i < samples.length; i += 1) {
        const norm = (samples[i] - 128) / 128;
        sumSq += norm * norm;
      }
      const rms = Math.min(1, Math.sqrt(sumSq / samples.length) * 4.2);
      this.callbacks.onRmsLevel(Math.max(0.12, rms));
      this.meterRafId = this.win.requestAnimationFrame(tick);
    };
    this.meterRafId = this.win.requestAnimationFrame(tick);
  }

  private teardownMediaAndRecognizer(keepRecognitionRefCleanOnly: boolean): void {
    this.listeningStarted = false;
    this.requestInFlight = false;

    if (this.meterRafId) {
      this.win.cancelAnimationFrame(this.meterRafId);
      this.meterRafId = 0;
    }

    if (this.micSourceNode) {
      try {
        this.micSourceNode.disconnect();
      } catch {
        // Ignore disconnect error
      }
      this.micSourceNode = null;
    }
    if (this.micAnalyserNode) {
      try {
        this.micAnalyserNode.disconnect();
      } catch {
        // Ignore disconnect error
      }
      this.micAnalyserNode = null;
    }

    const rec = this.recognition;
    this.recognition = null;
    if (rec) {
      rec.onstart = null;
      rec.onresult = null;
      rec.onerror = null;
      rec.onend = null;
      if (!keepRecognitionRefCleanOnly) {
        try {
          rec.stop();
        } catch {
          // Ignore already stopped recognizer
        }
      }
    }

    if (this.activeStream) {
      stopAndReleaseMediaStream(this.activeStream);
      this.activeStream = null;
    }

    this.callbacks.onRmsLevel(0);
  }
}
