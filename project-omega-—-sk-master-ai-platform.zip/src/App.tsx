import { useEffect, useRef, useState } from 'react';
import {
  CheckCircle2,
  ChevronDown,
  Flame,
  Layers,
  Lock,
  Menu,
  RefreshCw,
  RotateCcw,
  ShieldAlert,
  Volume2,
  VolumeX,
  XCircle,
} from 'lucide-react';
import { AssistantSidebar, OperationsSectionId } from './components/AssistantSidebar';
import { CompactCommandBar } from './components/CompactCommandBar';
import {
  CommandResultRecord,
  ExpandableOperationsDrawer,
} from './components/ExpandableOperationsDrawer';
import { HolographicCore } from './components/HolographicCore';
import { MagmiteFloatingCore } from './components/MagmiteFloatingCore';
import { SkMasterReactor } from './components/SkMasterReactor';
import {
  AnimationQuality,
  AssemblyStage,
  AssistantId,
  BrowserMicPermissionState,
  InterfaceMode,
  OmegaPlatformState,
  VoiceProviderMode,
  VoiceState,
} from './types/omega';
import {
  BrowserMicrophoneController,
  getSpeechRecognitionCtor,
  probeBrowserMicrophone,
} from './utils/browserMicrophone';
import { parseSkVoiceCommand } from './utils/voiceCommandParser';

const DEFAULT_BASE_PITCH: Record<AssistantId, number> = {
  SK: 0.90,
  JARVIS: 0.98,
  MAGMITE: 1.04,
  ULTRON: 0.72,
  FRIDAY: 1.12,
};

async function safeReadJson<T>(res: Response): Promise<T | null> {
  try {
    const text = await res.text();
    if (!text) return null;
    return JSON.parse(text) as T;
  } catch {
    return null;
  }
}

function classifyHttpError(status: number | undefined, serverMessage?: string): string {
  const cleanServer =
    serverMessage && !serverMessage.trim().startsWith('{') && !serverMessage.includes('stack')
      ? serverMessage.trim()
      : undefined;
  if (status === 504) return cleanServer || 'SK Master timed out waiting for the AI model. Please retry.';
  if (status === 503) return cleanServer || 'AI service is temporarily busy. Please try again in a moment.';
  if (status === 429) return cleanServer || 'AI rate limit reached. Please pause briefly and retry.';
  if (status === 409) return cleanServer || 'Duplicate or conflicting request is already running.';
  if (status === 400) return cleanServer || 'Invalid command request. Please rephrase and try again.';
  if (status && status >= 500) return cleanServer || 'Temporary backend issue while routing command. Please retry.';
  return cleanServer || 'SK command routing could not complete.';
}

export default function App() {
  const [state, setState] = useState<OmegaPlatformState | null>(null);
  const [activeId, setActiveId] = useState<AssistantId>('SK');
  const [interfaceMode, setInterfaceMode] = useState<InterfaceMode>('NORMAL');
  const [assemblyStage, setAssemblyStage] = useState<AssemblyStage>('IDLE');
  const [animationQuality, setAnimationQuality] = useState<AnimationQuality>('HIGH_60FPS');
  const [speakingAssistant, setSpeakingAssistant] = useState<AssistantId | null>(null);

  const [sidebarCollapsed, setSidebarCollapsed] = useState(false);
  const [mobileDrawerOpen, setMobileDrawerOpen] = useState(false);
  const [activeSection, setActiveSection] = useState<OperationsSectionId | null>(null);
  const [requestedDiagTab, setRequestedDiagTab] = useState<'voice' | 'audit' | 'android'>('voice');
  const [viewMenuOpen, setViewMenuOpen] = useState(false);

  const [commandInput, setCommandInput] = useState('');
  const [voiceEnabled, setVoiceEnabled] = useState(true);
  const [voiceProviderMode, setVoiceProviderMode] = useState<VoiceProviderMode>('NEURAL_GEMINI_TTS');
  const [voiceState, setVoiceState] = useState<VoiceState>('IDLE');
  const [micPermissionState, setMicPermissionState] = useState<BrowserMicPermissionState>('prompt');
  const [permissionsApiSupported, setPermissionsApiSupported] = useState<boolean>(false);
  const [speechRecognitionSupported, setSpeechRecognitionSupported] = useState<boolean>(true);
  const [isMicRequesting, setIsMicRequesting] = useState<boolean>(false);
  const [voiceRmsLevel, setVoiceRmsLevel] = useState(0);
  const [recognizedCommand, setRecognizedCommand] = useState<string | null>(null);
  const [speechError, setSpeechError] = useState<string | null>(null);
  const [voiceDiagnostics, setVoiceDiagnostics] = useState<string | null>(null);
  const [browserVoices, setBrowserVoices] = useState<Array<{ name: string; lang: string; localService: boolean }>>([]);
  const [isRouting, setIsRouting] = useState(false);
  const [isExecuting, setIsExecuting] = useState(false);
  const [generatingReport, setGeneratingReport] = useState(false);
  const [errorBanner, setErrorBanner] = useState<string | null>(null);
  const [lastFailedCommand, setLastFailedCommand] = useState<{
    command: string;
    preferred: AssistantId | null;
  } | null>(null);
  const [inlineCriticalConfirmed, setInlineCriticalConfirmed] = useState(false);
  const [commandResults, setCommandResults] = useState<CommandResultRecord[]>([]);
  const inFlightCommandRef = useRef<string | null>(null);

  const assemblyTimersRef = useRef<number[]>([]);
  const micControllerRef = useRef<BrowserMicrophoneController | null>(null);
  const handleCommandRef = useRef<(rawCommand?: string) => Promise<void>>(async () => {});
  const hasGreetedSessionRef = useRef(false);
  const audioCtxRef = useRef<AudioContext | null>(null);
  const activeSourceRef = useRef<AudioBufferSourceNode | null>(null);
  const ttsMeterRafRef = useRef<number>(0);
  const ttsAbortRef = useRef<AbortController | null>(null);
  const browserPulseTimerRef = useRef<number | null>(null);
  const viewMenuRef = useRef<HTMLDivElement | null>(null);

  const recordResult = (text: string, speaker: AssistantId = 'SK') => {
    const trimmed = text.trim();
    if (!trimmed) return;
    setCommandResults((prev) => [
      {
        id: `${Date.now()}-${Math.random().toString(36).slice(2, 7)}`,
        speaker,
        text: trimmed,
        timestamp: Date.now(),
      },
      ...prev.slice(0, 29),
    ]);
  };

  const isListening = voiceState === 'LISTENING';

  const clearAssemblyTimers = () => {
    assemblyTimersRef.current.forEach((t) => window.clearTimeout(t));
    assemblyTimersRef.current = [];
  };

  const stopSpeaking = () => {
    if (ttsAbortRef.current) {
      ttsAbortRef.current.abort();
      ttsAbortRef.current = null;
    }
    if (ttsMeterRafRef.current) {
      cancelAnimationFrame(ttsMeterRafRef.current);
      ttsMeterRafRef.current = 0;
    }
    if (activeSourceRef.current) {
      try {
        activeSourceRef.current.onended = null;
        activeSourceRef.current.stop();
        activeSourceRef.current.disconnect();
      } catch {
        // Ignore already stopped buffer source
      }
      activeSourceRef.current = null;
    }
    if (browserPulseTimerRef.current) {
      window.clearInterval(browserPulseTimerRef.current);
      browserPulseTimerRef.current = null;
    }
    if (typeof window !== 'undefined' && 'speechSynthesis' in window) {
      window.speechSynthesis.cancel();
    }
    setSpeakingAssistant(null);
    setVoiceRmsLevel(0);
    setVoiceState((prev) => (prev === 'SPEAKING' ? 'IDLE' : prev));
  };

  const pickBrowserVoiceForAssistant = (id: AssistantId, localeTag: string): SpeechSynthesisVoice | null => {
    if (typeof window === 'undefined' || !('speechSynthesis' in window)) return null;
    const voices = window.speechSynthesis.getVoices();
    if (voices.length === 0) return null;

    const english = voices.filter((v) => v.lang.toLowerCase().startsWith('en'));
    const pool = english.length > 0 ? english : voices;
    const lower = (v: SpeechSynthesisVoice) => v.name.toLowerCase();

    const femaleHints = ['female', 'zira', 'samantha', 'karen', 'victoria', 'aria', 'jenny', 'libby', 'sonia', 'google us english'];
    const maleHints = ['male', 'david', 'mark', 'daniel', 'george', 'ryan', 'guy', 'alex', 'arthur', 'oliver'];

    if (id === 'JARVIS') {
      return (
        pool.find((v) => v.lang.toLowerCase().includes('gb') && maleHints.some((h) => lower(v).includes(h))) ||
        pool.find((v) => v.lang.toLowerCase() === localeTag.toLowerCase()) ||
        pool.find((v) => v.lang.toLowerCase().includes('gb')) ||
        pool[0]
      );
    }
    if (id === 'MAGMITE') {
      return (
        pool.find((v) => femaleHints.some((h) => lower(v).includes(h))) ||
        pool[pool.length > 1 ? 1 : 0]
      );
    }
    if (id === 'FRIDAY') {
      const femalePool = pool.filter((v) => femaleHints.some((h) => lower(v).includes(h)));
      return (
        femalePool[femalePool.length > 1 ? 1 : 0] ||
        pool[pool.length > 2 ? 2 : 0]
      );
    }
    if (id === 'ULTRON') {
      const malePool = pool.filter((v) => maleHints.some((h) => lower(v).includes(h)));
      return (
        malePool[malePool.length > 1 ? 1 : 0] ||
        pool[pool.length > 3 ? 3 : 0]
      );
    }
    return (
      pool.find((v) => maleHints.some((h) => lower(v).includes(h))) ||
      pool[0]
    );
  };

  const speakWithBrowserTts = (text: string, speakerId: AssistantId) => {
    if (!state || typeof window === 'undefined' || !('speechSynthesis' in window)) {
      setSpeakingAssistant(null);
      setVoiceState('IDLE');
      return;
    }
    const profile = state.registry[speakerId];
    if (!profile) return;

    const utterance = new SpeechSynthesisUtterance(text);
    const chosenVoice = pickBrowserVoiceForAssistant(speakerId, profile.voiceConfig.localeTag);
    if (chosenVoice) {
      utterance.voice = chosenVoice;
      utterance.lang = chosenVoice.lang;
    } else {
      utterance.lang = profile.voiceConfig.localeTag;
    }
    utterance.pitch = profile.voiceConfig.pitch;
    utterance.rate = profile.voiceConfig.speechRate;

    utterance.onstart = () => {
      setSpeakingAssistant(speakerId);
      setVoiceState('SPEAKING');
      if (browserPulseTimerRef.current) window.clearInterval(browserPulseTimerRef.current);
      let phase = 0;
      browserPulseTimerRef.current = window.setInterval(() => {
        phase += 0.45;
        setVoiceRmsLevel(0.28 + 0.42 * Math.abs(Math.sin(phase)));
      }, 65);
    };
    const cleanup = () => {
      if (browserPulseTimerRef.current) {
        window.clearInterval(browserPulseTimerRef.current);
        browserPulseTimerRef.current = null;
      }
      setSpeakingAssistant(null);
      setVoiceRmsLevel(0);
      setVoiceState((prev) => (prev === 'SPEAKING' ? 'IDLE' : prev));
    };
    utterance.onend = cleanup;
    utterance.onerror = cleanup;
    window.speechSynthesis.speak(utterance);
  };

  const speak = async (
    text: string,
    speakerId: AssistantId,
    forcePreview = false,
    platformSnapshot?: OmegaPlatformState
  ) => {
    const targetState = platformSnapshot ?? state;
    if ((!voiceEnabled && !forcePreview) || !targetState || !text.trim()) return;
    const profile = targetState.registry[speakerId];
    if (!profile) return;

    stopSpeaking();
    setSpeakingAssistant(speakerId);
    setVoiceState('SPEAKING');

    if (voiceProviderMode === 'BROWSER_SYSTEM_TTS') {
      setVoiceDiagnostics(
        `Speaking via Browser TTS: ${speakerId} (${profile.voiceConfig.gender}, ${profile.voiceConfig.localeTag}, P=${profile.voiceConfig.pitch}, R=${profile.voiceConfig.speechRate}x)`
      );
      speakWithBrowserTts(text, speakerId);
      return;
    }

    const controller = new AbortController();
    ttsAbortRef.current = controller;

    try {
      const res = await fetch('/api/voice/synthesize', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ assistantId: speakerId, text }),
        signal: controller.signal,
      });

      if (!res.ok) {
        const errData = (await res.json().catch(() => ({}))) as { error?: string };
        throw new Error(errData.error || `Neural TTS HTTP ${res.status}`);
      }

      const payload = (await res.json()) as {
        audioBase64: string;
        voiceName: string;
        gender: string;
      };

      if (controller.signal.aborted) return;

      const binary = window.atob(payload.audioBase64);
      const bytes = new Uint8Array(binary.length);
      for (let i = 0; i < binary.length; i += 1) {
        bytes[i] = binary.charCodeAt(i);
      }

      const AudioCtx = window.AudioContext || (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext;
      if (!audioCtxRef.current || audioCtxRef.current.state === 'closed') {
        audioCtxRef.current = new AudioCtx();
      }
      const ctx = audioCtxRef.current;
      if (ctx.state === 'suspended') {
        await ctx.resume();
      }

      const audioBuffer = await ctx.decodeAudioData(bytes.buffer.slice(0));
      if (controller.signal.aborted) return;

      const source = ctx.createBufferSource();
      source.buffer = audioBuffer;
      source.playbackRate.value = profile.voiceConfig.speechRate;
      const basePitch = DEFAULT_BASE_PITCH[speakerId] ?? 1.0;
      const pitchShift = profile.voiceConfig.pitch - basePitch;
      if (Math.abs(pitchShift) > 0.01) {
        source.detune.value = pitchShift * 450;
      }

      const analyser = ctx.createAnalyser();
      analyser.fftSize = 128;
      source.connect(analyser);
      analyser.connect(ctx.destination);
      activeSourceRef.current = source;

      setVoiceDiagnostics(
        `Neural TTS Active: ${speakerId} (${payload.gender} · ${payload.voiceName} · ${profile.voiceConfig.voiceTone})`
      );

      const timeData = new Uint8Array(analyser.frequencyBinCount);
      const pumpMeter = () => {
        if (activeSourceRef.current !== source) return;
        analyser.getByteTimeDomainData(timeData);
        let sumSq = 0;
        for (let i = 0; i < timeData.length; i += 1) {
          const norm = (timeData[i] - 128) / 128;
          sumSq += norm * norm;
        }
        const rms = Math.min(1, Math.sqrt(sumSq / timeData.length) * 3.4);
        setVoiceRmsLevel(rms);
        ttsMeterRafRef.current = requestAnimationFrame(pumpMeter);
      };
      ttsMeterRafRef.current = requestAnimationFrame(pumpMeter);

      source.onended = () => {
        if (ttsMeterRafRef.current) {
          cancelAnimationFrame(ttsMeterRafRef.current);
          ttsMeterRafRef.current = 0;
        }
        if (activeSourceRef.current === source) {
          activeSourceRef.current = null;
        }
        setSpeakingAssistant(null);
        setVoiceRmsLevel(0);
        setVoiceState((prev) => (prev === 'SPEAKING' ? 'IDLE' : prev));
      };

      source.start(0);
    } catch (err) {
      if (controller.signal.aborted) return;
      const reason = err instanceof Error ? err.message : 'Neural TTS unavailable';
      setVoiceDiagnostics(`Neural TTS unavailable (${reason}). Using Browser System TTS fallback.`);
      speakWithBrowserTts(text, speakerId);
    }
  };

  const recordModeEvent = async (mode: string, actor: AssistantId, summary: string) => {
    try {
      const res = await fetch('/api/sk/mode-event', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ mode, actor, summary }),
      });
      const data = await res.json();
      if (data.state) setState(data.state);
    } catch {
      // Preserve UI responsiveness if background audit fails
    }
  };

  useEffect(() => {
    fetch('/api/state')
      .then((r) => r.json())
      .then((data: OmegaPlatformState) => {
        setState(data);
        if (!hasGreetedSessionRef.current) {
          hasGreetedSessionRef.current = true;
          fetch('/api/sk/greeting', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ hourOfDay: new Date().getHours() }),
          })
            .then((res) => (res.ok ? res.json() : null))
            .then((payload: { greetingText?: string } | null) => {
              if (payload?.greetingText) {
                recordResult(payload.greetingText, 'SK');
                void speak(payload.greetingText, 'SK', false, data);
              }
            })
            .catch(() => {
              // Preserve quiet initialization if greeting fetch fails
            });
        }
      })
      .catch(() => setErrorBanner('Failed to connect to SK Master backend service.'));

    const loadBrowserVoices = () => {
      if (typeof window !== 'undefined' && 'speechSynthesis' in window) {
        const list = window.speechSynthesis.getVoices().map((v) => ({
          name: v.name,
          lang: v.lang,
          localService: v.localService,
        }));
        setBrowserVoices(list);
      }
    };
    loadBrowserVoices();
    if (typeof window !== 'undefined' && 'speechSynthesis' in window) {
      window.speechSynthesis.onvoiceschanged = loadBrowserVoices;
    }

    let mounted = true;
    let watchedPermissionStatus: PermissionStatus | null = null;
    const handlePermissionChange = () => {
      if (!mounted || !watchedPermissionStatus) return;
      const next =
        watchedPermissionStatus.state === 'granted'
          ? 'granted'
          : watchedPermissionStatus.state === 'denied'
            ? 'denied'
            : 'prompt';
      setMicPermissionState(next);
      if (next === 'granted') {
        setSpeechError(null);
        setVoiceState((prev) => (prev === 'PERMISSION_REQUIRED' ? 'IDLE' : prev));
      } else if (next === 'denied') {
        setVoiceState((prev) => (prev === 'LISTENING' ? 'PERMISSION_REQUIRED' : prev));
      }
    };

    setSpeechRecognitionSupported(Boolean(getSpeechRecognitionCtor(window)));
    void probeBrowserMicrophone(navigator, window).then((probe) => {
      if (!mounted) return;
      setMicPermissionState(probe.permission);
      setPermissionsApiSupported(probe.permissionsApiSupported);
      setSpeechRecognitionSupported(probe.speechRecognitionSupported);
      if (probe.permission === 'denied' && probe.message) {
        setVoiceDiagnostics(probe.message);
      }
      if (probe.permissionStatus) {
        watchedPermissionStatus = probe.permissionStatus;
        watchedPermissionStatus.addEventListener?.('change', handlePermissionChange);
      }
    });

    micControllerRef.current = new BrowserMicrophoneController({
      onRequesting: () => {
        setIsMicRequesting(true);
        setSpeechError(null);
        setRecognizedCommand(null);
        setVoiceDiagnostics('Requesting browser microphone access via getUserMedia...');
      },
      onPermissionChange: (permission, apiSupported) => {
        setMicPermissionState(permission);
        setPermissionsApiSupported(apiSupported);
      },
      onListeningStarted: () => {
        setIsMicRequesting(false);
        setSpeechError(null);
        setVoiceDiagnostics('Browser microphone captured and speech recognition active.');
        setVoiceState('LISTENING');
      },
      onInterimTranscript: (transcript) => {
        setRecognizedCommand(transcript);
      },
      onFinalTranscript: (transcript) => {
        setIsMicRequesting(false);
        setRecognizedCommand(transcript);
        setVoiceState('PROCESSING');
        void handleCommandRef.current(transcript);
      },
      onRmsLevel: (level) => {
        setVoiceRmsLevel(level);
      },
      onStopped: () => {
        setIsMicRequesting(false);
        setVoiceRmsLevel(0);
        setVoiceState((prev) => (prev === 'LISTENING' ? 'IDLE' : prev));
      },
      onPermissionDenied: (message) => {
        setIsMicRequesting(false);
        setVoiceRmsLevel(0);
        setVoiceState('PERMISSION_REQUIRED');
        setSpeechError(message);
        setVoiceDiagnostics(message);
      },
      onError: (message) => {
        setIsMicRequesting(false);
        setVoiceRmsLevel(0);
        setVoiceState('ERROR');
        setSpeechError(message);
        setVoiceDiagnostics(message);
      },
    });

    return () => {
      mounted = false;
      clearAssemblyTimers();
      watchedPermissionStatus?.removeEventListener?.('change', handlePermissionChange);
      micControllerRef.current?.dispose();
      micControllerRef.current = null;
      stopSpeaking();
    };
  }, []);

  useEffect(() => {
    if (!viewMenuOpen) return;
    const handleOutside = (e: MouseEvent) => {
      if (viewMenuRef.current && !viewMenuRef.current.contains(e.target as Node)) {
        setViewMenuOpen(false);
      }
    };
    window.addEventListener('mousedown', handleOutside);
    return () => window.removeEventListener('mousedown', handleOutside);
  }, [viewMenuOpen]);

  const activateNormalMode = () => {
    clearAssemblyTimers();
    setAssemblyStage('IDLE');
    setInterfaceMode('NORMAL');
    setActiveId('SK');
    const msg = 'SK Master Reactor active in Normal Mode.';
    recordResult(msg, 'SK');
    void speak(msg, 'SK');
    void recordModeEvent('NORMAL', 'SK', msg);
  };

  const activatePhoenixMode = () => {
    clearAssemblyTimers();
    setAssemblyStage('IDLE');
    setInterfaceMode('PHOENIX');
    setActiveId('SK');
    const msg = 'SK Phoenix Mode engaged.';
    recordResult(msg, 'SK');
    void speak(msg, 'SK');
    void recordModeEvent('PHOENIX', 'SK', msg);
  };

  const triggerAssembleAll = () => {
    clearAssemblyTimers();
    setActiveId('SK');
    setInterfaceMode('ASSEMBLED');

    const stepMs = animationQuality === 'REDUCED_MOTION' ? 280 : 820;

    setAssemblyStage('SYSTEM_INITIALIZING');
    void speak('System initializing. Assembling all four assistant cores.', 'SK');

    assemblyTimersRef.current.push(
      window.setTimeout(() => {
        setAssemblyStage('CORE_DEPLOYMENT');
      }, stepMs),
      window.setTimeout(() => {
        setAssemblyStage('HOLOGRAPHIC_ASSEMBLY');
      }, stepMs * 2),
      window.setTimeout(() => {
        setAssemblyStage('CORE_SYNCHRONIZATION');
      }, stepMs * 3),
      window.setTimeout(() => {
        setAssemblyStage('OMEGA_ONLINE');
        const onlineMsg = 'OMEGA ONLINE — All five AI cores synchronized under SK Master.';
        recordResult(onlineMsg, 'SK');
        void speak('Omega online. All five cores synchronized.', 'SK');
        void recordModeEvent('ASSEMBLE_ALL', 'SK', onlineMsg);
      }, stepMs * 4)
    );
  };

  const triggerDisassembleAll = () => {
    clearAssemblyTimers();
    setAssemblyStage('DISASSEMBLING');
    void speak('Disassembling cores. Returning to SK normal mode.', 'SK');

    assemblyTimersRef.current.push(
      window.setTimeout(() => {
        setAssemblyStage('IDLE');
        setInterfaceMode('NORMAL');
        setActiveId('SK');
        const msg = 'SK Normal Mode restored.';
        recordResult(msg, 'SK');
        void recordModeEvent('DISASSEMBLE_ALL', 'SK', 'Disassembled all cores back to SK Normal Mode.');
      }, 900)
    );
  };

  const activateAssistantDirect = (id: AssistantId) => {
    if (id === 'SK') {
      setActiveId('SK');
      if (interfaceMode === 'ASSISTANT_ACTIVE') {
        setInterfaceMode('NORMAL');
      }
      const msg = 'SK Master Controller active.';
      recordResult(msg, 'SK');
      void speak(msg, 'SK');
      void recordModeEvent('SK_FOCUS', 'SK', msg);
      return;
    }

    if (state && !state.registry[id].isEnabled) {
      setErrorBanner(`${id} is currently disabled in System Status.`);
      return;
    }

    clearAssemblyTimers();
    setActiveId(id);
    if (interfaceMode !== 'ASSEMBLED') {
      setInterfaceMode('ASSISTANT_ACTIVE');
    }
    const msg = `${id} core active under SK Master supervision.`;
    recordResult(msg, id);
    void speak(msg, id);
    void recordModeEvent('ASSISTANT_ACTIVE', id, msg);
  };

  const routeTaskToBackend = async (cmd: string, preferred: AssistantId | null) => {
    const cleanCmd = cmd.trim();
    if (!cleanCmd || isRouting || inFlightCommandRef.current === cleanCmd.toLowerCase()) return;
    inFlightCommandRef.current = cleanCmd.toLowerCase();
    setErrorBanner(null);
    setLastFailedCommand(null);
    setIsRouting(true);
    setVoiceState('PROCESSING');

    const controller = new AbortController();
    const timeoutId = window.setTimeout(() => controller.abort(), 30_000);

    try {
      const res = await fetch('/api/sk/route', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          command: cleanCmd,
          preferredAssistant: preferred && preferred !== 'SK' ? preferred : null,
        }),
        signal: controller.signal,
      });
      const data = await safeReadJson<{
        error?: string;
        mode?: 'DIRECT_RESPONSE' | 'PROPOSAL';
        speaker?: AssistantId;
        replyText?: string;
        deduplicated?: boolean;
        proposal?: OmegaPlatformState['pendingProposals'][number];
        state?: OmegaPlatformState;
      }>(res);

      if (!res.ok || !data) {
        const msg = classifyHttpError(res.status, data?.error);
        setErrorBanner(msg);
        setLastFailedCommand({ command: cleanCmd, preferred });
        if (data?.state) setState(data.state);
        setVoiceState('IDLE');
        return;
      }

      if (data.state) setState(data.state);
      setLastFailedCommand(null);

      if (data.mode === 'DIRECT_RESPONSE') {
        const speaker: AssistantId = data.speaker || 'SK';
        if (speaker !== 'SK') {
          setActiveId(speaker);
          if (interfaceMode === 'NORMAL') {
            setInterfaceMode('ASSISTANT_ACTIVE');
          }
        }
        const reply = data.replyText || 'Command completed.';
        setVoiceState('RESPONDING');
        recordResult(reply, speaker);
        await speak(reply, speaker, false, data.state);
        return;
      }

      const proposal = data.proposal;
      if (!proposal) {
        setVoiceState('IDLE');
        return;
      }
      setInlineCriticalConfirmed(false);

      if (data.deduplicated) {
        const dupMsg = `Pending approval already exists for ${proposal.targetAssistant} (${proposal.exactOperation}).`;
        recordResult(dupMsg, 'SK');
        setVoiceState('IDLE');
        return;
      }

      const recipientHint =
        proposal.parameters?.recipientQuery || proposal.parameters?.contactName || '';
      const askText =
        proposal.riskLevel === 'CRITICAL'
          ? `Critical authorization required. Review parameters and confirm ${proposal.exactOperation} on screen.`
          : recipientHint
            ? `Should I proceed with ${proposal.actionSummary}? Say yes to approve or no to cancel.`
            : `${proposal.targetAssistant} is ready for ${proposal.actionSummary}. Please approve or reject on screen.`;

      const speakerCore: AssistantId =
        data.state?.registry[proposal.targetAssistant]?.isEnabled ? proposal.targetAssistant : 'SK';
      setVoiceState('RESPONDING');
      recordResult(askText, speakerCore);
      await speak(askText, speakerCore, false, data.state);
    } catch (err) {
      const isTimeout = err instanceof DOMException && err.name === 'AbortError';
      setVoiceState('IDLE');
      setLastFailedCommand({ command: cleanCmd, preferred });
      setErrorBanner(
        isTimeout
          ? 'Request timed out waiting for SK Master Core. Click Retry Command to try again.'
          : 'Network error while routing command to SK Master Core. Check connection and retry.'
      );
    } finally {
      window.clearTimeout(timeoutId);
      inFlightCommandRef.current = null;
      setIsRouting(false);
    }
  };

  const handleCommandOrVoiceInput = async (rawCommand?: string) => {
    const raw = (rawCommand ?? commandInput).trim();
    if (!raw) return;
    setErrorBanner(null);
    if (!rawCommand) setCommandInput('');

    // Voice/Text confirmation handling when an important proposal is awaiting user decision
    const topPending = state?.pendingProposals[0];
    if (topPending) {
      const norm = raw.toLowerCase().replace(/[.!?]/g, '').trim();
      if (/^(?:yes|yes please|approve|confirm|send it|go ahead|do it|proceed)$/.test(norm)) {
        if (topPending.riskLevel === 'CRITICAL') {
          const guardMsg = 'This action is marked CRITICAL. Please confirm using the on-screen confirmation checkbox.';
          recordResult(guardMsg, 'SK');
          void speak(guardMsg, 'SK');
          return;
        }
        await handleApproveProposal(topPending.proposalId, topPending.payloadHash);
        return;
      }
      if (/^(?:no|no thanks|cancel|reject|deny|abort|don't|dont)$/.test(norm)) {
        await handleRejectProposal(topPending.proposalId);
        return;
      }
    }

    const parsed = parseSkVoiceCommand(raw);
    switch (parsed.type) {
      case 'ACTIVATE_MASTER':
        activateAssistantDirect('SK');
        return;
      case 'SET_MODE':
        if (parsed.mode === 'NORMAL') activateNormalMode();
        else if (parsed.mode === 'PHOENIX') activatePhoenixMode();
        else if (parsed.mode === 'ASSEMBLED') triggerAssembleAll();
        return;
      case 'ASSEMBLE_ALL':
        triggerAssembleAll();
        return;
      case 'DISASSEMBLE_ALL':
        triggerDisassembleAll();
        return;
      case 'OPEN_DETAILS_VIEW':
        setViewMenuOpen(false);
        if (parsed.diagTab) {
          setRequestedDiagTab(parsed.diagTab);
        }
        setActiveSection(parsed.section);
        recordResult(parsed.spokenSummary, 'SK');
        void speak(parsed.spokenSummary, 'SK');
        return;
      case 'CLOSE_DETAILS_VIEW':
        setViewMenuOpen(false);
        setActiveSection(null);
        recordResult('Closed details overlay.', 'SK');
        setVoiceState((prev) => (prev === 'PROCESSING' ? 'IDLE' : prev));
        return;
      case 'STOP_SPEECH':
        stopSpeaking();
        recordResult('SK stopped active voice playback.', 'SK');
        return;
      case 'SET_VOICE_ENABLED':
        if (!parsed.enabled) {
          stopSpeaking();
          setVoiceEnabled(false);
          recordResult('SK disabled voice output.', 'SK');
        } else {
          setVoiceEnabled(true);
          const msg = 'SK Master voice output re-enabled.';
          recordResult(msg, 'SK');
          void speak(msg, 'SK', true);
        }
        return;
      case 'ACTIVATE_ASSISTANT':
        if (!parsed.trailingCommand) {
          activateAssistantDirect(parsed.assistantId);
        } else {
          if (state && !state.registry[parsed.assistantId].isEnabled) {
            setErrorBanner(`${parsed.assistantId} is currently disabled in System Status.`);
            return;
          }
          clearAssemblyTimers();
          setActiveId(parsed.assistantId);
          if (interfaceMode !== 'ASSEMBLED') {
            setInterfaceMode('ASSISTANT_ACTIVE');
          }
          await routeTaskToBackend(raw, parsed.assistantId);
        }
        return;
      case 'ROUTE_COMMAND':
        await routeTaskToBackend(parsed.commandText, activeId === 'SK' ? null : activeId);
        return;
    }
  };

  handleCommandRef.current = handleCommandOrVoiceInput;

  const toggleMicrophone = () => {
    const controller = micControllerRef.current;
    if (!controller) return;
    setSpeechError(null);

    if (voiceState === 'LISTENING' || controller.isActive()) {
      controller.stop();
      return;
    }

    stopSpeaking();
    void controller.startOrRetry();
  };

  const retryMicrophone = () => {
    const controller = micControllerRef.current;
    if (!controller) return;
    setSpeechError(null);
    stopSpeaking();
    void controller.retry();
  };

  const handleUpdateVoiceTuning = async (id: AssistantId, pitch: number, speechRate: number) => {
    const res = await fetch(`/api/voice/config/${id}`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ pitch, speechRate }),
    });
    const data = await res.json();
    if (!res.ok) {
      setErrorBanner(data.error || 'Failed to update voice configuration.');
      return;
    }
    setState(data.state);
    recordResult(`Saved ${id} voice calibration (Pitch ${pitch.toFixed(2)}, Rate ${speechRate.toFixed(2)}x).`, id);
  };

  const handlePreviewVoice = (id: AssistantId) => {
    const scripts: Record<AssistantId, string> = {
      SK: 'SK Master Controller online. All four assistant cores stand ready for supervised task authorization.',
      JARVIS: 'Good evening. JARVIS reasoning module is calibrated for structured analysis and knowledge synthesis.',
      MAGMITE: 'MAGMITE hardware control core active. Device sensors, audio streams, and connectivity await your approval.',
      ULTRON: 'ULTRON diagnostic engine operational. Deep system telemetry and fault detection protocols engaged.',
      FRIDAY: 'Hi there, FRIDAY scheduling core is ready. Let me know whenever you need a reminder or timeline plan.',
    };
    void speak(scripts[id], id, true);
  };

  const handleApproveProposal = async (proposalId: string, payloadHash: string) => {
    setErrorBanner(null);
    setIsExecuting(true);
    try {
      const res = await fetch('/api/sk/approve', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ proposalId, payloadHash }),
      });
      const data = await safeReadJson<{
        error?: string;
        state?: OmegaPlatformState;
        result?: { resultSummary: string; targetAssistant: AssistantId };
      }>(res);
      if (data?.state) setState(data.state);
      if (!res.ok || !data?.result) {
        setErrorBanner(classifyHttpError(res.status, data?.error || 'Task approval or permission check blocked execution.'));
        return;
      }
      setInlineCriticalConfirmed(false);
      recordResult(data.result.resultSummary, data.result.targetAssistant);
      void speak(data.result.resultSummary, data.result.targetAssistant, false, data.state);
    } catch {
      setErrorBanner('Failed to execute approved task. Please retry.');
    } finally {
      setIsExecuting(false);
    }
  };

  const handleRejectProposal = async (proposalId: string) => {
    setErrorBanner(null);
    try {
      const res = await fetch('/api/sk/reject', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ proposalId, reason: 'User declined task delegation' }),
      });
      const data = await safeReadJson<{ state?: OmegaPlatformState; error?: string }>(res);
      if (data?.state) setState(data.state);
      setInlineCriticalConfirmed(false);
      const cancelledMsg = 'Task cancelled as requested.';
      recordResult(cancelledMsg, 'SK');
      void speak(cancelledMsg, 'SK', false, data?.state);
    } catch {
      setErrorBanner('Could not cancel proposal due to a network issue.');
    }
  };

  const handleToggleAssistant = async (id: AssistantId, enabled: boolean) => {
    if (id === 'SK') return;
    setErrorBanner(null);
    const res = await fetch(`/api/assistants/${id}/toggle`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ enabled }),
    });
    const data = await res.json();
    if (!res.ok) {
      setErrorBanner(data.error || 'Failed to update assistant registration.');
      return;
    }
    setState(data.state);
  };

  const handleTogglePermission = async (permission: string, granted: boolean) => {
    const res = await fetch('/api/permissions/toggle', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ permission, granted }),
    });
    const data = await res.json();
    if (data.state) setState(data.state);
  };

  const handleCheckAssistantStatus = async (id: AssistantId) => {
    setErrorBanner(null);
    try {
      const res = await fetch(`/api/assistants/${id}/status`, { method: 'POST' });
      const data = await res.json();
      if (!res.ok) {
        setErrorBanner(data.error || `Unable to retrieve status for ${id}.`);
        return;
      }
      if (data.state) setState(data.state);
      const summaryText = data.statusReport?.spokenSummary || `${id} status retrieved.`;
      recordResult(summaryText, id);
      setActiveId(id);
      if (id !== 'SK' && interfaceMode !== 'ASSEMBLED') {
        setInterfaceMode('ASSISTANT_ACTIVE');
      }
      void speak(summaryText, id, false, data.state);
    } catch {
      setErrorBanner(`Failed to query operational status for ${id}.`);
    }
  };

  const handleGenerateReport = async () => {
    setGeneratingReport(true);
    setErrorBanner(null);
    try {
      const res = await fetch('/api/sk/report', { method: 'POST' });
      const data = await res.json();
      if (!res.ok) {
        setErrorBanner(data.error || 'Report generation failed.');
        return;
      }
      setState(data.state);
      recordResult(`Generated system report ${data.report.reportId}.`, 'SK');
    } finally {
      setGeneratingReport(false);
    }
  };

  const handleAcknowledgeAlert = async (alertId: string) => {
    const res = await fetch(`/api/alerts/${alertId}/ack`, { method: 'POST' });
    const data = await res.json();
    if (data.state) setState(data.state);
  };

  const handleToggleReminder = async (id: string) => {
    const res = await fetch(`/api/reminders/${id}/toggle`, { method: 'POST' });
    const data = await res.json();
    if (data.state) setState(data.state);
  };

  const openOperationsSection = (
    section: OperationsSectionId,
    toggleIfOpen = true,
    diagTab?: 'voice' | 'audit' | 'android'
  ) => {
    if (diagTab) setRequestedDiagTab(diagTab);
    setActiveSection((prev) => (toggleIfOpen && prev === section ? null : section));
    setViewMenuOpen(false);
  };

  if (!state) {
    return (
      <div className="min-h-screen bg-[#050608] text-slate-300 flex items-center justify-center text-sm font-mono">
        Initializing SK Master Reactor...
      </div>
    );
  }

  const activeProfile = state.registry[activeId];
  const pendingCount = state.pendingProposals.length;
  const skEntry = state.registry.SK;
  const hasActiveTask =
    isRouting ||
    isExecuting ||
    Object.values(state.registry).some((a) => a.metrics && a.metrics.activeTaskCount > 0);
  const showSkMasterReactor =
    activeId === 'SK' || interfaceMode === 'ASSEMBLED' || interfaceMode === 'PHOENIX';

  return (
    <div className="min-h-screen bg-[#050608] text-slate-100 flex flex-col">
      {/* Compact 3-Zone Top Header */}
      <header className="h-14 border-b border-white/10 bg-[#050608]/95 sticky top-0 z-30 backdrop-blur shrink-0">
        <div className="h-full px-3 sm:px-5 flex items-center justify-between gap-3">
          {/* Zone 1: Mobile Drawer Trigger + Brand */}
          <div className="flex items-center gap-2.5 min-w-0">
            <button
              type="button"
              onClick={() => setMobileDrawerOpen(true)}
              aria-label="Open assistant navigation drawer"
              className="lg:hidden w-10 h-10 min-w-[44px] min-h-[44px] inline-flex items-center justify-center rounded-lg text-slate-300 hover:text-white hover:bg-white/5 transition-colors shrink-0"
            >
              <Menu className="w-5 h-5" />
            </button>
            <button
              type="button"
              onClick={() => activateAssistantDirect('SK')}
              className="font-display text-sm sm:text-base font-bold tracking-tight text-amber-100 whitespace-nowrap shrink-0"
            >
              Project Omega
            </button>
          </div>

          {/* Zone 2: Essential Real-Time Status Only */}
          <div className="hidden sm:flex items-center gap-2 text-xs font-mono text-slate-400 truncate">
            <span className={skEntry.status === 'ONLINE' ? 'text-emerald-400' : 'text-amber-300'}>
              SK {skEntry.status}
            </span>
            <span aria-hidden="true">·</span>
            <span>{interfaceMode}</span>
            <span aria-hidden="true">·</span>
            <span className="text-slate-200">Focus: {activeProfile.displayName}</span>
            {hasActiveTask && (
              <>
                <span aria-hidden="true">·</span>
                <span className="text-sky-400">Active task</span>
              </>
            )}
          </div>

          {/* Zone 3: View Dropdown + Pending Approval Jump (Only When > 0) + Voice Mute */}
          <div className="flex items-center gap-2 shrink-0">
            {pendingCount > 0 && (
              <button
                type="button"
                onClick={() => openOperationsSection('approvals', false)}
                className="min-h-[36px] inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-amber-400 text-slate-950 text-xs font-semibold hover:bg-amber-300 transition-colors tabular-nums whitespace-nowrap shrink-0"
              >
                <Lock className="w-3.5 h-3.5" />
                <span>{pendingCount} Pending</span>
              </button>
            )}

            <div className="relative" ref={viewMenuRef}>
              <button
                type="button"
                onClick={() => setViewMenuOpen((o) => !o)}
                aria-expanded={viewMenuOpen}
                aria-haspopup="menu"
                className="min-h-[36px] inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-white/5 hover:bg-white/10 border border-white/10 text-xs font-medium text-slate-200 transition-colors whitespace-nowrap shrink-0"
              >
                <span>View</span>
                <ChevronDown className="w-3.5 h-3.5 text-amber-400" />
              </button>

              {viewMenuOpen && (
                <div
                  role="menu"
                  className="absolute right-0 mt-2 w-60 rounded-xl bg-[#090B10] border border-white/15 shadow-2xl py-1.5 z-50 text-xs"
                >
                  {(
                    [
                      { label: 'System & Mission Status', section: 'system' as OperationsSectionId },
                      { label: 'Five Assistant Details', section: 'activity' as OperationsSectionId },
                      { label: 'Previous Command Results', section: 'history' as OperationsSectionId },
                      { label: 'Device Telemetry & Info', section: 'device' as OperationsSectionId },
                      { label: `Approval Center${pendingCount > 0 ? ` (${pendingCount})` : ''}`, section: 'approvals' as OperationsSectionId },
                      { label: 'Voice Settings & Calibration', section: 'diagnostics' as OperationsSectionId, diagTab: 'voice' as const },
                      { label: 'Audit Logs & Reports', section: 'diagnostics' as OperationsSectionId, diagTab: 'audit' as const },
                      { label: 'Kotlin Android Project', section: 'diagnostics' as OperationsSectionId, diagTab: 'android' as const },
                    ]
                  ).map((item) => (
                    <button
                      key={item.label}
                      type="button"
                      role="menuitem"
                      onClick={() => openOperationsSection(item.section, false, item.diagTab)}
                      className="w-full text-left px-3.5 py-2 text-slate-200 hover:bg-white/[0.08] hover:text-amber-300 transition-colors"
                    >
                      {item.label}
                    </button>
                  ))}
                </div>
              )}
            </div>

            <button
              type="button"
              onClick={() => {
                if (voiceEnabled) stopSpeaking();
                setVoiceEnabled((v) => !v);
              }}
              aria-label={voiceEnabled ? 'Mute voice output' : 'Enable voice output'}
              title={voiceEnabled ? 'Mute voice output' : 'Enable voice output'}
              className="w-10 h-10 min-w-[40px] min-h-[40px] inline-flex items-center justify-center rounded-lg bg-white/5 hover:bg-white/10 text-slate-300 transition-colors shrink-0"
            >
              {voiceEnabled ? <Volume2 className="w-4 h-4 text-amber-400" /> : <VolumeX className="w-4 h-4" />}
            </button>
          </div>
        </div>
      </header>

      {/* Main Collapsible Sidebar + Focused Open Core Stage */}
      <div className="flex-1 flex min-w-0">
        <AssistantSidebar
          registry={state.registry}
          activeId={activeId}
          speakingAssistant={speakingAssistant}
          collapsed={sidebarCollapsed}
          mobileOpen={mobileDrawerOpen}
          pendingCount={pendingCount}
          activeSection={activeSection}
          onToggleCollapse={() => setSidebarCollapsed((c) => !c)}
          onCloseMobile={() => setMobileDrawerOpen(false)}
          onSelectAssistant={activateAssistantDirect}
          onSelectSection={(sec) => openOperationsSection(sec, true)}
        />

        <main className="flex-1 min-w-0 px-3 sm:px-6 py-4 sm:py-5 flex flex-col items-center justify-center">
          <div className="w-full max-w-[920px] space-y-4">
            {errorBanner && (
              <div className="bg-red-950/50 border border-red-500/40 rounded-xl px-3.5 py-2.5 flex items-center justify-between gap-3 text-xs sm:text-sm text-red-200">
                <div className="flex items-center gap-2 min-w-0">
                  <ShieldAlert className="w-4 h-4 text-red-400 shrink-0" />
                  <span className="truncate">{errorBanner}</span>
                </div>
                <div className="flex items-center gap-2.5 shrink-0">
                  {lastFailedCommand && (
                    <button
                      type="button"
                      onClick={() =>
                        void routeTaskToBackend(lastFailedCommand.command, lastFailedCommand.preferred)
                      }
                      disabled={isRouting}
                      className="inline-flex items-center gap-1 px-2.5 py-1 rounded-md bg-amber-400/20 border border-amber-400/40 text-amber-200 hover:bg-amber-400/30 text-xs font-medium whitespace-nowrap"
                    >
                      <RefreshCw className="w-3 h-3" />
                      Retry Command
                    </button>
                  )}
                  <button
                    type="button"
                    onClick={() => {
                      setErrorBanner(null);
                      setLastFailedCommand(null);
                    }}
                    className="text-xs text-red-300 hover:text-white whitespace-nowrap"
                  >
                    Dismiss
                  </button>
                </div>
              </div>
            )}

            {/* Minimal Centered Mode Controls */}
            <div className="flex justify-center">
              <div className="inline-flex items-center gap-1 p-1 bg-[#0D1017]/80 border border-white/10 rounded-lg shrink-0">
                <button
                  type="button"
                  onClick={activateNormalMode}
                  className={`inline-flex items-center gap-1 px-2.5 py-1 text-[11px] font-medium rounded-md transition-colors whitespace-nowrap ${
                    interfaceMode === 'NORMAL' && activeId === 'SK'
                      ? 'bg-amber-500/20 text-amber-200'
                      : 'text-slate-400 hover:text-white'
                  }`}
                >
                  <RotateCcw className="w-3 h-3" />
                  Normal
                </button>
                <button
                  type="button"
                  onClick={activatePhoenixMode}
                  className={`inline-flex items-center gap-1 px-2.5 py-1 text-[11px] font-medium rounded-md transition-colors whitespace-nowrap ${
                    interfaceMode === 'PHOENIX'
                      ? 'bg-orange-500/20 text-orange-200'
                      : 'text-slate-400 hover:text-white'
                  }`}
                >
                  <Flame className="w-3 h-3 text-orange-400" />
                  Phoenix
                </button>
                <button
                  type="button"
                  onClick={interfaceMode === 'ASSEMBLED' ? triggerDisassembleAll : triggerAssembleAll}
                  className={`inline-flex items-center gap-1 px-2.5 py-1 text-[11px] font-medium rounded-md transition-colors whitespace-nowrap ${
                    interfaceMode === 'ASSEMBLED'
                      ? 'bg-sky-500/20 text-sky-200'
                      : 'text-slate-400 hover:text-white'
                  }`}
                >
                  <Layers className="w-3 h-3 text-sky-400" />
                  {interfaceMode === 'ASSEMBLED' ? 'Disassemble' : 'Assemble All'}
                </button>
              </div>
            </div>

            {/* Dominant Visual Focus: Locked SK Master Reactor, MAGMITE Open Floating Core, or Individual Core */}
            {showSkMasterReactor ? (
              <SkMasterReactor
                interfaceMode={interfaceMode}
                assemblyStage={assemblyStage}
                activeIdentity={activeId}
                speakingAssistant={speakingAssistant}
                voiceState={voiceState}
                voiceRmsLevel={voiceRmsLevel}
                animationQuality={animationQuality}
                registry={state.registry}
                isRouting={isRouting}
                isExecuting={isExecuting}
                onSelectCore={activateAssistantDirect}
              />
            ) : activeId === 'MAGMITE' ? (
              <MagmiteFloatingCore
                activeIdentity={activeProfile}
                isRouting={isRouting}
                isExecuting={isExecuting}
                pendingCount={pendingCount}
                voiceState={voiceState}
                voiceRmsLevel={voiceRmsLevel}
                speaking={speakingAssistant === 'MAGMITE'}
                animationQuality={animationQuality}
                onReturnToSk={() => activateAssistantDirect('SK')}
                onCheckStatus={() => void handleCheckAssistantStatus('MAGMITE')}
              />
            ) : (
              <HolographicCore
                activeIdentity={activeProfile}
                isRouting={isRouting}
                isExecuting={isExecuting}
                pendingCount={pendingCount}
                voiceState={voiceState}
                voiceRmsLevel={voiceRmsLevel}
                speaking={speakingAssistant === activeId}
                animationQuality={animationQuality}
                onReturnToSk={() => activateAssistantDirect('SK')}
                onCheckStatus={() => void handleCheckAssistantStatus(activeId)}
              />
            )}

            {/* Shared Compact Voice & Text Command Bar */}
            <CompactCommandBar
              commandInput={commandInput}
              onChangeInput={setCommandInput}
              onSubmit={() => void handleCommandOrVoiceInput()}
              voiceState={voiceState}
              micPermissionState={micPermissionState}
              isMicRequesting={isMicRequesting}
              voiceRmsLevel={voiceRmsLevel}
              recognizedCommand={recognizedCommand}
              speechError={speechError}
              isRouting={isRouting}
              speakingAssistant={speakingAssistant}
              onToggleMicrophone={toggleMicrophone}
              onRetryMicrophone={retryMicrophone}
              onStopSpeaking={stopSpeaking}
            />

            {/* Inline Floating Approval Prompt (Appears ONLY for Important / Critical tasks) */}
            {state.pendingProposals[0] && (
              <div
                className="rounded-xl bg-[#090B10]/95 border px-4 py-3.5 shadow-2xl space-y-2.5"
                style={{
                  borderColor:
                    state.pendingProposals[0].riskLevel === 'CRITICAL'
                      ? 'rgba(239, 68, 68, 0.55)'
                      : `${state.registry[state.pendingProposals[0].targetAssistant].visualIdentity.primaryColor}66`,
                }}
              >
                <div className="flex flex-wrap items-center justify-between gap-2 text-xs font-mono">
                  <span
                    style={{
                      color: state.registry[state.pendingProposals[0].targetAssistant].visualIdentity.primaryColor,
                    }}
                  >
                    {state.pendingProposals[0].targetAssistant} · {state.pendingProposals[0].exactOperation}
                  </span>
                  <span
                    className={
                      state.pendingProposals[0].riskLevel === 'CRITICAL'
                        ? 'text-red-400 font-semibold'
                        : 'text-amber-400'
                    }
                  >
                    Risk: {state.pendingProposals[0].riskLevel}
                  </span>
                </div>
                <div className="text-xs sm:text-sm text-white font-medium">
                  {state.pendingProposals[0].actionSummary}
                </div>
                <div className="text-[11px] font-mono text-slate-400 break-all">
                  Params: {JSON.stringify(state.pendingProposals[0].parameters)} · Hash{' '}
                  {state.pendingProposals[0].payloadHash.slice(0, 12)}
                </div>
                {state.pendingProposals[0].riskLevel === 'CRITICAL' && (
                  <label className="flex items-start gap-2 rounded-lg bg-red-950/35 border border-red-500/40 px-3 py-2 text-xs text-red-200 cursor-pointer">
                    <input
                      type="checkbox"
                      checked={inlineCriticalConfirmed}
                      onChange={(e) => setInlineCriticalConfirmed(e.target.checked)}
                      className="mt-0.5 accent-red-500"
                    />
                    <span>
                      Strong Confirmation: I verified all parameters and authorize this CRITICAL action.
                    </span>
                  </label>
                )}
                <div className="flex flex-wrap items-center gap-2">
                  <button
                    type="button"
                    disabled={
                      isExecuting ||
                      (state.pendingProposals[0].riskLevel === 'CRITICAL' && !inlineCriticalConfirmed)
                    }
                    onClick={() =>
                      void handleApproveProposal(
                        state.pendingProposals[0].proposalId,
                        state.pendingProposals[0].payloadHash
                      )
                    }
                    className="min-h-[36px] inline-flex items-center gap-1.5 px-3.5 py-1.5 rounded-lg bg-emerald-500 hover:bg-emerald-400 disabled:opacity-50 text-slate-950 text-xs font-semibold transition-colors"
                  >
                    <CheckCircle2 className="w-3.5 h-3.5" />
                    {isExecuting
                      ? 'Executing...'
                      : state.pendingProposals[0].riskLevel === 'CRITICAL'
                        ? 'Confirm Critical Action'
                        : 'Approve'}
                  </button>
                  <button
                    type="button"
                    disabled={isExecuting}
                    onClick={() => void handleRejectProposal(state.pendingProposals[0].proposalId)}
                    className="min-h-[36px] inline-flex items-center gap-1.5 px-3.5 py-1.5 rounded-lg bg-white/10 hover:bg-white/15 text-slate-200 text-xs font-medium transition-colors"
                  >
                    <XCircle className="w-3.5 h-3.5" />
                    Reject
                  </button>
                  <button
                    type="button"
                    onClick={() => openOperationsSection('approvals', false)}
                    className="ml-auto text-[11px] font-mono text-amber-300 hover:text-amber-200"
                  >
                    Approval Center ({state.pendingProposals.length})
                  </button>
                </div>
              </div>
            )}

            {/* Subtle single-line latest reply readout */}
            {commandResults[0] && state.pendingProposals.length === 0 && (
              <div className="text-center text-xs text-slate-400 truncate px-2">
                <span className="font-mono text-amber-400/90 mr-1.5">{commandResults[0].speaker}:</span>
                <span className="text-slate-300">{commandResults[0].text}</span>
              </div>
            )}
          </div>
        </main>
      </div>

      {/* Controlled Details Modal Overlay (Opened Only via Side Menu, View Menu, or Voice Commands) */}
      <ExpandableOperationsDrawer
        state={state}
        activeSection={activeSection}
        requestedDiagTab={requestedDiagTab}
        commandResults={commandResults}
        onToggleSection={(sec) => openOperationsSection(sec, false)}
        onClose={() => setActiveSection(null)}
        interfaceMode={interfaceMode}
        animationQuality={animationQuality}
        voiceEnabled={voiceEnabled}
        voiceProviderMode={voiceProviderMode}
        voiceState={voiceState}
        micPermissionState={micPermissionState}
        permissionsApiSupported={permissionsApiSupported}
        speechRecognitionSupported={speechRecognitionSupported}
        isMicRequesting={isMicRequesting}
        speakingAssistant={speakingAssistant}
        recognizedCommand={recognizedCommand}
        voiceDiagnostics={voiceDiagnostics}
        browserVoices={browserVoices}
        isExecuting={isExecuting}
        generatingReport={generatingReport}
        onSelectMode={(mode) => {
          if (mode === 'NORMAL') activateNormalMode();
          else if (mode === 'PHOENIX') activatePhoenixMode();
          else if (mode === 'ASSEMBLED') triggerAssembleAll();
          else triggerDisassembleAll();
        }}
        onChangeAnimationQuality={setAnimationQuality}
        onToggleVoiceEnabled={(enabled) => {
          if (!enabled) stopSpeaking();
          setVoiceEnabled(enabled);
        }}
        onChangeProviderMode={setVoiceProviderMode}
        onUpdateVoiceTuning={handleUpdateVoiceTuning}
        onPreviewVoice={handlePreviewVoice}
        onStopSpeaking={stopSpeaking}
        onToggleMicrophone={toggleMicrophone}
        onRetryMicrophone={retryMicrophone}
        onApproveProposal={handleApproveProposal}
        onRejectProposal={handleRejectProposal}
        onToggleAssistant={handleToggleAssistant}
        onCheckAssistantStatus={handleCheckAssistantStatus}
        onTogglePermission={handleTogglePermission}
        onToggleReminder={handleToggleReminder}
        onGenerateReport={handleGenerateReport}
        onAcknowledgeAlert={handleAcknowledgeAlert}
      />
    </div>
  );
}
