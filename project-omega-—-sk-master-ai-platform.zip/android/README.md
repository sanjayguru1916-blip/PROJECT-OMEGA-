# PROJECT OMEGA — SK Master AI Platform (Android)

Multi-assistant Android AI platform built with **Kotlin**, **Jetpack Compose**, **MVVM + Clean Architecture**, **Room**, **DataStore**, **WorkManager**, and a modular **Backend AI Proxy Gateway**.

## 1. Five Independent AI Identities

| Identity | Role | Core Module | Visual Accent |
|---|---|---|---|
| **SK** | Central Master Controller | `com.projectomega.sk.sk.router` | Ice Cyan (`#38BDF8`) |
| **JARVIS** | General Intelligence, Knowledge & Reasoning | `com.projectomega.sk.assistants.jarvis` | Sapphire (`#3B82F6`) |
| **MAGMITE** | Android Phone Controls & Device Operations | `com.projectomega.sk.assistants.magmite` | Amber (`#F59E0B`) |
| **ULTRON** | Advanced System Analysis & Automation | `com.projectomega.sk.assistants.ultron` | Crimson (`#EF4444`) |
| **FRIDAY** | Personal Assistance, Reminders & Scheduling | `com.projectomega.sk.assistants.friday` | Emerald (`#10B981`) |

## 2. Security & Architectural Invariants

1. **Zero Unapproved Delegation**: `SkMasterCore` never executes a delegated command directly. Every command produces an immutable `TaskProposal` with a SHA-256 `payloadHash`.
2. **Task-Specific Single-Use Approval**: `ApprovalManager` mints a single-use `ApprovalToken` bound to `proposalId` + `payloadHash` + `requiredPermissions`. Replaying a token on a modified or different task fails immediately.
3. **Zero Permission Bypass**: `AndroidPermissionGuard` inspects `ContextCompat.checkSelfPermission`, `NotificationManager.isNotificationPolicyAccessGranted`, and `AlarmManager.canScheduleExactAlarms` before execution, returning missing permissions to the Activity launcher.
4. **No Client-Side API Keys**: `BackendProxyAiProvider` communicates only with `BuildConfig.OMEGA_BACKEND_URL` (the Express `/api/sk/*` backend in this project). No Gemini API keys exist in APK source or BuildConfig.
5. **Chained Audit Trail**: `AuditLogger` computes SHA-256 hash links (`prevHash -> entryHash`) in Room (`OmegaDatabase`).

## 3. Building the APK

1. Open `/android` in **Android Studio Ladybug (2024.2+)** with JDK 17.
2. In `/android/local.properties`, configure the backend proxy URL (for Android Emulator pointing to the host Express server on port 3000):
   ```properties
   OMEGA_BACKEND_URL=http://10.0.2.2:3000
   ```
   For a physical device or deployed Cloud Run service, set `OMEGA_BACKEND_URL` to your HTTPS server URL.
3. Ensure the Gradle wrapper is generated (in Android Studio **Sync Project with Gradle Files**, or run `gradle wrapper` locally).
4. Build the debug APK:
   ```bash
   ./gradlew :app:assembleDebug
   ```
   Output APK: `app/build/outputs/apk/debug/app-debug.apk`.
5. Build a release APK (configure signingConfig in `app/build.gradle.kts` first):
   ```bash
   ./gradlew :app:assembleRelease
   ```
