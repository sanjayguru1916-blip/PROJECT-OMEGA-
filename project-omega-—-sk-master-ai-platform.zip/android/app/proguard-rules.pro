-keepattributes *Annotation*
-keepclassmembers class * {
    @kotlinx.serialization.SerialName <fields>;
}
-keep class com.projectomega.sk.core.ai.** { *; }
-keep class com.projectomega.sk.core.model.** { *; }
