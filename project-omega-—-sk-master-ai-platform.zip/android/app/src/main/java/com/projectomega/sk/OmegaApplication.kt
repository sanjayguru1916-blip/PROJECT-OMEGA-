package com.projectomega.sk

import android.app.Application
import com.projectomega.sk.di.OmegaAppContainer
import com.projectomega.sk.sk.worker.SkPeriodicReportWorker

class OmegaApplication : Application() {

    lateinit var container: OmegaAppContainer
        private set

    override fun onCreate() {
        super.onCreate()
        container = OmegaAppContainer(this)
        SkPeriodicReportWorker.schedule(this)
    }
}
