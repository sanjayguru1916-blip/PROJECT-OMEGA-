package com.projectomega.sk.assistants.jarvis

import com.projectomega.sk.core.ai.AiProviderGateway
import com.projectomega.sk.core.approval.ApprovalManager
import com.projectomega.sk.core.model.ApprovalToken
import com.projectomega.sk.core.model.AssistantExecutionResult
import com.projectomega.sk.core.model.AssistantId
import com.projectomega.sk.core.model.AssistantProfile
import com.projectomega.sk.core.model.OmegaIdentityCatalog
import com.projectomega.sk.core.model.TaskProposal
import com.projectomega.sk.core.registry.AssistantModule

/**
 * JARVIS — General Intelligence, Knowledge & Reasoning Module.
 * Strictly isolated from device hardware control, system diagnostics, and reminders.
 */
class JarvisAssistantModule(
    private val aiProvider: AiProviderGateway,
    private val approvalManager: ApprovalManager
) : AssistantModule {

    override val profile: AssistantProfile = OmegaIdentityCatalog.profiles.getValue(AssistantId.JARVIS)

    override suspend fun healthCheck(): Boolean = true

    override suspend fun execute(
        proposal: TaskProposal,
        approvalToken: ApprovalToken
    ): AssistantExecutionResult {
        if (proposal.targetAssistant != AssistantId.JARVIS) {
            return AssistantExecutionResult.Denied(proposal.proposalId, "Boundary violation: proposal targeted ${proposal.targetAssistant}.")
        }
        if (!approvalManager.consumeVerifiedToken(proposal, approvalToken)) {
            return AssistantExecutionResult.Denied(proposal.proposalId, "Invalid, expired, or replayed approval token.")
        }

        return runCatching {
            val response = aiProvider.generateAssistantResponse(
                assistantId = AssistantId.JARVIS,
                operation = proposal.exactOperation,
                rawInput = proposal.rawInput,
                parameters = proposal.parameters
            )
            AssistantExecutionResult.Success(
                proposalId = proposal.proposalId,
                assistantId = AssistantId.JARVIS,
                summary = response.summary,
                outputPayload = response.structuredOutput
            )
        }.getOrElse { error ->
            AssistantExecutionResult.Failure(
                proposalId = proposal.proposalId,
                assistantId = AssistantId.JARVIS,
                errorMessage = error.message ?: "JARVIS reasoning request failed."
            )
        }
    }
}
