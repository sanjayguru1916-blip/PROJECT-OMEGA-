package com.projectomega.sk.di

import android.content.Context
import com.projectomega.sk.assistants.friday.FridayAssistantModule
import com.projectomega.sk.assistants.jarvis.JarvisAssistantModule
import com.projectomega.sk.assistants.magmite.AndroidPhoneController
import com.projectomega.sk.assistants.magmite.MagmiteAssistantModule
import com.projectomega.sk.assistants.ultron.UltronAssistantModule
import com.projectomega.sk.core.ai.AiProviderGateway
import com.projectomega.sk.core.ai.BackendProxyAiProvider
import com.projectomega.sk.core.approval.ApprovalManager
import com.projectomega.sk.core.data.OmegaDatabase
import com.projectomega.sk.core.data.OmegaPreferencesStore
import com.projectomega.sk.core.registry.AssistantRegistry
import com.projectomega.sk.core.security.AndroidPermissionGuard
import com.projectomega.sk.core.security.AuditLogger
import com.projectomega.sk.sk.router.SkMasterCore

class OmegaAppContainer(context: Context) {

    private val appContext = context.applicationContext

    val database: OmegaDatabase = OmegaDatabase.getInstance(appContext)
    val preferencesStore: OmegaPreferencesStore = OmegaPreferencesStore(appContext)
    val permissionGuard: AndroidPermissionGuard = AndroidPermissionGuard(appContext)
    val phoneController: AndroidPhoneController = AndroidPhoneController(appContext, permissionGuard)
    val approvalManager: ApprovalManager = ApprovalManager()
    val registry: AssistantRegistry = AssistantRegistry()
    val auditLogger: AuditLogger = AuditLogger(database.auditDao())
    val aiProvider: AiProviderGateway = BackendProxyAiProvider()

    val skMasterCore: SkMasterCore = SkMasterCore(
        registry = registry,
        approvalManager = approvalManager,
        permissionGuard = permissionGuard,
        phoneController = phoneController,
        aiProvider = aiProvider,
        auditLogger = auditLogger,
        taskHistoryDao = database.taskHistoryDao(),
        systemReportDao = database.systemReportDao()
    )

    init {
        registry.registerModule(JarvisAssistantModule(aiProvider, approvalManager))
        registry.registerModule(MagmiteAssistantModule(appContext, permissionGuard, approvalManager, phoneController))
        registry.registerModule(UltronAssistantModule(appContext, aiProvider, permissionGuard, approvalManager))
        registry.registerModule(
            FridayAssistantModule(
                context = appContext,
                reminderDao = database.reminderDao(),
                aiProvider = aiProvider,
                permissionGuard = permissionGuard,
                approvalManager = approvalManager
            )
        )
    }
}
