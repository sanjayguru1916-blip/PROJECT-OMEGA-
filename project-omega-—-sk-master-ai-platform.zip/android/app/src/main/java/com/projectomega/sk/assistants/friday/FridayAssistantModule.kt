package com.projectomega.sk.assistants.friday

import android.app.AlarmManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import com.projectomega.sk.core.ai.AiProviderGateway
import com.projectomega.sk.core.approval.ApprovalManager
import com.projectomega.sk.core.data.ReminderDao
import com.projectomega.sk.core.data.ReminderEntity
import com.projectomega.sk.core.model.ApprovalToken
import com.projectomega.sk.core.model.AssistantExecutionResult
import com.projectomega.sk.core.model.AssistantId
import com.projectomega.sk.core.model.AssistantProfile
import com.projectomega.sk.core.model.OmegaIdentityCatalog
import com.projectomega.sk.core.model.TaskProposal
import com.projectomega.sk.core.registry.AssistantModule
import com.projectomega.sk.core.security.AndroidPermissionGuard

/**
 * FRIDAY — Personal Assistance, Reminders & Scheduling Module.
 * Persists reminders in Room and schedules exact Android alarms when permitted.
 */
class FridayAssistantModule(
    private val context: Context,
    private val reminderDao: ReminderDao,
    private val aiProvider: AiProviderGateway,
    private val permissionGuard: AndroidPermissionGuard,
    private val approvalManager: ApprovalManager
) : AssistantModule {

    override val profile: AssistantProfile = OmegaIdentityCatalog.profiles.getValue(AssistantId.FRIDAY)

    override suspend fun healthCheck(): Boolean = true

    override suspend fun execute(
        proposal: TaskProposal,
        approvalToken: ApprovalToken
    ): AssistantExecutionResult {
        if (proposal.targetAssistant != AssistantId.FRIDAY) {
            return AssistantExecutionResult.Denied(proposal.proposalId, "Boundary violation: proposal targeted ${proposal.targetAssistant}.")
        }
        val missing = permissionGuard.checkPermissions(proposal.requiredPermissions)
        if (missing.isNotEmpty()) {
            return AssistantExecutionResult.PermissionMissing(proposal.proposalId, AssistantId.FRIDAY, missing)
        }
        if (!approvalManager.consumeVerifiedToken(proposal, approvalToken)) {
            return AssistantExecutionResult.Denied(proposal.proposalId, "Invalid or consumed approval token.")
        }

        return runCatching {
            when (proposal.exactOperation.uppercase()) {
                "CREATE_REMINDER", "SCHEDULE_EVENT" -> scheduleReminder(proposal)
                else -> {
                    val response = aiProvider.generateAssistantResponse(
                        assistantId = AssistantId.FRIDAY,
                        operation = proposal.exactOperation,
                        rawInput = proposal.rawInput,
                        parameters = proposal.parameters
                    )
                    AssistantExecutionResult.Success(
                        proposalId = proposal.proposalId,
                        assistantId = AssistantId.FRIDAY,
                        summary = response.summary,
                        outputPayload = response.structuredOutput
                    )
                }
            }
        }.getOrElse { error ->
            AssistantExecutionResult.Failure(
                proposalId = proposal.proposalId,
                assistantId = AssistantId.FRIDAY,
                errorMessage = error.message ?: "FRIDAY scheduling execution failed."
            )
        }
    }

    private suspend fun scheduleReminder(proposal: TaskProposal): AssistantExecutionResult {
        val title = proposal.parameters["title"] ?: proposal.rawInput.take(64)
        val notes = proposal.parameters["notes"] ?: proposal.rationale
        val delayMinutes = proposal.parameters["delayMinutes"]?.toLongOrNull()?.coerceAtLeast(1L) ?: 15L
        val triggerAt = System.currentTimeMillis() + delayMinutes * 60_000L

        val rowId = reminderDao.insert(
            ReminderEntity(
                title = title,
                notes = notes,
                triggerAtEpochMs = triggerAt,
                completed = false,
                createdByProposalId = proposal.proposalId
            )
        )

        val alarmManager = context.getSystemService(Context.ALARM_SERVICE) as AlarmManager
        val intent = Intent(context, FridayReminderReceiver::class.java).apply {
            putExtra(FridayReminderReceiver.EXTRA_REMINDER_ID, rowId)
            putExtra(FridayReminderReceiver.EXTRA_TITLE, title)
            putExtra(FridayReminderReceiver.EXTRA_NOTES, notes)
        }
        val pendingIntent = PendingIntent.getBroadcast(
            context,
            rowId.toInt(),
            intent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        alarmManager.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, triggerAt, pendingIntent)

        return AssistantExecutionResult.Success(
            proposalId = proposal.proposalId,
            assistantId = AssistantId.FRIDAY,
            summary = "Scheduled reminder \"$title\" in $delayMinutes minutes.",
            outputPayload = mapOf("reminderId" to rowId.toString(), "triggerAtEpochMs" to triggerAt.toString())
        )
    }
}
