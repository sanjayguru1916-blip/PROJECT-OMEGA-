package com.projectomega.sk.ui.voice

import android.Manifest
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import androidx.core.content.ContextCompat
import com.projectomega.sk.core.model.VoiceState
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import java.util.Locale

/**
 * Real Android SpeechRecognizer wrapper.
 * Executes all SpeechRecognizer creation/start/stop/destroy operations on the Main Looper
 * (required by Android OS), prevents overlapping sessions, and accurately surfaces
 * PERMISSION_REQUIRED, LISTENING, PROCESSING, ERROR, and IDLE states.
 */
class OmegaSpeechRecognizer(
    private val context: Context,
    private val onFinalTranscript: (String) -> Unit
) {
    private val mainHandler = Handler(Looper.getMainLooper())

    private val _isListening = MutableStateFlow(false)
    val isListening: StateFlow<Boolean> = _isListening.asStateFlow()

    private val _recognizerState = MutableStateFlow(VoiceState.IDLE)
    val recognizerState: StateFlow<VoiceState> = _recognizerState.asStateFlow()

    private val _partialText = MutableStateFlow("")
    val partialText: StateFlow<String> = _partialText.asStateFlow()

    private val _rmsLevel = MutableStateFlow(0f)
    val rmsLevel: StateFlow<Float> = _rmsLevel.asStateFlow()

    private val _errorMessage = MutableStateFlow<String?>(null)
    val errorMessage: StateFlow<String?> = _errorMessage.asStateFlow()

    private var recognizer: SpeechRecognizer? = null
    private var sessionActive: Boolean = false

    fun isAvailable(): Boolean = SpeechRecognizer.isRecognitionAvailable(context)

    fun hasAudioPermission(): Boolean {
        return ContextCompat.checkSelfPermission(
            context,
            Manifest.permission.RECORD_AUDIO
        ) == PackageManager.PERMISSION_GRANTED
    }

    fun markPermissionRequired(message: String) {
        _errorMessage.value = message
        _recognizerState.value = VoiceState.PERMISSION_REQUIRED
    }

    fun startListening() {
        runOnMainThread {
            if (sessionActive || recognizer != null) {
                return@runOnMainThread
            }
            _errorMessage.value = null
            if (!hasAudioPermission()) {
                _errorMessage.value = "Microphone permission (RECORD_AUDIO) is required for voice commands."
                _recognizerState.value = VoiceState.PERMISSION_REQUIRED
                return@runOnMainThread
            }
            if (!isAvailable()) {
                _errorMessage.value = "Android SpeechRecognizer service is unavailable on this device."
                _recognizerState.value = VoiceState.ERROR
                return@runOnMainThread
            }

            runCatching {
                val instance = SpeechRecognizer.createSpeechRecognizer(context.applicationContext)
                instance.setRecognitionListener(object : RecognitionListener {
                    override fun onReadyForSpeech(params: Bundle?) {
                        _isListening.value = true
                        _recognizerState.value = VoiceState.LISTENING
                        _partialText.value = ""
                    }

                    override fun onBeginningOfSpeech() {
                        _recognizerState.value = VoiceState.LISTENING
                    }

                    override fun onRmsChanged(rmsdB: Float) {
                        val normalized = ((rmsdB + 2f) / 12f).coerceIn(0f, 1f)
                        _rmsLevel.value = normalized
                    }

                    override fun onBufferReceived(buffer: ByteArray?) = Unit

                    override fun onEndOfSpeech() {
                        _isListening.value = false
                        _rmsLevel.value = 0f
                        _recognizerState.value = VoiceState.PROCESSING
                    }

                    override fun onError(error: Int) {
                        cleanupOnMainLocked()
                        val isPerm = error == SpeechRecognizer.ERROR_INSUFFICIENT_PERMISSIONS
                        _recognizerState.value = if (isPerm) VoiceState.PERMISSION_REQUIRED else VoiceState.ERROR
                        _errorMessage.value = when (error) {
                            SpeechRecognizer.ERROR_NO_MATCH -> "No speech recognized. Tap the mic and speak clearly."
                            SpeechRecognizer.ERROR_SPEECH_TIMEOUT -> "No voice input detected before timeout."
                            SpeechRecognizer.ERROR_INSUFFICIENT_PERMISSIONS -> "Microphone permission denied."
                            SpeechRecognizer.ERROR_AUDIO -> "Microphone hardware/audio focus error."
                            SpeechRecognizer.ERROR_NETWORK, SpeechRecognizer.ERROR_NETWORK_TIMEOUT ->
                                "Speech recognition network error. Check connection or type your command."
                            SpeechRecognizer.ERROR_RECOGNIZER_BUSY -> "Speech recognizer is busy; resetting session."
                            else -> "Speech recognition error ($error)."
                        }
                    }

                    override fun onResults(results: Bundle?) {
                        val matches = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                        val transcript = matches?.firstOrNull()?.trim().orEmpty()
                        cleanupOnMainLocked()
                        if (transcript.isNotEmpty()) {
                            _partialText.value = transcript
                            _recognizerState.value = VoiceState.PROCESSING
                            onFinalTranscript(transcript)
                        } else {
                            _recognizerState.value = VoiceState.IDLE
                        }
                    }

                    override fun onPartialResults(partialResults: Bundle?) {
                        val matches = partialResults?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                        val partial = matches?.firstOrNull().orEmpty()
                        if (partial.isNotEmpty()) {
                            _partialText.value = partial
                        }
                    }

                    override fun onEvent(eventType: Int, params: Bundle?) = Unit
                })

                val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
                    putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                    putExtra(RecognizerIntent.EXTRA_LANGUAGE, Locale.getDefault().toLanguageTag())
                    putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true)
                    putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 1)
                }

                recognizer = instance
                sessionActive = true
                _isListening.value = true
                _recognizerState.value = VoiceState.LISTENING
                instance.startListening(intent)
            }.onFailure { err ->
                cleanupOnMainLocked()
                _recognizerState.value = VoiceState.ERROR
                _errorMessage.value = err.message ?: "Failed to initialize speech recognizer."
            }
        }
    }

    fun stopListening() {
        runOnMainThread {
            runCatching { recognizer?.stopListening() }
            cleanupOnMainLocked()
            _recognizerState.value = VoiceState.IDLE
        }
    }

    fun markResponding() {
        if (!sessionActive) {
            _recognizerState.value = VoiceState.RESPONDING
        }
    }

    fun resetStateToIdle() {
        if (!sessionActive) {
            _recognizerState.value = VoiceState.IDLE
        }
    }

    private fun runOnMainThread(block: () -> Unit) {
        if (Looper.myLooper() == Looper.getMainLooper()) {
            block()
        } else {
            mainHandler.post(block)
        }
    }

    private fun cleanupOnMainLocked() {
        sessionActive = false
        _isListening.value = false
        _rmsLevel.value = 0f
        runCatching { recognizer?.destroy() }
        recognizer = null
    }
}
