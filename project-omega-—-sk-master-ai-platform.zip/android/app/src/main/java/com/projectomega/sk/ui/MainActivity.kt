package com.projectomega.sk.ui

import android.Manifest
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.viewModels
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.getValue
import androidx.compose.ui.graphics.Color
import androidx.core.app.ActivityCompat
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.projectomega.sk.ui.holographic.SkMasterScreen
import com.projectomega.sk.ui.viewmodel.OmegaViewModel

class MainActivity : ComponentActivity() {

    private val viewModel: OmegaViewModel by viewModels()

    private fun openAppSettingsScreen() {
        val intent = Intent(
            Settings.ACTION_APPLICATION_DETAILS_SETTINGS,
            Uri.parse("package:$packageName")
        ).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        startActivity(intent)
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        setContent {
            val state by viewModel.uiState.collectAsStateWithLifecycle()

            val runtimeLauncher = rememberLauncherForActivityResult(
                contract = ActivityResultContracts.RequestMultiplePermissions()
            ) { results ->
                val allGranted = results.values.all { it }
                val permanentlyDenied = results.entries.any { (perm, granted) ->
                    !granted && !ActivityCompat.shouldShowRequestPermissionRationale(this@MainActivity, perm)
                }
                viewModel.onRuntimePermissionsResult(allGranted, permanentlyDenied)
            }

            val audioPermissionLauncher = rememberLauncherForActivityResult(
                contract = ActivityResultContracts.RequestPermission()
            ) { granted ->
                val permanentlyDenied = !granted &&
                    !ActivityCompat.shouldShowRequestPermissionRationale(this@MainActivity, Manifest.permission.RECORD_AUDIO)
                viewModel.onAudioPermissionResult(granted, permanentlyDenied)
            }

            MaterialTheme(
                colorScheme = darkColorScheme(
                    primary = Color(0xFFFF8C1A),
                    background = Color(0xFF050608),
                    surface = Color(0xFF0E1117)
                )
            ) {
                SkMasterScreen(
                    state = state,
                    onSelectIdentity = viewModel::switchIdentity,
                    onNormalMode = viewModel::activateNormalMode,
                    onPhoenixMode = viewModel::activatePhoenixMode,
                    onAssembleAll = viewModel::assembleAll,
                    onDisassembleAll = viewModel::disassembleAll,
                    onSubmitCommand = viewModel::handleCommandInput,
                    onToggleListening = {
                        viewModel.toggleVoiceListening {
                            audioPermissionLauncher.launch(Manifest.permission.RECORD_AUDIO)
                        }
                    },
                    onStopSpeaking = viewModel::stopSpeaking,
                    onApproveProposal = viewModel::approveProposal,
                    onRejectProposal = viewModel::rejectProposal,
                    onToggleAssistant = viewModel::toggleAssistantAvailability,
                    onToggleVoice = viewModel::toggleVoice,
                    onSelectVoiceProvider = viewModel::setVoiceProviderMode,
                    onUpdateVoiceTuning = viewModel::updateVoiceTuning,
                    onPreviewVoice = viewModel::previewAssistantVoice,
                    onSelectAnimationQuality = viewModel::setAnimationQuality,
                    onGenerateReport = viewModel::generateSystemReport,
                    onAcknowledgeAlert = viewModel::acknowledgeAlert,
                    onSelectContact = viewModel::selectContactCandidate,
                    onSelectSim = viewModel::selectSimOption,
                    onDismissChoice = viewModel::dismissDisambiguation,
                    onOpenAppSettings = ::openAppSettingsScreen,
                    onCheckAssistantStatus = viewModel::requestStatusForAssistant,
                    onOpenDetailsSection = viewModel::openDetailsSection,
                    onCloseDetailsSection = viewModel::closeDetailsSection,
                    onRetryLastCommand = viewModel::retryLastCommand,
                    onRequestPermissions = { missing ->
                        val standardRuntime = missing.filter {
                            it != Manifest.permission.ACCESS_NOTIFICATION_POLICY &&
                                it != Manifest.permission.SCHEDULE_EXACT_ALARM
                        }
                        if (standardRuntime.isNotEmpty()) {
                            runtimeLauncher.launch(standardRuntime.toTypedArray())
                        }
                        if (missing.contains(Manifest.permission.ACCESS_NOTIFICATION_POLICY)) {
                            startActivity(Intent(Settings.ACTION_NOTIFICATION_POLICY_ACCESS_SETTINGS))
                        }
                        if (missing.contains(Manifest.permission.SCHEDULE_EXACT_ALARM)) {
                            val intent = Intent(
                                Settings.ACTION_REQUEST_SCHEDULE_EXACT_ALARM,
                                Uri.parse("package:$packageName")
                            )
                            startActivity(intent)
                        }
                    }
                )
            }
        }
    }
}
