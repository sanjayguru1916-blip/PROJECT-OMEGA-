package com.projectomega.sk.core.data

import android.content.Context
import androidx.datastore.core.DataStore
import androidx.datastore.preferences.core.Preferences
import androidx.datastore.preferences.core.booleanPreferencesKey
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.floatPreferencesKey
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import com.projectomega.sk.core.model.AnimationQuality
import com.projectomega.sk.core.model.AssistantId
import com.projectomega.sk.core.model.OmegaIdentityCatalog
import com.projectomega.sk.core.model.VoiceConfig
import com.projectomega.sk.core.model.VoiceProviderMode
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map

private val Context.omegaDataStore: DataStore<Preferences> by preferencesDataStore(name = "omega_sk_prefs")

class OmegaPreferencesStore(private val context: Context) {

    private val activeAssistantKey = stringPreferencesKey("active_holographic_assistant")
    private val voiceEnabledKey = booleanPreferencesKey("voice_synthesis_enabled")
    private val animationQualityKey = stringPreferencesKey("animation_quality_mode")
    private val voiceProviderModeKey = stringPreferencesKey("voice_provider_mode")

    private fun assistantEnabledKey(id: AssistantId) =
        booleanPreferencesKey("assistant_enabled_${id.name.lowercase()}")

    private fun voicePitchKey(id: AssistantId) =
        floatPreferencesKey("voice_pitch_${id.name.lowercase()}")

    private fun voiceRateKey(id: AssistantId) =
        floatPreferencesKey("voice_rate_${id.name.lowercase()}")

    val activeAssistantFlow: Flow<AssistantId> = context.omegaDataStore.data.map { prefs ->
        val raw = prefs[activeAssistantKey] ?: AssistantId.SK.name
        runCatching { AssistantId.valueOf(raw) }.getOrDefault(AssistantId.SK)
    }

    val voiceEnabledFlow: Flow<Boolean> = context.omegaDataStore.data.map { prefs ->
        prefs[voiceEnabledKey] ?: true
    }

    val animationQualityFlow: Flow<AnimationQuality> = context.omegaDataStore.data.map { prefs ->
        val raw = prefs[animationQualityKey] ?: AnimationQuality.HIGH_60FPS.name
        runCatching { AnimationQuality.valueOf(raw) }.getOrDefault(AnimationQuality.HIGH_60FPS)
    }

    val voiceProviderModeFlow: Flow<VoiceProviderMode> = context.omegaDataStore.data.map { prefs ->
        val raw = prefs[voiceProviderModeKey] ?: VoiceProviderMode.AUTO_NEURAL_OR_LOCAL.name
        runCatching { VoiceProviderMode.valueOf(raw) }.getOrDefault(VoiceProviderMode.AUTO_NEURAL_OR_LOCAL)
    }

    val voiceConfigsFlow: Flow<Map<AssistantId, VoiceConfig>> = context.omegaDataStore.data.map { prefs ->
        OmegaIdentityCatalog.profiles.mapValues { (id, profile) ->
            val base = profile.voiceConfig
            base.copy(
                pitch = prefs[voicePitchKey(id)] ?: base.pitch,
                speechRate = prefs[voiceRateKey(id)] ?: base.speechRate
            )
        }
    }

    fun isAssistantEnabledFlow(id: AssistantId): Flow<Boolean> = context.omegaDataStore.data.map { prefs ->
        if (id == AssistantId.SK) true else (prefs[assistantEnabledKey(id)] ?: true)
    }

    suspend fun setActiveAssistant(id: AssistantId) {
        context.omegaDataStore.edit { prefs ->
            prefs[activeAssistantKey] = id.name
        }
    }

    suspend fun setVoiceEnabled(enabled: Boolean) {
        context.omegaDataStore.edit { prefs ->
            prefs[voiceEnabledKey] = enabled
        }
    }

    suspend fun setAnimationQuality(quality: AnimationQuality) {
        context.omegaDataStore.edit { prefs ->
            prefs[animationQualityKey] = quality.name
        }
    }

    suspend fun setVoiceProviderMode(mode: VoiceProviderMode) {
        context.omegaDataStore.edit { prefs ->
            prefs[voiceProviderModeKey] = mode.name
        }
    }

    suspend fun updateVoiceTuning(id: AssistantId, pitch: Float, speechRate: Float) {
        context.omegaDataStore.edit { prefs ->
            prefs[voicePitchKey(id)] = pitch.coerceIn(0.5f, 1.6f)
            prefs[voiceRateKey(id)] = speechRate.coerceIn(0.5f, 1.6f)
        }
    }

    suspend fun setAssistantEnabled(id: AssistantId, enabled: Boolean) {
        if (id == AssistantId.SK) return
        context.omegaDataStore.edit { prefs ->
            prefs[assistantEnabledKey(id)] = enabled
        }
    }
}
