package com.projectomega.sk.core.registry

import com.projectomega.sk.core.model.AssistantId
import com.projectomega.sk.core.model.AssistantRuntimeMetrics
import com.projectomega.sk.core.model.AssistantStatus
import com.projectomega.sk.core.model.OmegaIdentityCatalog
import com.projectomega.sk.core.model.TaskProposal
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update

/**
 * Central SK Assistant Registry.
 * Manages assistant registration, availability toggles, and real runtime telemetry
 * while preserving SK as the immutable Master Controller.
 */
class AssistantRegistry {

    private val modules = mutableMapOf<AssistantId, AssistantModule>()

    private val _states = MutableStateFlow(
        OmegaIdentityCatalog.profiles.mapValues { (id, profile) ->
            RegisteredAssistantState(
                profile = profile,
                status = AssistantStatus.ONLINE,
                isEnabled = true,
                lastHeartbeatEpochMs = System.currentTimeMillis(),
                metrics = AssistantRuntimeMetrics(
                    currentActivity = "Idle",
                    communicationState = if (id == AssistantId.SK) "Orchestrating master bus" else "Silent standby until requested"
                )
            )
        }
    )
    val states: StateFlow<Map<AssistantId, RegisteredAssistantState>> = _states.asStateFlow()

    fun registerModule(module: AssistantModule) {
        val id = module.profile.id
        require(id != AssistantId.SK) {
            "SK is the immutable Master Controller and cannot be registered as a delegated worker."
        }
        modules[id] = module
        _states.update { current ->
            val existing = current[id]
            current + (id to RegisteredAssistantState(
                profile = module.profile,
                status = if (existing?.isEnabled == false) AssistantStatus.DISABLED else AssistantStatus.ONLINE,
                isEnabled = existing?.isEnabled ?: true,
                lastHeartbeatEpochMs = System.currentTimeMillis(),
                metrics = existing?.metrics ?: AssistantRuntimeMetrics(
                    currentActivity = "Idle",
                    communicationState = "Silent standby until requested"
                )
            ))
        }
    }

    fun getModule(id: AssistantId): AssistantModule? {
        val state = _states.value[id] ?: return null
        if (!state.isEnabled) return null
        return modules[id]
    }

    fun setAssistantEnabled(id: AssistantId, enabled: Boolean) {
        if (id == AssistantId.SK) {
            throw IllegalStateException("SK Master Controller cannot be disabled.")
        }
        _states.update { current ->
            val existing = current[id] ?: return@update current
            current + (id to existing.copy(
                isEnabled = enabled,
                status = if (enabled) AssistantStatus.ONLINE else AssistantStatus.DISABLED,
                lastHeartbeatEpochMs = System.currentTimeMillis(),
                metrics = existing.metrics.copy(
                    currentActivity = if (enabled) "Idle" else "Disabled by SK",
                    communicationState = if (enabled) "Silent standby until requested" else "Offline (disabled)"
                )
            ))
        }
    }

    fun updateStatus(
        id: AssistantId,
        status: AssistantStatus,
        error: String? = null,
        activity: String? = null,
        commState: String? = null
    ) {
        _states.update { current ->
            val existing = current[id] ?: return@update current
            val effectiveEnabled = existing.isEnabled || id == AssistantId.SK
            current + (id to existing.copy(
                status = if (!effectiveEnabled) AssistantStatus.DISABLED else status,
                lastHeartbeatEpochMs = System.currentTimeMillis(),
                lastError = error ?: if (status == AssistantStatus.ONLINE) existing.lastError else error,
                metrics = existing.metrics.copy(
                    currentActivity = activity ?: if (status == AssistantStatus.ONLINE) "Idle" else existing.metrics.currentActivity,
                    recentError = error ?: existing.metrics.recentError,
                    communicationState = commState ?: existing.metrics.communicationState
                )
            ))
        }
    }

    fun markExecutionStart(id: AssistantId, operation: String) {
        _states.update { current ->
            val existing = current[id] ?: return@update current
            current + (id to existing.copy(
                status = AssistantStatus.BUSY,
                lastHeartbeatEpochMs = System.currentTimeMillis(),
                metrics = existing.metrics.copy(
                    activeTaskCount = existing.metrics.activeTaskCount + 1,
                    currentActivity = "Executing $operation",
                    communicationState = "Active response channel"
                )
            ))
        }
    }

    fun markExecutionFinish(
        id: AssistantId,
        success: Boolean,
        responseMs: Long,
        errorMessage: String? = null
    ) {
        _states.update { current ->
            val existing = current[id] ?: return@update current
            val nextActive = (existing.metrics.activeTaskCount - 1).coerceAtLeast(0)
            current + (id to existing.copy(
                status = if (!existing.isEnabled && id != AssistantId.SK) AssistantStatus.DISABLED else AssistantStatus.ONLINE,
                lastHeartbeatEpochMs = System.currentTimeMillis(),
                lastError = if (success) existing.lastError else (errorMessage ?: existing.lastError),
                metrics = existing.metrics.copy(
                    activeTaskCount = nextActive,
                    completedTaskCount = existing.metrics.completedTaskCount + if (success) 1 else 0,
                    lastResponseMs = responseMs,
                    recentError = if (success) null else errorMessage,
                    currentActivity = if (nextActive > 0) existing.metrics.currentActivity else "Idle",
                    communicationState = "Completed (${responseMs} ms)"
                )
            ))
        }
    }

    fun syncPendingCounts(pendingProposals: List<TaskProposal>) {
        _states.update { current ->
            current.mapValues { (id, state) ->
                val pendingForId = pendingProposals.count { it.targetAssistant == id }
                state.copy(
                    metrics = state.metrics.copy(
                        pendingTaskCount = pendingForId
                    )
                )
            }
        }
    }

    fun availableDescriptors(): List<AssistantDescriptor> {
        return _states.value.values
            .filter { it.profile.id != AssistantId.SK }
            .map { state ->
                AssistantDescriptor(
                    id = state.profile.id,
                    roleTitle = state.profile.roleTitle,
                    capabilities = state.profile.capabilities,
                    isEnabled = state.isEnabled
                )
            }
    }

    suspend fun runHealthSweep(): Map<AssistantId, Boolean> {
        val results = mutableMapOf<AssistantId, Boolean>()
        modules.forEach { (id, module) ->
            val state = _states.value[id]
            if (state?.isEnabled == true) {
                val healthy = runCatching { module.healthCheck() }.getOrDefault(false)
                results[id] = healthy
                updateStatus(
                    id = id,
                    status = if (healthy) AssistantStatus.ONLINE else AssistantStatus.DEGRADED,
                    error = if (healthy) null else "Module health check returned false",
                    activity = if (healthy) "Idle" else "Degraded health check"
                )
            } else {
                results[id] = false
            }
        }
        return results
    }
}
