package com.projectomega.sk.core.registry

import com.projectomega.sk.core.model.ApprovalToken
import com.projectomega.sk.core.model.AssistantExecutionResult
import com.projectomega.sk.core.model.AssistantId
import com.projectomega.sk.core.model.AssistantProfile
import com.projectomega.sk.core.model.AssistantRuntimeMetrics
import com.projectomega.sk.core.model.TaskProposal
import com.projectomega.sk.core.registry.AssistantModule

/**
 * Isolated boundary contract implemented by each independent assistant module
 * (JARVIS, MAGMITE, ULTRON, FRIDAY). Assistants never communicate laterally or
 * execute without an explicit, single-use ApprovalToken minted by SK's ApprovalManager.
 */
interface AssistantModule {
    val profile: AssistantProfile

    suspend fun healthCheck(): Boolean

    suspend fun execute(
        proposal: TaskProposal,
        approvalToken: ApprovalToken
    ): AssistantExecutionResult
}

data class RegisteredAssistantState(
    val profile: AssistantProfile,
    val status: com.projectomega.sk.core.model.AssistantStatus,
    val isEnabled: Boolean,
    val lastHeartbeatEpochMs: Long,
    val lastError: String? = null,
    val metrics: AssistantRuntimeMetrics = AssistantRuntimeMetrics()
)

data class AssistantDescriptor(
    val id: AssistantId,
    val roleTitle: String,
    val capabilities: List<String>,
    val isEnabled: Boolean
)
