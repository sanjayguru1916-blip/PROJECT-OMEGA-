package com.projectomega.sk.core.security

import android.Manifest
import android.app.Activity
import android.app.AlarmManager
import android.app.NotificationManager
import android.content.Context
import android.content.pm.PackageManager
import android.os.Build
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import com.projectomega.sk.core.data.AuditDao
import com.projectomega.sk.core.data.AuditLogEntity
import com.projectomega.sk.core.model.AssistantId
import com.projectomega.sk.core.model.PermissionGrantStatus
import com.projectomega.sk.core.model.PermissionMetadata
import java.security.MessageDigest

/**
 * Inspects Android runtime and special permissions without ever attempting to bypass OS controls.
 * Evaluates feature-specific rationales and permanently-denied state honestly.
 */
class AndroidPermissionGuard(private val context: Context) {

    fun checkPermissions(requiredPermissions: List<String>): List<String> {
        val missing = mutableListOf<String>()
        requiredPermissions.forEach { permission ->
            when (permission) {
                Manifest.permission.POST_NOTIFICATIONS -> {
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU && !isGranted(permission)) {
                        missing.add(permission)
                    }
                }
                Manifest.permission.BLUETOOTH_CONNECT, Manifest.permission.BLUETOOTH_SCAN -> {
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S && !isGranted(permission)) {
                        missing.add(permission)
                    }
                }
                Manifest.permission.ACCESS_NOTIFICATION_POLICY -> {
                    val nm = context.getSystemService(Context.NOTIFICATION_SERVICE) as? NotificationManager
                    if (nm == null || !nm.isNotificationPolicyAccessGranted) {
                        missing.add(permission)
                    }
                }
                Manifest.permission.SCHEDULE_EXACT_ALARM -> {
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                        val am = context.getSystemService(Context.ALARM_SERVICE) as? AlarmManager
                        if (am == null || !am.canScheduleExactAlarms()) {
                            missing.add(permission)
                        }
                    }
                }
                else -> {
                    if (!isGranted(permission)) {
                        missing.add(permission)
                    }
                }
            }
        }
        return missing
    }

    fun evaluatePermissions(
        permissions: List<String>,
        activity: Activity? = null,
        hasAskedBefore: Set<String> = emptySet()
    ): List<PermissionMetadata> {
        return permissions.map { perm ->
            val missing = checkPermissions(listOf(perm)).isNotEmpty()
            val status = when {
                !missing -> PermissionGrantStatus.GRANTED
                perm == Manifest.permission.ACCESS_NOTIFICATION_POLICY || perm == Manifest.permission.SCHEDULE_EXACT_ALARM ->
                    PermissionGrantStatus.SPECIAL_ACCESS_REQUIRED
                activity != null &&
                    hasAskedBefore.contains(perm) &&
                    !ActivityCompat.shouldShowRequestPermissionRationale(activity, perm) ->
                    PermissionGrantStatus.PERMANENTLY_DENIED
                else -> PermissionGrantStatus.DENIED
            }
            val (label, rationale) = describePermission(perm)
            PermissionMetadata(
                permission = perm,
                label = label,
                rationale = rationale,
                status = status
            )
        }
    }

    fun describePermission(permission: String): Pair<String, String> = when (permission) {
        Manifest.permission.RECORD_AUDIO ->
            "Microphone" to "Needed only while the microphone button is active to capture your voice commands."
        Manifest.permission.READ_CONTACTS ->
            "Contacts" to "Used to look up the contact phone number when you ask SK or MAGMITE to call or message someone."
        Manifest.permission.CALL_PHONE ->
            "Make Phone Calls" to "Required to place an approved phone call directly or via your chosen SIM card."
        Manifest.permission.SEND_SMS ->
            "Send SMS" to "Required to send an approved text message without leaving Project Omega."
        Manifest.permission.READ_PHONE_STATE ->
            "Dual-SIM State" to "Used to list active SIM cards so you can choose which SIM places your call."
        Manifest.permission.CAMERA ->
            "Camera & Torch" to "Used by MAGMITE to toggle the rear flashlight or open the device camera."
        Manifest.permission.BLUETOOTH_CONNECT ->
            "Bluetooth Connect" to "Required on Android 12+ to inspect Bluetooth state and open device audio panels."
        Manifest.permission.ACCESS_NOTIFICATION_POLICY ->
            "Do Not Disturb Access" to "Required by Android before MAGMITE can switch ringer mode to silent or vibrate."
        Manifest.permission.POST_NOTIFICATIONS ->
            "Notifications" to "Allows FRIDAY reminders and critical SK alerts to appear."
        Manifest.permission.SCHEDULE_EXACT_ALARM ->
            "Exact Alarms" to "Allows FRIDAY to trigger scheduled reminders at the exact minute you specify."
        else ->
            permission.substringAfterLast('.') to "Required by Android for this approved operation."
    }

    fun isGranted(permission: String): Boolean {
        return ContextCompat.checkSelfPermission(context, permission) == PackageManager.PERMISSION_GRANTED
    }
}

/**
 * Writes tamper-evident, hash-chained audit logs to Room.
 */
class AuditLogger(private val auditDao: AuditDao) {

    suspend fun log(
        eventType: String,
        actor: AssistantId,
        proposalId: String?,
        summary: String
    ) {
        val now = System.currentTimeMillis()
        val prevHash = auditDao.getLatestHash() ?: GENESIS_HASH
        val entryMaterial = "$prevHash|$eventType|${actor.name}|${proposalId.orEmpty()}|$summary|$now"
        val entryHash = sha256(entryMaterial)
        auditDao.insert(
            AuditLogEntity(
                eventType = eventType,
                actor = actor.name,
                proposalId = proposalId,
                summary = summary,
                prevHash = prevHash,
                entryHash = entryHash,
                timestampEpochMs = now
            )
        )
    }

    private fun sha256(input: String): String {
        val bytes = MessageDigest.getInstance("SHA-256").digest(input.toByteArray(Charsets.UTF_8))
        return bytes.joinToString("") { "%02x".format(it) }
    }

    companion object {
        private const val GENESIS_HASH = "0000000000000000000000000000000000000000000000000000000000000000"
    }
}
