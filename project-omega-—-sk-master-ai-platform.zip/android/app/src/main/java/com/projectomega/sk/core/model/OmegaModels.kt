package com.projectomega.sk.core.model

import kotlinx.serialization.Serializable

@Serializable
enum class AssistantId {
    SK,
    JARVIS,
    MAGMITE,
    ULTRON,
    FRIDAY
}

@Serializable
enum class AssistantStatus {
    ONLINE,
    STANDBY,
    BUSY,
    DEGRADED,
    DISABLED
}

@Serializable
enum class RiskLevel {
    LOW,
    MEDIUM,
    HIGH,
    CRITICAL
}

@Serializable
enum class AlertSeverity {
    INFO,
    WARNING,
    ERROR,
    CRITICAL
}

@Serializable
enum class InterfaceMode {
    NORMAL,
    PHOENIX,
    ASSEMBLED,
    ASSISTANT_ACTIVE
}

@Serializable
enum class AssemblyStage(val hudLabel: String) {
    IDLE("STANDBY"),
    SYSTEM_INITIALIZING("SYSTEM INITIALIZING"),
    CORE_DEPLOYMENT("CORE DEPLOYMENT"),
    HOLOGRAPHIC_ASSEMBLY("HOLOGRAPHIC ASSEMBLY"),
    CORE_SYNCHRONIZATION("CORE SYNCHRONIZATION"),
    OMEGA_ONLINE("OMEGA ONLINE"),
    DISASSEMBLING("DISASSEMBLING CORES")
}

@Serializable
enum class AnimationQuality(val targetFrameDelayMs: Long, val label: String) {
    HIGH_60FPS(16L, "60 FPS Smooth"),
    BATTERY_SAVER_30FPS(33L, "30 FPS Eco"),
    REDUCED_MOTION(120L, "Reduced Motion")
}

@Serializable
enum class VoiceState(val hudLabel: String) {
    IDLE("IDLE"),
    PERMISSION_REQUIRED("MIC PERMISSION"),
    LISTENING("LISTENING"),
    PROCESSING("PROCESSING"),
    RESPONDING("RESPONDING"),
    SPEAKING("SPEAKING"),
    ERROR("VOICE ERROR")
}

@Serializable
enum class IntentCategory {
    GENERAL_CONVERSATION,
    LIVE_INFORMATION_QUESTION,
    ASSISTANT_STATUS_QUERY,
    SYSTEM_TASK_STATUS_QUERY,
    ASSISTANT_MODE_CONTROL,
    DEVICE_INFORMATION_READ,
    DEVICE_HARDWARE_CONTROL,
    APP_NAVIGATION_LAUNCH,
    COMMUNICATION,
    SYSTEM_DIAGNOSTIC_OR_SCHEDULE
}

@Serializable
data class AssistantRuntimeMetrics(
    val activeTaskCount: Int = 0,
    val completedTaskCount: Int = 0,
    val pendingTaskCount: Int = 0,
    val lastResponseMs: Long? = null,
    val recentError: String? = null,
    val currentActivity: String = "Idle",
    val communicationState: String = "Standby (ready on request)"
)

data class ContactCandidate(
    val displayName: String,
    val phoneNumber: String,
    val label: String = "Mobile"
)

data class SimAccountOption(
    val slotIndex: Int,
    val displayName: String,
    val carrierName: String,
    val subscriptionId: Int,
    val phoneAccountHandleId: String? = null
)

enum class PermissionGrantStatus {
    GRANTED,
    DENIED,
    PERMANENTLY_DENIED,
    SPECIAL_ACCESS_REQUIRED
}

data class PermissionMetadata(
    val permission: String,
    val label: String,
    val rationale: String,
    val status: PermissionGrantStatus
)

sealed interface SkRouteOutcome {
    data class DirectResponse(
        val speaker: AssistantId,
        val category: IntentCategory,
        val replyText: String,
        val outputPayload: Map<String, String> = emptyMap(),
        val exactOperation: String = ""
    ) : SkRouteOutcome

    data class ProposalRequired(
        val proposal: TaskProposal,
        val deduplicated: Boolean = false
    ) : SkRouteOutcome

    data class ContactSelectionRequired(
        val actionType: String,
        val queryName: String,
        val candidates: List<ContactCandidate>,
        val messageBody: String? = null,
        val rawInput: String
    ) : SkRouteOutcome

    data class SimSelectionRequired(
        val contactName: String,
        val phoneNumber: String,
        val simOptions: List<SimAccountOption>,
        val rawInput: String
    ) : SkRouteOutcome
}

@Serializable
enum class VoiceGender {
    MALE,
    FEMALE
}

@Serializable
enum class VoiceProviderMode(val label: String) {
    AUTO_NEURAL_OR_LOCAL("Auto (Neural + Local Fallback)"),
    BACKEND_NEURAL_TTS("Neural TTS (Gemini 3.8)"),
    ANDROID_LOCAL_TTS("Android Local TTS")
}

@Serializable
data class VoiceConfig(
    val pitch: Float,
    val speechRate: Float,
    val voiceTone: String,
    val localeTag: String = "en-US",
    val gender: VoiceGender = VoiceGender.MALE,
    val neuralVoiceName: String = "Fenrir",
    val stylePrompt: String = ""
)

data class AssistantVisualIdentity(
    val primaryColorHex: Long,
    val secondaryColorHex: Long,
    val emblemLabel: String,
    val ringPulseHz: Float,
    val orbitalNodes: Int
)

data class AssistantProfile(
    val id: AssistantId,
    val displayName: String,
    val roleTitle: String,
    val personality: String,
    val capabilities: List<String>,
    val declaredPermissions: List<String>,
    val voiceConfig: VoiceConfig,
    val visualIdentity: AssistantVisualIdentity,
    val isMasterController: Boolean = false
)

@Serializable
data class AssistantCommandRequest(
    val commandId: String,
    val rawInput: String,
    val targetAssistant: AssistantId,
    val intentAction: String,
    val parameters: Map<String, String> = emptyMap(),
    val requiredPermissions: List<String> = emptyList(),
    val riskLevel: RiskLevel,
    val rationale: String
)

@Serializable
data class TaskProposal(
    val proposalId: String,
    val commandId: String,
    val rawInput: String,
    val targetAssistant: AssistantId,
    val actionSummary: String,
    val exactOperation: String,
    val parameters: Map<String, String>,
    val requiredPermissions: List<String>,
    val riskLevel: RiskLevel,
    val rationale: String,
    val payloadHash: String,
    val createdAtEpochMs: Long,
    val expiresAtEpochMs: Long
) {
    val isCriticalRisk: Boolean get() = riskLevel == RiskLevel.CRITICAL
}

data class ApprovalToken(
    val proposalId: String,
    val payloadHash: String,
    val targetAssistant: AssistantId,
    val exactOperation: String,
    val approvedAtEpochMs: Long
)

sealed interface AssistantExecutionResult {
    data class Success(
        val proposalId: String,
        val assistantId: AssistantId,
        val summary: String,
        val outputPayload: Map<String, String> = emptyMap(),
        val executedAtEpochMs: Long = System.currentTimeMillis()
    ) : AssistantExecutionResult

    data class Denied(
        val proposalId: String,
        val reason: String
    ) : AssistantExecutionResult

    data class PermissionMissing(
        val proposalId: String,
        val assistantId: AssistantId,
        val missingPermissions: List<String>
    ) : AssistantExecutionResult

    data class Failure(
        val proposalId: String,
        val assistantId: AssistantId,
        val errorMessage: String
    ) : AssistantExecutionResult
}

data class SystemAlert(
    val alertId: String,
    val severity: AlertSeverity,
    val source: AssistantId,
    val title: String,
    val message: String,
    val createdAtEpochMs: Long,
    val acknowledged: Boolean = false
)

data class AuditLogRecord(
    val id: Long = 0L,
    val eventType: String,
    val actor: AssistantId,
    val proposalId: String?,
    val summary: String,
    val prevHash: String,
    val entryHash: String,
    val timestampEpochMs: Long
)

data class SystemReport(
    val reportId: String,
    val generatedAtEpochMs: Long,
    val periodLabel: String,
    val totalCommands: Int,
    val approvedTasks: Int,
    val rejectedTasks: Int,
    val failedTasks: Int,
    val activeAssistants: List<AssistantId>,
    val narrativeSummary: String
)

data class ReminderRecord(
    val id: Long = 0L,
    val title: String,
    val notes: String,
    val triggerAtEpochMs: Long,
    val completed: Boolean = false,
    val createdByProposalId: String
)

data class TaskHistoryRecord(
    val proposalId: String,
    val targetAssistant: AssistantId,
    val rawInput: String,
    val exactOperation: String,
    val status: String,
    val resultSummary: String,
    val timestampEpochMs: Long
)

object OmegaIdentityCatalog {
    val profiles: Map<AssistantId, AssistantProfile> = mapOf(
        AssistantId.SK to AssistantProfile(
            id = AssistantId.SK,
            displayName = "SK",
            roleTitle = "Central Master Controller",
            personality = "Calm, authoritative, observant system orchestrator focused on precision, consent, and integrity.",
            capabilities = listOf(
                "Command intent classification & routing",
                "Assistant lifecycle & health monitoring",
                "Explicit task-specific approval enforcement",
                "Periodic telemetry & security reporting",
                "Critical alert emission"
            ),
            declaredPermissions = listOf("android.permission.POST_NOTIFICATIONS"),
            voiceConfig = VoiceConfig(
                pitch = 0.90f,
                speechRate = 0.96f,
                voiceTone = "Authoritative Male Baritone",
                localeTag = "en-US",
                gender = VoiceGender.MALE,
                neuralVoiceName = "Fenrir",
                stylePrompt = "Deep, powerful, calm, confident, authoritative male central master controller"
            ),
            visualIdentity = AssistantVisualIdentity(
                primaryColorHex = 0xFFFF8C1AL,
                secondaryColorHex = 0xFFFFB830L,
                emblemLabel = "MASTER REACTOR",
                ringPulseHz = 0.65f,
                orbitalNodes = 5
            ),
            isMasterController = true
        ),
        AssistantId.JARVIS to AssistantProfile(
            id = AssistantId.JARVIS,
            displayName = "JARVIS",
            roleTitle = "General Intelligence & Reasoning",
            personality = "Articulate, analytical, encyclopedic strategist specializing in synthesis, logic, and research.",
            capabilities = listOf(
                "Deep reasoning & structured synthesis",
                "Technical & scientific knowledge retrieval",
                "Architecture & problem decomposition",
                "Natural language drafting & analysis"
            ),
            declaredPermissions = emptyList(),
            voiceConfig = VoiceConfig(
                pitch = 0.98f,
                speechRate = 1.00f,
                voiceTone = "Refined British Male",
                localeTag = "en-GB",
                gender = VoiceGender.MALE,
                neuralVoiceName = "Puck",
                stylePrompt = "Sophisticated male voice with refined British-style delivery, smooth and intelligent"
            ),
            visualIdentity = AssistantVisualIdentity(
                primaryColorHex = 0xFF3B82F6L,
                secondaryColorHex = 0xFF60A5FAL,
                emblemLabel = "REASONING",
                ringPulseHz = 0.9f,
                orbitalNodes = 3
            )
        ),
        AssistantId.MAGMITE to AssistantProfile(
            id = AssistantId.MAGMITE,
            displayName = "MAGMITE",
            roleTitle = "Android Device & Hardware Controls",
            personality = "Direct, tactical hardware operator strictly bound to Android runtime permissions and OS intents.",
            capabilities = listOf(
                "Torch / flashlight state toggling",
                "Audio volume & ringer profile control",
                "Connectivity settings panels (Wi-Fi / Bluetooth)",
                "Device hardware & battery state inspection"
            ),
            declaredPermissions = listOf(
                "android.permission.CAMERA",
                "android.permission.BLUETOOTH_CONNECT",
                "android.permission.MODIFY_AUDIO_SETTINGS",
                "android.permission.ACCESS_NOTIFICATION_POLICY"
            ),
            voiceConfig = VoiceConfig(
                pitch = 1.04f,
                speechRate = 1.00f,
                voiceTone = "Magnetic Expressive Female",
                localeTag = "en-US",
                gender = VoiceGender.FEMALE,
                neuralVoiceName = "Kore",
                stylePrompt = "Distinctive magnetic, elegant, expressive, warm yet authoritative female voice"
            ),
            visualIdentity = AssistantVisualIdentity(
                primaryColorHex = 0xFFF59E0BL,
                secondaryColorHex = 0xFFFBBF24L,
                emblemLabel = "DEVICE OPS",
                ringPulseHz = 1.25f,
                orbitalNodes = 6
            )
        ),
        AssistantId.ULTRON to AssistantProfile(
            id = AssistantId.ULTRON,
            displayName = "ULTRON",
            roleTitle = "System Analysis & Automation",
            personality = "Relentlessly thorough diagnostics auditor detecting anomalies, bottlenecks, and automation patterns.",
            capabilities = listOf(
                "Memory & storage capacity diagnostics",
                "Thermal & battery drain heuristics",
                "Automated system health rule checks",
                "Anomaly detection & execution audit verification"
            ),
            declaredPermissions = listOf("android.permission.ACCESS_NETWORK_STATE"),
            voiceConfig = VoiceConfig(
                pitch = 0.72f,
                speechRate = 0.88f,
                voiceTone = "Deep Robotic Male",
                localeTag = "en-US",
                gender = VoiceGender.MALE,
                neuralVoiceName = "Charon",
                stylePrompt = "Deep, heavy, dark, commanding futuristic robotic male voice with deliberate pacing"
            ),
            visualIdentity = AssistantVisualIdentity(
                primaryColorHex = 0xFFEF4444L,
                secondaryColorHex = 0xFFF87171L,
                emblemLabel = "SYS AUDIT",
                ringPulseHz = 1.5f,
                orbitalNodes = 4
            )
        ),
        AssistantId.FRIDAY to AssistantProfile(
            id = AssistantId.FRIDAY,
            displayName = "FRIDAY",
            roleTitle = "Personal Assistance & Scheduling",
            personality = "Warm, proactive executive coordinator managing reminders, agendas, and time-critical routines.",
            capabilities = listOf(
                "Reminder creation & exact alarm scheduling",
                "Daily agenda & briefing generation",
                "Follow-up tracking & priority sorting",
                "Calendar & routine coordination"
            ),
            declaredPermissions = listOf(
                "android.permission.POST_NOTIFICATIONS",
                "android.permission.SCHEDULE_EXACT_ALARM"
            ),
            voiceConfig = VoiceConfig(
                pitch = 1.12f,
                speechRate = 1.03f,
                voiceTone = "Warm Conversational Female",
                localeTag = "en-US",
                gender = VoiceGender.FEMALE,
                neuralVoiceName = "Zephyr",
                stylePrompt = "Soft, intelligent, warm, friendly and professional female conversational voice"
            ),
            visualIdentity = AssistantVisualIdentity(
                primaryColorHex = 0xFF10B981L,
                secondaryColorHex = 0xFF34D399L,
                emblemLabel = "SCHEDULE",
                ringPulseHz = 0.85f,
                orbitalNodes = 4
            )
        )
    )
}
