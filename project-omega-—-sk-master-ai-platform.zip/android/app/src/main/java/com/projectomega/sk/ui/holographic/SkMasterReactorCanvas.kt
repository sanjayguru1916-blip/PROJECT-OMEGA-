package com.projectomega.sk.ui.holographic

import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.PathEffect
import androidx.compose.ui.graphics.Shadow
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.rotate
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.drawText
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.rememberTextMeasurer
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.projectomega.sk.core.model.AnimationQuality
import com.projectomega.sk.core.model.AssemblyStage
import com.projectomega.sk.core.model.AssistantId
import com.projectomega.sk.core.model.AssistantStatus
import com.projectomega.sk.core.model.InterfaceMode
import com.projectomega.sk.core.model.OmegaIdentityCatalog
import com.projectomega.sk.core.model.VoiceState
import com.projectomega.sk.core.registry.RegisteredAssistantState
import kotlinx.coroutines.delay
import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.hypot
import kotlin.math.sin

private val SkOrange = Color(0xFFFF8C1A)
private val SkGold = Color(0xFFFFB830)
private val SkHighlight = Color(0xFFFFDF8E)
private val HoloCyan = Color(0xFF38BDF8)
private val PhoenixRed = Color(0xFFFF3D00)

private data class SkFieldParticle(
    val angle: Float,
    val radiusFactor: Float,
    val speed: Float,
    val verticalPhase: Float,
    val sizeDp: Float,
    val alpha: Float
)

private fun buildSkFieldParticles(count: Int): List<SkFieldParticle> {
    return List(count) { i ->
        val s1 = ((i * 1.61803398875) % 1.0).toFloat()
        val s2 = ((i * 2.718281828) % 1.0).toFloat()
        SkFieldParticle(
            angle = ((i.toFloat() / count) * 2.0 * PI + s1 * 0.4).toFloat(),
            radiusFactor = 0.36f + s1 * 0.56f,
            speed = (if (i % 2 == 0) 1f else -1f) * (0.22f + s2 * 0.44f),
            verticalPhase = i * 0.85f,
            sizeDp = 1.0f + s1 * 1.8f,
            alpha = 0.22f + s2 * 0.48f
        )
    }
}

/**
 * Locked SK Master Reactor (Open Floating Presentation) + Phoenix Transformation
 * + Borderless Five-Core Holographic Assembly + Live Voice Waveform Ring.
 */
@Composable
fun SkMasterReactorCanvas(
    interfaceMode: InterfaceMode,
    assemblyStage: AssemblyStage,
    activeIdentity: AssistantId,
    speakingAssistant: AssistantId?,
    voiceState: VoiceState,
    voiceRmsLevel: Float,
    animationQuality: AnimationQuality,
    assistantStates: Map<AssistantId, RegisteredAssistantState>,
    isRouting: Boolean,
    isExecuting: Boolean,
    onSelectCore: (AssistantId) -> Unit,
    modifier: Modifier = Modifier,
    masterGreeting: String? = null
) {
    val fieldParticles = remember { buildSkFieldParticles(24) }
    val textMeasurer = rememberTextMeasurer()

    var activating by remember { mutableStateOf(true) }
    LaunchedEffect(Unit) {
        delay(1100L)
        activating = false
    }

    val transition = rememberInfiniteTransition(label = "sk_reactor_motion")
    val durationMs = when (animationQuality) {
        AnimationQuality.HIGH_60FPS -> if (isRouting || isExecuting || interfaceMode == InterfaceMode.PHOENIX) 4500 else 9000
        AnimationQuality.BATTERY_SAVER_30FPS -> 11000
        AnimationQuality.REDUCED_MOTION -> 24000
    }

    val orbitPhase by transition.animateFloat(
        initialValue = 0f,
        targetValue = 360f,
        animationSpec = infiniteRepeatable(
            animation = tween(durationMillis = durationMs, easing = LinearEasing),
            repeatMode = RepeatMode.Restart
        ),
        label = "orbitPhase"
    )

    val pulsePhase by transition.animateFloat(
        initialValue = 0.72f,
        targetValue = 1.0f,
        animationSpec = infiniteRepeatable(
            animation = tween(durationMillis = 1600, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "pulsePhase"
    )

    val phoenixWeight by animateFloatAsState(
        targetValue = if (interfaceMode == InterfaceMode.PHOENIX) 1f else 0f,
        animationSpec = tween(durationMillis = 700, easing = FastOutSlowInEasing),
        label = "phoenixWeight"
    )

    val assemblyWeight by animateFloatAsState(
        targetValue = when {
            interfaceMode == InterfaceMode.ASSEMBLED && assemblyStage != AssemblyStage.DISASSEMBLING -> when (assemblyStage) {
                AssemblyStage.SYSTEM_INITIALIZING -> 0.16f
                AssemblyStage.CORE_DEPLOYMENT -> 0.48f
                AssemblyStage.HOLOGRAPHIC_ASSEMBLY -> 0.80f
                AssemblyStage.CORE_SYNCHRONIZATION -> 0.95f
                AssemblyStage.OMEGA_ONLINE -> 1.0f
                else -> 1.0f
            }
            assemblyStage == AssemblyStage.DISASSEMBLING -> 0.15f
            else -> 0f
        },
        animationSpec = tween(durationMillis = 750, easing = FastOutSlowInEasing),
        label = "assemblyWeight"
    )

    val satelliteOffsets = listOf(
        AssistantId.JARVIS to Pair(-0.33f, -0.29f),
        AssistantId.MAGMITE to Pair(0.33f, -0.29f),
        AssistantId.ULTRON to Pair(-0.33f, 0.29f),
        AssistantId.FRIDAY to Pair(0.33f, 0.29f)
    )

    val configuration = LocalConfiguration.current
    val maxResponsiveHeight = (configuration.screenHeightDp * 0.42f).dp.coerceIn(220.dp, 320.dp)

    BoxWithConstraints(
        modifier = modifier.fillMaxWidth(),
        contentAlignment = Alignment.Center
    ) {
        val stageHeight = minOf(maxWidth * 0.88f, maxResponsiveHeight)

        Box(
            modifier = Modifier
                .fillMaxWidth()
                .height(stageHeight),
            contentAlignment = Alignment.Center
        ) {
            Canvas(
                modifier = Modifier
                    .fillMaxSize()
                    .pointerInput(interfaceMode, assemblyWeight) {
                        detectTapGestures { tap ->
                            val center = Offset(size.width / 2f, size.height / 2f)
                            if (assemblyWeight > 0.35f) {
                                for ((id, rel) in satelliteOffsets) {
                                    val targetPos = Offset(
                                        center.x + rel.first * size.width * assemblyWeight,
                                        center.y + rel.second * size.height * assemblyWeight
                                    )
                                    if (hypot(tap.x - targetPos.x, tap.y - targetPos.y) <= 44.dp.toPx()) {
                                        onSelectCore(id)
                                        return@detectTapGestures
                                    }
                                }
                            }
                            if (hypot(tap.x - center.x, tap.y - center.y) <= 78.dp.toPx()) {
                                onSelectCore(AssistantId.SK)
                            }
                        }
                    }
            ) {
                val simRad = (orbitPhase * PI / 180.0).toFloat()
                val reducedMotion = animationQuality == AnimationQuality.REDUCED_MOTION
                val levitationY = if (reducedMotion || interfaceMode == InterfaceMode.ASSEMBLED) {
                    0f
                } else {
                    sin(simRad * 2f) * 3.5.dp.toPx()
                }
                val center = Offset(size.width / 2f, size.height / 2f + levitationY)
                val maxRatio = if (assemblyWeight > 0.2f) 0.25f else 0.34f
                val baseRadius = (size.minDimension * maxRatio).coerceAtMost(122.dp.toPx())
                val isListening = voiceState == VoiceState.LISTENING
                val isThinking = isRouting || isExecuting || voiceState == VoiceState.PROCESSING || voiceState == VoiceState.RESPONDING

                // 1. Borderless Open-Space Dual-Energy Volumetric Aura (Blue + Orange-Gold)
                val auraR = size.minDimension * 0.56f
                drawCircle(
                    brush = Brush.radialGradient(
                        colorStops = arrayOf(
                            0.0f to (if (phoenixWeight > 0.1f) SkOrange else SkOrange).copy(
                                alpha = if (phoenixWeight > 0.1f) 0.25f * phoenixWeight else if (isThinking) 0.22f else 0.16f
                            ),
                            0.46f to HoloCyan.copy(alpha = 0.08f + 0.06f * pulsePhase),
                            0.78f to SkGold.copy(alpha = 0.03f),
                            1.0f to Color.Transparent
                        ),
                        center = center,
                        radius = auraR
                    ),
                    radius = auraR,
                    center = center
                )

                // Independent 3D Tilted Blue + Orange-Gold Holographic Rings around SK when not assembled
                if (assemblyWeight < 0.15f) {
                    rotate(degrees = orbitPhase * 0.35f - 18f, pivot = center) {
                        val rx = baseRadius * 1.48f
                        val ry = baseRadius * 0.64f
                        drawOval(
                            color = HoloCyan.copy(alpha = if (isListening) 0.52f else 0.34f),
                            topLeft = Offset(center.x - rx, center.y - ry),
                            size = Size(rx * 2f, ry * 2f),
                            style = Stroke(
                                width = 1.4.dp.toPx(),
                                pathEffect = PathEffect.dashPathEffect(floatArrayOf(20f, 10f), orbitPhase)
                            )
                        )
                    }
                    rotate(degrees = -orbitPhase * 0.48f + 22f, pivot = center) {
                        val rx = baseRadius * 1.38f
                        val ry = baseRadius * 0.56f
                        drawOval(
                            color = SkGold.copy(alpha = 0.32f),
                            topLeft = Offset(center.x - rx, center.y - ry),
                            size = Size(rx * 2f, ry * 2f),
                            style = Stroke(width = 1.2.dp.toPx())
                        )
                    }
                    rotate(degrees = orbitPhase * 0.24f, pivot = center) {
                        drawCircle(
                            color = HoloCyan.copy(alpha = 0.24f),
                            radius = baseRadius * 1.22f,
                            center = center,
                            style = Stroke(
                                width = 1.dp.toPx(),
                                pathEffect = PathEffect.dashPathEffect(floatArrayOf(12f, 16f), -orbitPhase)
                            )
                        )
                    }
                }

                // Open-Space Blue & Gold Floating Energy Particles
                for (i in fieldParticles.indices) {
                    val pt = fieldParticles[i]
                    val theta = pt.angle + simRad * pt.speed
                    val convergePull = if (assemblyStage == AssemblyStage.SYSTEM_INITIALIZING) 1.3f - assemblyWeight else 1f
                    val pr = size.minDimension * 0.45f * pt.radiusFactor * convergePull
                    val px = center.x + cos(theta) * pr
                    val py = center.y + sin(theta) * pr * 0.65f + sin(simRad * 1.5f + pt.verticalPhase) * 5.dp.toPx()
                    val twinkle = 0.55f + 0.45f * sin(simRad * 2.4f + pt.verticalPhase)
                    val pColor = when {
                        i % 2 == 0 -> HoloCyan
                        i % 3 == 0 -> SkHighlight
                        else -> SkOrange
                    }
                    drawCircle(
                        color = pColor.copy(alpha = (pt.alpha * twinkle).coerceIn(0f, 1f)),
                        radius = pt.sizeDp.dp.toPx(),
                        center = Offset(px, py)
                    )
                }

                // 2. Phoenix Wings ONLY when Phoenix Mode active (phoenixWeight == 0 in Normal Mode)
                if (phoenixWeight > 0.02f) {
                    drawPhoenixWings(center, baseRadius, phoenixWeight, pulsePhase, orbitPhase)
                }

                // 3. Five-Core Open Floating Assembly (Borderless Satellites + Identity Geometry + Offline Respect)
                if (assemblyWeight > 0.02f) {
                    if (assemblyStage == AssemblyStage.CORE_SYNCHRONIZATION || assemblyStage == AssemblyStage.OMEGA_ONLINE) {
                        val syncWave = (orbitPhase / 360f)
                        drawCircle(
                            color = HoloCyan.copy(alpha = (1f - syncWave) * 0.34f * assemblyWeight),
                            radius = baseRadius + syncWave * size.minDimension * 0.42f,
                            center = center,
                            style = Stroke(width = 1.5.dp.toPx())
                        )
                    }

                    satelliteOffsets.forEachIndexed { idx, (id, rel) ->
                        val profile = OmegaIdentityCatalog.profiles.getValue(id)
                        val reg = assistantStates[id]
                        val enabled = (reg?.isEnabled ?: true) && (reg?.status != AssistantStatus.DISABLED)
                        val accent = if (enabled) Color(profile.visualIdentity.primaryColorHex) else Color(0xFF475569)
                        val floatY = if (enabled && !reducedMotion) sin(simRad * 1.6f + idx * 1.3f) * 3.dp.toPx() else 0f
                        val pos = Offset(
                            center.x + rel.first * size.width * assemblyWeight,
                            center.y + rel.second * size.height * assemblyWeight + floatY
                        )

                        // Holographic conduits ONLY connect enabled/operational cores
                        if (assemblyWeight > 0.52f && enabled) {
                            drawLine(
                                color = HoloCyan.copy(alpha = 0.55f * assemblyWeight),
                                start = center,
                                end = pos,
                                strokeWidth = 1.8.dp.toPx(),
                                pathEffect = PathEffect.dashPathEffect(floatArrayOf(12f, 8f), -orbitPhase)
                            )
                            if (assemblyStage == AssemblyStage.CORE_SYNCHRONIZATION || assemblyStage == AssemblyStage.OMEGA_ONLINE) {
                                val t = ((orbitPhase / 360f) + idx * 0.25f) % 1f
                                val pulsePos = Offset(
                                    center.x + (pos.x - center.x) * t,
                                    center.y + (pos.y - center.y) * t
                                )
                                drawCircle(
                                    color = if (speakingAssistant == id) accent else HoloCyan,
                                    radius = 3.8.dp.toPx(),
                                    center = pulsePos
                                )
                            }
                        }

                        val nodeR = 27.dp.toPx() * assemblyWeight.coerceIn(0.45f, 1f)
                        val isHighlighted = activeIdentity == id || speakingAssistant == id

                        // Open-space radial glow behind floating satellite (no opaque dark disc card)
                        drawCircle(
                            brush = Brush.radialGradient(
                                colorStops = arrayOf(
                                    0.0f to accent.copy(alpha = if (!enabled) 0.12f else if (speakingAssistant == id) 0.48f else 0.34f),
                                    0.6f to accent.copy(alpha = if (enabled) 0.12f else 0.04f),
                                    1.0f to Color.Transparent
                                ),
                                center = pos,
                                radius = nodeR * 1.45f
                            ),
                            radius = nodeR * 1.45f,
                            center = pos
                        )

                        // Rotating identity ring + tilted 3D mini gyro ring + polygon lattice
                        val ringRot = if (enabled) orbitPhase * (if (idx % 2 == 0) 1f else -1f) else 0f
                        rotate(degrees = ringRot, pivot = pos) {
                            drawCircle(
                                color = accent.copy(alpha = if (!enabled) 0.38f else if (isHighlighted) 1f else 0.78f),
                                radius = nodeR,
                                center = pos,
                                style = Stroke(
                                    width = (if (isHighlighted && enabled) 2.4f else 1.5f).dp.toPx(),
                                    pathEffect = PathEffect.dashPathEffect(
                                        if (id == AssistantId.ULTRON) floatArrayOf(8f, 5f) else floatArrayOf(15f, 7f),
                                        0f
                                    )
                                )
                            )

                            val satNodes = profile.visualIdentity.orbitalNodes
                            val polyPath = Path()
                            for (k in 0..satNodes) {
                                val kTheta = (k * 2.0 * PI) / satNodes + if (id == AssistantId.FRIDAY) PI / 4.0 else 0.0
                                val kx = pos.x + (cos(kTheta) * nodeR * 0.62f).toFloat()
                                val ky = pos.y + (sin(kTheta) * nodeR * 0.62f).toFloat()
                                if (k == 0) polyPath.moveTo(kx, ky) else polyPath.lineTo(kx, ky)
                            }
                            drawPath(
                                path = polyPath,
                                color = accent.copy(alpha = if (enabled) 0.56f else 0.22f),
                                style = Stroke(width = 1.dp.toPx())
                            )

                            if (enabled) {
                                for (k in 0 until satNodes) {
                                    val kTheta = (k * 2.0 * PI) / satNodes
                                    drawCircle(
                                        color = accent,
                                        radius = 2.2.dp.toPx(),
                                        center = Offset(
                                            pos.x + (cos(kTheta) * nodeR).toFloat(),
                                            pos.y + (sin(kTheta) * nodeR).toFloat()
                                        )
                                    )
                                }
                            }
                        }

                        if (enabled) {
                            rotate(degrees = (idx * 40f + orbitPhase * 0.55f) % 360f, pivot = pos) {
                                val rx = nodeR * 0.88f
                                val ry = nodeR * 0.36f
                                drawOval(
                                    color = accent.copy(alpha = 0.55f),
                                    topLeft = Offset(pos.x - rx, pos.y - ry),
                                    size = Size(rx * 2f, ry * 2f),
                                    style = Stroke(width = 1.dp.toPx())
                                )
                            }
                        }

                        if (assemblyWeight > 0.55f && enabled) {
                            drawCircle(
                                color = HoloCyan.copy(alpha = 0.34f * assemblyWeight),
                                radius = nodeR + 5.dp.toPx(),
                                center = pos,
                                style = Stroke(width = 1.dp.toPx())
                            )
                        }

                        // Crisp unboxed satellite label & status
                        val titleResult = textMeasurer.measure(
                            text = profile.displayName,
                            style = TextStyle(
                                color = if (enabled) Color(0xFFF8FAFC) else Color(0xFF64748B),
                                fontSize = 9.sp,
                                fontWeight = FontWeight.SemiBold,
                                fontFamily = FontFamily.Monospace,
                                shadow = Shadow(Color.Black, Offset(0f, 1f), 4f)
                            )
                        )
                        val satStatusText = when {
                            !enabled -> "OFFLINE"
                            speakingAssistant == id -> "SPEAKING"
                            else -> (reg?.status ?: AssistantStatus.ONLINE).name
                        }
                        val statusResult = textMeasurer.measure(
                            text = satStatusText,
                            style = TextStyle(
                                color = accent,
                                fontSize = 7.sp,
                                fontWeight = FontWeight.Medium,
                                fontFamily = FontFamily.Monospace,
                                shadow = Shadow(Color.Black, Offset(0f, 1f), 4f)
                            )
                        )
                        drawText(
                            textLayoutResult = titleResult,
                            topLeft = Offset(pos.x - titleResult.size.width / 2f, pos.y - titleResult.size.height * 0.85f)
                        )
                        drawText(
                            textLayoutResult = statusResult,
                            topLeft = Offset(pos.x - statusResult.size.width / 2f, pos.y + 1.dp.toPx())
                        )
                    }
                }

                // Voice Waveform Radial Bars
                if (voiceState == VoiceState.LISTENING || voiceState == VoiceState.SPEAKING || voiceState == VoiceState.PROCESSING || voiceState == VoiceState.RESPONDING) {
                    val speakerColor = speakingAssistant?.let {
                        Color(OmegaIdentityCatalog.profiles.getValue(it).visualIdentity.primaryColorHex)
                    } ?: SkGold
                    val barCount = 36
                    val ampBase = when (voiceState) {
                        VoiceState.LISTENING -> (0.25f + voiceRmsLevel * 0.9f)
                        VoiceState.SPEAKING, VoiceState.RESPONDING -> (0.35f + 0.45f * pulsePhase)
                        else -> 0.25f
                    }
                    for (i in 0 until barCount) {
                        val deg = i * (360.0 / barCount) + orbitPhase * 0.2
                        val rad = deg * PI / 180.0
                        val mod = 0.5f + 0.5f * sin(i * 0.8 + orbitPhase * 0.12).toFloat()
                        val barLen = (4.dp.toPx() + 14.dp.toPx() * ampBase * mod)
                        val rStart = baseRadius + 4.dp.toPx()
                        val rEnd = rStart + barLen
                        drawLine(
                            color = speakerColor.copy(alpha = 0.8f),
                            start = Offset(center.x + rStart * cos(rad).toFloat(), center.y + rStart * sin(rad).toFloat()),
                            end = Offset(center.x + rEnd * cos(rad).toFloat(), center.y + rEnd * sin(rad).toFloat()),
                            strokeWidth = 2.dp.toPx(),
                            cap = StrokeCap.Round
                        )
                    }
                }

                // 4. Locked SK Master Mechanical Reactor (MEANINGS REACTOR Preserved 100%)
                drawLockedSkReactor(
                    center = center,
                    radius = baseRadius,
                    orbitPhase = orbitPhase,
                    pulse = pulsePhase,
                    phoenixWeight = phoenixWeight,
                    isSpeaking = speakingAssistant == AssistantId.SK,
                    isActive = isRouting || isExecuting || voiceState == VoiceState.LISTENING
                )

                if (interfaceMode == InterfaceMode.ASSISTANT_ACTIVE && activeIdentity != AssistantId.SK) {
                    val activeProfile = OmegaIdentityCatalog.profiles.getValue(activeIdentity)
                    val activeAccent = Color(activeProfile.visualIdentity.primaryColorHex)
                    drawCircle(
                        color = activeAccent.copy(alpha = 0.75f * pulsePhase),
                        radius = baseRadius + 16.dp.toPx(),
                        center = center,
                        style = Stroke(
                            width = 2.dp.toPx(),
                            pathEffect = PathEffect.dashPathEffect(floatArrayOf(22f, 10f), orbitPhase)
                        )
                    )
                }
            }

            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                Text(
                    text = "SK",
                    color = SkHighlight,
                    fontSize = 18.sp,
                    fontWeight = FontWeight.Bold,
                    fontFamily = FontFamily.Monospace,
                    style = TextStyle(shadow = Shadow(Color.Black, Offset(0f, 2f), 8f))
                )
                Text(
                    text = when {
                        activating -> "ACTIVATING"
                        voiceState != VoiceState.IDLE -> voiceState.hudLabel
                        assemblyStage != AssemblyStage.IDLE && assemblyStage != AssemblyStage.OMEGA_ONLINE -> assemblyStage.hudLabel
                        interfaceMode == InterfaceMode.PHOENIX -> "PHOENIX"
                        interfaceMode == InterfaceMode.ASSEMBLED -> "OMEGA ONLINE"
                        interfaceMode == InterfaceMode.ASSISTANT_ACTIVE -> activeIdentity.name
                        else -> "MASTER CORE"
                    },
                    color = when {
                        voiceState == VoiceState.ERROR || voiceState == VoiceState.PERMISSION_REQUIRED -> Color(0xFFFCA5A5)
                        interfaceMode == InterfaceMode.ASSEMBLED -> HoloCyan
                        else -> SkGold
                    },
                    fontSize = 10.sp,
                    fontWeight = FontWeight.SemiBold,
                    fontFamily = FontFamily.Monospace,
                    style = TextStyle(shadow = Shadow(Color.Black, Offset(0f, 1f), 6f))
                )
            }
        }
    }
}

private fun DrawScope.drawLockedSkReactor(
    center: Offset,
    radius: Float,
    orbitPhase: Float,
    pulse: Float,
    phoenixWeight: Float,
    isSpeaking: Boolean,
    isActive: Boolean
) {
    val activeGlow = if (isSpeaking || isActive) 1f else pulse

    drawCircle(color = Color(0xFF14161B), radius = radius, center = center)
    drawCircle(color = Color(0xFF4A280D), radius = radius, center = center, style = Stroke(width = 6.dp.toPx()))

    rotate(degrees = orbitPhase * 0.45f, pivot = center) {
        val notchCount = 12
        for (i in 0 until notchCount) {
            val deg = i * (360f / notchCount)
            drawArc(
                color = if (i % 2 == 0) SkOrange else SkGold.copy(alpha = 0.65f),
                startAngle = deg,
                sweepAngle = 16f,
                useCenter = false,
                topLeft = Offset(center.x - radius * 0.88f, center.y - radius * 0.88f),
                size = Size(radius * 1.76f, radius * 1.76f),
                style = Stroke(width = 3.5.dp.toPx(), cap = StrokeCap.Butt)
            )
        }
    }

    rotate(degrees = -orbitPhase * 0.85f, pivot = center) {
        drawCircle(
            color = SkGold.copy(alpha = 0.85f),
            radius = radius * 0.72f,
            center = center,
            style = Stroke(width = 2.dp.toPx(), pathEffect = PathEffect.dashPathEffect(floatArrayOf(28f, 12f), 0f))
        )
        for (i in 0 until 8) {
            val rad = (i * 45.0) * PI / 180.0
            val p1 = Offset(center.x + (radius * 0.50f) * cos(rad).toFloat(), center.y + (radius * 0.50f) * sin(rad).toFloat())
            val p2 = Offset(center.x + (radius * 0.69f) * cos(rad).toFloat(), center.y + (radius * 0.69f) * sin(rad).toFloat())
            drawLine(color = SkOrange.copy(alpha = 0.75f), start = p1, end = p2, strokeWidth = 2.dp.toPx())
        }
    }

    drawCircle(
        brush = Brush.radialGradient(
            colors = listOf(
                SkHighlight.copy(alpha = 0.85f * activeGlow),
                SkOrange.copy(alpha = 0.55f + 0.3f * phoenixWeight),
                Color(0xFF1A0E05)
            ),
            center = center,
            radius = radius * 0.48f
        ),
        radius = radius * 0.46f,
        center = center
    )
    drawCircle(color = SkGold, radius = radius * 0.46f, center = center, style = Stroke(width = 2.dp.toPx()))
}

private fun DrawScope.drawPhoenixWings(
    center: Offset,
    baseRadius: Float,
    weight: Float,
    pulse: Float,
    orbitPhase: Float
) {
    // Wing Backlight Plasma Haze (Blue outer halo fading into gold/amber core glow)
    drawCircle(
        brush = Brush.radialGradient(
            colorStops = arrayOf(
                0.0f to SkGold.copy(alpha = 0.24f * weight),
                0.5f to HoloCyan.copy(alpha = 0.14f * weight),
                1.0f to Color.Transparent
            ),
            center = center,
            radius = baseRadius * 2.5f * weight
        ),
        radius = baseRadius * 2.5f * weight,
        center = center
    )

    // Symmetrical Swept Plasma Pinion Wings (6 layered blue & orange-gold feathers per side)
    for (side in listOf(-1f, 1f)) {
        for (feather in 0 until 6) {
            val spread = (0.85f + feather * 0.22f) * weight
            val sweepUp = (0.98f - feather * 0.18f) * baseRadius
            val tipDrop = (feather * 0.24f - 0.56f) * baseRadius

            val path = Path().apply {
                moveTo(center.x + side * baseRadius * 0.68f, center.y - baseRadius * 0.08f)
                quadraticTo(
                    center.x + side * baseRadius * (1.42f * spread),
                    center.y - sweepUp * 1.15f,
                    center.x + side * baseRadius * (2.26f * spread),
                    center.y + tipDrop
                )
            }

            val wingColor = when {
                feather % 2 == 0 -> HoloCyan
                feather == 1 -> SkHighlight
                feather == 3 -> SkGold
                else -> SkOrange
            }
            drawPath(
                path = path,
                color = wingColor.copy(alpha = (0.88f - feather * 0.10f) * weight * pulse),
                style = Stroke(width = (5.8f - feather * 0.55f).dp.toPx(), cap = StrokeCap.Round)
            )
        }

        // Secondary Lower Tail Wing Plumes
        val tailPath = Path().apply {
            moveTo(center.x + side * baseRadius * 0.55f, center.y + baseRadius * 0.34f)
            quadraticTo(
                center.x + side * baseRadius * 1.12f * weight,
                center.y + baseRadius * 0.92f,
                center.x + side * baseRadius * 1.56f * weight,
                center.y + baseRadius * 1.24f
            )
        }
        drawPath(
            path = tailPath,
            color = PhoenixRed.copy(alpha = 0.55f * weight * pulse),
            style = Stroke(width = 3.dp.toPx(), cap = StrokeCap.Round)
        )
    }

    // Dual Blue & Orange-Gold Shockwave Pulses
    val wave1 = (orbitPhase % 180f) / 180f
    val wave2 = ((orbitPhase + 90f) % 180f) / 180f
    drawCircle(
        color = HoloCyan.copy(alpha = (1f - wave1) * 0.42f * weight),
        radius = baseRadius * (1.05f + wave1 * 0.85f),
        center = center,
        style = Stroke(width = 1.8.dp.toPx())
    )
    drawCircle(
        color = SkOrange.copy(alpha = (1f - wave2) * 0.42f * weight),
        radius = baseRadius * (1.05f + wave2 * 0.85f),
        center = center,
        style = Stroke(width = 1.8.dp.toPx())
    )

    // Rising Dual-Tone Plasma Embers
    for (i in 0 until 14) {
        val t = ((orbitPhase / 360f) + i * 0.071f) % 1f
        val px = center.x + sin((i * 1.4 + t * 4.2)).toFloat() * baseRadius * 1.65f
        val py = center.y + baseRadius * 0.85f - t * baseRadius * 2.25f
        drawCircle(
            color = if (i % 2 == 0) HoloCyan else SkGold,
            radius = 2.4.dp.toPx() * weight,
            center = Offset(px, py),
            alpha = (1f - t) * weight
        )
    }
}
