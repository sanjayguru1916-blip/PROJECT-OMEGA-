package com.projectomega.sk.ui.voice

import com.projectomega.sk.core.model.AssistantId
import com.projectomega.sk.core.model.InterfaceMode

sealed interface ParsedVoiceIntent {
    data object ActivateMaster : ParsedVoiceIntent
    data class SetMode(val mode: InterfaceMode) : ParsedVoiceIntent
    data object AssembleAll : ParsedVoiceIntent
    data object DisassembleAll : ParsedVoiceIntent
    data object StopSpeech : ParsedVoiceIntent
    data class SetVoiceEnabled(val enabled: Boolean) : ParsedVoiceIntent
    data class OpenDetailsSection(val sectionName: String, val spokenSummary: String) : ParsedVoiceIntent
    data object CloseDetailsSection : ParsedVoiceIntent
    data class ActivateAssistant(val assistantId: AssistantId, val trailingCommand: String?) : ParsedVoiceIntent
    data class RouteCommand(val commandText: String) : ParsedVoiceIntent
}

object SkVoiceCommandParser {

    fun parse(rawInput: String): ParsedVoiceIntent {
        val normalized = rawInput.trim()
            .uppercase()
            .replace(Regex("\\s+"), " ")

        return when (normalized) {
            "SK", "HEY SK" -> ParsedVoiceIntent.ActivateMaster
            "SK NORMAL MODE", "NORMAL MODE",
            "SK DEACTIVATE PHOENIX MODE", "DEACTIVATE PHOENIX MODE",
            "SK EXIT PHOENIX MODE", "EXIT PHOENIX MODE",
            "SK PHOENIX OFF", "PHOENIX OFF" -> ParsedVoiceIntent.SetMode(InterfaceMode.NORMAL)
            "SK PHOENIX MODE", "PHOENIX MODE",
            "SK ACTIVATE PHOENIX MODE", "ACTIVATE PHOENIX MODE",
            "SK PHOENIX ON", "PHOENIX ON" -> ParsedVoiceIntent.SetMode(InterfaceMode.PHOENIX)
            "SK ASSEMBLE ALL", "ASSEMBLE ALL" -> ParsedVoiceIntent.AssembleAll
            "SK DISASSEMBLE ALL", "DISASSEMBLE ALL" -> ParsedVoiceIntent.DisassembleAll
            "SK STOP", "STOP SPEAKING", "STOP" -> ParsedVoiceIntent.StopSpeech
            "SK VOICE OFF", "VOICE OFF" -> ParsedVoiceIntent.SetVoiceEnabled(false)
            "SK VOICE ON", "VOICE ON" -> ParsedVoiceIntent.SetVoiceEnabled(true)
            "SK STATUS REPORT", "STATUS REPORT", "SK SYSTEM STATUS", "SYSTEM STATUS",
            "SK SHOW SYSTEM DETAILS", "SHOW SYSTEM DETAILS" ->
                ParsedVoiceIntent.OpenDetailsSection("SYSTEM", "Opening SK Master system and mission status report.")
            "SK SHOW ASSISTANT STATUS", "SHOW ASSISTANT STATUS",
            "SK ASSISTANT STATUS", "ASSISTANT STATUS",
            "SK SHOW ASSISTANTS", "SHOW ASSISTANTS" ->
                ParsedVoiceIntent.OpenDetailsSection("ACTIVITY", "Opening assistant status and telemetry for all five cores.")
            "SK SHOW AUDIT LOG", "SHOW AUDIT LOG", "SK AUDIT LOG", "AUDIT LOG",
            "SK SHOW AUDIT LOGS", "SHOW AUDIT LOGS" ->
                ParsedVoiceIntent.OpenDetailsSection("DIAGNOSTICS", "Opening SK Master audit logs and verification reports.")
            "SK SHOW DEVICE INFORMATION", "SHOW DEVICE INFORMATION",
            "SK SHOW DEVICE INFO", "SHOW DEVICE INFO",
            "SK DEVICE INFO", "DEVICE INFO" ->
                ParsedVoiceIntent.OpenDetailsSection("DEVICE", "Opening device telemetry and runtime information.")
            "SK SHOW APPROVALS", "SHOW APPROVALS", "SK APPROVALS", "APPROVALS" ->
                ParsedVoiceIntent.OpenDetailsSection("APPROVALS", "Opening task approval center.")
            "SK SHOW VOICE SETTINGS", "SHOW VOICE SETTINGS", "SK VOICE SETTINGS", "VOICE SETTINGS" ->
                ParsedVoiceIntent.OpenDetailsSection("DIAGNOSTICS", "Opening voice calibration and TTS settings.")
            "SK SHOW HISTORY", "SHOW HISTORY", "SK TASK HISTORY", "TASK HISTORY",
            "SK SHOW COMMAND RESULTS", "SHOW COMMAND RESULTS" ->
                ParsedVoiceIntent.OpenDetailsSection("HISTORY", "Opening previous command results and task history.")
            "SK CLOSE DETAILS", "CLOSE DETAILS", "CLOSE MENU", "SK CLOSE MENU" ->
                ParsedVoiceIntent.CloseDetailsSection
            "JARVIS" -> ParsedVoiceIntent.ActivateAssistant(AssistantId.JARVIS, null)
            "MAGMITE" -> ParsedVoiceIntent.ActivateAssistant(AssistantId.MAGMITE, null)
            "ULTRON" -> ParsedVoiceIntent.ActivateAssistant(AssistantId.ULTRON, null)
            "FRIDAY" -> ParsedVoiceIntent.ActivateAssistant(AssistantId.FRIDAY, null)
            else -> {
                val assistantPrefixes = listOf(
                    AssistantId.JARVIS,
                    AssistantId.MAGMITE,
                    AssistantId.ULTRON,
                    AssistantId.FRIDAY
                )
                for (id in assistantPrefixes) {
                    val prefix = "${id.name} "
                    val commaPrefix = "${id.name},"
                    val colonPrefix = "${id.name}:"
                    if (normalized.startsWith(prefix) || normalized.startsWith(commaPrefix) || normalized.startsWith(colonPrefix)) {
                        val remainder = rawInput.trim().drop(id.name.length).trimStart(',', ':', ' ')
                        return ParsedVoiceIntent.ActivateAssistant(id, remainder.ifBlank { null })
                    }
                }
                ParsedVoiceIntent.RouteCommand(rawInput.trim())
            }
        }
    }
}
