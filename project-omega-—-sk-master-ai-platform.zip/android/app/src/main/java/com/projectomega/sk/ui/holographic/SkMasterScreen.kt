package com.projectomega.sk.ui.holographic

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowDropDown
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Menu
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Send
import androidx.compose.material.icons.filled.Stop
import androidx.compose.material.icons.filled.VolumeOff
import androidx.compose.material.icons.filled.VolumeUp
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Checkbox
import androidx.compose.material3.CheckboxDefaults
import androidx.compose.material3.DrawerValue
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.ModalDrawerSheet
import androidx.compose.material3.ModalNavigationDrawer
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.rememberDrawerState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.PathEffect
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.projectomega.sk.core.model.AnimationQuality
import com.projectomega.sk.core.model.AssistantId
import com.projectomega.sk.core.model.AssistantStatus
import com.projectomega.sk.core.model.ContactCandidate
import com.projectomega.sk.core.model.InterfaceMode
import com.projectomega.sk.core.model.OmegaIdentityCatalog
import com.projectomega.sk.core.model.SimAccountOption
import com.projectomega.sk.core.model.TaskProposal
import com.projectomega.sk.core.model.VoiceProviderMode
import com.projectomega.sk.core.model.VoiceState
import com.projectomega.sk.ui.viewmodel.OmegaUiState
import kotlinx.coroutines.launch
import kotlin.math.abs
import kotlin.math.sin

private val BlackMetallicBg = Color(0xFF050608)
private val HudPanelBg = Color(0xFF0D1017)
private val DrawerBg = Color(0xFF090B10)
private val Hairline = Color(0x1FFFFFFF)
private val SkOrange = Color(0xFFFF8C1A)
private val SkGold = Color(0xFFFFB830)
private val SkHighlight = Color(0xFFFFDF8E)
private val HoloCyan = Color(0xFF38BDF8)

private enum class ExpandableSection(val label: String) {
    APPROVALS("Approvals"),
    SYSTEM("System"),
    ACTIVITY("Assistants"),
    DEVICE("Device"),
    HISTORY("Results"),
    DIAGNOSTICS("Voice & Logs")
}

@Composable
fun SkMasterScreen(
    state: OmegaUiState,
    onSelectIdentity: (AssistantId) -> Unit,
    onNormalMode: () -> Unit,
    onPhoenixMode: () -> Unit,
    onAssembleAll: () -> Unit,
    onDisassembleAll: () -> Unit,
    onSubmitCommand: (String) -> Unit,
    onToggleListening: () -> Unit,
    onStopSpeaking: () -> Unit,
    onApproveProposal: (TaskProposal) -> Unit,
    onRejectProposal: (String) -> Unit,
    onToggleAssistant: (AssistantId, Boolean) -> Unit,
    onToggleVoice: (Boolean) -> Unit,
    onSelectVoiceProvider: (VoiceProviderMode) -> Unit,
    onUpdateVoiceTuning: (AssistantId, Float, Float) -> Unit,
    onPreviewVoice: (AssistantId) -> Unit,
    onSelectAnimationQuality: (AnimationQuality) -> Unit,
    onGenerateReport: () -> Unit,
    onAcknowledgeAlert: (String) -> Unit,
    onRequestPermissions: (List<String>) -> Unit,
    onSelectContact: (ContactCandidate) -> Unit = {},
    onSelectSim: (SimAccountOption) -> Unit = {},
    onDismissChoice: () -> Unit = {},
    onOpenAppSettings: () -> Unit = {},
    onCheckAssistantStatus: (AssistantId) -> Unit = {},
    onOpenDetailsSection: (String) -> Unit = {},
    onCloseDetailsSection: () -> Unit = {},
    onRetryLastCommand: () -> Unit = {}
) {
    var commandText by remember { mutableStateOf("") }
    var expandedSection by remember { mutableStateOf<ExpandableSection?>(null) }
    var viewMenuExpanded by remember { mutableStateOf(false) }
    var selectedVoiceSettingsId by remember { mutableStateOf(AssistantId.SK) }

    val drawerState = rememberDrawerState(initialValue = DrawerValue.Closed)
    val scope = rememberCoroutineScope()

    LaunchedEffect(state.requestedDetailsSection) {
        expandedSection = when (state.requestedDetailsSection?.uppercase()) {
            "APPROVALS" -> ExpandableSection.APPROVALS
            "SYSTEM" -> ExpandableSection.SYSTEM
            "ACTIVITY" -> ExpandableSection.ACTIVITY
            "DEVICE" -> ExpandableSection.DEVICE
            "HISTORY" -> ExpandableSection.HISTORY
            "DIAGNOSTICS" -> ExpandableSection.DIAGNOSTICS
            null -> null
            else -> expandedSection
        }
    }

    val activeProfile = OmegaIdentityCatalog.profiles.getValue(state.activeIdentity)
    val accentColor = Color(activeProfile.visualIdentity.primaryColorHex)
    val skState = state.assistantStates[AssistantId.SK]
    val skStatusLabel = skState?.status?.name ?: AssistantStatus.ONLINE.name
    val hasActiveTask = state.isRouting || state.isExecuting ||
        state.assistantStates.values.any { it.metrics.activeTaskCount > 0 }
    val showSkReactor = state.activeIdentity == AssistantId.SK ||
        state.interfaceMode == InterfaceMode.ASSEMBLED ||
        state.interfaceMode == InterfaceMode.PHOENIX

    val pulseTransition = rememberInfiniteTransition(label = "mic_pulse")
    val micScale by pulseTransition.animateFloat(
        initialValue = 1f,
        targetValue = if (state.isListening) 1.1f else 1f,
        animationSpec = infiniteRepeatable(tween(700), RepeatMode.Reverse),
        label = "mic_scale"
    )

    ModalNavigationDrawer(
        drawerState = drawerState,
        drawerContent = {
            ModalDrawerSheet(
                drawerContainerColor = DrawerBg,
                drawerContentColor = Color.White,
                modifier = Modifier.width(268.dp)
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(14.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Text(
                        text = "PROJECT OMEGA · AI CORES",
                        color = SkGold,
                        fontSize = 11.sp,
                        fontFamily = FontFamily.Monospace,
                        fontWeight = FontWeight.SemiBold,
                        modifier = Modifier.padding(horizontal = 6.dp, vertical = 4.dp)
                    )
                    HorizontalDivider(color = Hairline)

                    AssistantId.entries.forEach { id ->
                        val profile = OmegaIdentityCatalog.profiles.getValue(id)
                        val regState = state.assistantStates[id]
                        val enabled = regState?.isEnabled ?: true
                        val coreColor = if (enabled) Color(profile.visualIdentity.primaryColorHex) else Color(0xFF64748B)
                        val isSelected = state.activeIdentity == id
                        val isSpeaking = state.speakingAssistant == id

                        Surface(
                            color = if (isSelected) Color(0x18FFFFFF) else Color.Transparent,
                            border = BorderStroke(1.dp, if (isSelected) coreColor.copy(alpha = 0.65f) else Color.Transparent),
                            shape = RoundedCornerShape(10.dp),
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable {
                                    onSelectIdentity(id)
                                    scope.launch { drawerState.close() }
                                }
                        ) {
                            Row(
                                modifier = Modifier.padding(horizontal = 10.dp, vertical = 10.dp),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(10.dp)
                            ) {
                                MiniCoreEmblem(
                                    color = coreColor,
                                    active = isSelected,
                                    speaking = isSpeaking
                                )
                                Column(modifier = Modifier.weight(1f)) {
                                    Text(
                                        text = profile.displayName,
                                        color = Color.White,
                                        fontSize = 13.sp,
                                        fontWeight = FontWeight.SemiBold,
                                        maxLines = 1
                                    )
                                    Text(
                                        text = when {
                                            isSpeaking -> "SPEAKING"
                                            id == AssistantId.SK -> "MASTER · $skStatusLabel"
                                            else -> (regState?.status ?: AssistantStatus.STANDBY).name
                                        },
                                        color = coreColor,
                                        fontSize = 10.sp,
                                        fontFamily = FontFamily.Monospace
                                    )
                                }
                            }
                        }
                    }

                    Spacer(Modifier.weight(1f))
                    HorizontalDivider(color = Hairline)
                    Text(
                        text = "OPERATIONS",
                        color = Color(0xFF64748B),
                        fontSize = 10.sp,
                        fontFamily = FontFamily.Monospace,
                        modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                    )

                    ExpandableSection.entries.forEach { sec ->
                        val isOpen = expandedSection == sec
                        val countLabel = if (sec == ExpandableSection.APPROVALS && state.pendingProposals.isNotEmpty()) {
                            " (${state.pendingProposals.size})"
                        } else ""
                        TextButton(
                            onClick = {
                                if (isOpen) {
                                    expandedSection = null
                                    onCloseDetailsSection()
                                } else {
                                    expandedSection = sec
                                    onOpenDetailsSection(sec.name)
                                }
                                scope.launch { drawerState.close() }
                            },
                            modifier = Modifier.fillMaxWidth(),
                            contentPadding = PaddingValues(horizontal = 10.dp, vertical = 6.dp)
                        ) {
                            Text(
                                text = "${sec.label}$countLabel",
                                color = if (isOpen) SkGold else Color(0xFFCBD5E1),
                                fontSize = 13.sp,
                                modifier = Modifier.fillMaxWidth()
                            )
                        }
                    }
                }
            }
        }
    ) {
        Scaffold(containerColor = BlackMetallicBg) { padding ->
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(padding)
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(horizontal = 12.dp, vertical = 8.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                // Compact Top Bar (Essential SK Status Only)
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        modifier = Modifier.weight(1f)
                    ) {
                        IconButton(
                            onClick = { scope.launch { drawerState.open() } },
                            modifier = Modifier.size(44.dp)
                        ) {
                            Icon(Icons.Filled.Menu, contentDescription = "Open assistant menu", tint = SkGold)
                        }
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = if (state.activeIdentity == AssistantId.SK) "SK MASTER" else activeProfile.displayName,
                                color = Color.White,
                                fontSize = 15.sp,
                                fontWeight = FontWeight.SemiBold,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis
                            )
                            Text(
                                text = buildString {
                                    append("SK $skStatusLabel · ${state.interfaceMode.name}")
                                    append(" · Focus ${activeProfile.displayName}")
                                    if (hasActiveTask) append(" · ACTIVE")
                                },
                                color = Color(0xFF94A3B8),
                                fontSize = 10.sp,
                                fontFamily = FontFamily.Monospace,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis
                            )
                        }
                    }

                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        if (state.pendingProposals.isNotEmpty()) {
                            Surface(
                                color = SkGold,
                                shape = RoundedCornerShape(8.dp),
                                modifier = Modifier.clickable {
                                    expandedSection = ExpandableSection.APPROVALS
                                    onOpenDetailsSection(ExpandableSection.APPROVALS.name)
                                }
                            ) {
                                Text(
                                    text = "${state.pendingProposals.size} Pending",
                                    color = BlackMetallicBg,
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.SemiBold,
                                    modifier = Modifier.padding(horizontal = 8.dp, vertical = 5.dp)
                                )
                            }
                        }

                        Box {
                            Surface(
                                color = HudPanelBg,
                                border = BorderStroke(1.dp, Hairline),
                                shape = RoundedCornerShape(8.dp),
                                modifier = Modifier.clickable { viewMenuExpanded = true }
                            ) {
                                Row(
                                    modifier = Modifier.padding(horizontal = 9.dp, vertical = 5.dp),
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.spacedBy(2.dp)
                                ) {
                                    Text(
                                        text = "View",
                                        color = Color(0xFFE2E8F0),
                                        fontSize = 11.sp,
                                        fontWeight = FontWeight.Medium
                                    )
                                    Icon(
                                        imageVector = Icons.Filled.ArrowDropDown,
                                        contentDescription = "Open View menu",
                                        tint = SkGold,
                                        modifier = Modifier.size(16.dp)
                                    )
                                }
                            }
                            DropdownMenu(
                                expanded = viewMenuExpanded,
                                onDismissRequest = { viewMenuExpanded = false },
                                modifier = Modifier.background(DrawerBg)
                            ) {
                                val viewEntries = listOf(
                                    ExpandableSection.SYSTEM to "System & Mission Status",
                                    ExpandableSection.ACTIVITY to "Five Assistant Details",
                                    ExpandableSection.HISTORY to "Previous Command Results",
                                    ExpandableSection.DEVICE to "Device Telemetry & Info",
                                    ExpandableSection.APPROVALS to "Approval Center",
                                    ExpandableSection.DIAGNOSTICS to "Voice Settings & Audit Logs"
                                )
                                viewEntries.forEach { (sec, label) ->
                                    DropdownMenuItem(
                                        text = {
                                            val suffix = if (sec == ExpandableSection.APPROVALS && state.pendingProposals.isNotEmpty()) {
                                                " (${state.pendingProposals.size})"
                                            } else ""
                                            Text(
                                                text = "$label$suffix",
                                                color = if (expandedSection == sec) SkGold else Color(0xFFE2E8F0),
                                                fontSize = 12.sp
                                            )
                                        },
                                        onClick = {
                                            viewMenuExpanded = false
                                            expandedSection = sec
                                            onOpenDetailsSection(sec.name)
                                        }
                                    )
                                }
                            }
                        }

                        IconButton(
                            onClick = { onToggleVoice(!state.voiceEnabled) },
                            modifier = Modifier.size(40.dp)
                        ) {
                            Icon(
                                imageVector = if (state.voiceEnabled) Icons.Filled.VolumeUp else Icons.Filled.VolumeOff,
                                contentDescription = if (state.voiceEnabled) "Mute voice" else "Enable voice",
                                tint = if (state.voiceEnabled) SkGold else Color(0xFF64748B)
                            )
                        }
                    }
                }

                // Runtime Permission Prompt (Shown Only When Needed)
                if (state.missingPermissionsPrompt.isNotEmpty()) {
                    Surface(
                        color = Color(0x26F59E0B),
                        border = BorderStroke(1.dp, SkGold),
                        shape = RoundedCornerShape(10.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Row(
                            modifier = Modifier.padding(horizontal = 12.dp, vertical = 8.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = if (state.missingPermissionsPermanentlyDenied) {
                                    "Permission permanently denied: ${state.missingPermissionsPrompt.joinToString { it.substringAfterLast('.') }}"
                                } else {
                                    "Permission required: ${state.missingPermissionsPrompt.joinToString { it.substringAfterLast('.') }}"
                                },
                                color = Color(0xFFFDE68A),
                                fontSize = 11.sp,
                                modifier = Modifier.weight(1f)
                            )
                            TextButton(
                                onClick = {
                                    if (state.missingPermissionsPermanentlyDenied) onOpenAppSettings()
                                    else onRequestPermissions(state.missingPermissionsPrompt)
                                }
                            ) {
                                Text(if (state.missingPermissionsPermanentlyDenied) "Settings" else "Grant", color = SkGold, fontSize = 11.sp)
                            }
                        }
                    }
                }

                // Disambiguation Dialogs (Shown Only When Active)
                state.pendingContactChoice?.let { choice ->
                    Surface(
                        color = HudPanelBg,
                        border = BorderStroke(1.dp, SkGold),
                        shape = RoundedCornerShape(10.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column(modifier = Modifier.padding(10.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                            Text(
                                text = "SELECT CONTACT FOR \"${choice.queryName}\"",
                                color = SkGold,
                                fontSize = 11.sp,
                                fontFamily = FontFamily.Monospace
                            )
                            choice.candidates.forEach { cand ->
                                OutlinedButton(onClick = { onSelectContact(cand) }, modifier = Modifier.fillMaxWidth()) {
                                    Text("${cand.displayName} (${cand.label}) · ${cand.phoneNumber}", color = Color.White, fontSize = 12.sp)
                                }
                            }
                            TextButton(onClick = onDismissChoice) {
                                Text("Cancel", color = Color(0xFF94A3B8), fontSize = 11.sp)
                            }
                        }
                    }
                }

                state.pendingSimChoice?.let { simChoice ->
                    Surface(
                        color = HudPanelBg,
                        border = BorderStroke(1.dp, HoloCyan),
                        shape = RoundedCornerShape(10.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column(modifier = Modifier.padding(10.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                            Text(
                                text = "CHOOSE SIM FOR ${simChoice.candidate.displayName.uppercase()}",
                                color = HoloCyan,
                                fontSize = 11.sp,
                                fontFamily = FontFamily.Monospace
                            )
                            simChoice.simOptions.forEach { sim ->
                                OutlinedButton(onClick = { onSelectSim(sim) }, modifier = Modifier.fillMaxWidth()) {
                                    Text("SIM ${sim.slotIndex} · ${sim.displayName} (${sim.carrierName})", color = Color.White, fontSize = 12.sp)
                                }
                            }
                            TextButton(onClick = onDismissChoice) {
                                Text("Cancel", color = Color(0xFF94A3B8), fontSize = 11.sp)
                            }
                        }
                    }
                }

                // Error Recovery Banner with One-Tap Retry Command
                state.lastFailedCommand?.let {
                    Surface(
                        color = Color(0x26EF4444),
                        border = BorderStroke(1.dp, Color(0xFFEF4444)),
                        shape = RoundedCornerShape(10.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Row(
                            modifier = Modifier.padding(horizontal = 12.dp, vertical = 8.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = state.lastStatusBanner ?: "Command routing failed. Tap Retry to try again.",
                                color = Color(0xFFFEE2E2),
                                fontSize = 11.sp,
                                modifier = Modifier.weight(1f),
                                maxLines = 2,
                                overflow = TextOverflow.Ellipsis
                            )
                            TextButton(onClick = onRetryLastCommand, enabled = !state.isRouting) {
                                Text("Retry", color = SkGold, fontSize = 11.sp, fontWeight = FontWeight.SemiBold)
                            }
                        }
                    }
                }

                // Clean Centered Open Stage (Core Only + Mode Controls — Details in Side/View Overlay)
                Column(
                    modifier = Modifier.weight(1f),
                    verticalArrangement = Arrangement.Center,
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Row(
                        modifier = Modifier
                            .horizontalScroll(rememberScrollState())
                            .padding(bottom = 6.dp),
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        OutlinedButton(
                            onClick = onNormalMode,
                            contentPadding = PaddingValues(horizontal = 12.dp, vertical = 6.dp),
                            border = BorderStroke(1.dp, if (state.interfaceMode == InterfaceMode.NORMAL && state.activeIdentity == AssistantId.SK) SkOrange else Hairline)
                        ) {
                            Text("Normal", color = Color.White, fontSize = 11.sp)
                        }
                        OutlinedButton(
                            onClick = onPhoenixMode,
                            contentPadding = PaddingValues(horizontal = 12.dp, vertical = 6.dp),
                            border = BorderStroke(1.dp, if (state.interfaceMode == InterfaceMode.PHOENIX) SkGold else Hairline)
                        ) {
                            Text("Phoenix", color = SkGold, fontSize = 11.sp)
                        }
                        OutlinedButton(
                            onClick = if (state.interfaceMode == InterfaceMode.ASSEMBLED) onDisassembleAll else onAssembleAll,
                            contentPadding = PaddingValues(horizontal = 12.dp, vertical = 6.dp),
                            border = BorderStroke(1.dp, if (state.interfaceMode == InterfaceMode.ASSEMBLED) HoloCyan else Hairline)
                        ) {
                            Text(
                                text = if (state.interfaceMode == InterfaceMode.ASSEMBLED) "Disassemble" else "Assemble All",
                                color = HoloCyan,
                                fontSize = 11.sp
                            )
                        }
                    }

                    // Dominant Open-Space Floating Core
                    if (showSkReactor) {
                        SkMasterReactorCanvas(
                            interfaceMode = state.interfaceMode,
                            assemblyStage = state.assemblyStage,
                            activeIdentity = state.activeIdentity,
                            speakingAssistant = state.speakingAssistant,
                            voiceState = state.voiceState,
                            voiceRmsLevel = state.voiceRmsLevel,
                            animationQuality = state.animationQuality,
                            assistantStates = state.assistantStates,
                            isRouting = state.isRouting,
                            isExecuting = state.isExecuting,
                            onSelectCore = onSelectIdentity,
                            masterGreeting = state.masterGreeting
                        )
                    } else if (state.activeIdentity == AssistantId.MAGMITE) {
                        val activeState = state.assistantStates[AssistantId.MAGMITE]
                        val activeMetrics = activeState?.metrics
                        val hasNonIdleActivity = activeMetrics != null &&
                            (activeMetrics.activeTaskCount > 0 ||
                                activeMetrics.pendingTaskCount > 0 ||
                                activeMetrics.currentActivity != "Idle" ||
                                !activeMetrics.recentError.isNullOrBlank())

                        Column(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(vertical = 2.dp),
                            horizontalAlignment = Alignment.CenterHorizontally,
                            verticalArrangement = Arrangement.spacedBy(4.dp)
                        ) {
                            MagmiteFloatingCoreCanvas(
                                isEnabled = activeState?.isEnabled ?: true,
                                status = activeState?.status ?: AssistantStatus.ONLINE,
                                voiceState = state.voiceState,
                                voiceRmsLevel = state.voiceRmsLevel,
                                isSpeaking = state.speakingAssistant == AssistantId.MAGMITE,
                                isRouting = state.isRouting,
                                isExecuting = state.isExecuting,
                                hasPendingApproval = state.pendingProposals.any { it.targetAssistant == AssistantId.MAGMITE },
                                animationQuality = state.animationQuality
                            )

                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(horizontal = 4.dp),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(
                                    text = if (hasNonIdleActivity) {
                                        activeMetrics?.recentError ?: activeMetrics?.currentActivity.orEmpty()
                                    } else {
                                        "MAGMITE Core · ${(activeState?.status ?: AssistantStatus.ONLINE).name} · SK Supervised"
                                    },
                                    color = Color(0xFF94A3B8),
                                    fontSize = 11.sp,
                                    fontFamily = FontFamily.Monospace,
                                    maxLines = 1,
                                    overflow = TextOverflow.Ellipsis,
                                    modifier = Modifier.weight(1f)
                                )
                                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                                    TextButton(onClick = { onCheckAssistantStatus(AssistantId.MAGMITE) }) {
                                        Text("Status", color = accentColor, fontSize = 11.sp)
                                    }
                                    TextButton(onClick = { onSelectIdentity(AssistantId.SK) }) {
                                        Text("SK Master", color = SkGold, fontSize = 11.sp)
                                    }
                                }
                            }
                        }
                    } else {
                        val activeState = state.assistantStates[state.activeIdentity]
                        val activeMetrics = activeState?.metrics
                        val hasNonIdleActivity = activeMetrics != null &&
                            (activeMetrics.activeTaskCount > 0 ||
                                activeMetrics.pendingTaskCount > 0 ||
                                activeMetrics.currentActivity != "Idle" ||
                                !activeMetrics.recentError.isNullOrBlank())

                        Column(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(vertical = 2.dp),
                            horizontalAlignment = Alignment.CenterHorizontally,
                            verticalArrangement = Arrangement.spacedBy(4.dp)
                        ) {
                            HolographicCoreCanvas(
                                activeAssistant = state.activeIdentity,
                                isEnabled = activeState?.isEnabled ?: true,
                                status = activeState?.status ?: AssistantStatus.ONLINE,
                                voiceState = state.voiceState,
                                voiceRmsLevel = state.voiceRmsLevel,
                                isSpeaking = state.speakingAssistant == state.activeIdentity,
                                isRouting = state.isRouting,
                                isExecuting = state.isExecuting,
                                hasPendingApproval = state.pendingProposals.any { it.targetAssistant == state.activeIdentity },
                                animationQuality = state.animationQuality
                            )

                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(horizontal = 4.dp),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(
                                    text = if (hasNonIdleActivity) {
                                        activeMetrics?.recentError ?: activeMetrics?.currentActivity.orEmpty()
                                    } else {
                                        "${activeProfile.displayName} Core · ${(activeState?.status ?: AssistantStatus.ONLINE).name} · SK Supervised"
                                    },
                                    color = Color(0xFF94A3B8),
                                    fontSize = 11.sp,
                                    fontFamily = FontFamily.Monospace,
                                    maxLines = 1,
                                    overflow = TextOverflow.Ellipsis,
                                    modifier = Modifier.weight(1f)
                                )
                                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                                    TextButton(onClick = { onCheckAssistantStatus(state.activeIdentity) }) {
                                        Text("Status", color = accentColor, fontSize = 11.sp)
                                    }
                                    TextButton(onClick = { onSelectIdentity(AssistantId.SK) }) {
                                        Text("SK Master", color = SkGold, fontSize = 11.sp)
                                    }
                                }
                            }
                        }
                    }
                }

                // Inline Floating Approval Prompt (Shown ONLY for Important / Critical tasks)
                state.pendingProposals.firstOrNull()?.let { pendingProposal ->
                    ProposalApprovalCard(
                        proposal = pendingProposal,
                        onApprove = { onApproveProposal(pendingProposal) },
                        onReject = { onRejectProposal(pendingProposal.proposalId) }
                    )
                }

                // Compact Voice & Text Command Bar (Thumb-Reachable Footer)
                Surface(
                    color = HudPanelBg,
                    border = BorderStroke(
                        1.dp,
                        when {
                            state.isListening -> HoloCyan
                            state.voiceState == VoiceState.ERROR || state.voiceState == VoiceState.PERMISSION_REQUIRED -> Color(0xFFEF4444)
                            else -> Hairline
                        }
                    ),
                    shape = RoundedCornerShape(14.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(
                        modifier = Modifier.padding(8.dp),
                        verticalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            Surface(
                                color = if (state.isListening) HoloCyan else SkOrange,
                                shape = CircleShape,
                                modifier = Modifier
                                    .size(46.dp)
                                    .scale(micScale)
                                    .clickable { onToggleListening() }
                            ) {
                                Box(contentAlignment = Alignment.Center) {
                                    Icon(
                                        imageVector = if (state.isListening) Icons.Filled.Stop else Icons.Filled.Mic,
                                        contentDescription = if (state.isListening) "Stop listening" else "Start microphone",
                                        tint = BlackMetallicBg
                                    )
                                }
                            }

                            OutlinedTextField(
                                value = commandText,
                                onValueChange = { commandText = it },
                                placeholder = { Text("Type a command...", fontSize = 13.sp) },
                                modifier = Modifier.weight(1f),
                                singleLine = true
                            )

                            Button(
                                onClick = {
                                    onSubmitCommand(commandText)
                                    commandText = ""
                                },
                                enabled = !state.isRouting && commandText.isNotBlank(),
                                contentPadding = PaddingValues(horizontal = 12.dp, vertical = 10.dp),
                                colors = ButtonDefaults.buttonColors(
                                    containerColor = SkGold,
                                    contentColor = BlackMetallicBg
                                ),
                                modifier = Modifier.height(48.dp)
                            ) {
                                Icon(Icons.Filled.Send, contentDescription = "Send command", modifier = Modifier.size(16.dp))
                            }
                        }

                        // Small Mic Status Indicator + Minimal Audio Waveform + Recognized Text
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(horizontal = 4.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(8.dp)
                            ) {
                                Text(
                                    text = state.voiceState.hudLabel,
                                    color = when (state.voiceState) {
                                        VoiceState.LISTENING -> HoloCyan
                                        VoiceState.SPEAKING -> SkGold
                                        VoiceState.ERROR, VoiceState.PERMISSION_REQUIRED -> Color(0xFFFCA5A5)
                                        else -> Color(0xFF94A3B8)
                                    },
                                    fontSize = 10.sp,
                                    fontFamily = FontFamily.Monospace
                                )

                                if (state.isListening || state.voiceState == VoiceState.SPEAKING) {
                                    MinimalAudioWaveform(
                                        rmsLevel = state.voiceRmsLevel,
                                        color = if (state.isListening) HoloCyan else SkGold
                                    )
                                }

                                if (state.speakingAssistant != null) {
                                    Text(
                                        text = "STOP",
                                        color = Color(0xFFFCA5A5),
                                        fontSize = 10.sp,
                                        fontFamily = FontFamily.Monospace,
                                        modifier = Modifier.clickable { onStopSpeaking() }
                                    )
                                }
                            }

                            val spokenPreview = when {
                                state.isListening && state.speechPartialText.isNotBlank() -> state.speechPartialText
                                state.recognizedCommand.isNotBlank() -> "\"${state.recognizedCommand}\""
                                else -> null
                            }
                            if (spokenPreview != null) {
                                Text(
                                    text = spokenPreview,
                                    color = Color(0xFFCBD5E1),
                                    fontSize = 10.sp,
                                    fontFamily = FontFamily.Monospace,
                                    maxLines = 1,
                                    overflow = TextOverflow.Ellipsis
                                )
                            }
                        }

                        AnimatedVisibility(visible = !state.speechError.isNullOrBlank() || state.micPermanentlyDenied) {
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(horizontal = 4.dp),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(
                                    text = state.speechError ?: "Microphone permission required in App Settings.",
                                    color = Color(0xFFFCA5A5),
                                    fontSize = 10.sp,
                                    fontFamily = FontFamily.Monospace,
                                    modifier = Modifier.weight(1f)
                                )
                                if (state.micPermanentlyDenied) {
                                    TextButton(onClick = onOpenAppSettings) {
                                        Text("Settings", color = SkGold, fontSize = 10.sp)
                                    }
                                }
                            }
                        }
                    }
                }
            }

            // Controlled Details Modal Overlay (Opened Only via Side Drawer, View Menu, or Voice Commands)
            expandedSection?.let { activeSec ->
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .background(Color(0xCC030407))
                        .clickable {
                            expandedSection = null
                            onCloseDetailsSection()
                        }
                        .padding(14.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Surface(
                        color = DrawerBg,
                        border = BorderStroke(1.dp, Hairline),
                        shape = RoundedCornerShape(16.dp),
                        modifier = Modifier
                            .fillMaxWidth()
                            .fillMaxHeight(0.86f)
                            .clickable(enabled = false) {}
                    ) {
                        Column(
                            modifier = Modifier
                                .fillMaxSize()
                                .padding(12.dp),
                            verticalArrangement = Arrangement.spacedBy(10.dp)
                        ) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Row(
                                    modifier = Modifier
                                        .weight(1f)
                                        .horizontalScroll(rememberScrollState()),
                                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                                ) {
                                    ExpandableSection.entries.forEach { sec ->
                                        val isOpen = activeSec == sec
                                        val suffix = if (sec == ExpandableSection.APPROVALS && state.pendingProposals.isNotEmpty()) {
                                            " (${state.pendingProposals.size})"
                                        } else ""
                                        Surface(
                                            color = if (isOpen) SkOrange.copy(alpha = 0.2f) else HudPanelBg,
                                            border = BorderStroke(
                                                1.dp,
                                                if (isOpen) SkOrange else if (sec == ExpandableSection.APPROVALS && state.pendingProposals.isNotEmpty()) SkGold else Hairline
                                            ),
                                            shape = RoundedCornerShape(8.dp),
                                            modifier = Modifier.clickable {
                                                expandedSection = sec
                                                onOpenDetailsSection(sec.name)
                                            }
                                        ) {
                                            Text(
                                                text = "${sec.label}$suffix",
                                                color = if (isOpen) SkGold else Color(0xFFCBD5E1),
                                                fontSize = 11.sp,
                                                fontFamily = FontFamily.Monospace,
                                                modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp)
                                            )
                                        }
                                    }
                                }
                                IconButton(
                                    onClick = {
                                        expandedSection = null
                                        onCloseDetailsSection()
                                    },
                                    modifier = Modifier.size(36.dp)
                                ) {
                                    Icon(Icons.Filled.Close, contentDescription = "Close details", tint = Color(0xFFCBD5E1))
                                }
                            }

                            HorizontalDivider(color = Hairline)

                            LazyColumn(
                                modifier = Modifier.weight(1f),
                                verticalArrangement = Arrangement.spacedBy(8.dp)
                            ) {
                                if (activeSec == ExpandableSection.APPROVALS) {
                                    if (state.pendingProposals.isEmpty()) {
                                        item {
                                            Text(
                                                text = "No pending task proposals awaiting approval.",
                                                color = Color(0xFF94A3B8),
                                                fontSize = 12.sp,
                                                modifier = Modifier.padding(4.dp)
                                            )
                                        }
                                    } else {
                                        items(state.pendingProposals, key = { it.proposalId }) { proposal ->
                                            ProposalApprovalCard(
                                                proposal = proposal,
                                                onApprove = { onApproveProposal(proposal) },
                                                onReject = { onRejectProposal(proposal.proposalId) }
                                            )
                                        }
                                    }
                                }

                                if (activeSec == ExpandableSection.SYSTEM) {
                                    item {
                                        Surface(
                                            color = HudPanelBg,
                                            border = BorderStroke(1.dp, Hairline),
                                            shape = RoundedCornerShape(10.dp),
                                            modifier = Modifier.fillMaxWidth()
                                        ) {
                                            Column(modifier = Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                                                Text("MISSION & RUNTIME STATUS", color = SkGold, fontSize = 11.sp, fontFamily = FontFamily.Monospace)
                                                Text("Mode: ${state.interfaceMode.name} · Focus: ${activeProfile.displayName}", color = Color.White, fontSize = 12.sp)
                                                Text("Voice State: ${state.voiceState.hudLabel} · Provider: ${state.voiceProviderMode.label}", color = Color(0xFFCBD5E1), fontSize = 11.sp, fontFamily = FontFamily.Monospace)
                                                if (!state.lastStatusBanner.isNullOrBlank()) {
                                                    Text("Latest Output: ${state.lastStatusBanner}", color = SkHighlight, fontSize = 11.sp)
                                                }
                                            }
                                        }
                                    }
                                }

                                if (activeSec == ExpandableSection.SYSTEM || activeSec == ExpandableSection.ACTIVITY) {
                                    items(AssistantId.entries) { id ->
                                        val profile = OmegaIdentityCatalog.profiles.getValue(id)
                                        val regState = state.assistantStates[id]
                                        val metrics = regState?.metrics
                                        Surface(
                                            color = HudPanelBg,
                                            border = BorderStroke(1.dp, Hairline),
                                            shape = RoundedCornerShape(10.dp),
                                            modifier = Modifier.fillMaxWidth()
                                        ) {
                                            Column(modifier = Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                                                Row(
                                                    horizontalArrangement = Arrangement.SpaceBetween,
                                                    verticalAlignment = Alignment.CenterVertically,
                                                    modifier = Modifier.fillMaxWidth()
                                                ) {
                                                    Column(modifier = Modifier.weight(1f)) {
                                                        Text(
                                                            text = "${profile.displayName} · ${profile.roleTitle}",
                                                            color = Color.White,
                                                            fontSize = 13.sp,
                                                            fontWeight = FontWeight.SemiBold
                                                        )
                                                        Text(
                                                            text = (regState?.status ?: AssistantStatus.ONLINE).name,
                                                            color = Color(profile.visualIdentity.primaryColorHex),
                                                            fontSize = 10.sp,
                                                            fontFamily = FontFamily.Monospace
                                                        )
                                                    }
                                                    if (activeSec == ExpandableSection.SYSTEM && !profile.isMasterController) {
                                                        Switch(
                                                            checked = regState?.isEnabled ?: true,
                                                            onCheckedChange = { onToggleAssistant(id, it) }
                                                        )
                                                    } else {
                                                        TextButton(onClick = { onCheckAssistantStatus(id) }) {
                                                            Text("Report", color = SkGold, fontSize = 11.sp, fontFamily = FontFamily.Monospace)
                                                        }
                                                    }
                                                }
                                                if (activeSec == ExpandableSection.ACTIVITY && metrics != null) {
                                                    val latency = metrics.lastResponseMs?.let { "$it ms" } ?: "Not available"
                                                    Text(
                                                        text = "${metrics.currentActivity} · Active ${metrics.activeTaskCount} · Done ${metrics.completedTaskCount} · Pending ${metrics.pendingTaskCount} · $latency",
                                                        color = Color(0xFFCBD5E1),
                                                        fontSize = 11.sp,
                                                        fontFamily = FontFamily.Monospace
                                                    )
                                                    metrics.recentError?.let { err ->
                                                        Text("Error: $err", color = Color(0xFFFCA5A5), fontSize = 11.sp, fontFamily = FontFamily.Monospace)
                                                    }
                                                }
                                            }
                                        }
                                    }
                                }

                                if (activeSec == ExpandableSection.DEVICE) {
                                    item {
                                        Surface(
                                            color = HudPanelBg,
                                            border = BorderStroke(1.dp, Hairline),
                                            shape = RoundedCornerShape(10.dp),
                                            modifier = Modifier.fillMaxWidth()
                                        ) {
                                            Column(modifier = Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                                                Text("ANDROID DEVICE TELEMETRY", color = SkGold, fontSize = 11.sp, fontFamily = FontFamily.Monospace)
                                                Text("Animation Pipeline: ${state.animationQuality.label}", color = Color(0xFFCBD5E1), fontSize = 12.sp)
                                                Text("Voice Engine: ${state.voiceProviderMode.label} (${if (state.voiceEnabled) "Enabled" else "Muted"})", color = Color(0xFFCBD5E1), fontSize = 12.sp)
                                                Text("Pending Permission Prompts: ${if (state.missingPermissionsPrompt.isEmpty()) "None" else state.missingPermissionsPrompt.joinToString { it.substringAfterLast('.') }}", color = Color(0xFF94A3B8), fontSize = 11.sp, fontFamily = FontFamily.Monospace)
                                                Text("Scheduled Reminders: ${state.reminders.size}", color = Color(0xFF94A3B8), fontSize = 11.sp, fontFamily = FontFamily.Monospace)
                                            }
                                        }
                                    }
                                    items(state.reminders, key = { it.id }) { rem ->
                                        Surface(
                                            color = HudPanelBg,
                                            border = BorderStroke(1.dp, Hairline),
                                            shape = RoundedCornerShape(8.dp),
                                            modifier = Modifier.fillMaxWidth()
                                        ) {
                                            Row(
                                                modifier = Modifier.padding(10.dp),
                                                horizontalArrangement = Arrangement.SpaceBetween
                                            ) {
                                                Text(rem.title, color = Color.White, fontSize = 12.sp, modifier = Modifier.weight(1f))
                                                Text(
                                                    text = if (rem.completed) "DONE" else "ACTIVE",
                                                    color = if (rem.completed) Color(0xFF64748B) else HoloCyan,
                                                    fontSize = 10.sp,
                                                    fontFamily = FontFamily.Monospace
                                                )
                                            }
                                        }
                                    }
                                }

                                if (activeSec == ExpandableSection.HISTORY) {
                                    item {
                                        Text("PREVIOUS COMMAND RESULTS & REPLIES", color = HoloCyan, fontSize = 11.sp, fontFamily = FontFamily.Monospace)
                                    }
                                    if (state.commandResultsHistory.isEmpty()) {
                                        item {
                                            Text("No command replies recorded in this session yet.", color = Color(0xFF94A3B8), fontSize = 12.sp)
                                        }
                                    } else {
                                        items(state.commandResultsHistory.take(15)) { entryText ->
                                            Surface(
                                                color = HudPanelBg,
                                                border = BorderStroke(1.dp, Hairline),
                                                shape = RoundedCornerShape(8.dp),
                                                modifier = Modifier.fillMaxWidth()
                                            ) {
                                                Text(entryText, color = Color(0xFFE2E8F0), fontSize = 12.sp, modifier = Modifier.padding(10.dp))
                                            }
                                        }
                                    }

                                    item {
                                        Spacer(Modifier.height(4.dp))
                                        Text("DELEGATED TASK HISTORY", color = SkGold, fontSize = 11.sp, fontFamily = FontFamily.Monospace)
                                    }
                                    if (state.taskHistory.isEmpty()) {
                                        item {
                                            Text("No delegated task history yet.", color = Color(0xFF94A3B8), fontSize = 12.sp)
                                        }
                                    } else {
                                        items(state.taskHistory.take(15), key = { it.proposalId }) { item ->
                                            Surface(
                                                color = HudPanelBg,
                                                border = BorderStroke(1.dp, Hairline),
                                                shape = RoundedCornerShape(10.dp),
                                                modifier = Modifier.fillMaxWidth()
                                            ) {
                                                Column(modifier = Modifier.padding(10.dp)) {
                                                    Text(
                                                        text = "${item.targetAssistant} · ${item.exactOperation} · ${item.status}",
                                                        color = SkGold,
                                                        fontSize = 11.sp,
                                                        fontFamily = FontFamily.Monospace
                                                    )
                                                    Spacer(Modifier.height(2.dp))
                                                    Text(item.resultSummary, color = Color(0xFFE2E8F0), fontSize = 12.sp)
                                                }
                                            }
                                        }
                                    }
                                }

                                if (activeSec == ExpandableSection.DIAGNOSTICS) {
                                    val selectedVoiceCfg = state.voiceConfigs[selectedVoiceSettingsId]
                                        ?: OmegaIdentityCatalog.profiles.getValue(selectedVoiceSettingsId).voiceConfig
                                    val selectedProfile = OmegaIdentityCatalog.profiles.getValue(selectedVoiceSettingsId)

                                    item {
                                        Surface(
                                            color = HudPanelBg,
                                            border = BorderStroke(1.dp, Hairline),
                                            shape = RoundedCornerShape(10.dp),
                                            modifier = Modifier.fillMaxWidth()
                                        ) {
                                            Column(modifier = Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                                                Text("Voice Provider & Calibration", color = SkGold, fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
                                                Row(
                                                    modifier = Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()),
                                                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                                                ) {
                                                    VoiceProviderMode.entries.forEach { mode ->
                                                        OutlinedButton(
                                                            onClick = { onSelectVoiceProvider(mode) },
                                                            border = BorderStroke(1.dp, if (state.voiceProviderMode == mode) SkOrange else Hairline)
                                                        ) {
                                                            Text(mode.label, color = Color.White, fontSize = 11.sp)
                                                        }
                                                    }
                                                }

                                                Row(
                                                    modifier = Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()),
                                                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                                                ) {
                                                    AssistantId.entries.forEach { id ->
                                                        val p = OmegaIdentityCatalog.profiles.getValue(id)
                                                        val selected = selectedVoiceSettingsId == id
                                                        OutlinedButton(
                                                            onClick = { selectedVoiceSettingsId = id },
                                                            border = BorderStroke(1.dp, if (selected) Color(p.visualIdentity.primaryColorHex) else Hairline)
                                                        ) {
                                                            Text(p.displayName, color = Color.White, fontSize = 11.sp)
                                                        }
                                                    }
                                                }

                                                Text(
                                                    text = "${selectedProfile.displayName} · ${selectedVoiceCfg.neuralVoiceName} · Pitch ${"%.2f".format(selectedVoiceCfg.pitch)} · ${"%.2f".format(selectedVoiceCfg.speechRate)}x",
                                                    color = Color(0xFFCBD5E1),
                                                    fontSize = 11.sp,
                                                    fontFamily = FontFamily.Monospace
                                                )
                                                Slider(
                                                    value = selectedVoiceCfg.pitch,
                                                    onValueChange = { onUpdateVoiceTuning(selectedVoiceSettingsId, it, selectedVoiceCfg.speechRate) },
                                                    valueRange = 0.5f..1.5f,
                                                    colors = SliderDefaults.colors(thumbColor = SkOrange, activeTrackColor = SkOrange)
                                                )
                                                Slider(
                                                    value = selectedVoiceCfg.speechRate,
                                                    onValueChange = { onUpdateVoiceTuning(selectedVoiceSettingsId, selectedVoiceCfg.pitch, it) },
                                                    valueRange = 0.6f..1.5f,
                                                    colors = SliderDefaults.colors(thumbColor = SkGold, activeTrackColor = SkGold)
                                                )
                                                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                                    Button(
                                                        onClick = { onPreviewVoice(selectedVoiceSettingsId) },
                                                        colors = ButtonDefaults.buttonColors(containerColor = SkOrange, contentColor = BlackMetallicBg),
                                                        modifier = Modifier.weight(1f)
                                                    ) {
                                                        Icon(Icons.Filled.PlayArrow, contentDescription = null, modifier = Modifier.size(16.dp))
                                                        Spacer(Modifier.width(4.dp))
                                                        Text("Preview", fontSize = 12.sp)
                                                    }
                                                    OutlinedButton(
                                                        onClick = onGenerateReport,
                                                        modifier = Modifier.weight(1f)
                                                    ) {
                                                        Text("System Report", color = Color.White, fontSize = 12.sp)
                                                    }
                                                }

                                                Row(
                                                    modifier = Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()),
                                                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                                                ) {
                                                    AnimationQuality.entries.forEach { q ->
                                                        OutlinedButton(
                                                            onClick = { onSelectAnimationQuality(q) },
                                                            border = BorderStroke(1.dp, if (state.animationQuality == q) SkOrange else Hairline)
                                                        ) {
                                                            Text(q.label, color = Color.White, fontSize = 10.sp)
                                                        }
                                                    }
                                                }
                                            }
                                        }
                                    }

                                    items(state.alerts.filter { !it.acknowledged }, key = { it.alertId }) { alert ->
                                        Surface(
                                            color = Color(0x26EF4444),
                                            border = BorderStroke(1.dp, Color(0xFFEF4444)),
                                            shape = RoundedCornerShape(10.dp),
                                            modifier = Modifier.fillMaxWidth()
                                        ) {
                                            Row(
                                                modifier = Modifier.padding(10.dp),
                                                horizontalArrangement = Arrangement.SpaceBetween,
                                                verticalAlignment = Alignment.CenterVertically
                                            ) {
                                                Column(modifier = Modifier.weight(1f)) {
                                                    Text("${alert.severity} · ${alert.title}", color = Color(0xFFFCA5A5), fontSize = 11.sp, fontWeight = FontWeight.SemiBold)
                                                    Text(alert.message, color = Color(0xFFFEE2E2), fontSize = 11.sp)
                                                }
                                                TextButton(onClick = { onAcknowledgeAlert(alert.alertId) }) {
                                                    Text("Dismiss", color = Color(0xFFFCA5A5), fontSize = 11.sp)
                                                }
                                            }
                                        }
                                    }

                                    items(state.reports.take(5), key = { it.reportId }) { report ->
                                        Surface(
                                            color = HudPanelBg,
                                            border = BorderStroke(1.dp, Hairline),
                                            shape = RoundedCornerShape(10.dp),
                                            modifier = Modifier.fillMaxWidth()
                                        ) {
                                            Column(modifier = Modifier.padding(10.dp)) {
                                                Text(
                                                    text = "${report.periodLabel} · ${report.approvedTasks}/${report.totalCommands} approved",
                                                    color = SkGold,
                                                    fontSize = 10.sp,
                                                    fontFamily = FontFamily.Monospace
                                                )
                                                Text(report.narrativeSummary, color = Color(0xFFE2E8F0), fontSize = 12.sp)
                                            }
                                        }
                                    }

                                    items(state.auditLogs.take(10), key = { it.id }) { log ->
                                        Column(
                                            modifier = Modifier
                                                .fillMaxWidth()
                                                .background(HudPanelBg, RoundedCornerShape(8.dp))
                                                .padding(10.dp)
                                        ) {
                                            Text(
                                                text = "${log.eventType} · ${log.actor} · #${log.entryHash.take(12)}",
                                                color = SkOrange,
                                                fontSize = 10.sp,
                                                fontFamily = FontFamily.Monospace
                                            )
                                            Text(log.summary, color = Color(0xFFCBD5E1), fontSize = 11.sp)
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
            }
        }
    }
}

@Composable
private fun MiniCoreEmblem(
    color: Color,
    active: Boolean,
    speaking: Boolean
) {
    Canvas(modifier = Modifier.size(30.dp)) {
        val center = this.center
        val r = size.minDimension * 0.44f
        drawCircle(
            color = color.copy(alpha = if (active) 0.95f else 0.45f),
            radius = r,
            center = center,
            style = Stroke(width = if (active) 2.dp.toPx() else 1.3.dp.toPx())
        )
        drawCircle(
            color = color.copy(alpha = if (speaking) 0.95f else 0.55f),
            radius = r * 0.68f,
            center = center,
            style = Stroke(
                width = 1.2.dp.toPx(),
                pathEffect = PathEffect.dashPathEffect(floatArrayOf(6f, 4f))
            )
        )
        drawCircle(
            color = color.copy(alpha = if (active || speaking) 0.95f else 0.65f),
            radius = r * (if (speaking) 0.34f else 0.25f),
            center = center
        )
    }
}

@Composable
private fun MinimalAudioWaveform(
    rmsLevel: Float,
    color: Color
) {
    val factors = listOf(0.45f, 0.85f, 1.0f, 0.7f, 0.5f)
    Row(
        horizontalArrangement = Arrangement.spacedBy(2.dp),
        verticalAlignment = Alignment.CenterVertically,
        modifier = Modifier.height(14.dp)
    ) {
        factors.forEachIndexed { idx, factor ->
            val level = (0.25f + rmsLevel * 0.9f + 0.15f * abs(sin(idx.toFloat()))).coerceIn(0.2f, 1f)
            Box(
                modifier = Modifier
                    .width(2.5.dp)
                    .height((12f * level * factor).dp.coerceAtLeast(3.dp))
                    .background(color, RoundedCornerShape(2.dp))
            )
        }
    }
}

@Composable
private fun ProposalApprovalCard(
    proposal: TaskProposal,
    onApprove: () -> Unit,
    onReject: () -> Unit
) {
    val profile = OmegaIdentityCatalog.profiles.getValue(proposal.targetAssistant)
    val accent = if (proposal.isCriticalRisk) Color(0xFFEF4444) else Color(profile.visualIdentity.primaryColorHex)
    var criticalConfirmed by remember(proposal.proposalId) { mutableStateOf(false) }

    Surface(
        color = HudPanelBg,
        border = BorderStroke(1.dp, accent),
        shape = RoundedCornerShape(12.dp),
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
            Text(
                text = "EXPLICIT APPROVAL REQUIRED · ${profile.displayName} · RISK ${proposal.riskLevel.name}",
                color = accent,
                fontSize = 11.sp,
                fontWeight = FontWeight.SemiBold,
                fontFamily = FontFamily.Monospace
            )
            Text(proposal.actionSummary, color = Color.White, fontSize = 14.sp, fontWeight = FontWeight.Medium)
            Text(
                text = "Operation: ${proposal.exactOperation} · Params: ${proposal.parameters}",
                color = Color(0xFFCBD5E1),
                fontSize = 12.sp,
                fontFamily = FontFamily.Monospace
            )
            if (proposal.requiredPermissions.isNotEmpty()) {
                Text(
                    text = "Permissions: ${proposal.requiredPermissions.joinToString()}",
                    color = SkGold,
                    fontSize = 11.sp,
                    fontFamily = FontFamily.Monospace
                )
            }
            Text(
                text = "Task Hash: ${proposal.payloadHash.take(20)}...",
                color = Color(0xFF64748B),
                fontSize = 11.sp,
                fontFamily = FontFamily.Monospace
            )
            if (proposal.isCriticalRisk) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(Color(0x26EF4444), RoundedCornerShape(8.dp))
                        .clickable { criticalConfirmed = !criticalConfirmed }
                        .padding(horizontal = 8.dp, vertical = 4.dp)
                ) {
                    Checkbox(
                        checked = criticalConfirmed,
                        onCheckedChange = { criticalConfirmed = it },
                        colors = CheckboxDefaults.colors(checkedColor = Color(0xFFEF4444))
                    )
                    Text(
                        text = "Strong Confirmation: I verified all parameters and authorize this CRITICAL action.",
                        color = Color(0xFFFEE2E2),
                        fontSize = 11.sp
                    )
                }
            }
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp), modifier = Modifier.padding(top = 4.dp)) {
                Button(
                    onClick = onApprove,
                    enabled = !proposal.isCriticalRisk || criticalConfirmed,
                    colors = ButtonDefaults.buttonColors(containerColor = accent, contentColor = BlackMetallicBg),
                    modifier = Modifier.weight(1f)
                ) {
                    Text(if (proposal.isCriticalRisk) "Confirm Critical Action" else "Approve & Execute")
                }
                OutlinedButton(onClick = onReject, modifier = Modifier.weight(1f)) {
                    Text("Reject", color = Color(0xFFE2E8F0))
                }
            }
        }
    }
}
