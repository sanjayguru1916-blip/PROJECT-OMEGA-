package com.projectomega.sk.ui.holographic

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.setValue
import androidx.compose.runtime.withFrameNanos
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.PathEffect
import androidx.compose.ui.graphics.Shadow
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.clipPath
import androidx.compose.ui.graphics.drawscope.rotate
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.projectomega.sk.core.model.AnimationQuality
import com.projectomega.sk.core.model.AssistantId
import com.projectomega.sk.core.model.AssistantStatus
import com.projectomega.sk.core.model.OmegaIdentityCatalog
import com.projectomega.sk.core.model.VoiceState
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlin.math.PI
import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.max
import kotlin.math.sin
import kotlin.math.sqrt

enum class MagmiteCoreVisualState {
    IDLE,
    LISTENING,
    THINKING,
    SPEAKING,
    ACTIVATING,
    OFFLINE
}

private data class MagmiteFloatingParticle(
    val angle: Float,
    val orbitRadiusFactor: Float,
    val speed: Float,
    val verticalPhase: Float,
    val verticalAmpFactor: Float,
    val tilt: Float,
    val sizeDp: Float,
    val baseAlpha: Float
)

private data class MagmiteOrbitRingConfig(
    val rxFactor: Float,
    val ryFactor: Float,
    val baseTiltDeg: Float,
    val rotSpeed: Float,
    val useGold: Boolean,
    val useAcousticTintWhenListening: Boolean,
    val strokeDp: Float,
    val dashIntervals: FloatArray?
)

private fun buildMagmiteParticlePool(count: Int): List<MagmiteFloatingParticle> {
    return List(count) { i ->
        val seed = ((i * 1.61803398875) % 1.0).toFloat()
        val seed2 = ((i * 2.718281828) % 1.0).toFloat()
        MagmiteFloatingParticle(
            angle = ((i.toFloat() / count) * (2.0 * PI) + seed * 0.5).toFloat(),
            orbitRadiusFactor = 0.42f + seed * 0.54f,
            speed = (if (i % 2 == 0) 1f else -1f) * (0.28f + seed2 * 0.52f),
            verticalPhase = i * 0.85f,
            verticalAmpFactor = 0.025f + seed * 0.048f,
            tilt = (seed2 - 0.5f) * 0.9f,
            sizeDp = 1.2f + seed * 2.1f,
            baseAlpha = 0.28f + seed2 * 0.55f
        )
    }
}

/**
 * Dedicated Borderless Open-Space Floating Holographic Core for MAGMITE.
 * Renders directly in open layout space with transparent canvas edges, 3D depth rings,
 * floating particles, orbital nodes with plasma trails, and 6 distinct operational states.
 */
@Composable
fun MagmiteFloatingCoreCanvas(
    isEnabled: Boolean,
    status: AssistantStatus,
    voiceState: VoiceState,
    voiceRmsLevel: Float,
    isSpeaking: Boolean,
    isRouting: Boolean,
    isExecuting: Boolean,
    hasPendingApproval: Boolean,
    animationQuality: AnimationQuality,
    modifier: Modifier = Modifier
) {
    val magmiteProfile = remember { OmegaIdentityCatalog.profiles.getValue(AssistantId.MAGMITE) }
    val particles = remember { buildMagmiteParticlePool(30) }
    val orbitRings = remember {
        listOf(
            MagmiteOrbitRingConfig(
                rxFactor = 1.08f,
                ryFactor = 0.42f,
                baseTiltDeg = 25f,
                rotSpeed = 0.72f,
                useGold = false,
                useAcousticTintWhenListening = false,
                strokeDp = 1.5f,
                dashIntervals = floatArrayOf(14f, 9f)
            ),
            MagmiteOrbitRingConfig(
                rxFactor = 0.96f,
                ryFactor = 0.38f,
                baseTiltDeg = -35f,
                rotSpeed = -0.95f,
                useGold = true,
                useAcousticTintWhenListening = false,
                strokeDp = 1.35f,
                dashIntervals = floatArrayOf(8f, 8f)
            ),
            MagmiteOrbitRingConfig(
                rxFactor = 0.84f,
                ryFactor = 0.32f,
                baseTiltDeg = 68f,
                rotSpeed = 1.15f,
                useGold = false,
                useAcousticTintWhenListening = true,
                strokeDp = 1.2f,
                dashIntervals = null
            )
        )
    }

    var activating by remember { mutableStateOf(true) }
    var activationProgress by remember { mutableFloatStateOf(0f) }

    LaunchedEffect(Unit) {
        val durationNs = 1_350_000_000L
        var startNs = 0L
        while (isActive && activating) {
            withFrameNanos { frameNanos ->
                if (startNs == 0L) startNs = frameNanos
                val progress = ((frameNanos - startNs).toFloat() / durationNs.toFloat()).coerceIn(0f, 1f)
                activationProgress = progress
                if (progress >= 1f) {
                    activating = false
                }
            }
        }
    }

    val visualState = when {
        !isEnabled || status == AssistantStatus.DISABLED -> MagmiteCoreVisualState.OFFLINE
        activating -> MagmiteCoreVisualState.ACTIVATING
        isSpeaking || voiceState == VoiceState.SPEAKING -> MagmiteCoreVisualState.SPEAKING
        voiceState == VoiceState.LISTENING -> MagmiteCoreVisualState.LISTENING
        isRouting || isExecuting || voiceState == VoiceState.PROCESSING || voiceState == VoiceState.RESPONDING ->
            MagmiteCoreVisualState.THINKING
        else -> MagmiteCoreVisualState.IDLE
    }

    val latestVisualState by rememberUpdatedState(visualState)
    val latestRms by rememberUpdatedState(voiceRmsLevel.coerceIn(0f, 1f))
    val latestActivationProgress by rememberUpdatedState(activationProgress)

    var simTime by remember { mutableFloatStateOf(0f) }
    var pulseWave by remember { mutableFloatStateOf(0f) }

    // Lifecycle-aware frame-throttled simulation loop (automatically cancels when leaving composition)
    LaunchedEffect(animationQuality) {
        val frameDelayMs = animationQuality.targetFrameDelayMs
        var lastNanos = 0L
        while (isActive) {
            withFrameNanos { frameNanos ->
                if (lastNanos == 0L) {
                    lastNanos = frameNanos
                } else {
                    val elapsedMs = (frameNanos - lastNanos) / 1_000_000L
                    if (elapsedMs >= frameDelayMs) {
                        val dt = ((frameNanos - lastNanos) / 1_000_000_000f).coerceIn(0.008f, 0.05f)
                        lastNanos = frameNanos
                        val st = latestVisualState
                        val rms = latestRms
                        val speedFactor = when {
                            animationQuality == AnimationQuality.REDUCED_MOTION -> 0.25f
                            st == MagmiteCoreVisualState.OFFLINE -> 0.28f
                            st == MagmiteCoreVisualState.THINKING -> 2.25f
                            st == MagmiteCoreVisualState.SPEAKING -> 1.65f + rms * 0.9f
                            st == MagmiteCoreVisualState.LISTENING -> 1.45f + rms * 0.7f
                            st == MagmiteCoreVisualState.ACTIVATING ->
                                2.6f * (1f - latestActivationProgress * 0.45f)
                            else -> 1.0f
                        }
                        simTime += dt * speedFactor
                        val pulseSpeed = when (st) {
                            MagmiteCoreVisualState.OFFLINE -> 0.18f
                            MagmiteCoreVisualState.THINKING -> 0.95f
                            MagmiteCoreVisualState.SPEAKING -> 0.85f
                            else -> 0.42f
                        }
                        pulseWave = (pulseWave + dt * pulseSpeed) % 1f
                    }
                }
            }
            if (frameDelayMs > 20L) {
                delay(frameDelayMs - 16L)
            }
        }
    }

    val statusText = when (visualState) {
        MagmiteCoreVisualState.OFFLINE -> "OFFLINE"
        MagmiteCoreVisualState.ACTIVATING -> "ACTIVATING"
        MagmiteCoreVisualState.LISTENING -> "LISTENING"
        MagmiteCoreVisualState.THINKING -> if (isExecuting) "EXECUTING" else "THINKING"
        MagmiteCoreVisualState.SPEAKING -> "SPEAKING"
        MagmiteCoreVisualState.IDLE -> status.name
    }

    val configuration = LocalConfiguration.current
    val maxResponsiveHeight = (configuration.screenHeightDp * 0.36f).dp.coerceIn(190.dp, 290.dp)

    BoxWithConstraints(
        modifier = modifier.fillMaxWidth(),
        contentAlignment = Alignment.Center
    ) {
        val stageHeight = minOf(maxWidth * 0.80f, maxResponsiveHeight)

        Box(
            modifier = Modifier
                .fillMaxWidth()
                .height(stageHeight),
            contentAlignment = Alignment.Center
        ) {
            Canvas(modifier = Modifier.fillMaxSize()) {
                val minDim = size.minDimension
                val reducedMotion = animationQuality == AnimationQuality.REDUCED_MOTION
                val st = visualState
                val isOffline = st == MagmiteCoreVisualState.OFFLINE
                val isListening = st == MagmiteCoreVisualState.LISTENING
                val isThinking = st == MagmiteCoreVisualState.THINKING
                val isSpeakingNow = st == MagmiteCoreVisualState.SPEAKING
                val isActivating = st == MagmiteCoreVisualState.ACTIVATING
                val rms = latestRms

                val ambientParallaxX = if (reducedMotion) 0f else sin(simTime * 0.7f) * 3.5.dp.toPx()
                val ambientParallaxY = if (reducedMotion) 0f else cos(simTime * 0.55f) * 2.5.dp.toPx()
                val levitationY = if (isOffline || reducedMotion) 0f else sin(simTime * 1.45f) * (minDim * 0.022f)

                val cx = size.width / 2f + ambientParallaxX * 0.4f
                val cy = size.height / 2f + levitationY + ambientParallaxY * 0.4f
                val center = Offset(cx, cy)

                val baseRadius = minDim * 0.34f
                val sphereScale = when {
                    isActivating -> 0.35f + 0.65f * sin(activationProgress * (PI.toFloat() / 2f))
                    isSpeakingNow -> 1f + 0.05f * sin(simTime * 6f) + rms * 0.14f
                    isListening -> 1f + 0.03f * sin(simTime * 4f) + rms * 0.09f
                    isOffline -> 0.92f
                    else -> 1f + 0.026f * sin(simTime * 2.1f)
                }
                val sphereRadius = baseRadius * 0.41f * sphereScale

                val primaryColor = if (isOffline) Color(0xFF64748B) else Color(0xFFF59E0B)
                val goldColor = if (isOffline) Color(0xFF78716C) else Color(0xFFFBBF24)
                val coreLightColor = if (isOffline) Color(0xFF94A3B8) else Color(0xFFFEF3C7)
                val deepAmber = Color(0xFFB45309)
                val listenAccent = Color(0xFF38BDF8)

                // 1. Open-Space Unbounded Volumetric Field Aura (fades cleanly to transparent)
                val auraRadius = minDim * 0.49f
                drawCircle(
                    brush = Brush.radialGradient(
                        colorStops = arrayOf(
                            0.0f to coreLightColor.copy(alpha = if (isOffline) 0.14f else if (isSpeakingNow) 0.42f else 0.28f),
                            0.32f to primaryColor.copy(alpha = if (isOffline) 0.08f else if (isThinking) 0.26f else 0.18f),
                            0.68f to goldColor.copy(alpha = if (isOffline) 0.02f else if (isListening) 0.08f else 0.06f),
                            1.0f to Color.Transparent
                        ),
                        center = center,
                        radius = auraRadius
                    ),
                    radius = auraRadius,
                    center = center
                )

                // 2. Dynamic Concentric Light Pulse Ripples
                if (!isOffline) {
                    val waveCount = if (isSpeakingNow || isActivating) 2 else 1
                    for (w in 0 until waveCount) {
                        val pPhase = (pulseWave + w * 0.5f) % 1f
                        val waveR = sphereRadius * 1.1f + pPhase * (baseRadius * 1.25f - sphereRadius)
                        val waveAlpha = (1f - pPhase) * if (isActivating) 0.48f else if (isSpeakingNow) 0.34f else 0.22f
                        drawCircle(
                            color = (if (isListening) listenAccent else goldColor).copy(alpha = waveAlpha),
                            radius = waveR,
                            center = center,
                            style = Stroke(width = (1.6f - pPhase * 0.9f).coerceAtLeast(0.5f).dp.toPx())
                        )
                    }
                }

                // 3. Back-Plane 3D Foreshortened Orbital Rings (behind sphere for volumetric depth)
                val ringExpand = if (isActivating) 0.45f + 0.55f * activationProgress else 1f
                val swayDeg = sin(simTime * 0.4f) * 3.0f
                val backCenter = Offset(cx - ambientParallaxX * 0.22f, cy - ambientParallaxY * 0.22f)

                orbitRings.forEach { cfg ->
                    val ringColor = if (cfg.useAcousticTintWhenListening && isListening) {
                        listenAccent
                    } else if (cfg.useGold) {
                        goldColor
                    } else {
                        primaryColor
                    }
                    drawTiltedEllipseArc(
                        center = backCenter,
                        rx = baseRadius * cfg.rxFactor * ringExpand,
                        ry = baseRadius * cfg.ryFactor * ringExpand,
                        tiltDeg = cfg.baseTiltDeg + swayDeg,
                        startAngleDeg = 180f,
                        sweepAngleDeg = 180f,
                        color = ringColor.copy(alpha = if (isOffline) 0.14f else 0.28f),
                        strokeWidthPx = cfg.strokeDp.dp.toPx(),
                        dashIntervals = cfg.dashIntervals
                    )
                }

                // 4. Outer Harmonic Containment Halo (subtle & borderless)
                rotate(degrees = (simTime * 18.3f) % 360f, pivot = center) {
                    drawCircle(
                        color = primaryColor.copy(alpha = if (isOffline) 0.16f else if (isThinking) 0.52f else 0.34f),
                        radius = baseRadius * 1.16f * ringExpand,
                        center = center,
                        style = Stroke(
                            width = 1.25.dp.toPx(),
                            pathEffect = PathEffect.dashPathEffect(floatArrayOf(20f, 14f, 5f, 14f), 0f)
                        )
                    )
                }

                // 5. Central Floating Volumetric Energy Sphere
                drawCircle(
                    brush = Brush.radialGradient(
                        colorStops = arrayOf(
                            0.0f to coreLightColor.copy(alpha = if (isOffline) 0.38f else 0.95f),
                            0.45f to goldColor.copy(alpha = if (isOffline) 0.26f else 0.82f),
                            0.82f to primaryColor.copy(alpha = if (isOffline) 0.18f else 0.62f),
                            1.0f to deepAmber.copy(alpha = if (isOffline) 0.08f else 0.22f)
                        ),
                        center = Offset(cx - sphereRadius * 0.24f, cy - sphereRadius * 0.24f),
                        radius = sphereRadius * 1.15f
                    ),
                    radius = sphereRadius,
                    center = center
                )

                // Clipped internal plasma waveform lines inside floating sphere
                if (!isOffline) {
                    val clipSphere = Path().apply {
                        addOval(
                            androidx.compose.ui.geometry.Rect(
                                left = cx - sphereRadius * 0.94f,
                                top = cy - sphereRadius * 0.94f,
                                right = cx + sphereRadius * 0.94f,
                                bottom = cy + sphereRadius * 0.94f
                            )
                        )
                    }
                    clipPath(clipSphere) {
                        val waveAmp = sphereRadius * when {
                            isSpeakingNow -> 0.22f + rms * 0.18f
                            isThinking -> 0.18f
                            else -> 0.12f
                        }
                        for (line in 0..1) {
                            val wavePath = Path()
                            val phaseOffset = line * 1.7f + simTime * if (line == 0) 3.2f else -2.4f
                            val step = max(3f, sphereRadius / 14f)
                            var x = -sphereRadius
                            var first = true
                            while (x <= sphereRadius) {
                                val norm = (x / sphereRadius).coerceIn(-1f, 1f)
                                val envelope = sqrt(max(0f, 1f - norm * norm))
                                val y = sin(norm * 4.5f + phaseOffset) * waveAmp * envelope
                                if (first) {
                                    wavePath.moveTo(cx + x, cy + y)
                                    first = false
                                } else {
                                    wavePath.lineTo(cx + x, cy + y)
                                }
                                x += step
                            }
                            drawPath(
                                path = wavePath,
                                color = coreLightColor.copy(alpha = if (line == 0) 0.55f else 0.32f),
                                style = Stroke(width = (if (line == 0) 1.5f else 1.0f).dp.toPx(), cap = StrokeCap.Round)
                            )
                        }
                    }
                }

                // Specular Fresnel rim highlight
                drawCircle(
                    color = coreLightColor.copy(alpha = if (isOffline) 0.18f else if (isSpeakingNow) 0.85f else 0.52f),
                    radius = sphereRadius,
                    center = center,
                    style = Stroke(width = 1.4.dp.toPx())
                )

                // 6. Inner Rotating 6-Node Magnetic Hex Lattice (MAGMITE signature)
                val nodes = magmiteProfile.visualIdentity.orbitalNodes
                val hexR = sphereRadius * 1.38f * ringExpand
                rotate(degrees = ((-simTime * 33.2f) % 360f), pivot = center) {
                    val hexPath = Path()
                    for (i in 0..nodes) {
                        val theta = (i * 2.0 * PI) / nodes
                        val px = cx + (cos(theta) * hexR).toFloat()
                        val py = cy + (sin(theta) * hexR).toFloat()
                        if (i == 0) hexPath.moveTo(px, py) else hexPath.lineTo(px, py)
                    }
                    drawPath(
                        path = hexPath,
                        color = goldColor.copy(alpha = if (isOffline) 0.16f else if (isThinking) 0.65f else 0.38f),
                        style = Stroke(width = 1.1.dp.toPx())
                    )
                }

                // 7. Front-Plane 3D Foreshortened Orbital Rings
                val frontCenter = Offset(cx + ambientParallaxX * 0.22f, cy + ambientParallaxY * 0.22f)
                orbitRings.forEach { cfg ->
                    val ringColor = if (cfg.useAcousticTintWhenListening && isListening) {
                        listenAccent
                    } else if (cfg.useGold) {
                        goldColor
                    } else {
                        primaryColor
                    }
                    drawTiltedEllipseArc(
                        center = frontCenter,
                        rx = baseRadius * cfg.rxFactor * ringExpand,
                        ry = baseRadius * cfg.ryFactor * ringExpand,
                        tiltDeg = cfg.baseTiltDeg + swayDeg,
                        startAngleDeg = 0f,
                        sweepAngleDeg = 180f,
                        color = ringColor.copy(alpha = if (isOffline) 0.24f else if (isThinking || isSpeakingNow) 0.88f else 0.68f),
                        strokeWidthPx = (cfg.strokeDp * 1.15f).dp.toPx(),
                        dashIntervals = cfg.dashIntervals
                    )
                }

                // 8. Six Glowing Orbital Nodes with Subtle Plasma Trails
                val nodeOrbitA = orbitRings[0]
                val nodeOrbitB = orbitRings[1]
                val trailSteps = if (isOffline) 2 else 7

                for (i in 0 until nodes) {
                    val cfg = if (i % 2 == 0) nodeOrbitA else nodeOrbitB
                    val rx = baseRadius * cfg.rxFactor * ringExpand
                    val ry = baseRadius * cfg.ryFactor * ringExpand
                    val tiltRad = ((cfg.baseTiltDeg + swayDeg) * PI / 180.0).toFloat()
                    val baseTheta = ((i * 2.0 * PI) / nodes).toFloat() + simTime * cfg.rotSpeed
                    val dirSign = if (cfg.rotSpeed >= 0f) 1f else -1f

                    for (s in trailSteps downTo 1) {
                        val lagTheta = baseTheta - s * 0.075f * dirSign
                        val lx = cos(lagTheta) * rx
                        val ly = sin(lagTheta) * ry
                        val tx = cx + lx * cos(tiltRad) - ly * sin(tiltRad)
                        val ty = cy + lx * sin(tiltRad) + ly * cos(tiltRad)
                        val frac = 1f - s.toFloat() / (trailSteps + 1).toFloat()
                        drawCircle(
                            color = primaryColor.copy(alpha = (if (isOffline) 0.08f else 0.45f) * frac * frac),
                            radius = (2.4f * frac).dp.toPx(),
                            center = Offset(tx, ty)
                        )
                    }

                    val lx = cos(baseTheta) * rx
                    val ly = sin(baseTheta) * ry
                    val nx = cx + lx * cos(tiltRad) - ly * sin(tiltRad)
                    val ny = cy + lx * sin(tiltRad) + ly * cos(tiltRad)
                    val nodePos = Offset(nx, ny)
                    val isFront = sin(baseTheta) >= 0f
                    val nodeRadiusPx = ((if (isFront) 3.8f else 2.7f) + if (isSpeakingNow) rms * 1.6f else 0f).dp.toPx()

                    drawCircle(
                        brush = Brush.radialGradient(
                            colorStops = arrayOf(
                                0.0f to coreLightColor.copy(alpha = if (isOffline) 0.25f else 0.92f),
                                0.45f to primaryColor.copy(alpha = if (isOffline) 0.12f else 0.55f),
                                1.0f to Color.Transparent
                            ),
                            center = nodePos,
                            radius = nodeRadiusPx * 3.1f
                        ),
                        radius = nodeRadiusPx * 3.1f,
                        center = nodePos
                    )
                    drawCircle(
                        color = when {
                            isOffline -> primaryColor.copy(alpha = 0.5f)
                            isFront -> coreLightColor.copy(alpha = 0.98f)
                            else -> goldColor.copy(alpha = 0.8f)
                        },
                        radius = nodeRadiusPx,
                        center = nodePos
                    )
                }

                // 9. Audio-Reactive Floating Harmonic Filaments (LISTENING & SPEAKING)
                if (isListening || isSpeakingNow) {
                    val filaments = 32
                    val ringBaseR = baseRadius * 1.24f
                    val baseLineWidth = 1.8.dp.toPx()
                    for (i in 0 until filaments) {
                        val theta = ((i * 2.0 * PI) / filaments).toFloat() + simTime * 0.45f
                        val harmonic = 0.4f + 0.6f * abs(sin(simTime * 4.8f + i * 0.65f))
                        val ampPx = (4f + 15f * max(0.18f, rms)).dp.toPx() * harmonic
                        val startPos = Offset(cx + cos(theta) * ringBaseR, cy + sin(theta) * ringBaseR)
                        val endPos = Offset(cx + cos(theta) * (ringBaseR + ampPx), cy + sin(theta) * (ringBaseR + ampPx))
                        drawLine(
                            color = (if (isListening) listenAccent else goldColor).copy(alpha = 0.38f + 0.44f * harmonic),
                            start = startPos,
                            end = endPos,
                            strokeWidth = baseLineWidth,
                            cap = StrokeCap.Round
                        )
                    }
                }

                // 10. Floating 3D Energy Particles in Open Space
                for (i in particles.indices) {
                    val pt = particles[i]
                    val theta = pt.angle + simTime * pt.speed
                    val pull = when {
                        isActivating -> 1.55f - 0.55f * activationProgress
                        isThinking -> 0.84f
                        isSpeakingNow -> 1.06f + rms * 0.14f
                        else -> 1.0f
                    }
                    val r = minDim * 0.48f * pt.orbitRadiusFactor * pull
                    val pxLocal = cos(theta) * r
                    val pzDepth = sin(theta) // -1..+1
                    val pyLocal = sin(theta + pt.tilt) * r * 0.36f +
                        sin(simTime * 1.3f + pt.verticalPhase) * (minDim * pt.verticalAmpFactor)

                    val px = cx + pxLocal + ambientParallaxX * (0.35f + pzDepth * 0.25f)
                    val py = cy + pyLocal + ambientParallaxY * (0.35f + pzDepth * 0.25f)
                    val depthScale = 0.68f + (pzDepth + 1f) * 0.32f
                    val twinkle = 0.6f + 0.4f * sin(simTime * 2.8f + pt.verticalPhase)
                    val alpha = (pt.baseAlpha *
                        twinkle *
                        (if (isOffline) 0.22f else if (hasPendingApproval) 1.0f else 0.85f) *
                        (0.55f + (pzDepth + 1f) * 0.225f)).coerceIn(0f, 1f)

                    val ptColor = when {
                        i % 5 == 0 && isListening -> listenAccent
                        i % 3 == 0 -> coreLightColor
                        else -> goldColor
                    }
                    drawCircle(
                        color = ptColor.copy(alpha = alpha),
                        radius = (pt.sizeDp * depthScale).dp.toPx(),
                        center = Offset(px, py)
                    )
                }
            }

            // Centered Floating Identity Overlay (borderless, crisp contrast over glowing sphere)
            Column(
                horizontalAlignment = Alignment.CenterHorizontally,
                modifier = Modifier.padding(horizontal = 16.dp)
            ) {
                Text(
                    text = statusText,
                    color = Color(0xFFFEF3C7).copy(alpha = 0.82f),
                    fontSize = 9.sp,
                    fontFamily = FontFamily.Monospace,
                    letterSpacing = 2.sp,
                    style = TextStyle(
                        shadow = Shadow(color = Color.Black, offset = Offset(0f, 1f), blurRadius = 6f)
                    )
                )
                Text(
                    text = magmiteProfile.displayName,
                    color = Color.White,
                    fontSize = 18.sp,
                    fontWeight = FontWeight.Bold,
                    letterSpacing = 1.6.sp,
                    style = TextStyle(
                        shadow = Shadow(color = Color.Black, offset = Offset(0f, 2f), blurRadius = 10f)
                    )
                )
                Text(
                    text = if (hasPendingApproval) "APPROVAL PENDING" else magmiteProfile.visualIdentity.emblemLabel,
                    color = Color(0xFFFBBF24).copy(alpha = 0.92f),
                    fontSize = 10.sp,
                    fontFamily = FontFamily.Monospace,
                    letterSpacing = 1.4.sp,
                    style = TextStyle(
                        shadow = Shadow(color = Color.Black, offset = Offset(0f, 1f), blurRadius = 8f)
                    )
                )
            }
        }
    }
}

private fun DrawScope.drawTiltedEllipseArc(
    center: Offset,
    rx: Float,
    ry: Float,
    tiltDeg: Float,
    startAngleDeg: Float,
    sweepAngleDeg: Float,
    color: Color,
    strokeWidthPx: Float,
    dashIntervals: FloatArray?
) {
    rotate(degrees = tiltDeg, pivot = center) {
        drawArc(
            color = color,
            startAngle = startAngleDeg,
            sweepAngle = sweepAngleDeg,
            useCenter = false,
            topLeft = Offset(center.x - rx, center.y - ry),
            size = Size(rx * 2f, ry * 2f),
            style = Stroke(
                width = strokeWidthPx,
                cap = StrokeCap.Round,
                pathEffect = dashIntervals?.let { PathEffect.dashPathEffect(it, 0f) }
            )
        )
    }
}
