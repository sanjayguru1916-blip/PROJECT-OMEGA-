package com.projectomega.sk.sk.router

import android.Manifest
import android.provider.Settings
import com.projectomega.sk.assistants.magmite.AndroidPhoneController
import com.projectomega.sk.core.ai.AiProviderGateway
import com.projectomega.sk.core.approval.ApprovalManager
import com.projectomega.sk.core.data.SystemReportDao
import com.projectomega.sk.core.data.SystemReportEntity
import com.projectomega.sk.core.data.TaskHistoryDao
import com.projectomega.sk.core.data.TaskHistoryEntity
import com.projectomega.sk.core.model.AlertSeverity
import com.projectomega.sk.core.model.AssistantCommandRequest
import com.projectomega.sk.core.model.AssistantExecutionResult
import com.projectomega.sk.core.model.AssistantId
import com.projectomega.sk.core.model.AssistantStatus
import com.projectomega.sk.core.model.ContactCandidate
import com.projectomega.sk.core.model.IntentCategory
import com.projectomega.sk.core.model.RiskLevel
import com.projectomega.sk.core.model.SimAccountOption
import com.projectomega.sk.core.model.SkRouteOutcome
import com.projectomega.sk.core.model.SystemAlert
import com.projectomega.sk.core.model.SystemReport
import com.projectomega.sk.core.model.TaskProposal
import com.projectomega.sk.core.registry.AssistantRegistry
import com.projectomega.sk.core.security.AndroidPermissionGuard
import com.projectomega.sk.core.security.AuditLogger
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import java.util.Calendar
import java.util.UUID

/**
 * SK Central Master Controller.
 * Coordinates:
 * - Single-session SK dynamic startup greeting (other cores stay silent until requested)
 * - Real operational status reporting without fabricated metrics
 * - 10-category natural language routing (direct answer vs explicit approval-gated delegation)
 * - Contact & Dual-SIM disambiguation for communication requests
 * - Deduplicated SHA-256 task approvals with in-flight execution locks
 */
class SkMasterCore(
    private val registry: AssistantRegistry,
    private val approvalManager: ApprovalManager,
    private val permissionGuard: AndroidPermissionGuard,
    private val phoneController: AndroidPhoneController,
    private val aiProvider: AiProviderGateway,
    private val auditLogger: AuditLogger,
    private val taskHistoryDao: TaskHistoryDao,
    private val systemReportDao: SystemReportDao
) {

    private val _alerts = MutableStateFlow<List<SystemAlert>>(emptyList())
    val alerts: StateFlow<List<SystemAlert>> = _alerts.asStateFlow()

    @Volatile
    private var hasGreetedThisSession: Boolean = false

    private val lowRiskDirectOps = setOf(
        "PLAY_MUSIC", "PAUSE_MUSIC", "RESUME_MUSIC", "STOP_MUSIC", "NEXT_TRACK", "PREVIOUS_TRACK",
        "OPEN_APPLICATION", "OPEN_APP", "LAUNCH_APP", "OPEN_WHATSAPP", "OPEN_YOUTUBE", "OPEN_CAMERA",
        "SET_ALARM", "OPEN_ALARM",
        "CHECK_TIME", "CHECK_DATE", "CHECK_BATTERY", "CHECK_NETWORK", "READ_DEVICE_POWER", "READ_DEVICE_INFO",
        "OPEN_SETTINGS", "OPEN_DEVICE_SETTINGS", "OPEN_WIFI_SETTINGS", "OPEN_BLUETOOTH_SETTINGS",
        "SHOW_APPLICATIONS", "NORMAL_NAVIGATION", "RETURN_TO_OMEGA",
        "DIRECT_ANSWER", "GENERAL_GREETING", "STATUS_CHECK", "SYSTEM_TASK_STATUS"
    )

    private val highRiskApprovalOps = setOf(
        "SEND_WHATSAPP_MESSAGE", "PREPARE_WHATSAPP",
        "SEND_SMS", "PREPARE_SMS",
        "SEND_EMAIL", "PREPARE_EMAIL",
        "CALL_CONTACT",
        "TOGGLE_TORCH", "SET_FLASHLIGHT", "SET_VOLUME", "ADJUST_VOLUME", "SET_RINGER_MODE",
        "CREATE_REMINDER", "SCHEDULE_EVENT"
    )

    private val criticalApprovalOps = setOf(
        "MONEY_TRANSFER", "ONLINE_PAYMENT", "DELETE_IMPORTANT_FILES", "SENSITIVE_ACCOUNT_CHANGES", "SHARE_PRIVATE_INFORMATION"
    )

    @Synchronized
    fun consumeStartupGreetingIfNeeded(): String? {
        if (hasGreetedThisSession) return null
        hasGreetedThisSession = true
        return buildDynamicMasterGreeting()
    }

    fun buildDynamicMasterGreeting(): String {
        val hour = Calendar.getInstance().get(Calendar.HOUR_OF_DAY)
        val timeGreeting = when {
            hour < 12 -> "Good morning"
            hour < 18 -> "Good afternoon"
            else -> "Good evening"
        }
        val states = registry.states.value
        val onlineModules = listOf(
            AssistantId.JARVIS,
            AssistantId.MAGMITE,
            AssistantId.ULTRON,
            AssistantId.FRIDAY
        ).filter { states[it]?.isEnabled == true }
        val disabledModules = listOf(
            AssistantId.JARVIS,
            AssistantId.MAGMITE,
            AssistantId.ULTRON,
            AssistantId.FRIDAY
        ).filter { states[it]?.isEnabled == false }

        val moduleClause = when {
            onlineModules.size == 4 -> "All four assistant modules (JARVIS, MAGMITE, ULTRON, and FRIDAY) are initialized on standby."
            onlineModules.isEmpty() -> "No subordinate assistant modules are currently enabled."
            else -> "Active standby modules: ${onlineModules.joinToString { it.name }}. Offline: ${disabledModules.joinToString { it.name }}."
        }
        val pendingCount = approvalManager.pendingQueue.value.size
        val pendingClause = if (pendingCount > 0) " $pendingCount task approval(s) await your review." else ""
        return "$timeGreeting, Commander. SK Master Systems are online. $moduleClause$pendingClause How can I assist you?"
    }

    fun buildRealAssistantStatusReport(id: AssistantId): String {
        val regState = registry.states.value[id]
            ?: return "${id.name} is not registered in the SK Assistant Registry."
        val pendingForId = approvalManager.pendingQueue.value.count { it.targetAssistant == id }
        val metrics = regState.metrics
        val latencyLabel = metrics.lastResponseMs?.let { "$it ms" } ?: "Not available"
        val idleSentence = if (metrics.activeTaskCount == 0 && regState.isEnabled) {
            "I am currently idle and ready for your next command."
        } else if (!regState.isEnabled) {
            "I am currently disabled by SK Master Controller."
        } else {
            "Current activity: ${metrics.currentActivity}."
        }
        val errorNote = metrics.recentError?.let { " Recent error: $it." } ?: ""
        return "${regState.profile.displayName} is ${regState.status.name.lowercase()}. $idleSentence " +
            "Active tasks: ${metrics.activeTaskCount}, completed: ${metrics.completedTaskCount}, pending approval: $pendingForId. " +
            "Last response time: $latencyLabel.$errorNote"
    }

    suspend fun routeUserUtterance(
        rawInput: String,
        preferredAssistant: AssistantId?
    ): Result<SkRouteOutcome> {
        val trimmed = rawInput.trim()
        if (trimmed.isEmpty()) {
            return Result.failure(IllegalArgumentException("Empty command input."))
        }
        val startedAt = System.currentTimeMillis()
        registry.updateStatus(AssistantId.SK, AssistantStatus.BUSY, activity = "Classifying command")

        return runCatching {
            val localOutcome = tryDeterministicDirectOutcome(trimmed, preferredAssistant, startedAt)
            if (localOutcome != null) {
                return@runCatching localOutcome
            }

            val descriptors = registry.availableDescriptors()
            val classified = aiProvider.classifyCommand(
                rawInput = trimmed,
                preferredAssistant = preferredAssistant,
                descriptors = descriptors
            )

            val normalizedOp = classified.request.intentAction.uppercase()
            val isCriticalOp = normalizedOp in criticalApprovalOps || classified.request.riskLevel == RiskLevel.CRITICAL
            val requiresApproval = when {
                isCriticalOp -> true
                normalizedOp in highRiskApprovalOps -> true
                normalizedOp in lowRiskDirectOps -> false
                else -> classified.requiresApproval
            }

            if (!requiresApproval) {
                val directExec = executeDirectPhoneOperation(
                    exactOperation = normalizedOp,
                    rawInput = trimmed,
                    parameters = classified.request.parameters
                )
                if (directExec != null) {
                    val elapsed = System.currentTimeMillis() - startedAt
                    return@runCatching directExec.fold(
                        onSuccess = { summary ->
                            registry.markExecutionFinish(AssistantId.MAGMITE, success = true, responseMs = elapsed)
                            registry.updateStatus(AssistantId.SK, AssistantStatus.ONLINE)
                            recordDirectExecutionHistory(AssistantId.MAGMITE, trimmed, normalizedOp, summary)
                            SkRouteOutcome.DirectResponse(
                                speaker = AssistantId.MAGMITE,
                                category = classified.category,
                                replyText = summary,
                                exactOperation = normalizedOp
                            )
                        },
                        onFailure = { err ->
                            val msg = err.message ?: "Unable to complete requested device action."
                            registry.markExecutionFinish(AssistantId.MAGMITE, success = false, responseMs = elapsed, errorMessage = msg)
                            registry.updateStatus(AssistantId.SK, AssistantStatus.ONLINE)
                            SkRouteOutcome.DirectResponse(
                                speaker = AssistantId.SK,
                                category = classified.category,
                                replyText = msg,
                                exactOperation = normalizedOp
                            )
                        }
                    )
                }

                val speaker = if (classified.category == IntentCategory.GENERAL_CONVERSATION && preferredAssistant == null) {
                    AssistantId.SK
                } else {
                    classified.request.targetAssistant
                }
                val reply = classified.directReply?.takeIf { it.isNotBlank() }
                    ?: aiProvider.generateAssistantResponse(
                        assistantId = speaker,
                        operation = classified.request.intentAction,
                        rawInput = trimmed,
                        parameters = classified.request.parameters
                    ).summary
                val elapsed = System.currentTimeMillis() - startedAt
                registry.markExecutionFinish(speaker, success = true, responseMs = elapsed)
                registry.updateStatus(AssistantId.SK, AssistantStatus.ONLINE)
                return@runCatching SkRouteOutcome.DirectResponse(
                    speaker = speaker,
                    category = classified.category,
                    replyText = reply,
                    exactOperation = normalizedOp
                )
            }

            // Communication shortcut: if AI classified CALL_CONTACT / PREPARE_SMS, run contact + SIM resolution cleanly
            if (normalizedOp == "CALL_CONTACT" || normalizedOp == "PREPARE_SMS" || normalizedOp == "SEND_SMS") {
                val contactName = classified.request.parameters["contactName"]?.takeIf { it.isNotBlank() }
                    ?: extractContactTarget(trimmed)
                if (!contactName.isNullOrBlank() && classified.request.parameters["phoneNumber"].isNullOrBlank()) {
                    val disambiguation = prepareCommunicationOutcome(
                        isSms = normalizedOp.contains("SMS"),
                        contactQuery = contactName,
                        messageBody = classified.request.parameters["message"],
                        rawInput = trimmed
                    )
                    registry.updateStatus(AssistantId.SK, AssistantStatus.ONLINE)
                    return@runCatching disambiguation
                }
            }

            val enforcedRequest = classified.request.copy(
                riskLevel = if (normalizedOp in criticalApprovalOps) RiskLevel.CRITICAL else classified.request.riskLevel
            )
            val proposalOutcome = createDeduplicatedProposal(enforcedRequest)
            registry.updateStatus(AssistantId.SK, AssistantStatus.ONLINE)
            SkRouteOutcome.ProposalRequired(
                proposal = proposalOutcome.proposal,
                deduplicated = proposalOutcome.deduplicated
            )
        }.onFailure { err ->
            registry.updateStatus(AssistantId.SK, AssistantStatus.ONLINE, error = err.message)
            emitAlert(
                AlertSeverity.ERROR,
                AssistantId.SK,
                "Command Routing Error",
                err.message ?: "Unable to route command."
            )
            auditLogger.log("ROUTING_ERROR", AssistantId.SK, null, err.message ?: "Routing error")
        }
    }

    private fun executeDirectPhoneOperation(
        exactOperation: String,
        rawInput: String,
        parameters: Map<String, String>
    ): Result<String>? {
        return when (exactOperation.uppercase()) {
            "PLAY_MUSIC", "PAUSE_MUSIC", "RESUME_MUSIC", "STOP_MUSIC", "NEXT_TRACK", "PREVIOUS_TRACK" ->
                phoneController.controlMediaPlayback(exactOperation, parameters["query"])
            "OPEN_APP", "OPEN_APPLICATION", "LAUNCH_APP", "OPEN_WHATSAPP", "OPEN_YOUTUBE" -> {
                val appName = parameters["appName"] ?: when (exactOperation.uppercase()) {
                    "OPEN_WHATSAPP" -> "WhatsApp"
                    "OPEN_YOUTUBE" -> "YouTube"
                    else -> rawInput
                }
                phoneController.launchInstalledAppByName(appName)
            }
            "SHOW_APPLICATIONS" -> phoneController.showInstalledApplications()
            "RETURN_TO_OMEGA", "NORMAL_NAVIGATION" -> phoneController.returnToProjectOmega()
            "OPEN_CAMERA" -> phoneController.openCameraApp()
            "SET_ALARM", "OPEN_ALARM" -> {
                val hr = parameters["hour"]?.toIntOrNull()
                val min = parameters["minute"]?.toIntOrNull()
                val label = parameters["label"] ?: parameters["message"]
                phoneController.openAlarmApp(hr, min, label)
            }
            "OPEN_WIFI_SETTINGS" -> phoneController.openSettingsPanel(Settings.Panel.ACTION_WIFI, "Wi-Fi settings")
            "OPEN_BLUETOOTH_SETTINGS" -> phoneController.openSettingsPanel(Settings.ACTION_BLUETOOTH_SETTINGS, "Bluetooth settings")
            "OPEN_SETTINGS", "OPEN_DEVICE_SETTINGS" -> phoneController.openSettingsPanel(Settings.ACTION_SETTINGS, "Android system settings")
            else -> null
        }
    }

    private suspend fun recordDirectExecutionHistory(
        speaker: AssistantId,
        rawInput: String,
        exactOperation: String,
        summary: String
    ) {
        taskHistoryDao.upsert(
            TaskHistoryEntity(
                proposalId = "direct-${UUID.randomUUID().toString().take(8)}",
                targetAssistant = speaker.name,
                rawInput = rawInput,
                exactOperation = exactOperation,
                status = "COMPLETED",
                resultSummary = summary,
                timestampEpochMs = System.currentTimeMillis()
            )
        )
        auditLogger.log("DIRECT_TASK_EXECUTED", speaker, null, "$exactOperation: $summary")
    }

    private suspend fun tryDeterministicDirectOutcome(
        raw: String,
        preferredAssistant: AssistantId?,
        startedAt: Long
    ): SkRouteOutcome? {
        val lower = raw.lowercase().trim()
        val stripped = lower
            .replace(Regex("^(hey|hi|ok|okay|please)\\s+"), "")
            .replace(Regex("^(sk|jarvis|magmite|ultron|friday)[,:]?\\s+"), "")
            .trim()

        // CRITICAL tasks -> Mandatory proposal with RiskLevel.CRITICAL
        if (Regex("\\b(transfer money|send money|bank transfer|pay bill|make payment|online payment|upi payment|delete all files|erase all data|format storage|change security password)\\b").containsMatchIn(stripped)) {
            val op = when {
                Regex("\\b(transfer money|send money|bank transfer)\\b").containsMatchIn(stripped) -> "MONEY_TRANSFER"
                Regex("\\b(pay bill|make payment|online payment|upi payment)\\b").containsMatchIn(stripped) -> "ONLINE_PAYMENT"
                Regex("\\b(delete|erase|format)\\b").containsMatchIn(stripped) -> "DELETE_IMPORTANT_FILES"
                else -> "SENSITIVE_ACCOUNT_CHANGES"
            }
            val req = AssistantCommandRequest(
                commandId = "cmd-${UUID.randomUUID().toString().take(10)}",
                rawInput = raw,
                targetAssistant = AssistantId.MAGMITE,
                intentAction = op,
                parameters = mapOf("command" to raw),
                requiredPermissions = emptyList(),
                riskLevel = RiskLevel.CRITICAL,
                rationale = "Critical high-impact operation requires explicit strong confirmation."
            )
            val outcome = createDeduplicatedProposal(req)
            registry.updateStatus(AssistantId.SK, AssistantStatus.ONLINE)
            return SkRouteOutcome.ProposalRequired(outcome.proposal, outcome.deduplicated)
        }

        // HIGH-risk WhatsApp messaging -> Explicit approval required
        val waMatch = Regex("^(?:send|write|message)\\s+(?:a\\s+)?whatsapp(?:\\s+message)?\\s+(?:to\\s+)?(.+)$").find(stripped)
            ?: Regex("^whatsapp\\s+(.+)$").find(stripped)
        if (waMatch != null) {
            val rest = waMatch.groupValues[1].trim()
            val bodySplit = Regex("^(.+?)\\s+(?:saying|that|:)\\s+(.+)$").find(rest)
            val recipient = bodySplit?.groupValues?.get(1)?.trim() ?: rest
            val msgBody = bodySplit?.groupValues?.get(2)?.trim().orEmpty()
            val req = AssistantCommandRequest(
                commandId = "cmd-${UUID.randomUUID().toString().take(10)}",
                rawInput = raw,
                targetAssistant = AssistantId.MAGMITE,
                intentAction = "SEND_WHATSAPP_MESSAGE",
                parameters = buildMap {
                    put("recipientQuery", recipient)
                    put("contactName", recipient)
                    if (msgBody.isNotBlank()) put("messageBody", msgBody)
                },
                requiredPermissions = listOf(Manifest.permission.READ_CONTACTS),
                riskLevel = RiskLevel.HIGH,
                rationale = "Send WhatsApp message to $recipient${if (msgBody.isNotBlank()) ": \"$msgBody\"" else ""}"
            )
            val outcome = createDeduplicatedProposal(req)
            registry.updateStatus(AssistantId.SK, AssistantStatus.ONLINE)
            return SkRouteOutcome.ProposalRequired(outcome.proposal, outcome.deduplicated)
        }

        // Category 4: System task status query
        if (lower.contains("current system task") ||
            lower.contains("pending approval") ||
            lower.contains("my tasks") ||
            lower.contains("active tasks")
        ) {
            val pending = approvalManager.pendingQueue.value
            val states = registry.states.value
            val busyList = states.values.filter { it.metrics.activeTaskCount > 0 }.map { it.profile.id.name }
            val msg = buildString {
                append("SK system summary: ")
                if (pending.isEmpty()) append("0 pending approvals. ")
                else append("${pending.size} pending approval(s) (${pending.joinToString { "${it.targetAssistant.name}:${it.exactOperation}" }}). ")
                if (busyList.isEmpty()) append("All assistants are currently idle and ready.")
                else append("Active assistants: ${busyList.joinToString()}.")
            }
            registry.markExecutionFinish(AssistantId.SK, success = true, responseMs = System.currentTimeMillis() - startedAt)
            return SkRouteOutcome.DirectResponse(AssistantId.SK, IntentCategory.SYSTEM_TASK_STATUS_QUERY, msg, exactOperation = "SYSTEM_TASK_STATUS")
        }

        // Category 3: Assistant Operational Status Query
        val statusKeywords = listOf("status", "what are you doing", "performance report", "what tasks", "what about ", "how is ", "activity")
        if (statusKeywords.any { lower.contains(it) }) {
            val mentioned = AssistantId.entries.firstOrNull { id ->
                lower.contains(id.name.lowercase())
            } ?: preferredAssistant
            if (mentioned != null) {
                val report = buildRealAssistantStatusReport(mentioned)
                registry.markExecutionFinish(mentioned, success = true, responseMs = System.currentTimeMillis() - startedAt)
                registry.updateStatus(AssistantId.SK, AssistantStatus.ONLINE)
                return SkRouteOutcome.DirectResponse(mentioned, IntentCategory.ASSISTANT_STATUS_QUERY, report, exactOperation = "STATUS_CHECK")
            }
        }

        // Category 1: Simple conversational greetings
        if (Regex("^(hi|hello|hey)(\\s+sk)?[,!?.\\s]*$").matches(lower) ||
            lower.contains("how are you")
        ) {
            val speaker = preferredAssistant ?: AssistantId.SK
            val greeting = when (speaker) {
                AssistantId.SK -> "SK Master Controller online and operating nominally. How may I assist you?"
                else -> "${speaker.name} active and standing by under SK supervision. Ready for your command."
            }
            registry.markExecutionFinish(speaker, success = true, responseMs = System.currentTimeMillis() - startedAt)
            registry.updateStatus(AssistantId.SK, AssistantStatus.ONLINE)
            return SkRouteOutcome.DirectResponse(speaker, IntentCategory.GENERAL_CONVERSATION, greeting, exactOperation = "GENERAL_GREETING")
        }

        // Low-Risk Direct Task: Media Playback Control
        val mediaOp = when {
            Regex("^(?:play|start)\\s+(?:some\\s+)?(?:music|song|songs|audio|spotify|playback)(?:\\s+(.+))?$").matches(stripped) ||
                stripped == "play" -> "PLAY_MUSIC"
            Regex("^(?:pause|hold)\\s+(?:the\\s+)?(?:music|song|audio|playback)$").matches(stripped) ||
                stripped == "pause music" -> "PAUSE_MUSIC"
            Regex("^resume\\s+(?:the\\s+)?(?:music|song|audio|playback)$").matches(stripped) -> "RESUME_MUSIC"
            Regex("^stop\\s+(?:the\\s+)?(?:music|song|audio|playback)$").matches(stripped) -> "STOP_MUSIC"
            stripped == "next song" || stripped == "next track" || stripped == "skip song" -> "NEXT_TRACK"
            stripped == "previous song" || stripped == "previous track" -> "PREVIOUS_TRACK"
            else -> null
        }
        if (mediaOp != null) {
            val exec = phoneController.controlMediaPlayback(mediaOp)
            val elapsed = System.currentTimeMillis() - startedAt
            return exec.fold(
                onSuccess = { reply ->
                    registry.markExecutionFinish(AssistantId.MAGMITE, success = true, responseMs = elapsed)
                    registry.updateStatus(AssistantId.SK, AssistantStatus.ONLINE)
                    recordDirectExecutionHistory(AssistantId.MAGMITE, raw, mediaOp, reply)
                    SkRouteOutcome.DirectResponse(AssistantId.MAGMITE, IntentCategory.DEVICE_HARDWARE_CONTROL, reply, exactOperation = mediaOp)
                },
                onFailure = { err ->
                    val errMsg = err.message ?: "Unable to control media playback."
                    registry.markExecutionFinish(AssistantId.MAGMITE, success = false, responseMs = elapsed, errorMessage = errMsg)
                    registry.updateStatus(AssistantId.SK, AssistantStatus.ONLINE)
                    SkRouteOutcome.DirectResponse(AssistantId.SK, IntentCategory.DEVICE_HARDWARE_CONTROL, errMsg, exactOperation = mediaOp)
                }
            )
        }

        // Low-Risk Direct Task: Alarm Creation
        if (Regex("^(?:set|create|add|open)\\s+(?:an?\\s+)?alarm\\b").containsMatchIn(stripped)) {
            val timeMatch = Regex("(\\d{1,2})(?::(\\d{2}))?\\s*(am|pm)?", RegexOption.IGNORE_CASE).find(stripped)
            var hour: Int? = timeMatch?.groupValues?.get(1)?.toIntOrNull()
            val minute = timeMatch?.groupValues?.getOrNull(2)?.toIntOrNull() ?: 0
            val ampm = timeMatch?.groupValues?.getOrNull(3)?.lowercase()
            if (hour != null) {
                if (ampm == "pm" && hour < 12) hour += 12
                if (ampm == "am" && hour == 12) hour = 0
                if (hour !in 0..23) hour = null
            }
            val exec = phoneController.openAlarmApp(hour, minute, null)
            val elapsed = System.currentTimeMillis() - startedAt
            return exec.fold(
                onSuccess = { reply ->
                    registry.markExecutionFinish(AssistantId.FRIDAY, success = true, responseMs = elapsed)
                    registry.updateStatus(AssistantId.SK, AssistantStatus.ONLINE)
                    recordDirectExecutionHistory(AssistantId.FRIDAY, raw, "SET_ALARM", reply)
                    SkRouteOutcome.DirectResponse(AssistantId.FRIDAY, IntentCategory.APP_NAVIGATION_LAUNCH, reply, exactOperation = "SET_ALARM")
                },
                onFailure = { err ->
                    val errMsg = err.message ?: "Unable to open alarm app."
                    registry.updateStatus(AssistantId.SK, AssistantStatus.ONLINE)
                    SkRouteOutcome.DirectResponse(AssistantId.SK, IntentCategory.APP_NAVIGATION_LAUNCH, errMsg, exactOperation = "SET_ALARM")
                }
            )
        }

        // Low-Risk Direct Task: App Listing & Launching
        if (Regex("^(?:show|list|view)\\s+(?:my\\s+)?(?:installed\\s+)?apps?(?:lications)?$").matches(stripped)) {
            val exec = phoneController.showInstalledApplications()
            val elapsed = System.currentTimeMillis() - startedAt
            val msg = exec.getOrElse { it.message ?: "Unable to list installed applications." }
            registry.markExecutionFinish(AssistantId.MAGMITE, success = exec.isSuccess, responseMs = elapsed)
            registry.updateStatus(AssistantId.SK, AssistantStatus.ONLINE)
            if (exec.isSuccess) recordDirectExecutionHistory(AssistantId.MAGMITE, raw, "SHOW_APPLICATIONS", msg)
            return SkRouteOutcome.DirectResponse(AssistantId.MAGMITE, IntentCategory.APP_NAVIGATION_LAUNCH, msg, exactOperation = "SHOW_APPLICATIONS")
        }

        val openMatch = Regex("^(?:open|launch|start)\\s+(.+)$").find(stripped)
        if (openMatch != null) {
            val targetName = openMatch.groupValues[1].trim()
            val exec = when {
                targetName.contains("wi-fi") || targetName.contains("wifi") ->
                    phoneController.openSettingsPanel(Settings.Panel.ACTION_WIFI, "Wi-Fi settings")
                targetName.contains("bluetooth") ->
                    phoneController.openSettingsPanel(Settings.ACTION_BLUETOOTH_SETTINGS, "Bluetooth settings")
                targetName == "settings" || targetName == "device settings" ->
                    phoneController.openSettingsPanel(Settings.ACTION_SETTINGS, "Android system settings")
                else -> phoneController.launchInstalledAppByName(targetName)
            }
            val elapsed = System.currentTimeMillis() - startedAt
            return exec.fold(
                onSuccess = { reply ->
                    registry.markExecutionFinish(AssistantId.MAGMITE, success = true, responseMs = elapsed)
                    registry.updateStatus(AssistantId.SK, AssistantStatus.ONLINE)
                    recordDirectExecutionHistory(AssistantId.MAGMITE, raw, "OPEN_APPLICATION", reply)
                    SkRouteOutcome.DirectResponse(AssistantId.MAGMITE, IntentCategory.APP_NAVIGATION_LAUNCH, reply, exactOperation = "OPEN_APPLICATION")
                },
                onFailure = { err ->
                    val errMsg = err.message ?: "Application \"$targetName\" could not be opened."
                    registry.markExecutionFinish(AssistantId.MAGMITE, success = false, responseMs = elapsed, errorMessage = errMsg)
                    registry.updateStatus(AssistantId.SK, AssistantStatus.ONLINE)
                    SkRouteOutcome.DirectResponse(AssistantId.SK, IntentCategory.APP_NAVIGATION_LAUNCH, errMsg, exactOperation = "OPEN_APPLICATION")
                }
            )
        }

        // Category 6: Read-only Device Information, Time & Battery (no approval required)
        if (lower.contains("battery") ||
            lower.contains("storage") ||
            lower.contains("device info") ||
            lower.contains("network status") ||
            Regex("\\b(what time is it|current time|what'?s the time|tell me the time|what'?s today'?s date|current date)\\b").containsMatchIn(stripped)
        ) {
            val snapshot = phoneController.readDeviceInfoSnapshot()
            val reply = when {
                Regex("\\b(time|date)\\b").containsMatchIn(stripped) && !lower.contains("battery") ->
                    "Local time and date: ${snapshot.formattedDateTime}."
                lower.contains("battery") ->
                    "Battery is ${snapshot.batteryPercent}% (${if (snapshot.isCharging) "charging" else "on battery"})."
                else -> snapshot.toSummaryText()
            }
            registry.markExecutionFinish(AssistantId.MAGMITE, success = true, responseMs = System.currentTimeMillis() - startedAt)
            registry.updateStatus(AssistantId.SK, AssistantStatus.ONLINE)
            return SkRouteOutcome.DirectResponse(
                speaker = AssistantId.MAGMITE,
                category = IntentCategory.DEVICE_INFORMATION_READ,
                replyText = reply,
                outputPayload = snapshot.toPayloadMap(),
                exactOperation = "READ_DEVICE_INFO"
            )
        }

        return null
    }

    private suspend fun prepareCommunicationOutcome(
        isSms: Boolean,
        contactQuery: String,
        messageBody: String?,
        rawInput: String
    ): SkRouteOutcome {
        val op = if (isSms) "PREPARE_SMS" else "CALL_CONTACT"
        val requiredPerms = if (isSms) {
            listOf(Manifest.permission.READ_CONTACTS, Manifest.permission.SEND_SMS)
        } else {
            listOf(Manifest.permission.READ_CONTACTS, Manifest.permission.CALL_PHONE, Manifest.permission.READ_PHONE_STATE)
        }

        if (!permissionGuard.isGranted(Manifest.permission.READ_CONTACTS)) {
            val req = AssistantCommandRequest(
                commandId = "cmd-${UUID.randomUUID().toString().take(10)}",
                rawInput = rawInput,
                targetAssistant = AssistantId.MAGMITE,
                intentAction = op,
                parameters = buildMap {
                    put("contactName", contactQuery)
                    if (!messageBody.isNullOrBlank()) put("message", messageBody)
                },
                requiredPermissions = requiredPerms,
                riskLevel = RiskLevel.HIGH,
                rationale = "${if (isSms) "Message" else "Call"} contact \"$contactQuery\" (requires Contacts permission before lookup)"
            )
            val outcome = createDeduplicatedProposal(req)
            return SkRouteOutcome.ProposalRequired(outcome.proposal, outcome.deduplicated)
        }

        val candidates = phoneController.searchContactsByName(contactQuery)
        if (candidates.size > 1) {
            return SkRouteOutcome.ContactSelectionRequired(
                actionType = op,
                queryName = contactQuery,
                candidates = candidates,
                messageBody = messageBody,
                rawInput = rawInput
            )
        }

        val chosen = candidates.firstOrNull()
        if (!isSms && chosen != null) {
            val sims = phoneController.getAvailableSimOptions()
            if (sims.size > 1) {
                return SkRouteOutcome.SimSelectionRequired(
                    contactName = chosen.displayName,
                    phoneNumber = chosen.phoneNumber,
                    simOptions = sims,
                    rawInput = rawInput
                )
            }
        }

        val req = AssistantCommandRequest(
            commandId = "cmd-${UUID.randomUUID().toString().take(10)}",
            rawInput = rawInput,
            targetAssistant = AssistantId.MAGMITE,
            intentAction = op,
            parameters = buildMap {
                put("contactName", chosen?.displayName ?: contactQuery)
                if (chosen != null) put("phoneNumber", chosen.phoneNumber)
                if (!messageBody.isNullOrBlank()) put("message", messageBody)
            },
            requiredPermissions = if (isSms) listOf(Manifest.permission.SEND_SMS) else listOf(Manifest.permission.CALL_PHONE),
            riskLevel = RiskLevel.HIGH,
            rationale = "${if (isSms) "Send SMS to" else "Call"} ${chosen?.displayName ?: contactQuery}${chosen?.let { " (${it.phoneNumber})" } ?: ""}"
        )
        val outcome = createDeduplicatedProposal(req)
        return SkRouteOutcome.ProposalRequired(outcome.proposal, outcome.deduplicated)
    }

    suspend fun createProposalForResolvedContact(
        actionType: String,
        candidate: ContactCandidate,
        simOption: SimAccountOption?,
        messageBody: String?,
        rawInput: String
    ): SkRouteOutcome {
        val isSms = actionType.uppercase().contains("SMS")
        if (!isSms && simOption == null) {
            val sims = phoneController.getAvailableSimOptions()
            if (sims.size > 1) {
                return SkRouteOutcome.SimSelectionRequired(
                    contactName = candidate.displayName,
                    phoneNumber = candidate.phoneNumber,
                    simOptions = sims,
                    rawInput = rawInput
                )
            }
        }
        val req = AssistantCommandRequest(
            commandId = "cmd-${UUID.randomUUID().toString().take(10)}",
            rawInput = rawInput,
            targetAssistant = AssistantId.MAGMITE,
            intentAction = actionType,
            parameters = buildMap {
                put("contactName", candidate.displayName)
                put("phoneNumber", candidate.phoneNumber)
                if (!messageBody.isNullOrBlank()) put("message", messageBody)
                if (simOption != null) {
                    put("simSlot", "SIM ${simOption.slotIndex} (${simOption.carrierName})")
                    put("subscriptionId", simOption.subscriptionId.toString())
                    simOption.phoneAccountHandleId?.let { put("phoneAccountHandleId", it) }
                }
            },
            requiredPermissions = if (isSms) listOf(Manifest.permission.SEND_SMS) else listOf(Manifest.permission.CALL_PHONE),
            riskLevel = RiskLevel.HIGH,
            rationale = "${if (isSms) "Send SMS to" else "Call"} ${candidate.displayName} (${candidate.phoneNumber})${simOption?.let { " via SIM ${it.slotIndex} (${it.carrierName})" } ?: ""}"
        )
        val outcome = createDeduplicatedProposal(req)
        return SkRouteOutcome.ProposalRequired(outcome.proposal, outcome.deduplicated)
    }

    private suspend fun createDeduplicatedProposal(request: AssistantCommandRequest): com.projectomega.sk.core.approval.CreateProposalOutcome {
        val targetState = registry.states.value[request.targetAssistant]
        if (targetState == null || !targetState.isEnabled) {
            val msg = "Assistant ${request.targetAssistant.name} is currently disabled or unregistered."
            emitAlert(AlertSeverity.WARNING, AssistantId.SK, "Delegation Blocked", msg)
            throw IllegalStateException(msg)
        }
        val outcome = approvalManager.createOrReuseProposal(request)
        registry.syncPendingCounts(approvalManager.pendingQueue.value)
        if (!outcome.deduplicated) {
            auditLogger.log(
                eventType = "PROPOSAL_CREATED",
                actor = AssistantId.SK,
                proposalId = outcome.proposal.proposalId,
                summary = "SK proposed ${outcome.proposal.exactOperation} -> ${outcome.proposal.targetAssistant.name} (hash=${outcome.proposal.payloadHash.take(10)})"
            )
        }
        return outcome
    }

    private fun extractContactTarget(raw: String): String? {
        val callMatch = Regex("\\b(?:call|dial|ring|phone)\\s+([a-zA-Z0-9 ._-]+)", RegexOption.IGNORE_CASE).find(raw)
        if (callMatch != null) return callMatch.groupValues[1].trim()
        val smsMatch = Regex("\\b(?:text|sms|message)\\s+([a-zA-Z0-9 ._-]+?)(?:\\s+(?:saying|that|:)|$)", RegexOption.IGNORE_CASE).find(raw)
        return smsMatch?.groupValues?.getOrNull(1)?.trim()
    }

    suspend fun approveAndExecute(proposal: TaskProposal): AssistantExecutionResult {
        if (!approvalManager.acquireExecutionLock(proposal.proposalId)) {
            return AssistantExecutionResult.Denied(proposal.proposalId, "Task execution already in progress.")
        }
        val startedAt = System.currentTimeMillis()
        try {
            val missing = permissionGuard.checkPermissions(proposal.requiredPermissions)
            if (missing.isNotEmpty()) {
                emitAlert(
                    AlertSeverity.WARNING,
                    proposal.targetAssistant,
                    "Android Permission Required",
                    "${proposal.targetAssistant.name} requires ${missing.joinToString()} before execution."
                )
                auditLogger.log(
                    eventType = "PERMISSION_MISSING",
                    actor = AssistantId.SK,
                    proposalId = proposal.proposalId,
                    summary = "Blocked execution; missing permissions: ${missing.joinToString()}"
                )
                return AssistantExecutionResult.PermissionMissing(
                    proposalId = proposal.proposalId,
                    assistantId = proposal.targetAssistant,
                    missingPermissions = missing
                )
            }

            val token = runCatching {
                approvalManager.approveProposal(proposal.proposalId, proposal.payloadHash)
            }.getOrElse { secErr ->
                emitAlert(AlertSeverity.CRITICAL, AssistantId.SK, "Approval Integrity Error", secErr.message ?: "Security check failed")
                auditLogger.log("APPROVAL_REJECTED", AssistantId.SK, proposal.proposalId, secErr.message ?: "Integrity error")
                return AssistantExecutionResult.Denied(proposal.proposalId, secErr.message ?: "Approval integrity failure")
            }

            auditLogger.log(
                eventType = "TASK_APPROVED",
                actor = AssistantId.SK,
                proposalId = proposal.proposalId,
                summary = "User explicitly approved ${proposal.exactOperation} for ${proposal.targetAssistant.name}"
            )

            val module = registry.getModule(proposal.targetAssistant)
                ?: return AssistantExecutionResult.Failure(
                    proposal.proposalId,
                    proposal.targetAssistant,
                    "${proposal.targetAssistant.name} module unavailable."
                )

            registry.markExecutionStart(proposal.targetAssistant, proposal.exactOperation)
            val result = module.execute(proposal, token)
            val elapsed = System.currentTimeMillis() - startedAt
            registry.syncPendingCounts(approvalManager.pendingQueue.value)

            when (result) {
                is AssistantExecutionResult.Success -> {
                    registry.markExecutionFinish(proposal.targetAssistant, success = true, responseMs = elapsed)
                    taskHistoryDao.upsert(
                        TaskHistoryEntity(
                            proposalId = proposal.proposalId,
                            targetAssistant = proposal.targetAssistant.name,
                            rawInput = proposal.rawInput,
                            exactOperation = proposal.exactOperation,
                            status = "COMPLETED",
                            resultSummary = result.summary,
                            timestampEpochMs = result.executedAtEpochMs
                        )
                    )
                    auditLogger.log(
                        eventType = "TASK_EXECUTED",
                        actor = proposal.targetAssistant,
                        proposalId = proposal.proposalId,
                        summary = result.summary
                    )
                }

                is AssistantExecutionResult.Denied -> {
                    registry.markExecutionFinish(proposal.targetAssistant, success = false, responseMs = elapsed, errorMessage = result.reason)
                    taskHistoryDao.upsert(
                        TaskHistoryEntity(
                            proposalId = proposal.proposalId,
                            targetAssistant = proposal.targetAssistant.name,
                            rawInput = proposal.rawInput,
                            exactOperation = proposal.exactOperation,
                            status = "DENIED",
                            resultSummary = result.reason,
                            timestampEpochMs = System.currentTimeMillis()
                        )
                    )
                    emitAlert(AlertSeverity.WARNING, proposal.targetAssistant, "Execution Denied", result.reason)
                }

                is AssistantExecutionResult.PermissionMissing -> {
                    registry.markExecutionFinish(proposal.targetAssistant, success = false, responseMs = elapsed, errorMessage = "Missing permissions")
                    emitAlert(
                        AlertSeverity.WARNING,
                        proposal.targetAssistant,
                        "Permission Missing",
                        "Missing: ${result.missingPermissions.joinToString()}"
                    )
                }

                is AssistantExecutionResult.Failure -> {
                    registry.markExecutionFinish(proposal.targetAssistant, success = false, responseMs = elapsed, errorMessage = result.errorMessage)
                    taskHistoryDao.upsert(
                        TaskHistoryEntity(
                            proposalId = proposal.proposalId,
                            targetAssistant = proposal.targetAssistant.name,
                            rawInput = proposal.rawInput,
                            exactOperation = proposal.exactOperation,
                            status = "FAILED",
                            resultSummary = result.errorMessage,
                            timestampEpochMs = System.currentTimeMillis()
                        )
                    )
                    emitAlert(AlertSeverity.ERROR, proposal.targetAssistant, "Execution Failure", result.errorMessage)
                    auditLogger.log("TASK_FAILED", proposal.targetAssistant, proposal.proposalId, result.errorMessage)
                }
            }

            return result
        } finally {
            approvalManager.releaseExecutionLock(proposal.proposalId)
        }
    }

    suspend fun rejectProposal(proposalId: String, reason: String = "Rejected by user") {
        val removed = approvalManager.rejectProposal(proposalId)
        registry.syncPendingCounts(approvalManager.pendingQueue.value)
        if (removed != null) {
            taskHistoryDao.upsert(
                TaskHistoryEntity(
                    proposalId = removed.proposalId,
                    targetAssistant = removed.targetAssistant.name,
                    rawInput = removed.rawInput,
                    exactOperation = removed.exactOperation,
                    status = "REJECTED",
                    resultSummary = reason,
                    timestampEpochMs = System.currentTimeMillis()
                )
            )
            auditLogger.log(
                eventType = "TASK_REJECTED",
                actor = AssistantId.SK,
                proposalId = proposalId,
                summary = "User denied ${removed.exactOperation} for ${removed.targetAssistant.name}: $reason"
            )
        }
    }

    suspend fun generatePeriodicSystemReport(periodLabel: String = "On-Demand Telemetry Window"): SystemReport {
        val history = taskHistoryDao.getAll()
        val approved = history.count { it.status == "COMPLETED" }
        val rejected = history.count { it.status == "REJECTED" || it.status == "DENIED" }
        val failed = history.count { it.status == "FAILED" }
        val active = registry.states.value.values
            .filter { it.isEnabled && it.profile.id != AssistantId.SK }
            .map { it.profile.id }

        val narrative = runCatching {
            aiProvider.synthesizeSystemReport(
                totalCommands = history.size,
                approvedTasks = approved,
                rejectedTasks = rejected,
                failedTasks = failed,
                activeAssistants = active
            )
        }.getOrElse {
            "SK telemetry summary: ${history.size} total tasks ($approved completed, $rejected rejected, $failed failed). Active assistants: ${active.joinToString()}."
        }

        val report = SystemReport(
            reportId = "rep-${UUID.randomUUID().toString().take(8)}",
            generatedAtEpochMs = System.currentTimeMillis(),
            periodLabel = periodLabel,
            totalCommands = history.size,
            approvedTasks = approved,
            rejectedTasks = rejected,
            failedTasks = failed,
            activeAssistants = active,
            narrativeSummary = narrative
        )

        systemReportDao.insert(
            SystemReportEntity(
                reportId = report.reportId,
                generatedAtEpochMs = report.generatedAtEpochMs,
                periodLabel = report.periodLabel,
                totalCommands = report.totalCommands,
                approvedTasks = report.approvedTasks,
                rejectedTasks = report.rejectedTasks,
                failedTasks = report.failedTasks,
                activeAssistantsCsv = report.activeAssistants.joinToString(",") { it.name },
                narrativeSummary = report.narrativeSummary
            )
        )

        auditLogger.log("REPORT_GENERATED", AssistantId.SK, null, "Generated SK periodic system report ${report.reportId}")
        return report
    }

    fun emitAlert(severity: AlertSeverity, source: AssistantId, title: String, message: String) {
        val alert = SystemAlert(
            alertId = "alt-${UUID.randomUUID().toString().take(8)}",
            severity = severity,
            source = source,
            title = title,
            message = message,
            createdAtEpochMs = System.currentTimeMillis()
        )
        _alerts.update { listOf(alert) + it.take(24) }
    }

    fun acknowledgeAlert(alertId: String) {
        _alerts.update { list ->
            list.map { if (it.alertId == alertId) it.copy(acknowledged = true) else it }
        }
    }
}
