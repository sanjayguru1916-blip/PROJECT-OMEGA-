package com.projectomega.sk.sk.worker

import android.content.Context
import androidx.work.CoroutineWorker
import androidx.work.ExistingPeriodicWorkPolicy
import androidx.work.PeriodicWorkRequestBuilder
import androidx.work.WorkManager
import androidx.work.WorkerParameters
import com.projectomega.sk.OmegaApplication
import java.util.concurrent.TimeUnit

class SkPeriodicReportWorker(
    appContext: Context,
    params: WorkerParameters
) : CoroutineWorker(appContext, params) {

    override suspend fun doWork(): Result {
        val app = applicationContext as? OmegaApplication ?: return Result.failure()
        return runCatching {
            app.container.registry.runHealthSweep()
            app.container.skMasterCore.generatePeriodicSystemReport("6-Hour Periodic Report")
            Result.success()
        }.getOrElse {
            Result.retry()
        }
    }

    companion object {
        private const val WORK_NAME = "sk_periodic_system_report"

        fun schedule(context: Context) {
            val request = PeriodicWorkRequestBuilder<SkPeriodicReportWorker>(6, TimeUnit.HOURS)
                .build()
            WorkManager.getInstance(context).enqueueUniquePeriodicWork(
                WORK_NAME,
                ExistingPeriodicWorkPolicy.KEEP,
                request
            )
        }
    }
}
