package com.projectomega.sk.assistants.magmite

import android.Manifest
import android.annotation.SuppressLint
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.PackageManager
import android.media.AudioManager
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import android.net.Uri
import android.os.BatteryManager
import android.os.Build
import android.os.Environment
import android.os.StatFs
import android.os.SystemClock
import android.provider.AlarmClock
import android.provider.ContactsContract
import android.provider.MediaStore
import android.provider.Settings
import android.telecom.PhoneAccountHandle
import android.telecom.TelecomManager
import android.telephony.SmsManager
import android.telephony.SubscriptionManager
import android.view.KeyEvent
import com.projectomega.sk.core.model.ContactCandidate
import com.projectomega.sk.core.model.SimAccountOption
import com.projectomega.sk.core.security.AndroidPermissionGuard
import com.projectomega.sk.ui.MainActivity
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

data class DeviceInfoSnapshot(
    val batteryPercent: Int,
    val isCharging: Boolean,
    val networkTransport: String,
    val storageFreeGb: String,
    val storageTotalGb: String,
    val deviceModel: String,
    val androidVersion: String,
    val formattedDateTime: String
) {
    fun toSummaryText(): String {
        val chargingLabel = if (isCharging) "charging" else "on battery"
        return "Battery is $batteryPercent% ($chargingLabel). Network: $networkTransport. " +
            "Storage: $storageFreeGb GB free of $storageTotalGb GB. Device: $deviceModel (Android $androidVersion). " +
            "Local time: $formattedDateTime."
    }

    fun toPayloadMap(): Map<String, String> = mapOf(
        "batteryPercent" to batteryPercent.toString(),
        "isCharging" to isCharging.toString(),
        "networkTransport" to networkTransport,
        "storageFreeGb" to storageFreeGb,
        "storageTotalGb" to storageTotalGb,
        "deviceModel" to deviceModel,
        "androidVersion" to androidVersion,
        "localDateTime" to formattedDateTime
    )
}

/**
 * Real Android device controller used strictly under MAGMITE + AndroidPermissionGuard + SK ApprovalManager.
 * Performs real PackageManager resolution, ContactsContract queries, Dual-SIM detection,
 * TelecomManager calling, SmsManager/ACTION_SENDTO messaging, Battery/Storage reads, and OS Settings panels.
 */
class AndroidPhoneController(
    private val context: Context,
    private val permissionGuard: AndroidPermissionGuard
) {

    fun readDeviceInfoSnapshot(): DeviceInfoSnapshot {
        val batteryIntent = context.registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
        val level = batteryIntent?.getIntExtra(BatteryManager.EXTRA_LEVEL, -1) ?: -1
        val scale = batteryIntent?.getIntExtra(BatteryManager.EXTRA_SCALE, 100) ?: 100
        val bm = context.getSystemService(Context.BATTERY_SERVICE) as? BatteryManager
        val pct = if (level >= 0 && scale > 0) (level * 100) / scale
        else bm?.getIntProperty(BatteryManager.BATTERY_PROPERTY_CAPACITY) ?: -1

        val status = batteryIntent?.getIntExtra(BatteryManager.EXTRA_STATUS, -1) ?: -1
        val isCharging = status == BatteryManager.BATTERY_STATUS_CHARGING ||
            status == BatteryManager.BATTERY_STATUS_FULL

        val cm = context.getSystemService(Context.CONNECTIVITY_SERVICE) as? ConnectivityManager
        val caps = cm?.getNetworkCapabilities(cm.activeNetwork)
        val networkTransport = when {
            caps == null -> "Offline"
            caps.hasTransport(NetworkCapabilities.TRANSPORT_WIFI) -> "Wi-Fi"
            caps.hasTransport(NetworkCapabilities.TRANSPORT_CELLULAR) -> "Cellular"
            caps.hasTransport(NetworkCapabilities.TRANSPORT_ETHERNET) -> "Ethernet"
            else -> "Connected"
        }

        val statFs = StatFs(Environment.getDataDirectory().path)
        val freeGb = "%.2f".format(statFs.availableBytes / (1024.0 * 1024.0 * 1024.0))
        val totalGb = "%.2f".format(statFs.totalBytes / (1024.0 * 1024.0 * 1024.0))
        val nowFormatted = SimpleDateFormat("EEEE, MMM d yyyy h:mm a", Locale.getDefault()).format(Date())

        return DeviceInfoSnapshot(
            batteryPercent = pct.coerceIn(0, 100),
            isCharging = isCharging,
            networkTransport = networkTransport,
            storageFreeGb = freeGb,
            storageTotalGb = totalGb,
            deviceModel = "${Build.MANUFACTURER} ${Build.MODEL}".trim(),
            androidVersion = Build.VERSION.RELEASE ?: Build.VERSION.SDK_INT.toString(),
            formattedDateTime = nowFormatted
        )
    }

    fun launchInstalledAppByName(appQuery: String): Result<String> {
        val cleanQuery = appQuery.trim().lowercase()
        if (cleanQuery.isEmpty()) {
            return Result.failure(IllegalArgumentException("No application name specified."))
        }
        if (cleanQuery.contains("omega") || cleanQuery == "sk" || cleanQuery == "sk master") {
            return returnToProjectOmega()
        }
        if (cleanQuery.contains("settings") || cleanQuery == "device settings") {
            return openSettingsPanel(Settings.ACTION_SETTINGS, "Android system settings")
        }
        if (cleanQuery.contains("camera")) {
            return openCameraApp()
        }

        val pm = context.packageManager
        val aliasPackages = when {
            cleanQuery.contains("whatsapp") -> listOf("com.whatsapp", "com.whatsapp.w4b")
            cleanQuery.contains("youtube") -> listOf("com.google.android.youtube")
            cleanQuery.contains("spotify") -> listOf("com.spotify.music")
            cleanQuery.contains("chrome") -> listOf("com.android.chrome")
            cleanQuery.contains("gmail") -> listOf("com.google.android.gm")
            cleanQuery.contains("maps") -> listOf("com.google.android.apps.maps")
            else -> emptyList()
        }
        for (pkg in aliasPackages) {
            val aliasLaunch = pm.getLaunchIntentForPackage(pkg)
            if (aliasLaunch != null) {
                aliasLaunch.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                context.startActivity(aliasLaunch)
                return Result.success("Opening ${appQuery.trim()}.")
            }
        }

        val launcherIntent = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        val activities = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            pm.queryIntentActivities(launcherIntent, PackageManager.ResolveInfoFlags.of(0))
        } else {
            @Suppress("DEPRECATION")
            pm.queryIntentActivities(launcherIntent, 0)
        }

        val matched = activities.firstOrNull { resolve ->
            val label = resolve.loadLabel(pm)?.toString()?.lowercase().orEmpty()
            val pkg = resolve.activityInfo.packageName.lowercase()
            label == cleanQuery || label.contains(cleanQuery) || pkg.contains(cleanQuery)
        }

        if (matched != null) {
            val pkgName = matched.activityInfo.packageName
            val launch = pm.getLaunchIntentForPackage(pkgName)
            if (launch != null) {
                launch.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                context.startActivity(launch)
                val appLabel = matched.loadLabel(pm)?.toString() ?: pkgName
                return Result.success("Opened $appLabel.")
            }
        }

        return Result.failure(
            IllegalStateException("Application \"$appQuery\" is not installed or unavailable for launch on this device.")
        )
    }

    fun showInstalledApplications(): Result<String> {
        val pm = context.packageManager
        val launcherIntent = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        val activities = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            pm.queryIntentActivities(launcherIntent, PackageManager.ResolveInfoFlags.of(0))
        } else {
            @Suppress("DEPRECATION")
            pm.queryIntentActivities(launcherIntent, 0)
        }
        val names = activities
            .mapNotNull { it.loadLabel(pm)?.toString()?.trim() }
            .filter { it.isNotEmpty() }
            .distinct()
            .sorted()
        return if (names.isEmpty()) {
            Result.failure(IllegalStateException("No launchable applications detected."))
        } else {
            val preview = names.take(12).joinToString(", ")
            Result.success("${names.size} installed apps detected: $preview.")
        }
    }

    fun controlMediaPlayback(action: String, query: String? = null): Result<String> {
        val audioManager = context.getSystemService(Context.AUDIO_SERVICE) as? AudioManager
            ?: return Result.failure(IllegalStateException("Android Audio service unavailable."))

        val keyCode = when (action.uppercase()) {
            "PLAY_MUSIC", "RESUME_MUSIC" -> KeyEvent.KEYCODE_MEDIA_PLAY
            "PAUSE_MUSIC" -> KeyEvent.KEYCODE_MEDIA_PAUSE
            "STOP_MUSIC" -> KeyEvent.KEYCODE_MEDIA_STOP
            "NEXT_TRACK" -> KeyEvent.KEYCODE_MEDIA_NEXT
            "PREVIOUS_TRACK" -> KeyEvent.KEYCODE_MEDIA_PREVIOUS
            else -> KeyEvent.KEYCODE_MEDIA_PLAY_PAUSE
        }

        if (!query.isNullOrBlank() && (keyCode == KeyEvent.KEYCODE_MEDIA_PLAY || keyCode == KeyEvent.KEYCODE_MEDIA_PLAY_PAUSE)) {
            val searchIntent = Intent(MediaStore.INTENT_ACTION_MEDIA_PLAY_FROM_SEARCH).apply {
                putExtra(MediaStore.EXTRA_MEDIA_FOCUS, "vnd.android.cursor.item/*")
                putExtra(android.app.SearchManager.QUERY, query)
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            if (searchIntent.resolveActivity(context.packageManager) != null) {
                context.startActivity(searchIntent)
                return Result.success("Playing music for \"$query\".")
            }
        }

        val eventTime = SystemClock.uptimeMillis()
        audioManager.dispatchMediaKeyEvent(KeyEvent(eventTime, eventTime, KeyEvent.ACTION_DOWN, keyCode, 0))
        audioManager.dispatchMediaKeyEvent(KeyEvent(eventTime, eventTime, KeyEvent.ACTION_UP, keyCode, 0))

        return when (keyCode) {
            KeyEvent.KEYCODE_MEDIA_PLAY -> {
                if (!audioManager.isMusicActive) {
                    val pm = context.packageManager
                    val musicIntent = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_APP_MUSIC)
                        .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                    if (musicIntent.resolveActivity(pm) != null) {
                        context.startActivity(musicIntent)
                        return Result.success("Opened default Music player and started playback.")
                    }
                    val spotify = pm.getLaunchIntentForPackage("com.spotify.music")
                    if (spotify != null) {
                        spotify.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                        context.startActivity(spotify)
                        return Result.success("Opened Spotify to resume music playback.")
                    }
                }
                Result.success("Playing music.")
            }
            KeyEvent.KEYCODE_MEDIA_PAUSE -> Result.success("Music playback paused.")
            KeyEvent.KEYCODE_MEDIA_STOP -> Result.success("Music playback stopped.")
            KeyEvent.KEYCODE_MEDIA_NEXT -> Result.success("Skipped to next track.")
            KeyEvent.KEYCODE_MEDIA_PREVIOUS -> Result.success("Returned to previous track.")
            else -> Result.success("Toggled music playback.")
        }
    }

    fun returnToProjectOmega(): Result<String> {
        val intent = Intent(context, MainActivity::class.java).apply {
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_REORDER_TO_FRONT or Intent.FLAG_ACTIVITY_SINGLE_TOP)
        }
        context.startActivity(intent)
        return Result.success("Returned to Project Omega SK interface.")
    }

    fun openCameraApp(): Result<String> {
        val intent = Intent(MediaStore.ACTION_IMAGE_CAPTURE).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        return if (intent.resolveActivity(context.packageManager) != null) {
            context.startActivity(intent)
            Result.success("Opened Android Camera interface.")
        } else {
            Result.failure(IllegalStateException("No camera application found on this device."))
        }
    }

    fun openAlarmApp(
        hour: Int? = null,
        minute: Int? = null,
        message: String? = null
    ): Result<String> {
        val intent = Intent(AlarmClock.ACTION_SET_ALARM).apply {
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            if (hour != null && hour in 0..23) {
                putExtra(AlarmClock.EXTRA_HOUR, hour)
                putExtra(AlarmClock.EXTRA_MINUTES, (minute ?: 0).coerceIn(0, 59))
                putExtra(AlarmClock.EXTRA_SKIP_UI, false)
            }
            if (!message.isNullOrBlank()) {
                putExtra(AlarmClock.EXTRA_MESSAGE, message)
            }
        }
        return if (intent.resolveActivity(context.packageManager) != null) {
            context.startActivity(intent)
            if (hour != null) {
                Result.success("Alarm prepared for %02d:%02d.".format(hour, (minute ?: 0).coerceIn(0, 59)))
            } else {
                Result.success("Opened Android Clock / Alarm interface.")
            }
        } else {
            Result.failure(IllegalStateException("No alarm application available on this device."))
        }
    }

    fun openSettingsPanel(action: String, label: String): Result<String> {
        val intent = if (action == Settings.Panel.ACTION_WIFI && Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            Intent(Settings.Panel.ACTION_WIFI)
        } else if (action == Settings.Panel.ACTION_WIFI) {
            Intent(Settings.ACTION_WIFI_SETTINGS)
        } else {
            Intent(action)
        }.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        context.startActivity(intent)
        return Result.success("Opened Android $label for explicit user control.")
    }

    fun searchContactsByName(nameQuery: String): List<ContactCandidate> {
        if (!permissionGuard.isGranted(Manifest.permission.READ_CONTACTS)) {
            return emptyList()
        }
        val clean = nameQuery.trim()
        if (clean.isEmpty()) return emptyList()

        val candidates = mutableListOf<ContactCandidate>()
        val seenNumbers = mutableSetOf<String>()
        val projection = arrayOf(
            ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME,
            ContactsContract.CommonDataKinds.Phone.NUMBER,
            ContactsContract.CommonDataKinds.Phone.TYPE
        )
        val selection = "${ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME} LIKE ?"
        val selectionArgs = arrayOf("%$clean%")

        context.contentResolver.query(
            ContactsContract.CommonDataKinds.Phone.CONTENT_URI,
            projection,
            selection,
            selectionArgs,
            "${ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME} ASC"
        )?.use { cursor ->
            val nameIdx = cursor.getColumnIndexOrThrow(ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME)
            val numIdx = cursor.getColumnIndexOrThrow(ContactsContract.CommonDataKinds.Phone.NUMBER)
            val typeIdx = cursor.getColumnIndexOrThrow(ContactsContract.CommonDataKinds.Phone.TYPE)

            while (cursor.moveToNext() && candidates.size < 8) {
                val displayName = cursor.getString(nameIdx)?.trim().orEmpty()
                val rawNumber = cursor.getString(numIdx)?.trim().orEmpty()
                val typeCode = cursor.getInt(typeIdx)
                val normalizedNum = rawNumber.replace(Regex("[\\s()-]"), "")
                if (displayName.isNotEmpty() && rawNumber.isNotEmpty() && seenNumbers.add(normalizedNum)) {
                    val label = ContactsContract.CommonDataKinds.Phone.getTypeLabel(
                        context.resources,
                        typeCode,
                        "Mobile"
                    ).toString()
                    candidates.add(ContactCandidate(displayName = displayName, phoneNumber = rawNumber, label = label))
                }
            }
        }
        return candidates
    }

    @SuppressLint("MissingPermission")
    fun getAvailableSimOptions(): List<SimAccountOption> {
        if (!permissionGuard.isGranted(Manifest.permission.READ_PHONE_STATE)) {
            return emptyList()
        }
        val options = mutableListOf<SimAccountOption>()
        val subManager = context.getSystemService(Context.TELEPHONY_SUBSCRIPTION_SERVICE) as? SubscriptionManager
        val telecomManager = context.getSystemService(Context.TELECOM_SERVICE) as? TelecomManager
        val activeSubs = runCatching { subManager?.activeSubscriptionInfoList.orEmpty() }.getOrDefault(emptyList())
        val phoneAccounts = runCatching { telecomManager?.callCapablePhoneAccounts.orEmpty() }.getOrDefault(emptyList())

        activeSubs.forEachIndexed { idx, info ->
            val handle = phoneAccounts.getOrNull(idx)
            options.add(
                SimAccountOption(
                    slotIndex = info.simSlotIndex + 1,
                    displayName = info.displayName?.toString().orEmpty().ifBlank { "SIM ${info.simSlotIndex + 1}" },
                    carrierName = info.carrierName?.toString().orEmpty().ifBlank { "Carrier ${info.simSlotIndex + 1}" },
                    subscriptionId = info.subscriptionId,
                    phoneAccountHandleId = handle?.id
                )
            )
        }
        return options
    }

    @SuppressLint("MissingPermission")
    fun placePhoneCall(
        phoneNumber: String,
        contactName: String,
        phoneAccountHandleId: String? = null
    ): Result<String> {
        val cleanNum = phoneNumber.trim()
        if (cleanNum.isEmpty()) {
            return Result.failure(IllegalArgumentException("Phone number is required to place a call."))
        }
        val uri = Uri.parse("tel:${Uri.encode(cleanNum)}")

        if (permissionGuard.isGranted(Manifest.permission.CALL_PHONE)) {
            val intent = Intent(Intent.ACTION_CALL, uri).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            if (!phoneAccountHandleId.isNullOrBlank() && permissionGuard.isGranted(Manifest.permission.READ_PHONE_STATE)) {
                val telecom = context.getSystemService(Context.TELECOM_SERVICE) as? TelecomManager
                val matchingHandle: PhoneAccountHandle? = telecom?.callCapablePhoneAccounts
                    ?.firstOrNull { it.id == phoneAccountHandleId }
                if (matchingHandle != null) {
                    intent.putExtra(TelecomManager.EXTRA_PHONE_ACCOUNT_HANDLE, matchingHandle)
                }
            }
            context.startActivity(intent)
            return Result.success("Placing approved call to $contactName ($cleanNum).")
        }

        // Safe fallback to OS dialer if CALL_PHONE is withheld by user
        val dialIntent = Intent(Intent.ACTION_DIAL, uri).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        context.startActivity(dialIntent)
        return Result.success("Opened Android Dialer for $contactName ($cleanNum).")
    }

    @Suppress("DEPRECATION")
    fun sendOrPrepareSms(
        phoneNumber: String,
        contactName: String,
        messageBody: String,
        subscriptionId: Int? = null
    ): Result<String> {
        val cleanNum = phoneNumber.trim()
        if (cleanNum.isEmpty()) {
            return Result.failure(IllegalArgumentException("Recipient phone number is required for SMS."))
        }

        if (permissionGuard.isGranted(Manifest.permission.SEND_SMS) && messageBody.isNotBlank()) {
            val smsManager: SmsManager = if (subscriptionId != null && subscriptionId >= 0) {
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                    context.getSystemService(SmsManager::class.java).createForSubscriptionId(subscriptionId)
                } else {
                    SmsManager.getSmsManagerForSubscriptionId(subscriptionId)
                }
            } else if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                context.getSystemService(SmsManager::class.java)
            } else {
                SmsManager.getDefault()
            }
            val parts = smsManager.divideMessage(messageBody)
            if (parts.size > 1) {
                smsManager.sendMultipartTextMessage(cleanNum, null, parts, null, null)
            } else {
                smsManager.sendTextMessage(cleanNum, null, messageBody, null, null)
            }
            return Result.success("Sent approved SMS to $contactName ($cleanNum).")
        }

        val smsIntent = Intent(Intent.ACTION_SENDTO, Uri.parse("smsto:${Uri.encode(cleanNum)}")).apply {
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            if (messageBody.isNotBlank()) {
                putExtra("sms_body", messageBody)
            }
        }
        context.startActivity(smsIntent)
        return Result.success("Prepared SMS draft to $contactName ($cleanNum) in Messages.")
    }

    fun prepareWhatsAppMessage(
        phoneNumber: String,
        contactName: String,
        messageBody: String
    ): Result<String> {
        val pm = context.packageManager
        val waPkg = listOf("com.whatsapp", "com.whatsapp.w4b").firstOrNull {
            pm.getLaunchIntentForPackage(it) != null
        } ?: return Result.failure(IllegalStateException("WhatsApp is not installed on this device."))

        val cleanNum = phoneNumber.replace(Regex("[^+0-9]"), "")
        if (cleanNum.isNotBlank()) {
            val encodedText = Uri.encode(messageBody)
            val uri = Uri.parse("https://api.whatsapp.com/send?phone=$cleanNum&text=$encodedText")
            val waIntent = Intent(Intent.ACTION_VIEW, uri).apply {
                setPackage(waPkg)
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            if (waIntent.resolveActivity(pm) != null) {
                context.startActivity(waIntent)
                return Result.success("Opened approved WhatsApp chat with $contactName.")
            }
        }

        val shareIntent = Intent(Intent.ACTION_SEND).apply {
            type = "text/plain"
            setPackage(waPkg)
            putExtra(Intent.EXTRA_TEXT, messageBody)
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        }
        context.startActivity(shareIntent)
        return Result.success("Opened WhatsApp to complete message to $contactName.")
    }

    fun prepareEmail(
        recipient: String,
        subject: String,
        body: String
    ): Result<String> {
        val mailIntent = Intent(Intent.ACTION_SENDTO).apply {
            data = Uri.parse("mailto:${Uri.encode(recipient.trim())}")
            if (subject.isNotBlank()) putExtra(Intent.EXTRA_SUBJECT, subject)
            if (body.isNotBlank()) putExtra(Intent.EXTRA_TEXT, body)
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        }
        return if (mailIntent.resolveActivity(context.packageManager) != null) {
            context.startActivity(mailIntent)
            Result.success("Opened approved email composer for $recipient.")
        } else {
            Result.failure(IllegalStateException("No email client installed on this device."))
        }
    }
}
