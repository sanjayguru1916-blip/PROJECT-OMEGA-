package com.projectomega.sk.assistants.magmite

import android.content.Context
import android.hardware.camera2.CameraCharacteristics
import android.hardware.camera2.CameraManager
import android.media.AudioManager
import android.provider.Settings
import com.projectomega.sk.core.approval.ApprovalManager
import com.projectomega.sk.core.model.ApprovalToken
import com.projectomega.sk.core.model.AssistantExecutionResult
import com.projectomega.sk.core.model.AssistantId
import com.projectomega.sk.core.model.AssistantProfile
import com.projectomega.sk.core.model.OmegaIdentityCatalog
import com.projectomega.sk.core.model.TaskProposal
import com.projectomega.sk.core.registry.AssistantModule
import com.projectomega.sk.core.security.AndroidPermissionGuard

/**
 * MAGMITE — Android Phone Controls & Device Operations Module.
 * Enforces explicit Android OS runtime permissions and uses official Settings Panels,
 * PackageManager, ContactsContract, TelecomManager, and SmsManager without bypassing OS security.
 */
class MagmiteAssistantModule(
    private val context: Context,
    private val permissionGuard: AndroidPermissionGuard,
    private val approvalManager: ApprovalManager,
    private val phoneController: AndroidPhoneController = AndroidPhoneController(context, permissionGuard)
) : AssistantModule {

    override val profile: AssistantProfile = OmegaIdentityCatalog.profiles.getValue(AssistantId.MAGMITE)

    override suspend fun healthCheck(): Boolean =
        context.getSystemService(Context.AUDIO_SERVICE) != null

    override suspend fun execute(
        proposal: TaskProposal,
        approvalToken: ApprovalToken
    ): AssistantExecutionResult {
        if (proposal.targetAssistant != AssistantId.MAGMITE) {
            return AssistantExecutionResult.Denied(proposal.proposalId, "Boundary violation: proposal targeted ${proposal.targetAssistant}.")
        }
        val missing = permissionGuard.checkPermissions(proposal.requiredPermissions)
        if (missing.isNotEmpty()) {
            return AssistantExecutionResult.PermissionMissing(
                proposalId = proposal.proposalId,
                assistantId = AssistantId.MAGMITE,
                missingPermissions = missing
            )
        }
        if (!approvalManager.consumeVerifiedToken(proposal, approvalToken)) {
            return AssistantExecutionResult.Denied(proposal.proposalId, "Invalid or already consumed approval token.")
        }

        return runCatching {
            when (proposal.exactOperation.uppercase()) {
                "TOGGLE_TORCH", "SET_FLASHLIGHT" -> handleTorch(proposal)
                "SET_VOLUME", "ADJUST_VOLUME" -> handleVolume(proposal)
                "SET_RINGER_MODE" -> handleRingerMode(proposal)
                "OPEN_WIFI_SETTINGS" -> {
                    val res = phoneController.openSettingsPanel(Settings.Panel.ACTION_WIFI, "Wi-Fi control panel")
                    mapControllerResult(proposal, res)
                }
                "OPEN_BLUETOOTH_SETTINGS" -> {
                    val res = phoneController.openSettingsPanel(Settings.ACTION_BLUETOOTH_SETTINGS, "Bluetooth settings")
                    mapControllerResult(proposal, res)
                }
                "OPEN_DEVICE_SETTINGS" -> {
                    val res = phoneController.openSettingsPanel(Settings.ACTION_SETTINGS, "Android system settings")
                    mapControllerResult(proposal, res)
                }
                "READ_DEVICE_POWER", "READ_DEVICE_INFO" -> {
                    val snapshot = phoneController.readDeviceInfoSnapshot()
                    AssistantExecutionResult.Success(
                        proposalId = proposal.proposalId,
                        assistantId = AssistantId.MAGMITE,
                        summary = snapshot.toSummaryText(),
                        outputPayload = snapshot.toPayloadMap()
                    )
                }
                "PLAY_MUSIC", "PAUSE_MUSIC", "RESUME_MUSIC", "STOP_MUSIC", "NEXT_TRACK", "PREVIOUS_TRACK" -> {
                    val query = proposal.parameters["query"]
                    mapControllerResult(proposal, phoneController.controlMediaPlayback(proposal.exactOperation, query))
                }
                "OPEN_APP", "OPEN_APPLICATION", "LAUNCH_APP", "OPEN_WHATSAPP", "OPEN_YOUTUBE" -> {
                    val appName = proposal.parameters["appName"] ?: when (proposal.exactOperation.uppercase()) {
                        "OPEN_WHATSAPP" -> "WhatsApp"
                        "OPEN_YOUTUBE" -> "YouTube"
                        else -> proposal.rawInput
                    }
                    mapControllerResult(proposal, phoneController.launchInstalledAppByName(appName))
                }
                "SHOW_APPLICATIONS" -> mapControllerResult(proposal, phoneController.showInstalledApplications())
                "RETURN_TO_OMEGA", "NORMAL_NAVIGATION" -> mapControllerResult(proposal, phoneController.returnToProjectOmega())
                "OPEN_CAMERA" -> mapControllerResult(proposal, phoneController.openCameraApp())
                "OPEN_ALARM", "SET_ALARM" -> {
                    val hr = proposal.parameters["hour"]?.toIntOrNull()
                    val min = proposal.parameters["minute"]?.toIntOrNull()
                    val label = proposal.parameters["label"] ?: proposal.parameters["message"]
                    mapControllerResult(proposal, phoneController.openAlarmApp(hr, min, label))
                }
                "CALL_CONTACT" -> {
                    val targetName = proposal.parameters["contactName"] ?: "Contact"
                    val number = proposal.parameters["phoneNumber"].orEmpty()
                    val accountId = proposal.parameters["phoneAccountHandleId"]
                    if (number.isBlank()) {
                        val matches = phoneController.searchContactsByName(targetName)
                        val first = matches.firstOrNull()
                        if (first == null) {
                            AssistantExecutionResult.Failure(
                                proposal.proposalId,
                                AssistantId.MAGMITE,
                                "No contact phone number found matching \"$targetName\"."
                            )
                        } else {
                            mapControllerResult(
                                proposal,
                                phoneController.placePhoneCall(first.phoneNumber, first.displayName, accountId)
                            )
                        }
                    } else {
                        mapControllerResult(proposal, phoneController.placePhoneCall(number, targetName, accountId))
                    }
                }
                "PREPARE_SMS", "SEND_SMS" -> {
                    val targetName = proposal.parameters["contactName"] ?: "Recipient"
                    val number = proposal.parameters["phoneNumber"].orEmpty()
                    val body = proposal.parameters["message"].orEmpty()
                    val subId = proposal.parameters["subscriptionId"]?.toIntOrNull()
                    if (number.isBlank()) {
                        val first = phoneController.searchContactsByName(targetName).firstOrNull()
                        if (first == null) {
                            AssistantExecutionResult.Failure(
                                proposal.proposalId,
                                AssistantId.MAGMITE,
                                "No contact phone number found matching \"$targetName\"."
                            )
                        } else {
                            mapControllerResult(
                                proposal,
                                phoneController.sendOrPrepareSms(first.phoneNumber, first.displayName, body, subId)
                            )
                        }
                    } else {
                        mapControllerResult(
                            proposal,
                            phoneController.sendOrPrepareSms(number, targetName, body, subId)
                        )
                    }
                }
                "SEND_WHATSAPP_MESSAGE", "PREPARE_WHATSAPP" -> {
                    val targetName = proposal.parameters["contactName"]
                        ?: proposal.parameters["recipientQuery"] ?: "Contact"
                    val number = proposal.parameters["phoneNumber"].orEmpty()
                    val body = proposal.parameters["message"] ?: proposal.parameters["messageBody"].orEmpty()
                    val resolvedNumber = if (number.isBlank()) {
                        phoneController.searchContactsByName(targetName).firstOrNull()?.phoneNumber.orEmpty()
                    } else number
                    mapControllerResult(
                        proposal,
                        phoneController.prepareWhatsAppMessage(resolvedNumber, targetName, body)
                    )
                }
                "SEND_EMAIL", "PREPARE_EMAIL" -> {
                    val recipient = proposal.parameters["recipient"]
                        ?: proposal.parameters["recipientQuery"] ?: ""
                    val subject = proposal.parameters["subject"].orEmpty()
                    val body = proposal.parameters["message"] ?: proposal.parameters["messageBody"].orEmpty()
                    mapControllerResult(
                        proposal,
                        phoneController.prepareEmail(recipient, subject, body)
                    )
                }
                "MONEY_TRANSFER", "ONLINE_PAYMENT", "DELETE_IMPORTANT_FILES", "SENSITIVE_ACCOUNT_CHANGES" -> {
                    AssistantExecutionResult.Success(
                        proposalId = proposal.proposalId,
                        assistantId = AssistantId.MAGMITE,
                        summary = "MAGMITE verified CRITICAL authorization for ${proposal.exactOperation}."
                    )
                }
                else -> AssistantExecutionResult.Failure(
                    proposalId = proposal.proposalId,
                    assistantId = AssistantId.MAGMITE,
                    errorMessage = "Unsupported MAGMITE device operation: ${proposal.exactOperation}"
                )
            }
        }.getOrElse { error ->
            AssistantExecutionResult.Failure(
                proposalId = proposal.proposalId,
                assistantId = AssistantId.MAGMITE,
                errorMessage = error.message ?: "MAGMITE device operation failed."
            )
        }
    }

    private fun mapControllerResult(
        proposal: TaskProposal,
        result: Result<String>
    ): AssistantExecutionResult {
        return result.fold(
            onSuccess = { summary ->
                AssistantExecutionResult.Success(
                    proposalId = proposal.proposalId,
                    assistantId = AssistantId.MAGMITE,
                    summary = summary
                )
            },
            onFailure = { err ->
                AssistantExecutionResult.Failure(
                    proposalId = proposal.proposalId,
                    assistantId = AssistantId.MAGMITE,
                    errorMessage = err.message ?: "Device action failed."
                )
            }
        )
    }

    private fun handleTorch(proposal: TaskProposal): AssistantExecutionResult {
        val enabled = proposal.parameters["enabled"]?.toBooleanStrictOrNull() ?: true
        val cameraManager = context.getSystemService(Context.CAMERA_SERVICE) as CameraManager
        val backFlashCameraId = cameraManager.cameraIdList.firstOrNull { id ->
            val chars = cameraManager.getCameraCharacteristics(id)
            chars.get(CameraCharacteristics.FLASH_INFO_AVAILABLE) == true
        } ?: return AssistantExecutionResult.Failure(
            proposal.proposalId,
            AssistantId.MAGMITE,
            "No camera flash unit available on this device."
        )
        cameraManager.setTorchMode(backFlashCameraId, enabled)
        return AssistantExecutionResult.Success(
            proposalId = proposal.proposalId,
            assistantId = AssistantId.MAGMITE,
            summary = "Flashlight ${if (enabled) "enabled" else "disabled"} on camera $backFlashCameraId.",
            outputPayload = mapOf("torchEnabled" to enabled.toString(), "cameraId" to backFlashCameraId)
        )
    }

    private fun handleVolume(proposal: TaskProposal): AssistantExecutionResult {
        val audioManager = context.getSystemService(Context.AUDIO_SERVICE) as AudioManager
        val stream = when (proposal.parameters["stream"]?.lowercase()) {
            "ring" -> AudioManager.STREAM_RING
            "alarm" -> AudioManager.STREAM_ALARM
            else -> AudioManager.STREAM_MUSIC
        }
        val maxVol = audioManager.getStreamMaxVolume(stream)
        val percent = (proposal.parameters["percent"]?.toIntOrNull() ?: 50).coerceIn(0, 100)
        val targetIndex = ((percent / 100f) * maxVol).toInt().coerceIn(0, maxVol)
        audioManager.setStreamVolume(stream, targetIndex, AudioManager.FLAG_SHOW_UI)
        return AssistantExecutionResult.Success(
            proposalId = proposal.proposalId,
            assistantId = AssistantId.MAGMITE,
            summary = "Adjusted volume to $percent% ($targetIndex/$maxVol).",
            outputPayload = mapOf("percent" to percent.toString(), "index" to targetIndex.toString(), "max" to maxVol.toString())
        )
    }

    private fun handleRingerMode(proposal: TaskProposal): AssistantExecutionResult {
        val audioManager = context.getSystemService(Context.AUDIO_SERVICE) as AudioManager
        val mode = when (proposal.parameters["mode"]?.lowercase()) {
            "silent" -> AudioManager.RINGER_MODE_SILENT
            "vibrate" -> AudioManager.RINGER_MODE_VIBRATE
            else -> AudioManager.RINGER_MODE_NORMAL
        }
        audioManager.ringerMode = mode
        return AssistantExecutionResult.Success(
            proposalId = proposal.proposalId,
            assistantId = AssistantId.MAGMITE,
            summary = "Ringer mode updated to ${proposal.parameters["mode"] ?: "normal"}."
        )
    }
}
