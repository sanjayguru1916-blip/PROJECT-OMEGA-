package com.projectomega.sk.core.ai

import com.projectomega.sk.BuildConfig
import com.projectomega.sk.core.model.AssistantCommandRequest
import com.projectomega.sk.core.model.AssistantId
import com.projectomega.sk.core.model.RiskLevel
import com.projectomega.sk.core.registry.AssistantDescriptor
import kotlinx.serialization.Serializable
import kotlinx.serialization.json.Json
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.logging.HttpLoggingInterceptor
import retrofit2.HttpException
import retrofit2.Retrofit
import retrofit2.converter.kotlinx.serialization.asConverterFactory
import retrofit2.http.Body
import retrofit2.http.POST
import java.io.IOException
import java.net.SocketTimeoutException
import java.net.UnknownHostException
import java.util.UUID
import java.util.concurrent.TimeUnit

@Serializable
data class RouteCommandApiRequest(
    val command: String,
    val preferredAssistant: String? = null,
    val availableAssistants: List<String>
)

@Serializable
data class RouteCommandApiResponse(
    val targetAssistant: String,
    val category: String = "GENERAL_CONVERSATION",
    val requiresApproval: Boolean = true,
    val directReply: String? = null,
    val exactOperation: String,
    val rationale: String,
    val riskLevel: String,
    val requiredPermissions: List<String> = emptyList(),
    val parameters: Map<String, String> = emptyMap()
)

data class ClassifiedRouteResult(
    val request: AssistantCommandRequest,
    val category: com.projectomega.sk.core.model.IntentCategory,
    val requiresApproval: Boolean,
    val directReply: String?
)

@Serializable
data class AssistantReasonApiRequest(
    val assistantId: String,
    val operation: String,
    val rawInput: String,
    val parameters: Map<String, String> = emptyMap()
)

@Serializable
data class AssistantReasonApiResponse(
    val assistantId: String,
    val summary: String,
    val structuredOutput: Map<String, String> = emptyMap()
)

@Serializable
data class SystemReportApiRequest(
    val totalCommands: Int,
    val approvedTasks: Int,
    val rejectedTasks: Int,
    val failedTasks: Int,
    val activeAssistants: List<String>
)

@Serializable
data class SystemReportApiResponse(
    val narrativeSummary: String
)

@Serializable
data class VoiceSynthesizeApiRequest(
    val assistantId: String,
    val text: String
)

@Serializable
data class VoiceSynthesizeApiResponse(
    val assistantId: String,
    val voiceName: String,
    val gender: String,
    val mimeType: String,
    val audioBase64: String,
    val provider: String
)

interface OmegaBackendApi {
    @POST("api/android/route")
    suspend fun routeCommand(@Body request: RouteCommandApiRequest): RouteCommandApiResponse

    @POST("api/android/reason")
    suspend fun reason(@Body request: AssistantReasonApiRequest): AssistantReasonApiResponse

    @POST("api/android/report")
    suspend fun synthesizeReport(@Body request: SystemReportApiRequest): SystemReportApiResponse

    @POST("api/android/voice/synthesize")
    suspend fun synthesizeSpeech(@Body request: VoiceSynthesizeApiRequest): VoiceSynthesizeApiResponse
}

/**
 * Modular AI Provider interface. Keeps all LLM credentials off the Android device
 * by delegating inference to a secure backend gateway.
 */
interface AiProviderGateway {
    suspend fun classifyCommand(
        rawInput: String,
        preferredAssistant: AssistantId?,
        descriptors: List<AssistantDescriptor>
    ): ClassifiedRouteResult

    suspend fun classifyAndRouteCommand(
        rawInput: String,
        preferredAssistant: AssistantId?,
        descriptors: List<AssistantDescriptor>
    ): AssistantCommandRequest = classifyCommand(rawInput, preferredAssistant, descriptors).request

    suspend fun generateAssistantResponse(
        assistantId: AssistantId,
        operation: String,
        rawInput: String,
        parameters: Map<String, String>
    ): AssistantReasonApiResponse

    suspend fun synthesizeSystemReport(
        totalCommands: Int,
        approvedTasks: Int,
        rejectedTasks: Int,
        failedTasks: Int,
        activeAssistants: List<AssistantId>
    ): String

    suspend fun synthesizeSpeech(
        assistantId: AssistantId,
        text: String
    ): VoiceSynthesizeApiResponse
}

class BackendProxyAiProvider(
    baseUrl: String = BuildConfig.OMEGA_BACKEND_URL
) : AiProviderGateway {

    private val json = Json {
        ignoreUnknownKeys = true
        encodeDefaults = true
    }

    private val api: OmegaBackendApi

    init {
        val logging = HttpLoggingInterceptor().apply {
            level = if (BuildConfig.DEBUG) HttpLoggingInterceptor.Level.BASIC
            else HttpLoggingInterceptor.Level.NONE
        }
        val client = OkHttpClient.Builder()
            .connectTimeout(15, TimeUnit.SECONDS)
            .writeTimeout(15, TimeUnit.SECONDS)
            .readTimeout(35, TimeUnit.SECONDS)
            .addInterceptor(logging)
            .build()

        val normalizedUrl = if (baseUrl.endsWith("/")) baseUrl else "$baseUrl/"
        val retrofit = Retrofit.Builder()
            .baseUrl(normalizedUrl)
            .client(client)
            .addConverterFactory(json.asConverterFactory("application/json".toMediaType()))
            .build()

        api = retrofit.create(OmegaBackendApi::class.java)
    }

    private suspend fun <T> safeGatewayCall(block: suspend () -> T): T {
        return try {
            block()
        } catch (err: SocketTimeoutException) {
            throw IllegalStateException("SK Master backend timed out waiting for AI model response. Please retry.", err)
        } catch (err: UnknownHostException) {
            throw IllegalStateException("Unable to reach SK Master backend server. Check your network connection.", err)
        } catch (err: HttpException) {
            val code = err.code()
            val bodyMsg = runCatching {
                val raw = err.response()?.errorBody()?.string().orEmpty()
                val match = Regex("\"error\"\\s*:\\s*\"([^\"]+)\"").find(raw)
                match?.groupValues?.getOrNull(1)
            }.getOrNull()
            val friendly = bodyMsg?.takeIf { it.isNotBlank() } ?: when (code) {
                504 -> "SK Master timed out waiting for the AI model. Please retry."
                503 -> "AI service is temporarily busy. Please try again shortly."
                429 -> "AI quota rate limit reached. Please pause briefly and retry."
                409 -> "Command is already running or target assistant is disabled."
                400 -> "Invalid command input. Please rephrase and try again."
                in 500..599 -> "Temporary backend error ($code). Please retry."
                else -> "Backend request failed (HTTP $code)."
            }
            throw IllegalStateException(friendly, err)
        } catch (err: IOException) {
            throw IllegalStateException("Network communication failed with SK Master backend. Please retry.", err)
        }
    }

    override suspend fun classifyCommand(
        rawInput: String,
        preferredAssistant: AssistantId?,
        descriptors: List<AssistantDescriptor>
    ): ClassifiedRouteResult {
        val enabledNames = descriptors.filter { it.isEnabled }.map { it.id.name }
        val response = safeGatewayCall {
            api.routeCommand(
                RouteCommandApiRequest(
                    command = rawInput,
                    preferredAssistant = preferredAssistant?.takeIf { it != AssistantId.SK }?.name,
                    availableAssistants = enabledNames
                )
            )
        }
        val target = runCatching { AssistantId.valueOf(response.targetAssistant) }.getOrDefault(AssistantId.JARVIS)
        val risk = runCatching { RiskLevel.valueOf(response.riskLevel) }.getOrDefault(RiskLevel.MEDIUM)
        val category = runCatching { com.projectomega.sk.core.model.IntentCategory.valueOf(response.category) }
            .getOrDefault(com.projectomega.sk.core.model.IntentCategory.GENERAL_CONVERSATION)
        val req = AssistantCommandRequest(
            commandId = "cmd-${UUID.randomUUID().toString().take(10)}",
            rawInput = rawInput,
            targetAssistant = target,
            intentAction = response.exactOperation,
            parameters = response.parameters,
            requiredPermissions = response.requiredPermissions,
            riskLevel = risk,
            rationale = response.rationale
        )
        return ClassifiedRouteResult(
            request = req,
            category = category,
            requiresApproval = response.requiresApproval,
            directReply = response.directReply
        )
    }

    override suspend fun generateAssistantResponse(
        assistantId: AssistantId,
        operation: String,
        rawInput: String,
        parameters: Map<String, String>
    ): AssistantReasonApiResponse {
        return safeGatewayCall {
            api.reason(
                AssistantReasonApiRequest(
                    assistantId = assistantId.name,
                    operation = operation,
                    rawInput = rawInput,
                    parameters = parameters
                )
            )
        }
    }

    override suspend fun synthesizeSystemReport(
        totalCommands: Int,
        approvedTasks: Int,
        rejectedTasks: Int,
        failedTasks: Int,
        activeAssistants: List<AssistantId>
    ): String {
        val res = safeGatewayCall {
            api.synthesizeReport(
                SystemReportApiRequest(
                    totalCommands = totalCommands,
                    approvedTasks = approvedTasks,
                    rejectedTasks = rejectedTasks,
                    failedTasks = failedTasks,
                    activeAssistants = activeAssistants.map { it.name }
                )
            )
        }
        return res.narrativeSummary
    }

    override suspend fun synthesizeSpeech(
        assistantId: AssistantId,
        text: String
    ): VoiceSynthesizeApiResponse {
        return safeGatewayCall {
            api.synthesizeSpeech(
                VoiceSynthesizeApiRequest(
                    assistantId = assistantId.name,
                    text = text
                )
            )
        }
    }
}
