package com.projectomega.sk.core.approval

import com.projectomega.sk.core.model.ApprovalToken
import com.projectomega.sk.core.model.AssistantCommandRequest
import com.projectomega.sk.core.model.TaskProposal
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import java.security.MessageDigest
import java.util.UUID

data class CreateProposalOutcome(
    val proposal: TaskProposal,
    val deduplicated: Boolean
)

/**
 * Enforces Project Omega's core security invariant:
 * - No delegated task executes without explicit user approval.
 * - Approval is cryptographically bound (SHA-256) to the exact TaskProposal parameters,
 *   target assistant, exact operation, and required permissions.
 * - Deduplicates identical unexpired pending proposals and prevents double-execution via in-flight locks.
 * - Tokens are single-use and invalidated immediately upon consumption, failure, or rejection.
 */
class ApprovalManager {

    private val pendingProposals = LinkedHashMap<String, TaskProposal>()
    private val mintedTokens = LinkedHashMap<String, ApprovalToken>()
    private val inFlightProposalIds = LinkedHashSet<String>()

    private val _pendingQueue = MutableStateFlow<List<TaskProposal>>(emptyList())
    val pendingQueue: StateFlow<List<TaskProposal>> = _pendingQueue.asStateFlow()

    @Synchronized
    fun createOrReuseProposal(request: AssistantCommandRequest): CreateProposalOutcome {
        purgeExpiredLocked()

        val canonicalParams = canonicalParamsString(request.parameters)
        val existingDuplicate = pendingProposals.values.firstOrNull { p ->
            p.targetAssistant == request.targetAssistant &&
                p.exactOperation.equals(request.intentAction, ignoreCase = true) &&
                canonicalParamsString(p.parameters) == canonicalParams
        }
        if (existingDuplicate != null) {
            return CreateProposalOutcome(proposal = existingDuplicate, deduplicated = true)
        }

        val now = System.currentTimeMillis()
        val proposalId = "prop-${UUID.randomUUID().toString().take(12)}"
        val payloadHash = computeProposalHash(
            proposalId = proposalId,
            targetAssistant = request.targetAssistant.name,
            exactOperation = request.intentAction,
            parameters = request.parameters,
            requiredPermissions = request.requiredPermissions
        )
        val proposal = TaskProposal(
            proposalId = proposalId,
            commandId = request.commandId,
            rawInput = request.rawInput,
            targetAssistant = request.targetAssistant,
            actionSummary = request.rationale,
            exactOperation = request.intentAction,
            parameters = request.parameters,
            requiredPermissions = request.requiredPermissions,
            riskLevel = request.riskLevel,
            rationale = request.rationale,
            payloadHash = payloadHash,
            createdAtEpochMs = now,
            expiresAtEpochMs = now + 5 * 60 * 1000L // 5-minute approval window
        )
        pendingProposals[proposalId] = proposal
        syncFlow()
        return CreateProposalOutcome(proposal = proposal, deduplicated = false)
    }

    fun createProposal(request: AssistantCommandRequest): TaskProposal {
        return createOrReuseProposal(request).proposal
    }

    @Synchronized
    fun acquireExecutionLock(proposalId: String): Boolean {
        return inFlightProposalIds.add(proposalId)
    }

    @Synchronized
    fun releaseExecutionLock(proposalId: String) {
        inFlightProposalIds.remove(proposalId)
    }

    @Synchronized
    fun approveProposal(proposalId: String, expectedHash: String): ApprovalToken {
        purgeExpiredLocked()

        val proposal = pendingProposals[proposalId]
            ?: throw SecurityException("Proposal $proposalId not found or already resolved.")

        if (System.currentTimeMillis() > proposal.expiresAtEpochMs) {
            pendingProposals.remove(proposalId)
            syncFlow()
            throw SecurityException("Proposal $proposalId expired before user approval.")
        }

        if (proposal.payloadHash != expectedHash) {
            throw SecurityException("Payload integrity mismatch: approval hash does not match exact task.")
        }

        val recomputedHash = computeProposalHash(
            proposalId = proposal.proposalId,
            targetAssistant = proposal.targetAssistant.name,
            exactOperation = proposal.exactOperation,
            parameters = proposal.parameters,
            requiredPermissions = proposal.requiredPermissions
        )
        if (recomputedHash != proposal.payloadHash) {
            throw SecurityException("Tampered proposal detected during approval.")
        }

        val token = ApprovalToken(
            proposalId = proposal.proposalId,
            payloadHash = proposal.payloadHash,
            targetAssistant = proposal.targetAssistant,
            exactOperation = proposal.exactOperation,
            approvedAtEpochMs = System.currentTimeMillis()
        )
        mintedTokens[proposalId] = token
        return token
    }

    @Synchronized
    fun rejectProposal(proposalId: String): TaskProposal? {
        val removed = pendingProposals.remove(proposalId)
        mintedTokens.remove(proposalId)
        inFlightProposalIds.remove(proposalId)
        syncFlow()
        return removed
    }

    @Synchronized
    fun consumeVerifiedToken(proposal: TaskProposal, token: ApprovalToken): Boolean {
        val storedToken = mintedTokens[proposal.proposalId] ?: return false
        val expectedHash = computeProposalHash(
            proposalId = proposal.proposalId,
            targetAssistant = proposal.targetAssistant.name,
            exactOperation = proposal.exactOperation,
            parameters = proposal.parameters,
            requiredPermissions = proposal.requiredPermissions
        )
        val valid = storedToken == token &&
            token.proposalId == proposal.proposalId &&
            token.payloadHash == expectedHash &&
            token.targetAssistant == proposal.targetAssistant &&
            token.exactOperation == proposal.exactOperation

        // Single-use: always revoke after verification attempt
        mintedTokens.remove(proposal.proposalId)
        pendingProposals.remove(proposal.proposalId)
        syncFlow()
        return valid
    }

    private fun purgeExpiredLocked() {
        val now = System.currentTimeMillis()
        val expiredIds = pendingProposals.values.filter { now > it.expiresAtEpochMs }.map { it.proposalId }
        if (expiredIds.isNotEmpty()) {
            expiredIds.forEach { id ->
                pendingProposals.remove(id)
                mintedTokens.remove(id)
                inFlightProposalIds.remove(id)
            }
            syncFlow()
        }
    }

    private fun syncFlow() {
        _pendingQueue.value = pendingProposals.values.toList()
    }

    companion object {
        private fun canonicalParamsString(parameters: Map<String, String>): String {
            return parameters.toSortedMap().entries.joinToString("&") { "${it.key}=${it.value.trim()}" }
        }

        fun computeProposalHash(
            proposalId: String,
            targetAssistant: String,
            exactOperation: String,
            parameters: Map<String, String>,
            requiredPermissions: List<String>
        ): String {
            val canonicalParams = parameters.toSortedMap().entries.joinToString("&") { "${it.key}=${it.value}" }
            val canonicalPerms = requiredPermissions.sorted().joinToString(",")
            val material = "$proposalId|$targetAssistant|$exactOperation|$canonicalParams|$canonicalPerms"
            val digest = MessageDigest.getInstance("SHA-256").digest(material.toByteArray(Charsets.UTF_8))
            return digest.joinToString("") { "%02x".format(it) }
        }
    }
}
