package com.projectomega.sk.assistants.ultron

import android.app.ActivityManager
import android.content.Context
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import android.os.BatteryManager
import android.os.Environment
import android.os.StatFs
import com.projectomega.sk.core.ai.AiProviderGateway
import com.projectomega.sk.core.approval.ApprovalManager
import com.projectomega.sk.core.model.ApprovalToken
import com.projectomega.sk.core.model.AssistantExecutionResult
import com.projectomega.sk.core.model.AssistantId
import com.projectomega.sk.core.model.AssistantProfile
import com.projectomega.sk.core.model.OmegaIdentityCatalog
import com.projectomega.sk.core.model.TaskProposal
import com.projectomega.sk.core.registry.AssistantModule
import com.projectomega.sk.core.security.AndroidPermissionGuard

/**
 * ULTRON — Advanced System Analysis & Automation Module.
 * Performs real Android OS memory, storage, battery, and network diagnostics,
 * paired with structured AI anomaly evaluation.
 */
class UltronAssistantModule(
    private val context: Context,
    private val aiProvider: AiProviderGateway,
    private val permissionGuard: AndroidPermissionGuard,
    private val approvalManager: ApprovalManager
) : AssistantModule {

    override val profile: AssistantProfile = OmegaIdentityCatalog.profiles.getValue(AssistantId.ULTRON)

    override suspend fun healthCheck(): Boolean = true

    override suspend fun execute(
        proposal: TaskProposal,
        approvalToken: ApprovalToken
    ): AssistantExecutionResult {
        if (proposal.targetAssistant != AssistantId.ULTRON) {
            return AssistantExecutionResult.Denied(proposal.proposalId, "Boundary violation: proposal targeted ${proposal.targetAssistant}.")
        }
        val missing = permissionGuard.checkPermissions(proposal.requiredPermissions)
        if (missing.isNotEmpty()) {
            return AssistantExecutionResult.PermissionMissing(proposal.proposalId, AssistantId.ULTRON, missing)
        }
        if (!approvalManager.consumeVerifiedToken(proposal, approvalToken)) {
            return AssistantExecutionResult.Denied(proposal.proposalId, "Invalid or consumed approval token.")
        }

        return runCatching {
            val metrics = collectSystemDiagnostics()
            val mergedParams = proposal.parameters + metrics
            val analysis = aiProvider.generateAssistantResponse(
                assistantId = AssistantId.ULTRON,
                operation = proposal.exactOperation,
                rawInput = proposal.rawInput,
                parameters = mergedParams
            )
            AssistantExecutionResult.Success(
                proposalId = proposal.proposalId,
                assistantId = AssistantId.ULTRON,
                summary = analysis.summary,
                outputPayload = metrics + analysis.structuredOutput
            )
        }.getOrElse { error ->
            AssistantExecutionResult.Failure(
                proposalId = proposal.proposalId,
                assistantId = AssistantId.ULTRON,
                errorMessage = error.message ?: "ULTRON diagnostic sweep failed."
            )
        }
    }

    private fun collectSystemDiagnostics(): Map<String, String> {
        val am = context.getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager
        val memInfo = ActivityManager.MemoryInfo()
        am.getMemoryInfo(memInfo)

        val statFs = StatFs(Environment.getDataDirectory().path)
        val freeGb = (statFs.availableBytes / (1024.0 * 1024.0 * 1024.0))
        val totalGb = (statFs.totalBytes / (1024.0 * 1024.0 * 1024.0))

        val bm = context.getSystemService(Context.BATTERY_SERVICE) as BatteryManager
        val batteryPct = bm.getIntProperty(BatteryManager.BATTERY_PROPERTY_CAPACITY)

        val cm = context.getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
        val caps = cm.getNetworkCapabilities(cm.activeNetwork)
        val transport = when {
            caps == null -> "Offline"
            caps.hasTransport(NetworkCapabilities.TRANSPORT_WIFI) -> "Wi-Fi"
            caps.hasTransport(NetworkCapabilities.TRANSPORT_CELLULAR) -> "Cellular"
            else -> "Other"
        }

        return mapOf(
            "ramAvailableMb" to (memInfo.availMem / (1024 * 1024)).toString(),
            "ramTotalMb" to (memInfo.totalMem / (1024 * 1024)).toString(),
            "lowMemoryFlag" to memInfo.lowMemory.toString(),
            "storageFreeGb" to "%.2f".format(freeGb),
            "storageTotalGb" to "%.2f".format(totalGb),
            "batteryPercent" to batteryPct.toString(),
            "networkTransport" to transport
        )
    }
}
