package com.projectomega.sk.ui.voice

import android.content.Context
import android.media.AudioAttributes
import android.media.AudioFocusRequest
import android.media.AudioManager
import android.media.MediaPlayer
import android.os.Build
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import android.speech.tts.Voice
import android.util.Base64
import com.projectomega.sk.core.ai.AiProviderGateway
import com.projectomega.sk.core.model.AssistantId
import com.projectomega.sk.core.model.OmegaIdentityCatalog
import com.projectomega.sk.core.model.VoiceConfig
import com.projectomega.sk.core.model.VoiceGender
import com.projectomega.sk.core.model.VoiceProviderMode
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File
import java.util.Locale

data class LocalTtsVoiceInfo(
    val name: String,
    val locale: String,
    val quality: Int,
    val requiresNetwork: Boolean
)

/**
 * Centralized Assistant-Specific Voice Routing Engine.
 * - Inspects installed Android TextToSpeech voices and assigns distinct local voices per assistant where available.
 * - When local Android TTS cannot provide 5 genuinely distinct voices (or Neural TTS is chosen),
 *   synthesizes authentic 5-identity neural speech via the backend Gemini 3.8 TTS proxy (zero client API keys).
 * - Guarantees zero overlapping speech and emits speakingAssistant in real time.
 */
class OmegaVoiceEngine(
    private val context: Context,
    private val aiProvider: AiProviderGateway
) : TextToSpeech.OnInitListener {

    private val appContext = context.applicationContext
    private val audioManager = appContext.getSystemService(Context.AUDIO_SERVICE) as AudioManager
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main.immediate)

    private var tts: TextToSpeech? = TextToSpeech(appContext, this)
    private var localReady: Boolean = false
    private var mediaPlayer: MediaPlayer? = null
    private var activeSpeechJob: Job? = null
    private var focusRequest: AudioFocusRequest? = null

    private val assignedLocalVoices = mutableMapOf<AssistantId, Voice?>()

    private val _speakingAssistant = MutableStateFlow<AssistantId?>(null)
    val speakingAssistant: StateFlow<AssistantId?> = _speakingAssistant.asStateFlow()

    private val _availableLocalVoices = MutableStateFlow<List<LocalTtsVoiceInfo>>(emptyList())
    val availableLocalVoices: StateFlow<List<LocalTtsVoiceInfo>> = _availableLocalVoices.asStateFlow()

    private val _activeVoiceDescriptions = MutableStateFlow<Map<AssistantId, String>>(emptyMap())
    val activeVoiceDescriptions: StateFlow<Map<AssistantId, String>> = _activeVoiceDescriptions.asStateFlow()

    private val _voiceDiagnosticsNotice = MutableStateFlow<String?>(null)
    val voiceDiagnosticsNotice: StateFlow<String?> = _voiceDiagnosticsNotice.asStateFlow()

    override fun onInit(status: Int) {
        localReady = (status == TextToSpeech.SUCCESS)
        if (!localReady) {
            _voiceDiagnosticsNotice.value = "Local Android TTS unavailable; Neural TTS backend will be used when online."
            return
        }

        val engine = tts ?: return
        engine.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
            override fun onStart(utteranceId: String?) {
                val speaker = utteranceId?.substringBefore(":")?.let { raw ->
                    runCatching { AssistantId.valueOf(raw) }.getOrNull()
                }
                _speakingAssistant.value = speaker
            }

            override fun onDone(utteranceId: String?) {
                abandonAudioFocus()
                _speakingAssistant.value = null
            }

            @Deprecated("Deprecated in Java")
            override fun onError(utteranceId: String?) {
                abandonAudioFocus()
                _speakingAssistant.value = null
            }

            override fun onError(utteranceId: String?, errorCode: Int) {
                abandonAudioFocus()
                _speakingAssistant.value = null
            }
        })

        assignDistinctLocalVoices(engine)
    }

    private fun assignDistinctLocalVoices(engine: TextToSpeech) {
        val allVoices = runCatching { engine.voices?.toList().orEmpty() }.getOrDefault(emptyList())
        _availableLocalVoices.value = allVoices
            .filter { it.locale.language == "en" }
            .sortedByDescending { it.quality }
            .map {
                LocalTtsVoiceInfo(
                    name = it.name,
                    locale = it.locale.toLanguageTag(),
                    quality = it.quality,
                    requiresNetwork = it.isNetworkConnectionRequired
                )
            }

        val englishVoices = allVoices.filter { it.locale.language == "en" }
            .sortedWith(compareByDescending<Voice> { it.quality }.thenBy { it.isNetworkConnectionRequired })

        val usedNames = mutableSetOf<String>()
        val descriptions = mutableMapOf<AssistantId, String>()

        AssistantId.entries.forEach { id ->
            val config = OmegaIdentityCatalog.profiles.getValue(id).voiceConfig
            val selected = pickBestDistinctVoice(id, config, englishVoices, usedNames)
            assignedLocalVoices[id] = selected
            if (selected != null) {
                usedNames.add(selected.name)
                descriptions[id] = "Local: ${selected.name} (${selected.locale.toLanguageTag()}) | Neural: ${config.neuralVoiceName}"
            } else {
                descriptions[id] = "No distinct local voice; Neural: ${config.neuralVoiceName}"
            }
        }

        val distinctCount = assignedLocalVoices.values.filterNotNull().map { it.name }.distinct().size
        _activeVoiceDescriptions.value = descriptions
        _voiceDiagnosticsNotice.value = if (distinctCount < 5) {
            "Android TTS reported $distinctCount distinct English voice(s); Neural TTS (Gemini 3.8) recommended for 5 distinct male/female identities."
        } else {
            null
        }
    }

    private fun pickBestDistinctVoice(
        id: AssistantId,
        config: VoiceConfig,
        pool: List<Voice>,
        usedNames: Set<String>
    ): Voice? {
        val unused = pool.filterNot { usedNames.contains(it.name) }
        val candidates = unused.ifEmpty { pool }
        val targetLocale = Locale.forLanguageTag(config.localeTag)

        val scored = candidates.sortedByDescending { v ->
            var score = 0
            if (v.locale.country.equals(targetLocale.country, ignoreCase = true)) score += 40
            if (v.quality >= Voice.QUALITY_HIGH) score += 20
            val lower = v.name.lowercase()
            val matchesFemaleHint = lower.contains("female") || lower.contains("-f-") || lower.contains("sfg") || lower.contains("tpf") || lower.contains("iol")
            val matchesMaleHint = lower.contains("male") || lower.contains("-m-") || lower.contains("iom") || lower.contains("tpd")
            if (config.gender == VoiceGender.FEMALE && matchesFemaleHint) score += 30
            if (config.gender == VoiceGender.MALE && matchesMaleHint) score += 30
            if (id == AssistantId.JARVIS && v.locale.country.equals("GB", ignoreCase = true)) score += 35
            score
        }
        return scored.firstOrNull()
    }

    fun speak(
        text: String,
        speaker: AssistantId,
        config: VoiceConfig,
        providerMode: VoiceProviderMode
    ) {
        if (text.isBlank()) return
        stopSpeaking()
        requestPlaybackFocus()

        val distinctLocalCount = assignedLocalVoices.values.filterNotNull().map { it.name }.distinct().size
        val useNeural = when (providerMode) {
            VoiceProviderMode.BACKEND_NEURAL_TTS -> true
            VoiceProviderMode.ANDROID_LOCAL_TTS -> false
            VoiceProviderMode.AUTO_NEURAL_OR_LOCAL -> distinctLocalCount < 5
        }

        if (useNeural) {
            activeSpeechJob = scope.launch {
                val neuralSucceeded = playNeuralSpeech(text, speaker)
                if (!neuralSucceeded && localReady) {
                    speakLocal(text, speaker, config)
                }
            }
        } else if (localReady) {
            speakLocal(text, speaker, config)
        } else {
            abandonAudioFocus()
        }
    }

    private suspend fun playNeuralSpeech(text: String, speaker: AssistantId): Boolean {
        return runCatching {
            val response = withContext(Dispatchers.IO) {
                aiProvider.synthesizeSpeech(speaker, text)
            }
            val wavBytes = Base64.decode(response.audioBase64, Base64.DEFAULT)
            val tempFile = withContext(Dispatchers.IO) {
                File.createTempFile("omega_${speaker.name.lowercase()}_", ".wav", appContext.cacheDir).apply {
                    writeBytes(wavBytes)
                }
            }
            val player = MediaPlayer().apply {
                setDataSource(tempFile.absolutePath)
                prepare()
            }
            mediaPlayer = player
            _speakingAssistant.value = speaker
            player.setOnCompletionListener { mp ->
                mp.release()
                if (mediaPlayer === mp) mediaPlayer = null
                abandonAudioFocus()
                _speakingAssistant.value = null
                tempFile.delete()
            }
            player.setOnErrorListener { mp, _, _ ->
                mp.release()
                if (mediaPlayer === mp) mediaPlayer = null
                abandonAudioFocus()
                _speakingAssistant.value = null
                tempFile.delete()
                true
            }
            player.start()
            true
        }.getOrElse {
            abandonAudioFocus()
            _speakingAssistant.value = null
            false
        }
    }

    private fun speakLocal(text: String, speaker: AssistantId, config: VoiceConfig) {
        val engine = tts ?: return
        val matchedVoice = assignedLocalVoices[speaker]
        if (matchedVoice != null) {
            engine.voice = matchedVoice
        } else {
            engine.language = Locale.forLanguageTag(config.localeTag)
        }
        engine.setPitch(config.pitch)
        engine.setSpeechRate(config.speechRate)
        val utteranceId = "${speaker.name}:${System.currentTimeMillis()}"
        engine.speak(text, TextToSpeech.QUEUE_FLUSH, null, utteranceId)
    }

    private fun requestPlaybackFocus() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val attrs = AudioAttributes.Builder()
                .setUsage(AudioAttributes.USAGE_ASSISTANT)
                .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH)
                .build()
            val req = AudioFocusRequest.Builder(AudioManager.AUDIOFOCUS_GAIN_TRANSIENT_MAY_DUCK)
                .setAudioAttributes(attrs)
                .setOnAudioFocusChangeListener { change ->
                    if (change == AudioManager.AUDIOFOCUS_LOSS || change == AudioManager.AUDIOFOCUS_LOSS_TRANSIENT) {
                        stopSpeaking()
                    }
                }
                .build()
            focusRequest = req
            audioManager.requestAudioFocus(req)
        }
    }

    private fun abandonAudioFocus() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            focusRequest?.let { audioManager.abandonAudioFocusRequest(it) }
            focusRequest = null
        }
    }

    fun stopSpeaking() {
        activeSpeechJob?.cancel()
        activeSpeechJob = null
        mediaPlayer?.runCatching {
            if (isPlaying) stop()
            release()
        }
        mediaPlayer = null
        tts?.stop()
        abandonAudioFocus()
        _speakingAssistant.value = null
    }

    fun shutdown() {
        stopSpeaking()
        tts?.shutdown()
        tts = null
        localReady = false
    }
}
