package com.projectomega.sk.core.data

import android.content.Context
import androidx.room.Dao
import androidx.room.Database
import androidx.room.Entity
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.PrimaryKey
import androidx.room.Query
import androidx.room.Room
import androidx.room.RoomDatabase
import kotlinx.coroutines.flow.Flow

@Entity(tableName = "task_history")
data class TaskHistoryEntity(
    @PrimaryKey val proposalId: String,
    val targetAssistant: String,
    val rawInput: String,
    val exactOperation: String,
    val status: String,
    val resultSummary: String,
    val timestampEpochMs: Long
)

@Entity(tableName = "audit_logs")
data class AuditLogEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0L,
    val eventType: String,
    val actor: String,
    val proposalId: String?,
    val summary: String,
    val prevHash: String,
    val entryHash: String,
    val timestampEpochMs: Long
)

@Entity(tableName = "reminders")
data class ReminderEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0L,
    val title: String,
    val notes: String,
    val triggerAtEpochMs: Long,
    val completed: Boolean = false,
    val createdByProposalId: String
)

@Entity(tableName = "system_reports")
data class SystemReportEntity(
    @PrimaryKey val reportId: String,
    val generatedAtEpochMs: Long,
    val periodLabel: String,
    val totalCommands: Int,
    val approvedTasks: Int,
    val rejectedTasks: Int,
    val failedTasks: Int,
    val activeAssistantsCsv: String,
    val narrativeSummary: String
)

@Dao
interface TaskHistoryDao {
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsert(item: TaskHistoryEntity)

    @Query("SELECT * FROM task_history ORDER BY timestampEpochMs DESC LIMIT 100")
    fun observeRecent(): Flow<List<TaskHistoryEntity>>

    @Query("SELECT * FROM task_history ORDER BY timestampEpochMs DESC")
    suspend fun getAll(): List<TaskHistoryEntity>
}

@Dao
interface AuditDao {
    @Insert
    suspend fun insert(entry: AuditLogEntity)

    @Query("SELECT entryHash FROM audit_logs ORDER BY id DESC LIMIT 1")
    suspend fun getLatestHash(): String?

    @Query("SELECT * FROM audit_logs ORDER BY id DESC LIMIT 150")
    fun observeRecent(): Flow<List<AuditLogEntity>>
}

@Dao
interface ReminderDao {
    @Insert
    suspend fun insert(reminder: ReminderEntity): Long

    @Query("SELECT * FROM reminders ORDER BY triggerAtEpochMs ASC")
    fun observeAll(): Flow<List<ReminderEntity>>

    @Query("UPDATE reminders SET completed = :completed WHERE id = :id")
    suspend fun setCompleted(id: Long, completed: Boolean)
}

@Dao
interface SystemReportDao {
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insert(report: SystemReportEntity)

    @Query("SELECT * FROM system_reports ORDER BY generatedAtEpochMs DESC LIMIT 30")
    fun observeReports(): Flow<List<SystemReportEntity>>
}

@Database(
    entities = [
        TaskHistoryEntity::class,
        AuditLogEntity::class,
        ReminderEntity::class,
        SystemReportEntity::class
    ],
    version = 1,
    exportSchema = false
)
abstract class OmegaDatabase : RoomDatabase() {
    abstract fun taskHistoryDao(): TaskHistoryDao
    abstract fun auditDao(): AuditDao
    abstract fun reminderDao(): ReminderDao
    abstract fun systemReportDao(): SystemReportDao

    companion object {
        @Volatile
        private var INSTANCE: OmegaDatabase? = null

        fun getInstance(context: Context): OmegaDatabase {
            return INSTANCE ?: synchronized(this) {
                INSTANCE ?: Room.databaseBuilder(
                    context.applicationContext,
                    OmegaDatabase::class.java,
                    "project_omega_sk.db"
                ).build().also { INSTANCE = it }
            }
        }
    }
}
