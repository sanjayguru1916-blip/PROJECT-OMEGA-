package com.projectomega.sk.ui.viewmodel

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.projectomega.sk.OmegaApplication
import com.projectomega.sk.core.data.AuditLogEntity
import com.projectomega.sk.core.data.ReminderEntity
import com.projectomega.sk.core.data.SystemReportEntity
import com.projectomega.sk.core.data.TaskHistoryEntity
import com.projectomega.sk.core.model.AnimationQuality
import com.projectomega.sk.core.model.AssemblyStage
import com.projectomega.sk.core.model.AssistantExecutionResult
import com.projectomega.sk.core.model.AssistantId
import com.projectomega.sk.core.model.ContactCandidate
import com.projectomega.sk.core.model.InterfaceMode
import com.projectomega.sk.core.model.OmegaIdentityCatalog
import com.projectomega.sk.core.model.SimAccountOption
import com.projectomega.sk.core.model.SkRouteOutcome
import com.projectomega.sk.core.model.SystemAlert
import com.projectomega.sk.core.model.TaskProposal
import com.projectomega.sk.core.model.VoiceConfig
import com.projectomega.sk.core.model.VoiceProviderMode
import com.projectomega.sk.core.model.VoiceState
import com.projectomega.sk.core.registry.RegisteredAssistantState
import com.projectomega.sk.ui.voice.LocalTtsVoiceInfo
import com.projectomega.sk.ui.voice.OmegaSpeechRecognizer
import com.projectomega.sk.ui.voice.OmegaVoiceEngine
import com.projectomega.sk.ui.voice.ParsedVoiceIntent
import com.projectomega.sk.ui.voice.SkVoiceCommandParser
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

data class PendingContactChoice(
    val actionType: String,
    val queryName: String,
    val candidates: List<ContactCandidate>,
    val messageBody: String?,
    val rawInput: String
)

data class PendingSimChoice(
    val actionType: String,
    val candidate: ContactCandidate,
    val simOptions: List<SimAccountOption>,
    val messageBody: String?,
    val rawInput: String
)

data class OmegaUiState(
    val activeIdentity: AssistantId = AssistantId.SK,
    val interfaceMode: InterfaceMode = InterfaceMode.NORMAL,
    val assemblyStage: AssemblyStage = AssemblyStage.IDLE,
    val speakingAssistant: AssistantId? = null,
    val voiceState: VoiceState = VoiceState.IDLE,
    val voiceRmsLevel: Float = 0f,
    val recognizedCommand: String = "",
    val masterGreeting: String? = null,
    val voiceProviderMode: VoiceProviderMode = VoiceProviderMode.AUTO_NEURAL_OR_LOCAL,
    val voiceConfigs: Map<AssistantId, VoiceConfig> = OmegaIdentityCatalog.profiles.mapValues { it.value.voiceConfig },
    val activeVoiceDescriptions: Map<AssistantId, String> = emptyMap(),
    val availableLocalVoices: List<LocalTtsVoiceInfo> = emptyList(),
    val voiceDiagnosticsNotice: String? = null,
    val animationQuality: AnimationQuality = AnimationQuality.HIGH_60FPS,
    val assistantStates: Map<AssistantId, RegisteredAssistantState> = emptyMap(),
    val pendingProposals: List<TaskProposal> = emptyList(),
    val pendingContactChoice: PendingContactChoice? = null,
    val pendingSimChoice: PendingSimChoice? = null,
    val taskHistory: List<TaskHistoryEntity> = emptyList(),
    val auditLogs: List<AuditLogEntity> = emptyList(),
    val reminders: List<ReminderEntity> = emptyList(),
    val reports: List<SystemReportEntity> = emptyList(),
    val alerts: List<SystemAlert> = emptyList(),
    val voiceEnabled: Boolean = true,
    val isListening: Boolean = false,
    val speechPartialText: String = "",
    val speechError: String? = null,
    val micPermanentlyDenied: Boolean = false,
    val isRouting: Boolean = false,
    val isExecuting: Boolean = false,
    val lastStatusBanner: String? = null,
    val lastFailedCommand: String? = null,
    val commandResultsHistory: List<String> = emptyList(),
    val requestedDetailsSection: String? = null,
    val missingPermissionsPrompt: List<String> = emptyList(),
    val missingPermissionsPermanentlyDenied: Boolean = false
)

class OmegaViewModel(application: Application) : AndroidViewModel(application) {

    private val container = (application as OmegaApplication).container
    private val voiceEngine = OmegaVoiceEngine(application, container.aiProvider)
    private val speechRecognizer = OmegaSpeechRecognizer(application) { transcript ->
        recognizedCommand.value = transcript
        handleCommandInput(transcript)
    }

    private val interfaceMode = MutableStateFlow(InterfaceMode.NORMAL)
    private val assemblyStage = MutableStateFlow(AssemblyStage.IDLE)
    private val recognizedCommand = MutableStateFlow("")
    private val masterGreeting = MutableStateFlow<String?>(null)
    private val pendingContactChoice = MutableStateFlow<PendingContactChoice?>(null)
    private val pendingSimChoice = MutableStateFlow<PendingSimChoice?>(null)
    private val isRouting = MutableStateFlow(false)
    private val isExecuting = MutableStateFlow(false)
    private val lastBanner = MutableStateFlow<String?>(null)
    private val lastFailedCommandText = MutableStateFlow<String?>(null)
    private var lastFailedPreferred: AssistantId? = null
    private val commandResultsHistory = MutableStateFlow<List<String>>(emptyList())
    private val requestedDetailsSection = MutableStateFlow<String?>(null)
    private val missingPermissions = MutableStateFlow<List<String>>(emptyList())
    private val missingPermsPermanent = MutableStateFlow(false)
    private val micPermanentDenied = MutableStateFlow(false)

    private var assemblyJob: Job? = null
    private var routingJob: Job? = null

    private fun recordBanner(msg: String) {
        val trimmed = msg.trim()
        if (trimmed.isEmpty()) return
        lastBanner.value = trimmed
        commandResultsHistory.value = (listOf(trimmed) + commandResultsHistory.value).take(30)
    }

    init {
        viewModelScope.launch {
            val greeting = container.skMasterCore.consumeStartupGreetingIfNeeded()
            if (!greeting.isNullOrBlank()) {
                masterGreeting.value = greeting
                recordBanner(greeting)
                val voiceEnabledNow = container.preferencesStore.voiceEnabledFlow.first()
                if (voiceEnabledNow) {
                    val cfg = container.preferencesStore.voiceConfigsFlow.first()[AssistantId.SK]
                        ?: OmegaIdentityCatalog.profiles.getValue(AssistantId.SK).voiceConfig
                    val mode = container.preferencesStore.voiceProviderModeFlow.first()
                    voiceEngine.speak(greeting, AssistantId.SK, cfg, mode)
                }
            }
        }
    }

    private val coreDataFlow = combine(
        container.preferencesStore.activeAssistantFlow,
        container.registry.states,
        container.approvalManager.pendingQueue,
        container.database.taskHistoryDao().observeRecent(),
        container.database.auditDao().observeRecent()
    ) { activeId, states, pending, history, audits ->
        CoreDataSlice(activeId, states, pending, history, audits)
    }

    private val telemetryFlow = combine(
        container.database.reminderDao().observeAll(),
        container.database.systemReportDao().observeReports(),
        container.skMasterCore.alerts,
        container.preferencesStore.voiceEnabledFlow,
        container.preferencesStore.animationQualityFlow
    ) { reminders, reports, alerts, voice, animQuality ->
        TelemetrySlice(reminders, reports, alerts, voice, animQuality)
    }

    private val voiceSettingsFlow = combine(
        container.preferencesStore.voiceProviderModeFlow,
        container.preferencesStore.voiceConfigsFlow,
        voiceEngine.activeVoiceDescriptions,
        voiceEngine.availableLocalVoices,
        voiceEngine.voiceDiagnosticsNotice
    ) { providerMode, configs, descriptions, localVoices, notice ->
        VoiceSettingsSlice(providerMode, configs, descriptions, localVoices, notice)
    }

    private val modeFlow = combine(
        interfaceMode,
        assemblyStage,
        voiceEngine.speakingAssistant,
        speechRecognizer.recognizerState,
        speechRecognizer.rmsLevel
    ) { mode, stage, speaking, recState, rms ->
        ModeSlice(mode, stage, speaking, recState, rms)
    }

    private val statusFlow = combine(
        isRouting,
        isExecuting,
        lastBanner,
        missingPermissions,
        speechRecognizer.errorMessage
    ) { routing, executing, banner, missingPerms, speechErr ->
        StatusSlice(routing, executing, banner, missingPerms, speechErr)
    }

    private val speechMetaFlow = combine(
        speechRecognizer.isListening,
        speechRecognizer.partialText,
        recognizedCommand,
        masterGreeting,
        micPermanentDenied
    ) { listening, partial, recognized, greeting, micPerm ->
        SpeechMetaSlice(listening, partial, recognized, greeting, micPerm)
    }

    private val choiceFlow = combine(
        pendingContactChoice,
        pendingSimChoice,
        missingPermsPermanent,
        commandResultsHistory,
        requestedDetailsSection
    ) { contactChoice, simChoice, permsPerm, resultsHistory, reqSection ->
        ChoiceAndDetailsSlice(contactChoice, simChoice, permsPerm, resultsHistory, reqSection)
    }

    val uiState: StateFlow<OmegaUiState> = combine(
        coreDataFlow,
        telemetryFlow,
        voiceSettingsFlow,
        modeFlow,
        statusFlow,
        speechMetaFlow,
        choiceFlow,
        lastFailedCommandText
    ) { values ->
        val core = values[0] as CoreDataSlice
        val telemetry = values[1] as TelemetrySlice
        val vSettings = values[2] as VoiceSettingsSlice
        val mode = values[3] as ModeSlice
        val status = values[4] as StatusSlice
        val speechMeta = values[5] as SpeechMetaSlice
        val choices = values[6] as ChoiceAndDetailsSlice
        val failedCmd = values[7] as String?

        val computedVoiceState = when {
            mode.speaking != null -> VoiceState.SPEAKING
            status.routing -> VoiceState.PROCESSING
            else -> mode.recState
        }

        OmegaUiState(
            activeIdentity = core.activeId,
            interfaceMode = mode.mode,
            assemblyStage = mode.stage,
            speakingAssistant = mode.speaking,
            voiceState = computedVoiceState,
            voiceRmsLevel = mode.rms,
            recognizedCommand = speechMeta.recognized,
            masterGreeting = speechMeta.greeting,
            voiceProviderMode = vSettings.providerMode,
            voiceConfigs = vSettings.configs,
            activeVoiceDescriptions = vSettings.descriptions,
            availableLocalVoices = vSettings.localVoices,
            voiceDiagnosticsNotice = vSettings.notice,
            animationQuality = telemetry.animQuality,
            assistantStates = core.states,
            pendingProposals = core.pending,
            pendingContactChoice = choices.contactChoice,
            pendingSimChoice = choices.simChoice,
            taskHistory = core.history,
            auditLogs = core.audits,
            reminders = telemetry.reminders,
            reports = telemetry.reports,
            alerts = telemetry.alerts,
            voiceEnabled = telemetry.voice,
            isListening = speechMeta.listening,
            speechPartialText = speechMeta.partial,
            speechError = status.speechErr,
            micPermanentlyDenied = speechMeta.micPermDenied,
            isRouting = status.routing,
            isExecuting = status.executing,
            lastStatusBanner = status.banner,
            lastFailedCommand = failedCmd,
            commandResultsHistory = choices.resultsHistory,
            requestedDetailsSection = choices.requestedSection,
            missingPermissionsPrompt = status.missingPerms,
            missingPermissionsPermanentlyDenied = choices.permsPerm
        )
    }.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5_000),
        initialValue = OmegaUiState()
    )

    fun switchIdentity(id: AssistantId) {
        if (id == AssistantId.SK) returnToSkMaster() else activateAssistantDirect(id)
    }

    fun activateNormalMode() {
        assemblyJob?.cancel()
        assemblyStage.value = AssemblyStage.IDLE
        interfaceMode.value = InterfaceMode.NORMAL
        viewModelScope.launch {
            container.preferencesStore.setActiveAssistant(AssistantId.SK)
            container.auditLogger.log("MODE_NORMAL", AssistantId.SK, null, "Returned to locked SK Master Reactor (Normal Mode).")
        }
        val msg = "SK Master Reactor in Normal Mode."
        recordBanner(msg)
        speakIfEnabled(msg, AssistantId.SK)
        speechRecognizer.resetStateToIdle()
    }

    fun activatePhoenixMode() {
        assemblyJob?.cancel()
        assemblyStage.value = AssemblyStage.IDLE
        interfaceMode.value = InterfaceMode.PHOENIX
        viewModelScope.launch {
            container.preferencesStore.setActiveAssistant(AssistantId.SK)
            container.auditLogger.log("MODE_PHOENIX", AssistantId.SK, null, "SK entered Phoenix plasma transformation mode.")
        }
        val msg = "SK Phoenix Mode engaged. Five-core thermal pulse active."
        recordBanner(msg)
        speakIfEnabled(msg, AssistantId.SK)
        speechRecognizer.resetStateToIdle()
    }

    fun assembleAll() {
        assemblyJob?.cancel()
        assemblyJob = viewModelScope.launch {
            container.preferencesStore.setActiveAssistant(AssistantId.SK)
            interfaceMode.value = InterfaceMode.ASSEMBLED

            val stepDelay = when (uiState.value.animationQuality) {
                AnimationQuality.HIGH_60FPS -> 850L
                AnimationQuality.BATTERY_SAVER_30FPS -> 700L
                AnimationQuality.REDUCED_MOTION -> 250L
            }

            assemblyStage.value = AssemblyStage.SYSTEM_INITIALIZING
            lastBanner.value = "SYSTEM INITIALIZING — SK Master Reactor energizing rings."
            speakIfEnabled("System initializing. Assembling all four assistant cores.", AssistantId.SK)
            delay(stepDelay)

            assemblyStage.value = AssemblyStage.CORE_DEPLOYMENT
            lastBanner.value = "CORE DEPLOYMENT — Deploying JARVIS, MAGMITE, ULTRON, and FRIDAY modules."
            delay(stepDelay)

            assemblyStage.value = AssemblyStage.HOLOGRAPHIC_ASSEMBLY
            lastBanner.value = "HOLOGRAPHIC ASSEMBLY — Aligning orbital brackets and locking cores."
            delay(stepDelay)

            assemblyStage.value = AssemblyStage.CORE_SYNCHRONIZATION
            lastBanner.value = "CORE SYNCHRONIZATION — Establishing master telemetry conduits."
            delay(stepDelay)

            assemblyStage.value = AssemblyStage.OMEGA_ONLINE
            recordBanner("OMEGA ONLINE — All five AI cores synchronized under SK.")
            container.auditLogger.log(
                "MODE_ASSEMBLE_ALL",
                AssistantId.SK,
                null,
                "Completed 5-stage holographic assembly sequence (OMEGA ONLINE)."
            )
            speakIfEnabled("Omega online. All five cores synchronized.", AssistantId.SK)
            speechRecognizer.resetStateToIdle()
        }
    }

    fun disassembleAll() {
        assemblyJob?.cancel()
        assemblyJob = viewModelScope.launch {
            assemblyStage.value = AssemblyStage.DISASSEMBLING
            lastBanner.value = "Disassembling holographic cores and returning to SK Master Reactor."
            speakIfEnabled("Disassembling cores. Returning to SK normal mode.", AssistantId.SK)
            delay(900L)
            assemblyStage.value = AssemblyStage.IDLE
            interfaceMode.value = InterfaceMode.NORMAL
            container.preferencesStore.setActiveAssistant(AssistantId.SK)
            container.auditLogger.log(
                "MODE_DISASSEMBLE_ALL",
                AssistantId.SK,
                null,
                "Disassembled satellite cores and restored SK Normal Mode."
            )
            speechRecognizer.resetStateToIdle()
        }
    }

    fun activateAssistantDirect(id: AssistantId, silent: Boolean = false) {
        if (id == AssistantId.SK) {
            returnToSkMaster()
            return
        }
        val regState = uiState.value.assistantStates[id]
        if (regState != null && !regState.isEnabled) {
            lastBanner.value = "${id.name} is currently disabled in the Assistant Registry."
            return
        }
        assemblyJob?.cancel()
        viewModelScope.launch {
            container.preferencesStore.setActiveAssistant(id)
            if (interfaceMode.value != InterfaceMode.ASSEMBLED) {
                interfaceMode.value = InterfaceMode.ASSISTANT_ACTIVE
            }
            if (!silent) {
                container.auditLogger.log(
                    "MODE_ASSISTANT_ACTIVE",
                    id,
                    null,
                    "Direct activation of ${id.name} under SK Master supervision."
                )
            }
        }
        if (!silent) {
            val profile = OmegaIdentityCatalog.profiles.getValue(id)
            val msg = "${profile.displayName} active under SK supervision. Ready for your command."
            recordBanner(msg)
            speakIfEnabled(msg, id)
        }
    }

    fun requestStatusForAssistant(id: AssistantId) {
        val summary = container.skMasterCore.buildRealAssistantStatusReport(id)
        if (id != AssistantId.SK) {
            activateAssistantDirect(id, silent = true)
        }
        recordBanner(summary)
        speakIfEnabled(summary, id)
    }

    fun openDetailsSection(sectionName: String) {
        requestedDetailsSection.value = sectionName
    }

    fun closeDetailsSection() {
        requestedDetailsSection.value = null
    }

    fun returnToSkMaster() {
        viewModelScope.launch {
            container.preferencesStore.setActiveAssistant(AssistantId.SK)
            if (interfaceMode.value == InterfaceMode.ASSISTANT_ACTIVE) {
                interfaceMode.value = InterfaceMode.NORMAL
            }
            container.auditLogger.log("MODE_SK_FOCUS", AssistantId.SK, null, "Returned focus to SK Master Controller.")
        }
        val msg = "SK Master Controller active."
        recordBanner(msg)
        speakIfEnabled(msg, AssistantId.SK)
        speechRecognizer.resetStateToIdle()
    }

    fun stopSpeaking() {
        voiceEngine.stopSpeaking()
        speechRecognizer.resetStateToIdle()
        recordBanner("Speech output stopped.")
    }

    fun handleCommandInput(rawInput: String) {
        val trimmed = rawInput.trim()
        if (trimmed.isBlank()) return
        recognizedCommand.value = trimmed

        val topPending = uiState.value.pendingProposals.firstOrNull()
        if (topPending != null) {
            val normalizedReply = trimmed.lowercase().replace(Regex("[.!?]"), "").trim()
            if (Regex("^(yes|yes please|approve|confirm|send it|go ahead|do it|proceed)$").matches(normalizedReply)) {
                if (topPending.isCriticalRisk) {
                    val guardMsg = "This operation is marked CRITICAL. Please confirm using the on-screen confirmation switch."
                    recordBanner(guardMsg)
                    speakIfEnabled(guardMsg, AssistantId.SK)
                } else {
                    approveProposal(topPending)
                }
                return
            }
            if (Regex("^(no|no thanks|cancel|reject|deny|abort|don't|dont)$").matches(normalizedReply)) {
                rejectProposal(topPending.proposalId)
                return
            }
        }

        when (val intent = SkVoiceCommandParser.parse(trimmed)) {
            ParsedVoiceIntent.ActivateMaster -> returnToSkMaster()
            is ParsedVoiceIntent.SetMode -> when (intent.mode) {
                InterfaceMode.NORMAL -> activateNormalMode()
                InterfaceMode.PHOENIX -> activatePhoenixMode()
                InterfaceMode.ASSEMBLED -> assembleAll()
                InterfaceMode.ASSISTANT_ACTIVE -> Unit
            }
            ParsedVoiceIntent.AssembleAll -> assembleAll()
            ParsedVoiceIntent.DisassembleAll -> disassembleAll()
            ParsedVoiceIntent.StopSpeech -> stopSpeaking()
            is ParsedVoiceIntent.SetVoiceEnabled -> {
                toggleVoice(intent.enabled)
                recordBanner(if (intent.enabled) "Voice interaction enabled." else "Voice interaction disabled.")
                speechRecognizer.resetStateToIdle()
            }
            is ParsedVoiceIntent.OpenDetailsSection -> {
                requestedDetailsSection.value = intent.sectionName
                recordBanner(intent.spokenSummary)
                speakIfEnabled(intent.spokenSummary, AssistantId.SK)
            }
            ParsedVoiceIntent.CloseDetailsSection -> {
                requestedDetailsSection.value = null
                recordBanner("Closed details overlay.")
                speechRecognizer.resetStateToIdle()
            }
            is ParsedVoiceIntent.ActivateAssistant -> {
                if (intent.trailingCommand.isNullOrBlank()) {
                    activateAssistantDirect(intent.assistantId, silent = false)
                    speechRecognizer.resetStateToIdle()
                } else {
                    activateAssistantDirect(intent.assistantId, silent = true)
                    routeTaskCommand(trimmed, intent.assistantId)
                }
            }
            is ParsedVoiceIntent.RouteCommand -> {
                val preferred = uiState.value.activeIdentity.takeIf { it != AssistantId.SK }
                routeTaskCommand(intent.commandText, preferred)
            }
        }
    }

    fun retryLastCommand() {
        val failed = lastFailedCommandText.value ?: return
        routeTaskCommand(failed, lastFailedPreferred)
    }

    private fun routeTaskCommand(commandText: String, preferred: AssistantId?) {
        val cleanCmd = commandText.trim()
        if (cleanCmd.isEmpty()) return
        routingJob?.cancel()
        routingJob = viewModelScope.launch {
            isRouting.value = true
            lastFailedCommandText.value = null
            missingPermissions.value = emptyList()
            try {
                val result = container.skMasterCore.routeUserUtterance(cleanCmd, preferred)
                result.onSuccess { outcome ->
                    lastFailedCommandText.value = null
                    lastFailedPreferred = null
                    when (outcome) {
                        is SkRouteOutcome.DirectResponse -> {
                            if (outcome.speaker != AssistantId.SK) {
                                activateAssistantDirect(outcome.speaker, silent = true)
                            }
                            speechRecognizer.markResponding()
                            recordBanner(outcome.replyText)
                            speakIfEnabled(outcome.replyText, outcome.speaker)
                        }
                        is SkRouteOutcome.ProposalRequired -> {
                            if (outcome.deduplicated) {
                                val dupMsg = "Pending approval already exists for ${outcome.proposal.targetAssistant.name} (${outcome.proposal.exactOperation})."
                                recordBanner(dupMsg)
                                speechRecognizer.resetStateToIdle()
                            } else {
                                speechRecognizer.markResponding()
                                val askText = if (outcome.proposal.isCriticalRisk) {
                                    "Critical authorization required. Review parameters and confirm ${outcome.proposal.exactOperation} on screen."
                                } else {
                                    "Should I proceed with ${outcome.proposal.actionSummary}? Say yes to approve or no to cancel."
                                }
                                recordBanner(askText)
                                speakIfEnabled(askText, outcome.proposal.targetAssistant)
                            }
                        }
                        is SkRouteOutcome.ContactSelectionRequired -> {
                            pendingContactChoice.value = PendingContactChoice(
                                actionType = outcome.actionType,
                                queryName = outcome.queryName,
                                candidates = outcome.candidates,
                                messageBody = outcome.messageBody,
                                rawInput = outcome.rawInput
                            )
                            val msg = "Multiple contacts match \"${outcome.queryName}\". Select the intended contact."
                            recordBanner(msg)
                            speakIfEnabled(msg, AssistantId.SK)
                        }
                        is SkRouteOutcome.SimSelectionRequired -> {
                            pendingSimChoice.value = PendingSimChoice(
                                actionType = "CALL_CONTACT",
                                candidate = ContactCandidate(outcome.contactName, outcome.phoneNumber),
                                simOptions = outcome.simOptions,
                                messageBody = null,
                                rawInput = outcome.rawInput
                            )
                            val msg = "Select which SIM card to use to call ${outcome.contactName}."
                            recordBanner(msg)
                            speakIfEnabled(msg, AssistantId.SK)
                        }
                    }
                }.onFailure { err ->
                    speechRecognizer.resetStateToIdle()
                    lastFailedCommandText.value = cleanCmd
                    lastFailedPreferred = preferred
                    recordBanner(err.message ?: "Command routing failed. Tap Retry to try again.")
                }
            } finally {
                isRouting.value = false
            }
        }
    }

    fun selectContactCandidate(candidate: ContactCandidate) {
        val choice = pendingContactChoice.value ?: return
        pendingContactChoice.value = null
        viewModelScope.launch {
            val outcome = container.skMasterCore.createProposalForResolvedContact(
                actionType = choice.actionType,
                candidate = candidate,
                simOption = null,
                messageBody = choice.messageBody,
                rawInput = choice.rawInput
            )
            when (outcome) {
                is SkRouteOutcome.SimSelectionRequired -> {
                    pendingSimChoice.value = PendingSimChoice(
                        actionType = choice.actionType,
                        candidate = candidate,
                        simOptions = outcome.simOptions,
                        messageBody = choice.messageBody,
                        rawInput = choice.rawInput
                    )
                    val msg = "Select which SIM card to use to call ${candidate.displayName}."
                    lastBanner.value = msg
                    speakIfEnabled(msg, AssistantId.SK)
                }
                is SkRouteOutcome.ProposalRequired -> {
                    val msg = "Approval ready for ${candidate.displayName} (${candidate.phoneNumber})."
                    lastBanner.value = msg
                    speakIfEnabled(msg, AssistantId.SK)
                }
                else -> Unit
            }
        }
    }

    fun selectSimOption(sim: SimAccountOption) {
        val simChoice = pendingSimChoice.value ?: return
        pendingSimChoice.value = null
        viewModelScope.launch {
            val outcome = container.skMasterCore.createProposalForResolvedContact(
                actionType = simChoice.actionType,
                candidate = simChoice.candidate,
                simOption = sim,
                messageBody = simChoice.messageBody,
                rawInput = simChoice.rawInput
            )
            if (outcome is SkRouteOutcome.ProposalRequired) {
                val msg = "Prepared ${simChoice.candidate.displayName} call via ${sim.displayName} (${sim.carrierName}) for approval."
                lastBanner.value = msg
                speakIfEnabled(msg, AssistantId.SK)
            }
        }
    }

    fun dismissDisambiguation() {
        pendingContactChoice.value = null
        pendingSimChoice.value = null
    }

    fun toggleVoiceListening(onNeedAudioPermission: () -> Unit) {
        if (uiState.value.isListening) {
            speechRecognizer.stopListening()
            return
        }
        if (!speechRecognizer.hasAudioPermission()) {
            speechRecognizer.markPermissionRequired("Microphone permission is needed to listen for voice commands.")
            onNeedAudioPermission()
            return
        }
        micPermanentDenied.value = false
        voiceEngine.stopSpeaking()
        speechRecognizer.startListening()
    }

    fun onAudioPermissionResult(granted: Boolean, permanentlyDenied: Boolean) {
        if (granted) {
            micPermanentDenied.value = false
            voiceEngine.stopSpeaking()
            speechRecognizer.startListening()
        } else {
            micPermanentDenied.value = permanentlyDenied
            val msg = if (permanentlyDenied) {
                "Microphone permission was permanently denied. Open App Settings to enable Microphone access."
            } else {
                "Microphone permission denied. Tap the mic button to grant access when ready."
            }
            speechRecognizer.markPermissionRequired(msg)
            lastBanner.value = msg
        }
    }

    fun onRuntimePermissionsResult(allGranted: Boolean, permanentlyDenied: Boolean) {
        if (allGranted) {
            missingPermissions.value = emptyList()
            missingPermsPermanent.value = false
        } else {
            missingPermsPermanent.value = permanentlyDenied
        }
    }

    fun toggleVoice(enabled: Boolean) {
        if (!enabled) voiceEngine.stopSpeaking()
        viewModelScope.launch {
            container.preferencesStore.setVoiceEnabled(enabled)
        }
    }

    fun setVoiceProviderMode(mode: VoiceProviderMode) {
        viewModelScope.launch {
            container.preferencesStore.setVoiceProviderMode(mode)
        }
    }

    fun updateVoiceTuning(id: AssistantId, pitch: Float, speechRate: Float) {
        viewModelScope.launch {
            container.preferencesStore.updateVoiceTuning(id, pitch, speechRate)
        }
    }

    fun previewAssistantVoice(id: AssistantId) {
        val sampleText = when (id) {
            AssistantId.SK -> "SK Master Controller online. All subsystems synchronized under explicit approval control."
            AssistantId.JARVIS -> "Good day. JARVIS analytical reasoning module is online and at your service."
            AssistantId.MAGMITE -> "MAGMITE hardware interface standing by. Android device controls calibrated."
            AssistantId.ULTRON -> "ULTRON diagnostic lattice active. System telemetry and automation rules verified."
            AssistantId.FRIDAY -> "Hello! FRIDAY personal scheduling assistant here, ready to organize your agenda."
        }
        val config = uiState.value.voiceConfigs[id] ?: OmegaIdentityCatalog.profiles.getValue(id).voiceConfig
        voiceEngine.speak(sampleText, id, config, uiState.value.voiceProviderMode)
    }

    fun setAnimationQuality(quality: AnimationQuality) {
        viewModelScope.launch {
            container.preferencesStore.setAnimationQuality(quality)
        }
    }

    fun toggleAssistantAvailability(id: AssistantId, enabled: Boolean) {
        if (id == AssistantId.SK) return
        viewModelScope.launch {
            container.registry.setAssistantEnabled(id, enabled)
            container.preferencesStore.setAssistantEnabled(id, enabled)
            container.auditLogger.log(
                eventType = if (enabled) "ASSISTANT_ENABLED" else "ASSISTANT_DISABLED",
                actor = AssistantId.SK,
                proposalId = null,
                summary = "SK set ${id.name} availability to ${if (enabled) "ONLINE" else "DISABLED"}"
            )
        }
    }

    fun approveProposal(proposal: TaskProposal) {
        viewModelScope.launch {
            isExecuting.value = true
            when (val res = container.skMasterCore.approveAndExecute(proposal)) {
                is AssistantExecutionResult.Success -> {
                    recordBanner("${res.assistantId.name}: ${res.summary}")
                    speakIfEnabled(res.summary, res.assistantId)
                    missingPermissions.value = emptyList()
                    missingPermsPermanent.value = false
                }
                is AssistantExecutionResult.PermissionMissing -> {
                    missingPermissions.value = res.missingPermissions
                    missingPermsPermanent.value = false
                    recordBanner("Grant required Android permissions for ${res.assistantId.name} before retrying.")
                }
                is AssistantExecutionResult.Denied -> {
                    recordBanner("Execution blocked: ${res.reason}")
                }
                is AssistantExecutionResult.Failure -> {
                    recordBanner("${res.assistantId.name} error: ${res.errorMessage}")
                }
            }
            isExecuting.value = false
        }
    }

    fun rejectProposal(proposalId: String) {
        viewModelScope.launch {
            container.skMasterCore.rejectProposal(proposalId)
            recordBanner("Proposal $proposalId rejected by user.")
        }
    }

    fun generateSystemReport() {
        viewModelScope.launch {
            val report = container.skMasterCore.generatePeriodicSystemReport("Manual SK Audit")
            recordBanner("System report ${report.reportId} generated.")
        }
    }

    fun acknowledgeAlert(alertId: String) {
        container.skMasterCore.acknowledgeAlert(alertId)
    }

    fun clearMissingPermissionsPrompt() {
        missingPermissions.value = emptyList()
        missingPermsPermanent.value = false
    }

    private fun speakIfEnabled(text: String, speaker: AssistantId) {
        if (!uiState.value.voiceEnabled) {
            speechRecognizer.resetStateToIdle()
            return
        }
        val config = uiState.value.voiceConfigs[speaker]
            ?: OmegaIdentityCatalog.profiles[speaker]?.voiceConfig
            ?: return
        voiceEngine.speak(text, speaker, config, uiState.value.voiceProviderMode)
    }

    override fun onCleared() {
        super.onCleared()
        speechRecognizer.stopListening()
        voiceEngine.shutdown()
    }
}

private data class CoreDataSlice(
    val activeId: AssistantId,
    val states: Map<AssistantId, RegisteredAssistantState>,
    val pending: List<TaskProposal>,
    val history: List<TaskHistoryEntity>,
    val audits: List<AuditLogEntity>
)

private data class TelemetrySlice(
    val reminders: List<ReminderEntity>,
    val reports: List<SystemReportEntity>,
    val alerts: List<SystemAlert>,
    val voice: Boolean,
    val animQuality: AnimationQuality
)

private data class VoiceSettingsSlice(
    val providerMode: VoiceProviderMode,
    val configs: Map<AssistantId, VoiceConfig>,
    val descriptions: Map<AssistantId, String>,
    val localVoices: List<LocalTtsVoiceInfo>,
    val notice: String?
)

private data class ModeSlice(
    val mode: InterfaceMode,
    val stage: AssemblyStage,
    val speaking: AssistantId?,
    val recState: VoiceState,
    val rms: Float
)

private data class StatusSlice(
    val routing: Boolean,
    val executing: Boolean,
    val banner: String?,
    val missingPerms: List<String>,
    val speechErr: String?
)

private data class SpeechMetaSlice(
    val listening: Boolean,
    val partial: String,
    val recognized: String,
    val greeting: String?,
    val micPermDenied: Boolean
)

private data class ChoiceAndDetailsSlice(
    val contactChoice: PendingContactChoice?,
    val simChoice: PendingSimChoice?,
    val permsPerm: Boolean,
    val resultsHistory: List<String>,
    val requestedSection: String?
)
