package com.projectomega.sk.ui.holographic

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.setValue
import androidx.compose.runtime.withFrameNanos
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Rect
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.PathEffect
import androidx.compose.ui.graphics.Shadow
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.clipPath
import androidx.compose.ui.graphics.drawscope.rotate
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.projectomega.sk.core.model.AnimationQuality
import com.projectomega.sk.core.model.AssistantId
import com.projectomega.sk.core.model.AssistantStatus
import com.projectomega.sk.core.model.OmegaIdentityCatalog
import com.projectomega.sk.core.model.VoiceState
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlin.math.PI
import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.max
import kotlin.math.sin
import kotlin.math.sqrt

enum class CoreVisualState {
    IDLE,
    LISTENING,
    THINKING,
    SPEAKING,
    ACTIVATING,
    OFFLINE
}

private data class HoloFloatingParticle(
    val angle: Float,
    val orbitRadiusFactor: Float,
    val speed: Float,
    val verticalPhase: Float,
    val verticalAmpFactor: Float,
    val tilt: Float,
    val sizeDp: Float,
    val baseAlpha: Float
)

private data class HoloOrbitConfig(
    val rxFactor: Float,
    val ryFactor: Float,
    val baseTiltDeg: Float,
    val rotSpeed: Float,
    val useSecondary: Boolean,
    val useListenAccent: Boolean,
    val strokeDp: Float,
    val dashIntervals: FloatArray?
)

private fun buildHoloParticlePool(count: Int): List<HoloFloatingParticle> {
    return List(count) { i ->
        val seed = ((i * 1.61803398875) % 1.0).toFloat()
        val seed2 = ((i * 2.718281828) % 1.0).toFloat()
        HoloFloatingParticle(
            angle = ((i.toFloat() / count) * (2.0 * PI) + seed * 0.5).toFloat(),
            orbitRadiusFactor = 0.44f + seed * 0.52f,
            speed = (if (i % 2 == 0) 1f else -1f) * (0.26f + seed2 * 0.48f),
            verticalPhase = i * 0.9f,
            verticalAmpFactor = 0.024f + seed * 0.045f,
            tilt = (seed2 - 0.5f) * 0.95f,
            sizeDp = 1.1f + seed * 2.0f,
            baseAlpha = 0.28f + seed2 * 0.52f
        )
    }
}

/**
 * Universal Borderless Open-Space Floating Holographic Core Visualizer for JARVIS, ULTRON, and FRIDAY.
 * Preserves each identity's distinct geometry, color palette, orbital node count, and 6-state animation.
 */
@Composable
fun HolographicCoreCanvas(
    activeAssistant: AssistantId,
    isEnabled: Boolean = true,
    status: AssistantStatus = AssistantStatus.ONLINE,
    voiceState: VoiceState = VoiceState.IDLE,
    voiceRmsLevel: Float = 0f,
    isSpeaking: Boolean = false,
    isRouting: Boolean,
    isExecuting: Boolean,
    hasPendingApproval: Boolean,
    animationQuality: AnimationQuality = AnimationQuality.HIGH_60FPS,
    modifier: Modifier = Modifier
) {
    val profile = remember(activeAssistant) { OmegaIdentityCatalog.profiles.getValue(activeAssistant) }
    val particles = remember { buildHoloParticlePool(28) }
    val orbitConfigs = remember(activeAssistant) {
        when (activeAssistant) {
            AssistantId.JARVIS -> listOf(
                HoloOrbitConfig(1.08f, 0.46f, 21f, 0.68f, false, false, 1.5f, floatArrayOf(18f, 8f)),
                HoloOrbitConfig(0.94f, 0.40f, -45f, -0.92f, true, false, 1.35f, floatArrayOf(6f, 8f)),
                HoloOrbitConfig(0.82f, 0.34f, 72f, 1.05f, false, true, 1.15f, null)
            )
            AssistantId.ULTRON -> listOf(
                HoloOrbitConfig(1.06f, 0.36f, 30f, 0.88f, false, false, 1.75f, floatArrayOf(12f, 6f, 4f, 6f)),
                HoloOrbitConfig(0.95f, 0.34f, -30f, -1.12f, true, false, 1.5f, floatArrayOf(10f, 6f)),
                HoloOrbitConfig(0.82f, 0.30f, 90f, 0.95f, false, true, 1.3f, floatArrayOf(8f, 8f))
            )
            else -> listOf(
                HoloOrbitConfig(1.07f, 0.48f, 18f, 0.62f, false, false, 1.5f, null),
                HoloOrbitConfig(0.94f, 0.42f, -39f, -0.78f, true, false, 1.35f, floatArrayOf(16f, 10f)),
                HoloOrbitConfig(0.82f, 0.36f, 54f, 0.90f, false, true, 1.15f, floatArrayOf(6f, 10f))
            )
        }
    }

    var activating by remember(activeAssistant) { mutableStateOf(true) }
    var activationProgress by remember(activeAssistant) { mutableFloatStateOf(0f) }

    LaunchedEffect(activeAssistant) {
        activating = true
        activationProgress = 0f
        val durationNs = 1_250_000_000L
        var startNs = 0L
        while (isActive && activating) {
            withFrameNanos { frameNanos ->
                if (startNs == 0L) startNs = frameNanos
                val progress = ((frameNanos - startNs).toFloat() / durationNs.toFloat()).coerceIn(0f, 1f)
                activationProgress = progress
                if (progress >= 1f) {
                    activating = false
                }
            }
        }
    }

    val visualState = when {
        !isEnabled || status == AssistantStatus.DISABLED -> CoreVisualState.OFFLINE
        activating -> CoreVisualState.ACTIVATING
        isSpeaking || voiceState == VoiceState.SPEAKING -> CoreVisualState.SPEAKING
        voiceState == VoiceState.LISTENING -> CoreVisualState.LISTENING
        isRouting || isExecuting || voiceState == VoiceState.PROCESSING || voiceState == VoiceState.RESPONDING ->
            CoreVisualState.THINKING
        else -> CoreVisualState.IDLE
    }

    val latestState by rememberUpdatedState(visualState)
    val latestRms by rememberUpdatedState(voiceRmsLevel.coerceIn(0f, 1f))
    val latestActProgress by rememberUpdatedState(activationProgress)

    var simTime by remember { mutableFloatStateOf(0f) }
    var pulseWave by remember { mutableFloatStateOf(0f) }

    LaunchedEffect(animationQuality, activeAssistant) {
        val frameDelayMs = animationQuality.targetFrameDelayMs
        var lastNanos = 0L
        while (isActive) {
            withFrameNanos { frameNanos ->
                if (lastNanos == 0L) {
                    lastNanos = frameNanos
                } else {
                    val elapsedMs = (frameNanos - lastNanos) / 1_000_000L
                    if (elapsedMs >= frameDelayMs) {
                        val dt = ((frameNanos - lastNanos) / 1_000_000_000f).coerceIn(0.008f, 0.05f)
                        lastNanos = frameNanos
                        val st = latestState
                        val rms = latestRms
                        val speedFactor = when {
                            animationQuality == AnimationQuality.REDUCED_MOTION -> 0.25f
                            st == CoreVisualState.OFFLINE -> 0.20f
                            st == CoreVisualState.THINKING -> 2.20f
                            st == CoreVisualState.SPEAKING -> 1.65f + rms * 0.85f
                            st == CoreVisualState.LISTENING -> 1.45f + rms * 0.70f
                            st == CoreVisualState.ACTIVATING -> 2.5f * (1f - latestActProgress * 0.4f)
                            activeAssistant == AssistantId.ULTRON -> 1.15f
                            activeAssistant == AssistantId.FRIDAY -> 0.90f
                            else -> 1.0f
                        }
                        simTime += dt * speedFactor
                        val pulseSpeed = when (st) {
                            CoreVisualState.OFFLINE -> 0.14f
                            CoreVisualState.THINKING -> 0.92f
                            CoreVisualState.SPEAKING -> 0.85f
                            else -> 0.42f
                        }
                        pulseWave = (pulseWave + dt * pulseSpeed) % 1f
                    }
                }
            }
            if (frameDelayMs > 20L) {
                delay(frameDelayMs - 16L)
            }
        }
    }

    val statusLabel = when (visualState) {
        CoreVisualState.OFFLINE -> "OFFLINE"
        CoreVisualState.ACTIVATING -> "ACTIVATING"
        CoreVisualState.LISTENING -> "LISTENING"
        CoreVisualState.THINKING -> if (isExecuting) "EXECUTING" else "THINKING"
        CoreVisualState.SPEAKING -> "SPEAKING"
        CoreVisualState.IDLE -> status.name
    }

    val configuration = LocalConfiguration.current
    val maxResponsiveHeight = (configuration.screenHeightDp * 0.36f).dp.coerceIn(190.dp, 290.dp)

    BoxWithConstraints(
        modifier = modifier.fillMaxWidth(),
        contentAlignment = Alignment.Center
    ) {
        val stageHeight = minOf(maxWidth * 0.80f, maxResponsiveHeight)

        Box(
            modifier = Modifier
                .fillMaxWidth()
                .height(stageHeight),
            contentAlignment = Alignment.Center
        ) {
            Canvas(modifier = Modifier.fillMaxSize()) {
                val minDim = size.minDimension
                val reducedMotion = animationQuality == AnimationQuality.REDUCED_MOTION
                val st = visualState
                val isOffline = st == CoreVisualState.OFFLINE
                val isListening = st == CoreVisualState.LISTENING
                val isThinking = st == CoreVisualState.THINKING
                val isSpeakingNow = st == CoreVisualState.SPEAKING
                val isActivating = st == CoreVisualState.ACTIVATING
                val rms = latestRms

                val ambientParallaxX = if (reducedMotion) 0f else sin(simTime * 0.65f) * 3.2.dp.toPx()
                val ambientParallaxY = if (reducedMotion) 0f else cos(simTime * 0.5f) * 2.4.dp.toPx()
                val levitationY = if (isOffline || reducedMotion) 0f else sin(simTime * 1.4f) * (minDim * 0.021f)

                val cx = size.width / 2f + ambientParallaxX * 0.4f
                val cy = size.height / 2f + levitationY + ambientParallaxY * 0.4f
                val center = Offset(cx, cy)

                val baseRadius = minDim * 0.34f
                val sphereScale = when {
                    isActivating -> 0.35f + 0.65f * sin(activationProgress * (PI.toFloat() / 2f))
                    isSpeakingNow -> 1f + 0.055f * sin(simTime * 6f) + rms * 0.14f
                    isListening -> 1f + 0.032f * sin(simTime * 4f) + rms * 0.09f
                    isOffline -> 0.90f
                    else -> 1f + 0.025f * sin(simTime * 2.0f)
                }
                val coreRadius = baseRadius * 0.38f * sphereScale

                val primaryColor = if (isOffline) Color(0xFF64748B) else Color(profile.visualIdentity.primaryColorHex)
                val secondaryColor = if (isOffline) Color(0xFF94A3B8) else Color(profile.visualIdentity.secondaryColorHex)
                val highlightColor = when {
                    isOffline -> Color(0xFFCBD5E1)
                    activeAssistant == AssistantId.JARVIS -> Color(0xFFDBEAFE)
                    activeAssistant == AssistantId.ULTRON -> Color(0xFFFECACA)
                    else -> Color(0xFFD1FAE5)
                }
                val listenAccent = Color(0xFF38BDF8)

                // 1. Open-Space Unbounded Volumetric Radial Aura (fades cleanly to transparent)
                val auraR = minDim * 0.49f
                drawCircle(
                    brush = Brush.radialGradient(
                        colorStops = arrayOf(
                            0.0f to highlightColor.copy(alpha = if (isOffline) 0.12f else if (isSpeakingNow) 0.38f else 0.24f),
                            0.35f to primaryColor.copy(alpha = if (isOffline) 0.06f else if (isThinking) 0.24f else 0.16f),
                            0.70f to secondaryColor.copy(alpha = if (isOffline) 0.02f else 0.06f),
                            1.0f to Color.Transparent
                        ),
                        center = center,
                        radius = auraR
                    ),
                    radius = auraR,
                    center = center
                )

                // 2. Dynamic Light Pulse Ripples
                if (!isOffline) {
                    val waveCount = if (isSpeakingNow || isActivating) 2 else 1
                    for (w in 0 until waveCount) {
                        val pPhase = (pulseWave + w * 0.5f) % 1f
                        val waveR = coreRadius * 1.15f + pPhase * (baseRadius * 1.24f - coreRadius)
                        val waveAlpha = (1f - pPhase) * if (isActivating) 0.46f else if (isSpeakingNow) 0.32f else 0.20f
                        drawCircle(
                            color = (if (isListening) listenAccent else secondaryColor).copy(alpha = waveAlpha),
                            radius = waveR,
                            center = center,
                            style = Stroke(width = (1.5f - pPhase * 0.8f).coerceAtLeast(0.6f).dp.toPx())
                        )
                    }
                }

                // 3. Back-Plane 3D Foreshortened Orbital Rings
                val ringExpand = if (isActivating) 0.45f + 0.55f * activationProgress else 1f
                val swayDeg = sin(simTime * 0.4f) * 3.0f
                val backCenter = Offset(cx - ambientParallaxX * 0.22f, cy - ambientParallaxY * 0.22f)

                orbitConfigs.forEach { cfg ->
                    val ringColor = when {
                        cfg.useListenAccent && isListening -> listenAccent
                        cfg.useSecondary -> secondaryColor
                        else -> primaryColor
                    }
                    drawCoreTiltedArc(
                        center = backCenter,
                        rx = baseRadius * cfg.rxFactor * ringExpand,
                        ry = baseRadius * cfg.ryFactor * ringExpand,
                        tiltDeg = cfg.baseTiltDeg + swayDeg,
                        startAngleDeg = 180f,
                        sweepAngleDeg = 180f,
                        color = ringColor.copy(alpha = if (isOffline) 0.14f else 0.28f),
                        strokeWidthPx = cfg.strokeDp.dp.toPx(),
                        dashIntervals = cfg.dashIntervals
                    )
                }

                // 4. Outer Identity Harmonic Containment Ring
                val outerDash = when (activeAssistant) {
                    AssistantId.ULTRON -> floatArrayOf(14f, 7f, 4f, 7f)
                    AssistantId.JARVIS -> floatArrayOf(24f, 10f)
                    else -> floatArrayOf(32f, 12f)
                }
                val outerRotDeg = simTime * (if (activeAssistant == AssistantId.ULTRON) -26.3f else 20.6f)
                rotate(degrees = outerRotDeg % 360f, pivot = center) {
                    drawCircle(
                        color = primaryColor.copy(alpha = if (isOffline) 0.16f else if (isThinking) 0.56f else 0.38f),
                        radius = baseRadius * 1.14f * ringExpand,
                        center = center,
                        style = Stroke(
                            width = (if (activeAssistant == AssistantId.ULTRON) 1.8f else 1.4f).dp.toPx(),
                            pathEffect = PathEffect.dashPathEffect(outerDash, 0f)
                        )
                    )
                }

                // 5. Identity-Specific Central Holographic Sphere
                drawCircle(
                    brush = Brush.radialGradient(
                        colorStops = arrayOf(
                            0.0f to highlightColor.copy(alpha = if (isOffline) 0.32f else 0.92f),
                            0.48f to secondaryColor.copy(alpha = if (isOffline) 0.22f else 0.72f),
                            0.84f to primaryColor.copy(alpha = if (isOffline) 0.14f else 0.48f),
                            1.0f to primaryColor.copy(alpha = if (isOffline) 0.05f else 0.12f)
                        ),
                        center = Offset(cx - coreRadius * 0.24f, cy - coreRadius * 0.24f),
                        radius = coreRadius * 1.15f
                    ),
                    radius = coreRadius,
                    center = center
                )

                if (!isOffline) {
                    val clipSphere = Path().apply {
                        addOval(
                            Rect(
                                left = cx - coreRadius * 0.94f,
                                top = cy - coreRadius * 0.94f,
                                right = cx + coreRadius * 0.94f,
                                bottom = cy + coreRadius * 0.94f
                            )
                        )
                    }
                    clipPath(clipSphere) {
                        when (activeAssistant) {
                            AssistantId.JARVIS -> {
                                for (ring in 0..1) {
                                    rotate(degrees = (simTime * (if (ring == 0) 51f else -40f)) % 360f, pivot = center) {
                                        val rx = coreRadius * (0.45f + ring * 0.24f)
                                        val ry = coreRadius * 0.90f
                                        drawOval(
                                            color = highlightColor.copy(alpha = if (ring == 0) 0.52f else 0.32f),
                                            topLeft = Offset(cx - rx, cy - ry),
                                            size = Size(rx * 2f, ry * 2f),
                                            style = Stroke(width = 1.2.dp.toPx())
                                        )
                                    }
                                }
                            }
                            AssistantId.ULTRON -> {
                                for (bar in -2..2) {
                                    val yOff = bar * (coreRadius * 0.28f)
                                    val pulseX = sin(simTime * 3.4f + bar) * coreRadius * 0.14f
                                    drawLine(
                                        color = highlightColor.copy(alpha = 0.5f),
                                        start = Offset(cx - coreRadius * 0.7f + pulseX, cy + yOff),
                                        end = Offset(cx + coreRadius * 0.7f + pulseX, cy + yOff),
                                        strokeWidth = 1.4.dp.toPx(),
                                        cap = StrokeCap.Round
                                    )
                                }
                            }
                            else -> {
                                val waveAmp = coreRadius * if (isSpeakingNow) 0.24f + rms * 0.16f else 0.14f
                                for (line in 0..1) {
                                    val wavePath = Path()
                                    val phaseOffset = line * 1.9f + simTime * if (line == 0) 2.8f else -2.1f
                                    val step = max(3f, coreRadius / 14f)
                                    var x = -coreRadius
                                    var first = true
                                    while (x <= coreRadius) {
                                        val norm = (x / coreRadius).coerceIn(-1f, 1f)
                                        val env = sqrt(max(0f, 1f - norm * norm))
                                        val y = sin(norm * 4.0f + phaseOffset) * waveAmp * env
                                        if (first) {
                                            wavePath.moveTo(cx + x, cy + y)
                                            first = false
                                        } else {
                                            wavePath.lineTo(cx + x, cy + y)
                                        }
                                        x += step
                                    }
                                    drawPath(
                                        path = wavePath,
                                        color = highlightColor.copy(alpha = if (line == 0) 0.56f else 0.34f),
                                        style = Stroke(width = 1.35.dp.toPx(), cap = StrokeCap.Round)
                                    )
                                }
                            }
                        }
                    }
                }

                // Specular Rim Highlight
                drawCircle(
                    color = highlightColor.copy(alpha = if (isOffline) 0.18f else if (isSpeakingNow) 0.85f else 0.52f),
                    radius = coreRadius,
                    center = center,
                    style = Stroke(width = 1.35.dp.toPx())
                )

                // 6. Identity Geometric Lattice Signature
                val nodes = profile.visualIdentity.orbitalNodes.coerceAtLeast(3)
                val latticeR = coreRadius * 1.44f * ringExpand
                val latticeRotDeg = simTime * (if (activeAssistant == AssistantId.ULTRON) 27.5f else -25.8f)
                rotate(degrees = latticeRotDeg % 360f, pivot = center) {
                    val polyPath = Path()
                    for (i in 0..nodes) {
                        val theta = (i * 2.0 * PI) / nodes
                        val px = cx + (cos(theta) * latticeR).toFloat()
                        val py = cy + (sin(theta) * latticeR).toFloat()
                        if (i == 0) polyPath.moveTo(px, py) else polyPath.lineTo(px, py)
                    }
                    drawPath(
                        path = polyPath,
                        color = secondaryColor.copy(alpha = if (isOffline) 0.16f else if (isThinking) 0.72f else 0.46f),
                        style = Stroke(width = (if (activeAssistant == AssistantId.ULTRON) 1.5f else 1.15f).dp.toPx())
                    )

                    if (activeAssistant == AssistantId.FRIDAY) {
                        rotate(degrees = 45f, pivot = center) {
                            val poly2 = Path()
                            for (i in 0..nodes) {
                                val theta = (i * 2.0 * PI) / nodes
                                val px = cx + (cos(theta) * latticeR * 0.92f).toFloat()
                                val py = cy + (sin(theta) * latticeR * 0.92f).toFloat()
                                if (i == 0) poly2.moveTo(px, py) else poly2.lineTo(px, py)
                            }
                            drawPath(
                                path = poly2,
                                color = primaryColor.copy(alpha = if (isOffline) 0.12f else 0.34f),
                                style = Stroke(width = 1.1.dp.toPx())
                            )
                        }
                    } else if (activeAssistant == AssistantId.JARVIS) {
                        for (i in 0 until nodes) {
                            val theta = (i * 2.0 * PI) / nodes
                            drawLine(
                                color = secondaryColor.copy(alpha = if (isOffline) 0.16f else 0.48f),
                                start = Offset(
                                    cx + (cos(theta) * coreRadius * 1.05f).toFloat(),
                                    cy + (sin(theta) * coreRadius * 1.05f).toFloat()
                                ),
                                end = Offset(
                                    cx + (cos(theta) * latticeR).toFloat(),
                                    cy + (sin(theta) * latticeR).toFloat()
                                ),
                                strokeWidth = 1.1.dp.toPx()
                            )
                        }
                    }
                }

                // 7. Front-Plane 3D Rings
                val frontCenter = Offset(cx + ambientParallaxX * 0.22f, cy + ambientParallaxY * 0.22f)
                orbitConfigs.forEach { cfg ->
                    val ringColor = when {
                        cfg.useListenAccent && isListening -> listenAccent
                        cfg.useSecondary -> secondaryColor
                        else -> primaryColor
                    }
                    drawCoreTiltedArc(
                        center = frontCenter,
                        rx = baseRadius * cfg.rxFactor * ringExpand,
                        ry = baseRadius * cfg.ryFactor * ringExpand,
                        tiltDeg = cfg.baseTiltDeg + swayDeg,
                        startAngleDeg = 0f,
                        sweepAngleDeg = 180f,
                        color = ringColor.copy(alpha = if (isOffline) 0.22f else if (isThinking || isSpeakingNow) 0.88f else 0.68f),
                        strokeWidthPx = (cfg.strokeDp * 1.15f).dp.toPx(),
                        dashIntervals = cfg.dashIntervals
                    )
                }

                // 8. Identity Orbital Nodes with Energy Trails
                val nodeOrbitA = orbitConfigs[0]
                val nodeOrbitB = orbitConfigs[1]
                val trailSteps = if (isOffline) 2 else 6

                for (i in 0 until nodes) {
                    val cfg = if (i % 2 == 0) nodeOrbitA else nodeOrbitB
                    val rx = baseRadius * cfg.rxFactor * ringExpand
                    val ry = baseRadius * cfg.ryFactor * ringExpand
                    val tiltRad = ((cfg.baseTiltDeg + swayDeg) * PI / 180.0).toFloat()
                    val baseTheta = ((i * 2.0 * PI) / nodes).toFloat() + simTime * cfg.rotSpeed
                    val dirSign = if (cfg.rotSpeed >= 0f) 1f else -1f

                    for (s in trailSteps downTo 1) {
                        val lagTheta = baseTheta - s * 0.08f * dirSign
                        val lx = cos(lagTheta) * rx
                        val ly = sin(lagTheta) * ry
                        val tx = cx + lx * cos(tiltRad) - ly * sin(tiltRad)
                        val ty = cy + lx * sin(tiltRad) + ly * cos(tiltRad)
                        val frac = 1f - s.toFloat() / (trailSteps + 1).toFloat()
                        drawCircle(
                            color = primaryColor.copy(alpha = (if (isOffline) 0.08f else 0.45f) * frac * frac),
                            radius = (2.3f * frac).dp.toPx(),
                            center = Offset(tx, ty)
                        )
                    }

                    val lx = cos(baseTheta) * rx
                    val ly = sin(baseTheta) * ry
                    val nx = cx + lx * cos(tiltRad) - ly * sin(tiltRad)
                    val ny = cy + lx * sin(tiltRad) + ly * cos(tiltRad)
                    val nodePos = Offset(nx, ny)
                    val isFront = sin(baseTheta) >= 0f
                    val nodeRadiusPx = ((if (isFront) 3.7f else 2.6f) + if (isSpeakingNow) rms * 1.5f else 0f).dp.toPx()

                    drawCircle(
                        brush = Brush.radialGradient(
                            colorStops = arrayOf(
                                0.0f to highlightColor.copy(alpha = if (isOffline) 0.25f else 0.92f),
                                0.45f to primaryColor.copy(alpha = if (isOffline) 0.12f else 0.52f),
                                1.0f to Color.Transparent
                            ),
                            center = nodePos,
                            radius = nodeRadiusPx * 3.0f
                        ),
                        radius = nodeRadiusPx * 3.0f,
                        center = nodePos
                    )
                    drawCircle(
                        color = when {
                            isOffline -> primaryColor.copy(alpha = 0.5f)
                            isFront -> highlightColor.copy(alpha = 0.98f)
                            else -> secondaryColor.copy(alpha = 0.84f)
                        },
                        radius = nodeRadiusPx,
                        center = nodePos
                    )
                }

                // 9. Audio-Reactive Radial Harmonic Filaments
                if (isListening || isSpeakingNow) {
                    val filaments = 32
                    val ringBaseR = baseRadius * 1.22f
                    val baseLineW = 1.9.dp.toPx()
                    for (i in 0 until filaments) {
                        val theta = ((i * 2.0 * PI) / filaments).toFloat() + simTime * 0.45f
                        val harmonic = 0.4f + 0.6f * abs(sin(simTime * 4.6f + i * 0.65f))
                        val ampPx = (4f + 15f * max(0.18f, rms)).dp.toPx() * harmonic
                        drawLine(
                            color = (if (isListening) listenAccent else secondaryColor).copy(alpha = 0.38f + 0.44f * harmonic),
                            start = Offset(cx + cos(theta) * ringBaseR, cy + sin(theta) * ringBaseR),
                            end = Offset(cx + cos(theta) * (ringBaseR + ampPx), cy + sin(theta) * (ringBaseR + ampPx)),
                            strokeWidth = baseLineW,
                            cap = StrokeCap.Round
                        )
                    }
                }

                // 10. Floating 3D Energy Particles in Open Space
                for (i in particles.indices) {
                    val pt = particles[i]
                    val theta = pt.angle + simTime * pt.speed
                    val pull = when {
                        isActivating -> 1.50f - 0.50f * activationProgress
                        isThinking -> 0.84f
                        isSpeakingNow -> 1.06f + rms * 0.14f
                        else -> 1.0f
                    }
                    val r = minDim * 0.47f * pt.orbitRadiusFactor * pull
                    val pxLocal = cos(theta) * r
                    val pzDepth = sin(theta)
                    val pyLocal = sin(theta + pt.tilt) * r * 0.36f +
                        sin(simTime * 1.3f + pt.verticalPhase) * (minDim * pt.verticalAmpFactor)

                    val px = cx + pxLocal + ambientParallaxX * (0.35f + pzDepth * 0.25f)
                    val py = cy + pyLocal + ambientParallaxY * (0.35f + pzDepth * 0.25f)
                    val depthScale = 0.68f + (pzDepth + 1f) * 0.32f
                    val twinkle = 0.6f + 0.4f * sin(simTime * 2.8f + pt.verticalPhase)
                    val alpha = (pt.baseAlpha *
                        twinkle *
                        (if (isOffline) 0.20f else if (hasPendingApproval) 1.0f else 0.85f) *
                        (0.55f + (pzDepth + 1f) * 0.225f)).coerceIn(0f, 1f)

                    val ptColor = when {
                        i % 5 == 0 && isListening -> listenAccent
                        i % 3 == 0 -> highlightColor
                        else -> secondaryColor
                    }
                    drawCircle(
                        color = ptColor.copy(alpha = alpha),
                        radius = (pt.sizeDp * depthScale).dp.toPx(),
                        center = Offset(px, py)
                    )
                }
            }

            // Centered Floating Identity Overlay (zero rectangular container)
            Column(
                horizontalAlignment = Alignment.CenterHorizontally,
                modifier = Modifier.padding(horizontal = 16.dp)
            ) {
                Text(
                    text = statusLabel,
                    color = (if (isEnabled && status != AssistantStatus.DISABLED) {
                        Color(profile.visualIdentity.secondaryColorHex)
                    } else {
                        Color(0xFF94A3B8)
                    }).copy(alpha = 0.88f),
                    fontSize = 9.sp,
                    fontFamily = FontFamily.Monospace,
                    letterSpacing = 2.sp,
                    style = TextStyle(
                        shadow = Shadow(color = Color.Black, offset = Offset(0f, 1f), blurRadius = 6f)
                    )
                )
                Text(
                    text = profile.displayName,
                    color = Color.White,
                    fontSize = 18.sp,
                    fontWeight = FontWeight.Bold,
                    letterSpacing = 1.6.sp,
                    style = TextStyle(
                        shadow = Shadow(color = Color.Black, offset = Offset(0f, 2f), blurRadius = 10f)
                    )
                )
                Text(
                    text = if (hasPendingApproval) "APPROVAL PENDING" else profile.visualIdentity.emblemLabel,
                    color = Color(profile.visualIdentity.primaryColorHex).copy(alpha = 0.92f),
                    fontSize = 10.sp,
                    fontFamily = FontFamily.Monospace,
                    letterSpacing = 1.4.sp,
                    style = TextStyle(
                        shadow = Shadow(color = Color.Black, offset = Offset(0f, 1f), blurRadius = 8f)
                    )
                )
            }
        }
    }
}

private fun DrawScope.drawCoreTiltedArc(
    center: Offset,
    rx: Float,
    ry: Float,
    tiltDeg: Float,
    startAngleDeg: Float,
    sweepAngleDeg: Float,
    color: Color,
    strokeWidthPx: Float,
    dashIntervals: FloatArray?
) {
    rotate(degrees = tiltDeg, pivot = center) {
        drawArc(
            color = color,
            startAngle = startAngleDeg,
            sweepAngle = sweepAngleDeg,
            useCenter = false,
            topLeft = Offset(center.x - rx, center.y - ry),
            size = Size(rx * 2f, ry * 2f),
            style = Stroke(
                width = strokeWidthPx,
                cap = StrokeCap.Round,
                pathEffect = dashIntervals?.let { PathEffect.dashPathEffect(it, 0f) }
            )
        )
    }
}
