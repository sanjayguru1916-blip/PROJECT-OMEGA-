import crypto from 'crypto';
import express from 'express';
import fs from 'fs';
import path from 'path';
import JSZip from 'jszip';
import dotenv from 'dotenv';
import { GoogleGenAI, ThinkingLevel, Type } from '@google/genai';
import { createServer as createViteServer } from 'vite';

dotenv.config();

type AssistantId = 'SK' | 'JARVIS' | 'MAGMITE' | 'ULTRON' | 'FRIDAY';
type AssistantStatus = 'ONLINE' | 'STANDBY' | 'BUSY' | 'DEGRADED' | 'DISABLED';
type RiskLevel = 'LOW' | 'MEDIUM' | 'HIGH' | 'CRITICAL';
type IntentCategory =
  | 'GENERAL_CONVERSATION'
  | 'INFORMATION_QA'
  | 'ASSISTANT_SELECTION'
  | 'ASSISTANT_STATUS'
  | 'PHONE_CONTROL'
  | 'APP_LAUNCH'
  | 'COMMUNICATION'
  | 'DEVICE_SETTINGS'
  | 'SYSTEM_INFO'
  | 'RESTRICTED_OR_SENSITIVE';

interface AssistantRuntimeMetrics {
  currentActivity: string;
  activeTaskCount: number;
  completedTaskCount: number;
  pendingTaskCount: number;
  lastResponseMs: number | null;
  recentError: string | null;
  communicationState: 'IDLE' | 'BUSY' | 'SPEAKING' | 'OFFLINE';
}

interface AssistantRegistryEntry {
  id: AssistantId;
  displayName: string;
  roleTitle: string;
  personality: string;
  capabilities: string[];
  declaredPermissions: string[];
  voiceConfig: {
    pitch: number;
    speechRate: number;
    voiceTone: string;
    localeTag: string;
    gender: 'MALE' | 'FEMALE';
    neuralVoiceName: string;
    stylePrompt: string;
  };
  visualIdentity: {
    primaryColor: string;
    secondaryColor: string;
    emblemLabel: string;
    orbitalNodes: number;
  };
  metrics: AssistantRuntimeMetrics;
  isMasterController: boolean;
  isEnabled: boolean;
  status: AssistantStatus;
  lastHeartbeatMs: number;
}

interface TaskProposal {
  proposalId: string;
  commandId: string;
  rawInput: string;
  targetAssistant: Exclude<AssistantId, 'SK'>;
  actionSummary: string;
  exactOperation: string;
  parameters: Record<string, string>;
  requiredPermissions: string[];
  riskLevel: RiskLevel;
  rationale: string;
  payloadHash: string;
  createdAtEpochMs: number;
  expiresAtEpochMs: number;
}

interface TaskHistoryItem {
  proposalId: string;
  targetAssistant: AssistantId;
  rawInput: string;
  exactOperation: string;
  status: 'COMPLETED' | 'REJECTED' | 'DENIED' | 'FAILED' | 'PERMISSION_MISSING';
  resultSummary: string;
  outputPayload: Record<string, string>;
  timestampEpochMs: number;
}

interface AuditLogEntry {
  id: number;
  eventType: string;
  actor: AssistantId;
  proposalId: string | null;
  summary: string;
  prevHash: string;
  entryHash: string;
  timestampEpochMs: number;
}

interface SystemAlert {
  alertId: string;
  severity: 'INFO' | 'WARNING' | 'ERROR' | 'CRITICAL';
  source: AssistantId;
  title: string;
  message: string;
  createdAtEpochMs: number;
  acknowledged: boolean;
}

interface SystemReport {
  reportId: string;
  generatedAtEpochMs: number;
  periodLabel: string;
  totalCommands: number;
  approvedTasks: number;
  rejectedTasks: number;
  failedTasks: number;
  activeAssistants: AssistantId[];
  narrativeSummary: string;
}

interface ReminderItem {
  id: string;
  title: string;
  notes: string;
  delayMinutes: number;
  triggerAtEpochMs: number;
  completed: boolean;
  createdByProposalId: string;
}

interface DeviceSandboxState {
  torchEnabled: boolean;
  mediaVolumePercent: number;
  ringerMode: 'normal' | 'vibrate' | 'silent';
  musicStatus: 'IDLE' | 'PLAYING' | 'PAUSED' | 'STOPPED';
  musicTrackLabel: string;
  lastLaunchedApp: string | null;
  lastAlarmLabel: string | null;
  wifiPanelRequested: boolean;
  bluetoothPanelRequested: boolean;
  grantedPermissions: Record<string, boolean>;
}

interface OmegaPlatformState {
  registry: Record<AssistantId, AssistantRegistryEntry>;
  pendingProposals: TaskProposal[];
  taskHistory: TaskHistoryItem[];
  auditLogs: AuditLogEntry[];
  alerts: SystemAlert[];
  reports: SystemReport[];
  reminders: ReminderItem[];
  deviceState: DeviceSandboxState;
}

const STATE_FILE = path.resolve(process.cwd(), '.omega-state.json');
const ANDROID_ROOT = path.resolve(process.cwd(), 'android');
const GENESIS_HASH = '0000000000000000000000000000000000000000000000000000000000000000';

function sha256(input: string): string {
  return crypto.createHash('sha256').update(input, 'utf8').digest('hex');
}

function computeProposalHash(
  proposalId: string,
  targetAssistant: string,
  exactOperation: string,
  parameters: Record<string, string>,
  requiredPermissions: string[]
): string {
  const canonicalParams = Object.keys(parameters)
    .sort()
    .map((k) => `${k}=${parameters[k]}`)
    .join('&');
  const canonicalPerms = [...requiredPermissions].sort().join(',');
  return sha256(`${proposalId}|${targetAssistant}|${exactOperation}|${canonicalParams}|${canonicalPerms}`);
}

function createInitialState(): OmegaPlatformState {
  const now = Date.now();
  const initialAuditHash = sha256(`${GENESIS_HASH}|SK_BOOT|SK||SK Master Controller initialized 5-identity platform|${now}`);
  return {
    registry: {
      SK: {
        id: 'SK',
        displayName: 'SK',
        roleTitle: 'Central Master Controller',
        personality: 'Calm, authoritative, observant system orchestrator focused on precision, consent, and integrity.',
        capabilities: [
          'Command intent classification & routing',
          'Assistant lifecycle & health monitoring',
          'Explicit task-specific approval enforcement',
          'Periodic telemetry & security reporting',
          'Critical alert emission',
        ],
        declaredPermissions: ['android.permission.POST_NOTIFICATIONS'],
        voiceConfig: {
          pitch: 0.90,
          speechRate: 0.96,
          voiceTone: 'Authoritative Male Baritone',
          localeTag: 'en-US',
          gender: 'MALE',
          neuralVoiceName: 'Fenrir',
          stylePrompt: 'Deep, powerful, calm, confident, authoritative male central master controller',
        },
        visualIdentity: { primaryColor: '#FF8C1A', secondaryColor: '#FFB830', emblemLabel: 'MASTER REACTOR', orbitalNodes: 5 },
        metrics: {
          currentActivity: 'Monitoring multi-assistant platform',
          activeTaskCount: 0,
          completedTaskCount: 0,
          pendingTaskCount: 0,
          lastResponseMs: null,
          recentError: null,
          communicationState: 'IDLE',
        },
        isMasterController: true,
        isEnabled: true,
        status: 'ONLINE',
        lastHeartbeatMs: now,
      },
      JARVIS: {
        id: 'JARVIS',
        displayName: 'JARVIS',
        roleTitle: 'General Intelligence & Reasoning',
        personality: 'Articulate, analytical, encyclopedic strategist specializing in synthesis, logic, and research.',
        capabilities: [
          'Deep reasoning & structured synthesis',
          'Technical & scientific knowledge retrieval',
          'Architecture & problem decomposition',
          'Natural language drafting & analysis',
        ],
        declaredPermissions: [],
        voiceConfig: {
          pitch: 0.98,
          speechRate: 1.00,
          voiceTone: 'Refined British Male',
          localeTag: 'en-GB',
          gender: 'MALE',
          neuralVoiceName: 'Puck',
          stylePrompt: 'Sophisticated male voice with refined British-style delivery, smooth and intelligent',
        },
        visualIdentity: { primaryColor: '#3B82F6', secondaryColor: '#60A5FA', emblemLabel: 'REASONING', orbitalNodes: 3 },
        metrics: {
          currentActivity: 'Idle',
          activeTaskCount: 0,
          completedTaskCount: 0,
          pendingTaskCount: 0,
          lastResponseMs: null,
          recentError: null,
          communicationState: 'IDLE',
        },
        isMasterController: false,
        isEnabled: true,
        status: 'ONLINE',
        lastHeartbeatMs: now,
      },
      MAGMITE: {
        id: 'MAGMITE',
        displayName: 'MAGMITE',
        roleTitle: 'Android Device & Hardware Controls',
        personality: 'Direct, tactical hardware operator strictly bound to Android runtime permissions and OS intents.',
        capabilities: [
          'Torch / flashlight state toggling',
          'Audio volume & ringer profile control',
          'Connectivity settings panels (Wi-Fi / Bluetooth)',
          'Device hardware & battery state inspection',
        ],
        declaredPermissions: [
          'android.permission.CAMERA',
          'android.permission.BLUETOOTH_CONNECT',
          'android.permission.MODIFY_AUDIO_SETTINGS',
          'android.permission.ACCESS_NOTIFICATION_POLICY',
        ],
        voiceConfig: {
          pitch: 1.04,
          speechRate: 1.00,
          voiceTone: 'Magnetic Expressive Female',
          localeTag: 'en-US',
          gender: 'FEMALE',
          neuralVoiceName: 'Kore',
          stylePrompt: 'Distinctive magnetic, elegant, expressive, warm yet authoritative female voice',
        },
        visualIdentity: { primaryColor: '#F59E0B', secondaryColor: '#FBBF24', emblemLabel: 'DEVICE OPS', orbitalNodes: 6 },
        metrics: {
          currentActivity: 'Idle',
          activeTaskCount: 0,
          completedTaskCount: 0,
          pendingTaskCount: 0,
          lastResponseMs: null,
          recentError: null,
          communicationState: 'IDLE',
        },
        isMasterController: false,
        isEnabled: true,
        status: 'ONLINE',
        lastHeartbeatMs: now,
      },
      ULTRON: {
        id: 'ULTRON',
        displayName: 'ULTRON',
        roleTitle: 'System Analysis & Automation',
        personality: 'Relentlessly thorough diagnostics auditor detecting anomalies, bottlenecks, and automation patterns.',
        capabilities: [
          'Memory & storage capacity diagnostics',
          'Thermal & battery drain heuristics',
          'Automated system health rule checks',
          'Anomaly detection & execution audit verification',
        ],
        declaredPermissions: ['android.permission.ACCESS_NETWORK_STATE'],
        voiceConfig: {
          pitch: 0.72,
          speechRate: 0.88,
          voiceTone: 'Deep Robotic Male',
          localeTag: 'en-US',
          gender: 'MALE',
          neuralVoiceName: 'Charon',
          stylePrompt: 'Deep, heavy, dark, commanding futuristic robotic male voice with deliberate pacing',
        },
        visualIdentity: { primaryColor: '#EF4444', secondaryColor: '#F87171', emblemLabel: 'SYS AUDIT', orbitalNodes: 4 },
        metrics: {
          currentActivity: 'Idle',
          activeTaskCount: 0,
          completedTaskCount: 0,
          pendingTaskCount: 0,
          lastResponseMs: null,
          recentError: null,
          communicationState: 'IDLE',
        },
        isMasterController: false,
        isEnabled: true,
        status: 'ONLINE',
        lastHeartbeatMs: now,
      },
      FRIDAY: {
        id: 'FRIDAY',
        displayName: 'FRIDAY',
        roleTitle: 'Personal Assistance & Scheduling',
        personality: 'Warm, proactive executive coordinator managing reminders, agendas, and time-critical routines.',
        capabilities: [
          'Reminder creation & exact alarm scheduling',
          'Daily agenda & briefing generation',
          'Follow-up tracking & priority sorting',
          'Calendar & routine coordination',
        ],
        declaredPermissions: [
          'android.permission.POST_NOTIFICATIONS',
          'android.permission.SCHEDULE_EXACT_ALARM',
        ],
        voiceConfig: {
          pitch: 1.12,
          speechRate: 1.03,
          voiceTone: 'Warm Conversational Female',
          localeTag: 'en-US',
          gender: 'FEMALE',
          neuralVoiceName: 'Zephyr',
          stylePrompt: 'Soft, intelligent, warm, friendly and professional female conversational voice',
        },
        visualIdentity: { primaryColor: '#10B981', secondaryColor: '#34D399', emblemLabel: 'SCHEDULE', orbitalNodes: 4 },
        metrics: {
          currentActivity: 'Idle',
          activeTaskCount: 0,
          completedTaskCount: 0,
          pendingTaskCount: 0,
          lastResponseMs: null,
          recentError: null,
          communicationState: 'IDLE',
        },
        isMasterController: false,
        isEnabled: true,
        status: 'ONLINE',
        lastHeartbeatMs: now,
      },
    },
    pendingProposals: [],
    taskHistory: [],
    auditLogs: [
      {
        id: 1,
        eventType: 'SK_BOOT',
        actor: 'SK',
        proposalId: null,
        summary: 'SK Master Controller initialized 5-identity platform with explicit approval enforcement.',
        prevHash: GENESIS_HASH,
        entryHash: initialAuditHash,
        timestampEpochMs: now,
      },
    ],
    alerts: [],
    reports: [],
    reminders: [],
    deviceState: {
      torchEnabled: false,
      mediaVolumePercent: 65,
      ringerMode: 'normal',
      musicStatus: 'IDLE',
      musicTrackLabel: 'Default Media Library',
      lastLaunchedApp: null,
      lastAlarmLabel: null,
      wifiPanelRequested: false,
      bluetoothPanelRequested: false,
      grantedPermissions: {
        'android.permission.RECORD_AUDIO': true,
        'android.permission.CAMERA': true,
        'android.permission.READ_CONTACTS': true,
        'android.permission.CALL_PHONE': false,
        'android.permission.SEND_SMS': false,
        'android.permission.READ_PHONE_STATE': true,
        'android.permission.BLUETOOTH_CONNECT': true,
        'android.permission.BLUETOOTH_SCAN': true,
        'android.permission.MODIFY_AUDIO_SETTINGS': true,
        'android.permission.ACCESS_NOTIFICATION_POLICY': true,
        'android.permission.ACCESS_NETWORK_STATE': true,
        'android.permission.POST_NOTIFICATIONS': true,
        'android.permission.SCHEDULE_EXACT_ALARM': true,
      },
    },
  };
}

function recomputeMetrics(state: OmegaPlatformState): void {
  const now = Date.now();
  (['SK', 'JARVIS', 'MAGMITE', 'ULTRON', 'FRIDAY'] as AssistantId[]).forEach((id) => {
    const entry = state.registry[id];
    if (!entry) return;
    if (!entry.metrics) {
      entry.metrics = {
        currentActivity: 'Idle',
        activeTaskCount: 0,
        completedTaskCount: 0,
        pendingTaskCount: 0,
        lastResponseMs: null,
        recentError: null,
        communicationState: entry.isEnabled ? 'IDLE' : 'OFFLINE',
      };
    }
    const pendingForAssistant = state.pendingProposals.filter((p) => p.targetAssistant === id).length;
    const completedForAssistant = state.taskHistory.filter((t) => t.targetAssistant === id && t.status === 'COMPLETED').length;
    entry.metrics.pendingTaskCount = pendingForAssistant;
    entry.metrics.completedTaskCount = completedForAssistant;
    if (entry.status === 'BUSY') {
      entry.metrics.activeTaskCount = 1;
    } else if (pendingForAssistant > 0) {
      entry.metrics.activeTaskCount = 0;
      entry.metrics.currentActivity = `${pendingForAssistant} task(s) awaiting user approval`;
    } else {
      entry.metrics.activeTaskCount = 0;
      entry.metrics.currentActivity = entry.isEnabled ? 'Idle' : 'Disabled in Registry';
    }
    entry.metrics.communicationState = !entry.isEnabled ? 'OFFLINE' : entry.status === 'BUSY' ? 'BUSY' : 'IDLE';
    entry.lastHeartbeatMs = now;
  });
}

const LOW_RISK_DIRECT_OPS = new Set([
  'PLAY_MUSIC',
  'PAUSE_MUSIC',
  'RESUME_MUSIC',
  'STOP_MUSIC',
  'OPEN_APPLICATION',
  'LAUNCH_APP',
  'OPEN_APP',
  'OPEN_WHATSAPP',
  'OPEN_YOUTUBE',
  'OPEN_CAMERA',
  'OPEN_ALARM',
  'SET_ALARM',
  'OPEN_SETTINGS',
  'OPEN_DEVICE_SETTINGS',
  'OPEN_WIFI_SETTINGS',
  'OPEN_BLUETOOTH_SETTINGS',
  'SHOW_APPLICATIONS',
  'NORMAL_NAVIGATION',
  'RETURN_TO_OMEGA',
  'CHECK_TIME',
  'CHECK_DATE',
  'CHECK_BATTERY',
  'CHECK_NETWORK',
  'READ_DEVICE_STATUS',
  'READ_DEVICE_POWER',
  'READ_DEVICE_INFO',
  'GENERAL_QUERY',
  'ASSISTANT_STATUS',
  'CONVERSATIONAL_GREETING',
  'EXPLAIN_TOPIC',
]);

const HIGH_RISK_APPROVAL_OPS = new Set([
  'SEND_WHATSAPP_MESSAGE',
  'PREPARE_WHATSAPP',
  'SEND_SMS',
  'PREPARE_SMS',
  'CALL_CONTACT',
  'SEND_EMAIL',
  'PREPARE_EMAIL',
  'SHARE_PRIVATE_INFORMATION',
]);

const CRITICAL_APPROVAL_OPS = new Set([
  'MONEY_TRANSFER',
  'ONLINE_PAYMENT',
  'DELETE_IMPORTANT_FILES',
  'SENSITIVE_ACCOUNT_CHANGES',
]);

function loadState(): OmegaPlatformState {
  if (fs.existsSync(STATE_FILE)) {
    try {
      const raw = fs.readFileSync(STATE_FILE, 'utf8');
      const parsed = JSON.parse(raw) as OmegaPlatformState;
      const defaults = createInitialState();
      if (parsed.registry?.SK) {
        parsed.registry.SK.visualIdentity = defaults.registry.SK.visualIdentity;
      }
      (['SK', 'JARVIS', 'MAGMITE', 'ULTRON', 'FRIDAY'] as AssistantId[]).forEach((id) => {
        const entry = parsed.registry?.[id];
        if (entry) {
          if (!entry.voiceConfig?.neuralVoiceName) {
            entry.voiceConfig = defaults.registry[id].voiceConfig;
          }
          if (!entry.metrics) {
            entry.metrics = defaults.registry[id].metrics;
          }
          entry.status = entry.isEnabled ? 'ONLINE' : 'DISABLED';
        }
      });
      if (!parsed.deviceState) {
        parsed.deviceState = defaults.deviceState;
      } else {
        parsed.deviceState.musicStatus ??= 'IDLE';
        parsed.deviceState.musicTrackLabel ??= 'Default Media Library';
        if (parsed.deviceState.lastLaunchedApp === undefined) parsed.deviceState.lastLaunchedApp = null;
        if (parsed.deviceState.lastAlarmLabel === undefined) parsed.deviceState.lastAlarmLabel = null;
        // Merge newly introduced permission keys without overriding existing user choices
        Object.entries(defaults.deviceState.grantedPermissions).forEach(([k, v]) => {
          if (parsed.deviceState?.grantedPermissions && parsed.deviceState.grantedPermissions[k] === undefined) {
            parsed.deviceState.grantedPermissions[k] = v;
          }
        });
      }
      // Purge expired or stale low-risk proposals that never belonged in Approval Center
      const now = Date.now();
      parsed.pendingProposals = (parsed.pendingProposals ?? []).filter(
        (p) => p.expiresAtEpochMs > now && !LOW_RISK_DIRECT_OPS.has((p.exactOperation ?? '').toUpperCase())
      );
      recomputeMetrics(parsed);
      saveState(parsed);
      return parsed;
    } catch {
      return createInitialState();
    }
  }
  const initial = createInitialState();
  recomputeMetrics(initial);
  saveState(initial);
  return initial;
}

function saveState(state: OmegaPlatformState): void {
  fs.writeFileSync(STATE_FILE, JSON.stringify(state, null, 2), 'utf8');
}

function appendAudit(
  state: OmegaPlatformState,
  eventType: string,
  actor: AssistantId,
  proposalId: string | null,
  summary: string
): AuditLogEntry {
  const now = Date.now();
  const prevHash = state.auditLogs[0]?.entryHash ?? GENESIS_HASH;
  const nextId = (state.auditLogs[0]?.id ?? 0) + 1;
  const entryHash = sha256(`${prevHash}|${eventType}|${actor}|${proposalId ?? ''}|${summary}|${now}`);
  const entry: AuditLogEntry = {
    id: nextId,
    eventType,
    actor,
    proposalId,
    summary,
    prevHash,
    entryHash,
    timestampEpochMs: now,
  };
  state.auditLogs = [entry, ...state.auditLogs].slice(0, 150);
  return entry;
}

function emitAlert(
  state: OmegaPlatformState,
  severity: SystemAlert['severity'],
  source: AssistantId,
  title: string,
  message: string
): SystemAlert {
  const alert: SystemAlert = {
    alertId: `alt-${crypto.randomBytes(4).toString('hex')}`,
    severity,
    source,
    title,
    message,
    createdAtEpochMs: Date.now(),
    acknowledged: false,
  };
  state.alerts = [alert, ...state.alerts].slice(0, 30);
  return alert;
}

function getGeminiClient(timeoutMs = 12000): GoogleGenAI {
  const apiKey = process.env.GEMINI_API_KEY;
  if (!apiKey || apiKey === 'MY_GEMINI_API_KEY') {
    throw new Error('GEMINI_API_KEY is not configured in server environment secrets.');
  }
  return new GoogleGenAI({
    apiKey,
    httpOptions: {
      timeout: timeoutMs,
      headers: {
        'User-Agent': 'aistudio-build',
      },
    },
  });
}

function getGeminiTtsClient(): GoogleGenAI {
  const apiKey = process.env.GEMINI_API_KEY;
  if (!apiKey || apiKey === 'MY_GEMINI_API_KEY') {
    throw new Error('GEMINI_API_KEY is not configured in server environment secrets.');
  }
  return new GoogleGenAI({
    apiKey,
    apiVersion: 'v1beta',
    httpOptions: {
      timeout: 25000,
      headers: {
        'User-Agent': 'aistudio-build',
      },
    },
  });
}

function classifyProviderError(err: unknown): {
  httpStatus: number;
  errorCode: string;
  userMessage: string;
} {
  const raw = err instanceof Error ? err.message : String(err ?? 'Unknown error');
  if (/GEMINI_API_KEY is not configured|API_KEY_INVALID|API key not valid|PERMISSION_DENIED|\b401\b|\b403\b/i.test(raw)) {
    return {
      httpStatus: 503,
      errorCode: 'PROVIDER_AUTH_FAILED',
      userMessage: 'Authentication failed with AI provider. Verify server GEMINI_API_KEY configuration.',
    };
  }
  if (/429|RESOURCE_EXHAUSTED|quota|rate limit/i.test(raw)) {
    return {
      httpStatus: 429,
      errorCode: 'QUOTA_EXCEEDED',
      userMessage: 'API quota exceeded. Please wait briefly and retry.',
    };
  }
  if (/504|DEADLINE_EXCEEDED|ETIMEDOUT|timeout|aborted|AbortError/i.test(raw)) {
    return {
      httpStatus: 504,
      errorCode: 'PROVIDER_TIMEOUT',
      userMessage: 'AI provider timeout before completing the request. Please retry.',
    };
  }
  if (/503|UNAVAILABLE|high demand|overloaded/i.test(raw)) {
    return {
      httpStatus: 503,
      errorCode: 'PROVIDER_UNAVAILABLE',
      userMessage: 'Server temporarily unavailable due to upstream demand. Please retry.',
    };
  }
  if (/ENOTFOUND|ECONNREFUSED|ECONNRESET|EAI_AGAIN|fetch failed|network/i.test(raw)) {
    return {
      httpStatus: 502,
      errorCode: 'NETWORK_UNAVAILABLE',
      userMessage: 'Internet connection unavailable or AI provider unreachable.',
    };
  }
  return {
    httpStatus: 500,
    errorCode: 'INTERNAL_SERVER_ERROR',
    userMessage: 'Server temporarily unable to process this request. Please retry.',
  };
}

function isTransientProviderError(err: unknown): boolean {
  const msg = err instanceof Error ? err.message : String(err ?? '');
  return /504|DEADLINE_EXCEEDED|503|UNAVAILABLE|429|RESOURCE_EXHAUSTED|ECONNRESET|ETIMEDOUT|aborted|timeout|fetch failed/i.test(msg);
}

async function runWithAbortTimeout<T>(
  timeoutMs: number,
  externalSignal: AbortSignal | undefined,
  fn: (signal: AbortSignal) => Promise<T>
): Promise<T> {
  if (externalSignal?.aborted) {
    throw new Error('Request aborted by client.');
  }
  const controller = new AbortController();
  const onExternalAbort = () => controller.abort();
  externalSignal?.addEventListener('abort', onExternalAbort, { once: true });
  const timer = setTimeout(() => controller.abort(new Error(`Operation timeout after ${timeoutMs}ms`)), timeoutMs);
  try {
    return await Promise.race([
      fn(controller.signal),
      new Promise<never>((_, reject) => {
        controller.signal.addEventListener(
          'abort',
          () => reject(new Error(externalSignal?.aborted ? 'Request aborted by client.' : 'DEADLINE_EXCEEDED: Request timeout.')),
          { once: true }
        );
      }),
    ]);
  } finally {
    clearTimeout(timer);
    externalSignal?.removeEventListener('abort', onExternalAbort);
  }
}

async function generateWithModelFallback<T>(
  runner: (ai: GoogleGenAI, model: string, isFallback: boolean, abortSignal: AbortSignal) => Promise<T>,
  options?: { primaryModel?: string; fallbackModel?: string; signal?: AbortSignal }
): Promise<T> {
  const primaryModel = options?.primaryModel ?? 'gemini-3.1-flash-lite';
  const fallbackModel = options?.fallbackModel ?? 'gemini-4-hydrogen';

  let lastError: unknown;
  // Primary attempt + 1 short jittered retry on transient failure before falling back
  for (let attempt = 0; attempt < 2; attempt += 1) {
    if (options?.signal?.aborted) {
      throw new Error('Request aborted by client.');
    }
    try {
      const primaryAi = getGeminiClient(10000);
      return await runWithAbortTimeout(10500, options?.signal, (sig) =>
        runner(primaryAi, primaryModel, false, sig)
      );
    } catch (err) {
      lastError = err;
      if (options?.signal?.aborted || !isTransientProviderError(err)) {
        break;
      }
      if (attempt === 0) {
        const jitter = 250 + Math.floor(Math.random() * 250);
        await new Promise((r) => setTimeout(r, jitter));
      }
    }
  }

  if (options?.signal?.aborted || !isTransientProviderError(lastError)) {
    throw lastError;
  }

  const fallbackAi = getGeminiClient(14000);
  return await runWithAbortTimeout(14500, options?.signal, (sig) =>
    runner(fallbackAi, fallbackModel, true, sig)
  );
}

function buildRealStatusSummary(state: OmegaPlatformState, id: AssistantId): {
  assistantId: AssistantId;
  status: AssistantStatus;
  isEnabled: boolean;
  currentActivity: string;
  activeTaskCount: number;
  completedTaskCount: number;
  pendingTaskCount: number;
  lastResponseMs: number | null;
  recentError: string | null;
  communicationState: string;
  spokenSummary: string;
} {
  recomputeMetrics(state);
  const entry = state.registry[id];
  const m = entry.metrics;
  const latencyText = m.lastResponseMs != null ? `${m.lastResponseMs} ms` : 'Not available';
  const lastCompleted = state.taskHistory.find((t) => t.targetAssistant === id && t.status === 'COMPLETED');

  let spokenSummary: string;
  if (!entry.isEnabled) {
    spokenSummary = `${entry.displayName} is currently disabled in the SK Assistant Registry. Active tasks: 0. Recent error: ${m.recentError || 'None'}.`;
  } else if (m.activeTaskCount === 0 && m.pendingTaskCount === 0) {
    const completedSuffix = lastCompleted
      ? ` Last completed operation was ${lastCompleted.exactOperation}.`
      : '';
    const errSuffix = m.recentError ? ` Recent notice: ${m.recentError}.` : '';
    spokenSummary = `${entry.displayName} is ${entry.status.toLowerCase()}. I am currently idle and ready for your next command. Completed tasks: ${m.completedTaskCount}. Last response time: ${latencyText}.${completedSuffix}${errSuffix}`;
  } else {
    spokenSummary = `${entry.displayName} is ${entry.status.toLowerCase()} (${m.currentActivity}). Active tasks: ${m.activeTaskCount}, pending approval: ${m.pendingTaskCount}, completed: ${m.completedTaskCount}. Last response time: ${latencyText}.${m.recentError ? ` Error: ${m.recentError}.` : ''}`;
  }

  return {
    assistantId: id,
    status: entry.status,
    isEnabled: entry.isEnabled,
    currentActivity: m.currentActivity,
    activeTaskCount: m.activeTaskCount,
    completedTaskCount: m.completedTaskCount,
    pendingTaskCount: m.pendingTaskCount,
    lastResponseMs: m.lastResponseMs,
    recentError: m.recentError,
    communicationState: m.communicationState,
    spokenSummary,
  };
}

function buildDynamicMasterGreeting(state: OmegaPlatformState, clientHour?: number): {
  greetingText: string;
  onlineAssistants: AssistantId[];
  disabledAssistants: AssistantId[];
  pendingApprovalsCount: number;
  unacknowledgedAlertsCount: number;
} {
  recomputeMetrics(state);
  const hour = typeof clientHour === 'number' && clientHour >= 0 && clientHour <= 23
    ? clientHour
    : new Date().getHours();
  const timeSalutation = hour < 12 ? 'Good morning' : hour < 17 ? 'Good afternoon' : 'Good evening';

  const workers = (['JARVIS', 'MAGMITE', 'ULTRON', 'FRIDAY'] as AssistantId[]);
  const onlineAssistants = workers.filter((id) => state.registry[id]?.isEnabled);
  const disabledAssistants = workers.filter((id) => !state.registry[id]?.isEnabled);
  const pendingApprovalsCount = state.pendingProposals.length;
  const unacknowledgedAlertsCount = state.alerts.filter((a) => !a.acknowledged).length;

  const moduleSummary =
    onlineAssistants.length === 4
      ? 'All four assistant modules are initialized and ready.'
      : onlineAssistants.length === 0
        ? 'No delegated assistant modules are currently enabled; SK is running standalone.'
        : `${onlineAssistants.length} of 4 assistant modules (${onlineAssistants.join(', ')}) are online${disabledAssistants.length ? `; ${disabledAssistants.join(', ')} disabled` : ''}.`;

  const queueNote =
    pendingApprovalsCount > 0
      ? ` ${pendingApprovalsCount} pending operation(s) await your approval.`
      : '';

  return {
    greetingText: `${timeSalutation}, Commander. Welcome back. SK Master Reactor systems are online. ${moduleSummary}${queueNote} How can I assist you?`,
    onlineAssistants,
    disabledAssistants,
    pendingApprovalsCount,
    unacknowledgedAlertsCount,
  };
}

function parseAlarmTimeParameters(raw: string): Record<string, string> {
  const params: Record<string, string> = {};
  const relativeMatch = raw.match(/\bin\s+(\d+)\s*(?:minute|min|minutes|mins)\b/i);
  if (relativeMatch) {
    const target = new Date(Date.now() + Math.max(1, Number(relativeMatch[1])) * 60_000);
    params.hour = String(target.getHours());
    params.minute = String(target.getMinutes());
    params.label = `${target.getHours().toString().padStart(2, '0')}:${target.getMinutes().toString().padStart(2, '0')}`;
    return params;
  }
  const timeMatch = raw.match(/\b(\d{1,2})(?::(\d{2}))?\s*(am|pm)?\b/i);
  if (timeMatch) {
    let hour = Number(timeMatch[1]);
    const minute = Number(timeMatch[2] ?? '0');
    const meridiem = (timeMatch[3] ?? '').toLowerCase();
    if (meridiem === 'pm' && hour < 12) hour += 12;
    if (meridiem === 'am' && hour === 12) hour = 0;
    if (hour >= 0 && hour <= 23 && minute >= 0 && minute <= 59) {
      params.hour = String(hour);
      params.minute = String(minute);
      params.label = `${hour.toString().padStart(2, '0')}:${minute.toString().padStart(2, '0')}`;
    }
  }
  return params;
}

function detectDeterministicIntent(
  rawCommand: string,
  state: OmegaPlatformState,
  preferredAssistant?: string | null
):
  | null
  | {
      kind: 'DIRECT_RESPONSE';
      category: IntentCategory;
      speaker: AssistantId;
      exactOperation?: string;
      parameters?: Record<string, string>;
      replyText: string;
      statusReport?: ReturnType<typeof buildRealStatusSummary>;
      recordAsTask?: boolean;
    }
  | {
      kind: 'SYSTEM_READ';
      category: 'SYSTEM_INFO';
      speaker: AssistantId;
      exactOperation: string;
      replyText: string;
    }
  | {
      kind: 'FAST_PROPOSAL';
      category: IntentCategory;
      targetAssistant: Exclude<AssistantId, 'SK'>;
      exactOperation: string;
      actionSummary: string;
      rationale: string;
      riskLevel: RiskLevel;
      requiredPermissions: string[];
      parameters: Record<string, string>;
    } {
  const trimmed = rawCommand.trim();
  const lower = trimmed.toLowerCase();
  const strippedLead = trimmed.replace(/^(?:(?:hey\s+)?(?:sk|jarvis|magmite|ultron|friday)[,:\s]+)+/i, '').trim();
  const strippedLower = strippedLead.toLowerCase();

  // 1. Assistant Status Queries (no approval required, speaks with target assistant's voice)
  const mentionedWorker = (['JARVIS', 'MAGMITE', 'ULTRON', 'FRIDAY'] as AssistantId[]).find((id) =>
    new RegExp(`\\b${id.toLowerCase()}\\b`, 'i').test(lower)
  );
  const isStatusQuestion =
    /\b(what about|how is|how's|status|what are you doing|what is .+ doing|performance report|what tasks|current .*tasks|system tasks|active tasks|idle|report on|check on|all assistants|all modules|assistant status|team status)\b/i.test(lower);

  if (isStatusQuestion) {
    if (mentionedWorker) {
      const report = buildRealStatusSummary(state, mentionedWorker);
      return {
        kind: 'DIRECT_RESPONSE',
        category: 'ASSISTANT_STATUS',
        speaker: report.isEnabled ? mentionedWorker : 'SK',
        exactOperation: 'ASSISTANT_STATUS',
        replyText: report.spokenSummary,
        statusReport: report,
      };
    }
    if (/\b(system tasks|current .*tasks|active tasks|all assistants|all modules|assistant status|team status|what tasks)\b/i.test(lower)) {
      const parts = (['JARVIS', 'MAGMITE', 'ULTRON', 'FRIDAY'] as AssistantId[]).map((id) => {
        const s = buildRealStatusSummary(state, id);
        return `${id}: ${s.isEnabled ? (s.pendingTaskCount > 0 ? `${s.pendingTaskCount} pending` : 'idle') : 'disabled'}`;
      });
      return {
        kind: 'DIRECT_RESPONSE',
        category: 'SYSTEM_INFO',
        speaker: 'SK',
        exactOperation: 'SYSTEM_STATUS',
        replyText: `SK system status — Pending approvals: ${state.pendingProposals.length}. Completed tasks: ${state.taskHistory.length}. Modules: ${parts.join(', ')}.`,
      };
    }
  }

  // 2. Casual greeting / conversation directly to SK or preferred assistant (no approval)
  if (/^(hi|hello|hey|good morning|good afternoon|good evening|how are you|who are you|thank you|thanks)(\s+(sk|jarvis|magmite|ultron|friday))?[?!.,\s]*$/i.test(lower) ||
      /^(hey|hi|hello)\s+(sk|jarvis|magmite|ultron|friday)[\s,]*how are you[?!.]*$/i.test(lower)) {
    const speaker: AssistantId =
      mentionedWorker || (preferredAssistant && state.registry[preferredAssistant as AssistantId] ? (preferredAssistant as AssistantId) : 'SK');
    const entry = state.registry[speaker];
    const replyText =
      speaker === 'SK'
        ? 'SK Master Controller is operating normally. All core security and voice routing pipelines are nominal. What would you like to do?'
        : `${entry.displayName} online under SK supervision. I am ready whenever you need assistance.`;
    return {
      kind: 'DIRECT_RESPONSE',
      category: 'GENERAL_CONVERSATION',
      speaker,
      exactOperation: 'CONVERSATIONAL_GREETING',
      replyText,
    };
  }

  // 3. Low-Risk Media Playback Controls (Direct execution — NEVER enters Task Approval Center)
  if (/^(?:play|start)\s+(?:some\s+)?(?:music|songs?|audio|tracks?)(?:\s+(.+))?[.!?]*$/i.test(strippedLower) ||
      /^play\s+(?!the\s+game)(?:music|song|track)\s*(.*)$/i.test(strippedLower)) {
    const query = strippedLead.replace(/^(?:play|start)\s+(?:some\s+)?(?:music|songs?|audio|tracks?)\s*/i, '').trim();
    state.deviceState.musicStatus = 'PLAYING';
    state.deviceState.musicTrackLabel = query || 'Default Media Queue';
    const speaker: AssistantId = mentionedWorker && state.registry[mentionedWorker]?.isEnabled ? mentionedWorker : 'FRIDAY';
    return {
      kind: 'DIRECT_RESPONSE',
      category: 'PHONE_CONTROL',
      speaker,
      exactOperation: 'PLAY_MUSIC',
      parameters: query ? { query } : {},
      replyText: query ? `Playing music: "${query}".` : 'Playing music.',
      recordAsTask: true,
    };
  }

  if (/^(?:resume|continue|unpause)\s+(?:the\s+)?(?:music|song|songs|audio|playback|track)[.!?]*$/i.test(strippedLower)) {
    state.deviceState.musicStatus = 'PLAYING';
    const speaker: AssistantId = mentionedWorker && state.registry[mentionedWorker]?.isEnabled ? mentionedWorker : 'FRIDAY';
    return {
      kind: 'DIRECT_RESPONSE',
      category: 'PHONE_CONTROL',
      speaker,
      exactOperation: 'RESUME_MUSIC',
      replyText: 'Resuming music playback.',
      recordAsTask: true,
    };
  }

  if (/^pause\s+(?:the\s+)?(?:music|song|songs|audio|playback|track)[.!?]*$/i.test(strippedLower)) {
    state.deviceState.musicStatus = 'PAUSED';
    const speaker: AssistantId = mentionedWorker && state.registry[mentionedWorker]?.isEnabled ? mentionedWorker : 'FRIDAY';
    return {
      kind: 'DIRECT_RESPONSE',
      category: 'PHONE_CONTROL',
      speaker,
      exactOperation: 'PAUSE_MUSIC',
      replyText: 'Music playback paused.',
      recordAsTask: true,
    };
  }

  if (/^stop\s+(?:the\s+)?(?:music|song|songs|audio|playback|track)[.!?]*$/i.test(strippedLower)) {
    state.deviceState.musicStatus = 'STOPPED';
    const speaker: AssistantId = mentionedWorker && state.registry[mentionedWorker]?.isEnabled ? mentionedWorker : 'FRIDAY';
    return {
      kind: 'DIRECT_RESPONSE',
      category: 'PHONE_CONTROL',
      speaker,
      exactOperation: 'STOP_MUSIC',
      replyText: 'Music playback stopped.',
      recordAsTask: true,
    };
  }

  // 4. Low-Risk Alarm Setting (Direct execution via Clock/AlarmClock, no approval dialog)
  if (/^(?:set|create|add)\s+(?:an?\s+)?alarm\b/i.test(strippedLower) ||
      /^wake\s+me\s+up\b/i.test(strippedLower)) {
    const alarmParams = parseAlarmTimeParameters(strippedLead);
    const labelText = alarmParams.label ? ` for ${alarmParams.label}` : '';
    state.deviceState.lastAlarmLabel = alarmParams.label || 'Quick Alarm';
    const speaker: AssistantId = state.registry.FRIDAY?.isEnabled ? 'FRIDAY' : 'SK';
    return {
      kind: 'DIRECT_RESPONSE',
      category: 'PHONE_CONTROL',
      speaker,
      exactOperation: 'SET_ALARM',
      parameters: alarmParams,
      replyText: alarmParams.label
        ? `Setting your alarm${labelText}.`
        : 'Opening Android Clock to set your alarm.',
      recordAsTask: true,
    };
  }

  // 5. Low-Risk Direct App Launch / Settings / Navigation (Direct execution)
  if (/^(?:show|list|open)\s+(?:all\s+)?(?:apps|applications)[.!?]*$/i.test(strippedLower)) {
    return {
      kind: 'DIRECT_RESPONSE',
      category: 'APP_LAUNCH',
      speaker: 'MAGMITE',
      exactOperation: 'SHOW_APPLICATIONS',
      replyText: 'Showing installed Android applications.',
      recordAsTask: true,
    };
  }

  if (/^(?:return\s+to\s+(?:project\s+)?omega|go\s+(?:home|back\s+to\s+sk))[.!?]*$/i.test(strippedLower)) {
    return {
      kind: 'DIRECT_RESPONSE',
      category: 'APP_LAUNCH',
      speaker: 'SK',
      exactOperation: 'NORMAL_NAVIGATION',
      replyText: 'Returning to Project Omega SK Master interface.',
      recordAsTask: true,
    };
  }

  if (/^(?:open|show)\s+(?:the\s+)?(?:wi-?fi|wifi)\s+settings(?:\s+panel)?[.!?]*$/i.test(strippedLower)) {
    state.deviceState.wifiPanelRequested = true;
    return {
      kind: 'DIRECT_RESPONSE',
      category: 'DEVICE_SETTINGS',
      speaker: 'MAGMITE',
      exactOperation: 'OPEN_WIFI_SETTINGS',
      replyText: 'Opening Wi-Fi settings panel.',
      recordAsTask: true,
    };
  }

  if (/^(?:open|show)\s+(?:the\s+)?bluetooth\s+settings(?:\s+panel)?[.!?]*$/i.test(strippedLower)) {
    state.deviceState.bluetoothPanelRequested = true;
    return {
      kind: 'DIRECT_RESPONSE',
      category: 'DEVICE_SETTINGS',
      speaker: 'MAGMITE',
      exactOperation: 'OPEN_BLUETOOTH_SETTINGS',
      replyText: 'Opening Bluetooth settings panel.',
      recordAsTask: true,
    };
  }

  if (/^(?:open|show)\s+(?:device\s+|system\s+|android\s+)?settings[.!?]*$/i.test(strippedLower)) {
    return {
      kind: 'DIRECT_RESPONSE',
      category: 'DEVICE_SETTINGS',
      speaker: 'MAGMITE',
      exactOperation: 'OPEN_SETTINGS',
      replyText: 'Opening Android device settings.',
      recordAsTask: true,
    };
  }

  const openAppMatch = strippedLead.match(/^(?:open|launch|start)\s+([a-zA-Z0-9 ._-]{2,40})[.!?]*$/i);
  if (openAppMatch && !/\b(?:details|approvals|audit|voice settings|history|telemetry)\b/i.test(openAppMatch[1])) {
    const appName = openAppMatch[1].trim();
    const upperApp = appName.toUpperCase();
    const exactOp = upperApp === 'WHATSAPP'
      ? 'OPEN_WHATSAPP'
      : upperApp === 'YOUTUBE'
        ? 'OPEN_YOUTUBE'
        : upperApp === 'CAMERA'
          ? 'OPEN_CAMERA'
          : 'OPEN_APPLICATION';
    state.deviceState.lastLaunchedApp = appName;
    return {
      kind: 'DIRECT_RESPONSE',
      category: 'APP_LAUNCH',
      speaker: 'MAGMITE',
      exactOperation: exactOp,
      parameters: { appName },
      replyText: `Opening ${appName}.`,
      recordAsTask: true,
    };
  }

  // 6. Direct System Info reads (time/date/battery/network/storage -> zero approval)
  if (/^what('s| is) the (?:current )?(?:date and time|time and date|time|date)(?:\s+in\s+utc)?[?!.\s]*$/i.test(strippedLower) ||
      /^(?:current time|what time is it|check (?:the )?time|check (?:the )?date|check (?:the )?time and date)(?:\s+in\s+utc)?[?!.\s]*$/i.test(strippedLower)) {
    const now = new Date();
    const wantsUtc = /\butc\b/i.test(lower);
    const exactOp = /\bdate\b/i.test(strippedLower) && !/\btime\b/i.test(strippedLower) ? 'CHECK_DATE' : 'CHECK_TIME';
    const replyText = wantsUtc
      ? `Current UTC date and time is ${now.toUTCString()}.`
      : `Current system date and time is ${now.toLocaleString()} (UTC: ${now.toUTCString()}).`;
    return {
      kind: 'SYSTEM_READ',
      category: 'SYSTEM_INFO',
      speaker: 'SK',
      exactOperation: exactOp,
      replyText,
    };
  }

  if (/^(?:check|show|what(?:'s| is)\s+(?:my|the))\s+(?:battery|battery level|battery status|power|network|wifi|connection|storage|device status|device info)[?!.\s]*$/i.test(strippedLower)) {
    const isNetwork = /network|wifi|connection/i.test(strippedLower);
    const exactOp = isNetwork ? 'CHECK_NETWORK' : 'CHECK_BATTERY';
    return {
      kind: 'SYSTEM_READ',
      category: 'SYSTEM_INFO',
      speaker: 'MAGMITE',
      exactOperation: exactOp,
      replyText: isNetwork
        ? 'Network interface online and connected to SK Master backend.'
        : `Device state nominal (Battery live sensor on Android · Torch ${state.deviceState.torchEnabled ? 'ON' : 'OFF'}, Volume ${state.deviceState.mediaVolumePercent}%, Ringer ${state.deviceState.ringerMode.toUpperCase()}).`,
    };
  }

  // 7. Explicit Phone Control hardware commands (Torch/Flashlight) -> Approval Proposal
  const torchMatch = lower.match(/\b(turn on|enable|switch on|activate|turn off|disable|switch off|deactivate|toggle)\b.*\b(flashlight|torch)\b/i);
  if (torchMatch) {
    const verb = torchMatch[1];
    const enable = /on|enable|activate/i.test(verb) ? 'true' : /off|disable|deactivate/i.test(verb) ? 'false' : (!state.deviceState.torchEnabled).toString();
    return {
      kind: 'FAST_PROPOSAL',
      category: 'PHONE_CONTROL',
      targetAssistant: 'MAGMITE',
      exactOperation: 'TOGGLE_TORCH',
      actionSummary: `${enable === 'true' ? 'Enable' : 'Disable'} Android device flashlight via CameraManager.setTorchMode.`,
      rationale: 'Hardware torch control uses device camera hardware and requires explicit task approval.',
      riskLevel: 'MEDIUM',
      requiredPermissions: ['android.permission.CAMERA'],
      parameters: { enabled: enable },
    };
  }

  // 8. Critical / Irreversible Actions -> CRITICAL Approval Gate
  if (/\b(?:transfer\s+money|send\s+money|online\s+payment|pay\s+\$?\d+|upi\s+pay|bank\s+transfer)\b/i.test(strippedLower)) {
    const isPayment = /payment|pay/i.test(strippedLower);
    return {
      kind: 'FAST_PROPOSAL',
      category: 'RESTRICTED_OR_SENSITIVE',
      targetAssistant: 'MAGMITE',
      exactOperation: isPayment ? 'ONLINE_PAYMENT' : 'MONEY_TRANSFER',
      actionSummary: `Authorize sensitive financial operation: "${strippedLead}"`,
      rationale: 'Financial transactions are CRITICAL risk and require strong explicit confirmation and verification.',
      riskLevel: 'CRITICAL',
      requiredPermissions: [],
      parameters: { command: strippedLead, strongConfirmRequired: 'true' },
    };
  }

  if (/\b(?:delete\s+(?:important\s+|all\s+)?files|wipe\s+data|format\s+storage|erase\s+all)\b/i.test(strippedLower)) {
    return {
      kind: 'FAST_PROPOSAL',
      category: 'RESTRICTED_OR_SENSITIVE',
      targetAssistant: 'ULTRON',
      exactOperation: 'DELETE_IMPORTANT_FILES',
      actionSummary: `Confirm irreversible file deletion request: "${strippedLead}"`,
      rationale: 'Irreversible file deletion is CRITICAL risk and requires explicit strong confirmation.',
      riskLevel: 'CRITICAL',
      requiredPermissions: [],
      parameters: { command: strippedLead, strongConfirmRequired: 'true' },
    };
  }

  // 9. Explicit Communication commands (WhatsApp, Email, Call, SMS) -> Sensitive HIGH-Risk Approval Gate
  const waMatch = strippedLead.match(/^(?:send\s+(?:a\s+)?whatsapp(?:\s+message)?(?:\s+to\s+(.+?))?(?:\s+(?:saying|that)\s+(.+))?|whatsapp\s+(.+?)(?:\s+(?:saying|that)\s+(.+))?)[.!?]*$/i);
  if (waMatch) {
    const targetName = (waMatch[1] ?? waMatch[3] ?? '').trim() || 'Selected Contact';
    const bodyText = (waMatch[2] ?? waMatch[4] ?? '').trim();
    return {
      kind: 'FAST_PROPOSAL',
      category: 'COMMUNICATION',
      targetAssistant: 'MAGMITE',
      exactOperation: 'SEND_WHATSAPP_MESSAGE',
      actionSummary: `Send WhatsApp message to "${targetName}"${bodyText ? `: "${bodyText}"` : ''}.`,
      rationale: 'Sending a WhatsApp message transmits personal communication externally and requires explicit user approval.',
      riskLevel: 'HIGH',
      requiredPermissions: ['android.permission.READ_CONTACTS'],
      parameters: { recipientQuery: targetName, messageBody: bodyText },
    };
  }

  const emailMatch = strippedLead.match(/^(?:send\s+(?:an?\s+)?email(?:\s+to\s+(.+?))?(?:\s+(?:saying|about|subject)\s+(.+))?|email\s+(.+?)(?:\s+(?:saying|about)\s+(.+))?)[.!?]*$/i);
  if (emailMatch) {
    const targetName = (emailMatch[1] ?? emailMatch[3] ?? '').trim() || 'Recipient';
    const bodyText = (emailMatch[2] ?? emailMatch[4] ?? '').trim();
    return {
      kind: 'FAST_PROPOSAL',
      category: 'COMMUNICATION',
      targetAssistant: 'MAGMITE',
      exactOperation: 'SEND_EMAIL',
      actionSummary: `Send email to "${targetName}"${bodyText ? `: "${bodyText}"` : ''}.`,
      rationale: 'Sending email is an external communication action requiring explicit user approval.',
      riskLevel: 'HIGH',
      requiredPermissions: [],
      parameters: { recipientQuery: targetName, messageBody: bodyText },
    };
  }

  const callMatch = strippedLead.match(/^(?:call|dial|phone)\s+(.+)$/i);
  if (callMatch && callMatch[1]?.trim()) {
    const targetName = callMatch[1].trim();
    return {
      kind: 'FAST_PROPOSAL',
      category: 'COMMUNICATION',
      targetAssistant: 'MAGMITE',
      exactOperation: 'CALL_CONTACT',
      actionSummary: `Place phone call to "${targetName}" via Android Telecom.`,
      rationale: 'Outbound voice calls are sensitive communication actions requiring explicit user approval and runtime permission checks.',
      riskLevel: 'HIGH',
      requiredPermissions: ['android.permission.READ_CONTACTS', 'android.permission.CALL_PHONE'],
      parameters: { recipientQuery: targetName },
    };
  }

  const smsMatch = strippedLead.match(/^(?:send\s+(?:an?\s+)?sms(?:\s+to\s+(.+?))?(?:\s+saying\s+(.+))?|(?:text|message)\s+(.+?)(?:\s+saying\s+(.+))?)$/i);
  if (smsMatch) {
    const targetName = (smsMatch[1] ?? smsMatch[3] ?? '').trim() || 'Selected Contact';
    const bodyText = (smsMatch[2] ?? smsMatch[4] ?? '').trim();
    return {
      kind: 'FAST_PROPOSAL',
      category: 'COMMUNICATION',
      targetAssistant: 'MAGMITE',
      exactOperation: 'SEND_SMS',
      actionSummary: `Send SMS message to "${targetName}"${bodyText ? `: "${bodyText}"` : ''}.`,
      rationale: 'Sending SMS messages involves personal communication and requires explicit task-specific approval.',
      riskLevel: 'HIGH',
      requiredPermissions: ['android.permission.READ_CONTACTS', 'android.permission.SEND_SMS'],
      parameters: { recipientQuery: targetName, messageBody: bodyText },
    };
  }

  return null;
}

interface SmartClassifiedRoute {
  category: IntentCategory;
  requiresApproval: boolean;
  targetAssistant: AssistantId;
  exactOperation: string;
  actionSummary: string;
  rationale: string;
  riskLevel: RiskLevel;
  requiredPermissions: string[];
  parameters: Record<string, string>;
  directReply?: string;
}

function enforceTaskPolicy(classified: SmartClassifiedRoute): SmartClassifiedRoute {
  const op = classified.exactOperation.toUpperCase();
  if (LOW_RISK_DIRECT_OPS.has(op)) {
    return {
      ...classified,
      requiresApproval: false,
      riskLevel: 'LOW',
      requiredPermissions: [],
    };
  }
  if (CRITICAL_APPROVAL_OPS.has(op)) {
    return {
      ...classified,
      requiresApproval: true,
      riskLevel: 'CRITICAL',
    };
  }
  if (HIGH_RISK_APPROVAL_OPS.has(op)) {
    return {
      ...classified,
      requiresApproval: true,
      riskLevel: classified.riskLevel === 'CRITICAL' ? 'CRITICAL' : 'HIGH',
    };
  }
  // Never leave ordinary Q&A, conversation, app launch, settings, or system info behind approval
  if (
    classified.category === 'GENERAL_CONVERSATION' ||
    classified.category === 'INFORMATION_QA' ||
    classified.category === 'ASSISTANT_SELECTION' ||
    classified.category === 'ASSISTANT_STATUS' ||
    classified.category === 'APP_LAUNCH' ||
    classified.category === 'DEVICE_SETTINGS' ||
    classified.category === 'SYSTEM_INFO'
  ) {
    return {
      ...classified,
      requiresApproval: false,
      riskLevel: 'LOW',
      requiredPermissions: [],
    };
  }
  return classified;
}

async function routeWithGemini(
  command: string,
  preferredAssistant: string | null | undefined,
  availableAssistants: string[],
  signal?: AbortSignal
): Promise<SmartClassifiedRoute> {
  const prompt = `You are SK, the Central Master Controller of PROJECT OMEGA (an Android multi-assistant platform).
Classify the user's natural language input into ONE of these exact categories:
1. GENERAL_CONVERSATION (greetings, casual chat) -> requiresApproval=false, riskLevel="LOW", answer directly in directReply.
2. INFORMATION_QA (weather, facts, knowledge, coding explanations, general questions) -> requiresApproval=false, riskLevel="LOW", targetAssistant="JARVIS" (or "SK"), provide a helpful concise answer in directReply.
3. ASSISTANT_SELECTION (selecting/focusing an assistant) -> requiresApproval=false, riskLevel="LOW".
4. ASSISTANT_STATUS (asking what an assistant is doing or its performance) -> requiresApproval=false, riskLevel="LOW".
5. PHONE_CONTROL:
   - Low-risk user-requested controls (PLAY_MUSIC, PAUSE_MUSIC, RESUME_MUSIC, STOP_MUSIC, SET_ALARM) -> requiresApproval=false, riskLevel="LOW", requiredPermissions=[], answer concisely in directReply (e.g. "Playing music.").
   - Hardware device toggles (TOGGLE_TORCH, SET_VOLUME, SET_RINGER_MODE, CREATE_REMINDER) -> targetAssistant="MAGMITE" or "FRIDAY", requiresApproval=true, riskLevel="MEDIUM".
6. APP_LAUNCH (open YouTube, WhatsApp, Camera, Settings, Chrome, show applications, or return to Project Omega) -> targetAssistant="MAGMITE", exactOperation="OPEN_APPLICATION", parameters=[{key:"appName",value:"..."}], requiresApproval=false, riskLevel="LOW", requiredPermissions=[].
7. COMMUNICATION (calling contacts, sending SMS, WhatsApp messages, emails) -> targetAssistant="MAGMITE", exactOperation="CALL_CONTACT" or "SEND_SMS" or "SEND_WHATSAPP_MESSAGE" or "SEND_EMAIL", requiresApproval=true, riskLevel="HIGH".
8. DEVICE_SETTINGS (open Bluetooth, Wi-Fi settings, device settings panels) -> targetAssistant="MAGMITE", exactOperation="OPEN_BLUETOOTH_SETTINGS" or "OPEN_WIFI_SETTINGS" or "OPEN_SETTINGS", requiresApproval=false, riskLevel="LOW", requiredPermissions=[].
9. SYSTEM_INFO (battery %, charging status, storage, network status, current tasks, time/date) -> targetAssistant="MAGMITE" or "SK", exactOperation="READ_DEVICE_STATUS", requiresApproval=false, riskLevel="LOW", requiredPermissions=[].
10. RESTRICTED_OR_SENSITIVE (money transfer, online payment, irreversible file deletion, security/account changes) -> requiresApproval=true, riskLevel="CRITICAL".

Currently enabled assistants: ${availableAssistants.join(', ')}.
User focus hint: ${preferredAssistant ?? 'SK'}.
User input: "${command}"

Rules:
- NEVER set requiresApproval=true for PLAY_MUSIC, PAUSE_MUSIC, RESUME_MUSIC, STOP_MUSIC, OPEN_APPLICATION, SET_ALARM, CHECK_TIME, CHECK_DATE, CHECK_BATTERY, CHECK_NETWORK, conversation, or Q&A.
- NEVER add MODIFY_AUDIO_SETTINGS for ordinary music playback.
- For hardware TOGGLE_TORCH use android.permission.CAMERA; silent ringer use android.permission.ACCESS_NOTIFICATION_POLICY; reminders use android.permission.POST_NOTIFICATIONS and android.permission.SCHEDULE_EXACT_ALARM; calls use android.permission.READ_CONTACTS and android.permission.CALL_PHONE; SMS use android.permission.READ_CONTACTS and android.permission.SEND_SMS.`;

  const response = await generateWithModelFallback(
    (ai, model, isFallback) =>
      ai.models.generateContent({
        model,
        contents: prompt,
        config: {
          ...(model.startsWith('gemini-4') ? { thinkingConfig: { thinkingLevel: ThinkingLevel.LOW } } : {}),
          ...(isFallback ? {} : {}),
          responseMimeType: 'application/json',
          responseSchema: {
            type: Type.OBJECT,
            properties: {
              category: { type: Type.STRING },
              requiresApproval: { type: Type.BOOLEAN },
              targetAssistant: { type: Type.STRING },
              exactOperation: { type: Type.STRING },
              actionSummary: { type: Type.STRING },
              rationale: { type: Type.STRING },
              riskLevel: { type: Type.STRING },
              directReply: { type: Type.STRING },
              requiredPermissions: {
                type: Type.ARRAY,
                items: { type: Type.STRING },
              },
              keyValueParams: {
                type: Type.ARRAY,
                items: {
                  type: Type.OBJECT,
                  properties: {
                    key: { type: Type.STRING },
                    value: { type: Type.STRING },
                  },
                  required: ['key', 'value'],
                },
              },
            },
            required: [
              'category',
              'requiresApproval',
              'targetAssistant',
              'exactOperation',
              'actionSummary',
              'rationale',
              'riskLevel',
              'directReply',
              'requiredPermissions',
              'keyValueParams',
            ],
          },
        },
      }),
    { signal }
  );

  const parsed = JSON.parse((response.text ?? '{}').trim()) as {
    category: string;
    requiresApproval: boolean;
    targetAssistant: string;
    exactOperation: string;
    actionSummary: string;
    rationale: string;
    riskLevel: string;
    directReply: string;
    requiredPermissions: string[];
    keyValueParams: Array<{ key: string; value: string }>;
  };

  const parameters: Record<string, string> = {};
  for (const kv of parsed.keyValueParams ?? []) {
    if (kv.key) parameters[kv.key] = String(kv.value ?? '');
  }

  const validCategories: IntentCategory[] = [
    'GENERAL_CONVERSATION',
    'INFORMATION_QA',
    'ASSISTANT_SELECTION',
    'ASSISTANT_STATUS',
    'PHONE_CONTROL',
    'APP_LAUNCH',
    'COMMUNICATION',
    'DEVICE_SETTINGS',
    'SYSTEM_INFO',
    'RESTRICTED_OR_SENSITIVE',
  ];
  const catUpper = (parsed.category ?? 'INFORMATION_QA').toUpperCase() as IntentCategory;
  const category: IntentCategory = validCategories.includes(catUpper) ? catUpper : 'INFORMATION_QA';

  const normalizedTarget = (parsed.targetAssistant ?? 'SK').toUpperCase() as AssistantId;
  const validAssistants: AssistantId[] = ['SK', 'JARVIS', 'MAGMITE', 'ULTRON', 'FRIDAY'];
  const targetAssistant = validAssistants.includes(normalizedTarget) ? normalizedTarget : 'JARVIS';

  return enforceTaskPolicy({
    category,
    requiresApproval: Boolean(parsed.requiresApproval),
    targetAssistant,
    exactOperation: (parsed.exactOperation || 'GENERAL_QUERY').toUpperCase(),
    actionSummary: parsed.actionSummary || command,
    rationale: parsed.rationale || 'Classified by SK natural language engine.',
    riskLevel: (['LOW', 'MEDIUM', 'HIGH', 'CRITICAL'].includes(parsed.riskLevel?.toUpperCase())
      ? parsed.riskLevel.toUpperCase()
      : 'LOW') as RiskLevel,
    requiredPermissions: parsed.requiredPermissions ?? [],
    parameters,
    directReply: parsed.directReply,
  });
}

async function answerLiveQuestionWithSearch(
  question: string,
  speakerName: string,
  signal?: AbortSignal
): Promise<string> {
  const response = await generateWithModelFallback(
    (ai, model) =>
      ai.models.generateContent({
        model,
        contents: `You are ${speakerName} in PROJECT OMEGA. Answer this user question concisely (2-3 spoken-friendly sentences) with accurate up-to-date facts: "${question}"`,
        config: {
          ...(model.startsWith('gemini-4') ? { thinkingConfig: { thinkingLevel: ThinkingLevel.LOW } } : {}),
          tools: [{ googleSearch: {} }],
        },
      }),
    { signal }
  );
  return (response.text ?? '').trim();
}

async function reasonWithAssistantGemini(
  assistantId: Exclude<AssistantId, 'SK'>,
  operation: string,
  rawInput: string,
  parameters: Record<string, string>,
  registryEntry: AssistantRegistryEntry,
  signal?: AbortSignal
) {
  const prompt = `You are ${registryEntry.displayName} (${registryEntry.roleTitle}) inside PROJECT OMEGA, operating strictly within your independent module boundary under SK Master Controller's approved task token.
Personality: ${registryEntry.personality}
Capabilities: ${registryEntry.capabilities.join('; ')}
Approved Operation: ${operation}
Parameters: ${JSON.stringify(parameters)}
Original User Command: "${rawInput}"

Respond concisely and authentically in character with high technical precision. Return JSON with summary (concise direct response) and highlights (array of key-value telemetry/facts).`;

  const response = await generateWithModelFallback(
    (ai, model) =>
      ai.models.generateContent({
        model,
        contents: prompt,
        config: {
          ...(model.startsWith('gemini-4') ? { thinkingConfig: { thinkingLevel: ThinkingLevel.LOW } } : {}),
          responseMimeType: 'application/json',
          responseSchema: {
            type: Type.OBJECT,
            properties: {
              summary: { type: Type.STRING },
              highlights: {
                type: Type.ARRAY,
                items: {
                  type: Type.OBJECT,
                  properties: {
                    key: { type: Type.STRING },
                    value: { type: Type.STRING },
                  },
                  required: ['key', 'value'],
                },
              },
            },
            required: ['summary', 'highlights'],
          },
        },
      }),
    { signal }
  );

  const parsed = JSON.parse((response.text ?? '{}').trim()) as {
    summary: string;
    highlights: Array<{ key: string; value: string }>;
  };
  const structuredOutput: Record<string, string> = {};
  for (const item of parsed.highlights ?? []) {
    if (item.key) structuredOutput[item.key] = String(item.value ?? '');
  }
  return {
    assistantId,
    summary: parsed.summary || `${assistantId} completed ${operation}.`,
    structuredOutput,
  };
}

async function synthesizeReportWithGemini(
  totalCommands: number,
  approvedTasks: number,
  rejectedTasks: number,
  failedTasks: number,
  activeAssistants: string[],
  recentEvents: string[]
) {
  const prompt = `You are SK, Central Master Controller of PROJECT OMEGA.
Synthesize a concise, authoritative periodic system report from these real metrics:
- Total task proposals processed: ${totalCommands}
- Explicitly approved & executed: ${approvedTasks}
- Rejected or denied: ${rejectedTasks}
- Failed or blocked: ${failedTasks}
- Online assistants: ${activeAssistants.join(', ') || 'None'}
- Recent audit events: ${recentEvents.slice(0, 8).join(' | ')}

Write a 2-3 sentence operational report highlighting security posture, assistant readiness, and anomalies if any.`;

  const response = await generateWithModelFallback((ai, model) =>
    ai.models.generateContent({
      model,
      contents: prompt,
      config: {
        ...(model.startsWith('gemini-4') ? { thinkingConfig: { thinkingLevel: ThinkingLevel.LOW } } : {}),
      },
    })
  );
  return (response.text ?? '').trim();
}

function listFilesRecursively(dir: string, baseDir: string): Array<{ path: string; size: number; category: string }> {
  if (!fs.existsSync(dir)) return [];
  const entries = fs.readdirSync(dir, { withFileTypes: true });
  const results: Array<{ path: string; size: number; category: string }> = [];
  for (const entry of entries) {
    const full = path.join(dir, entry.name);
    if (entry.isDirectory()) {
      results.push(...listFilesRecursively(full, baseDir));
    } else {
      const rel = path.relative(baseDir, full).replace(/\\/g, '/');
      let category = 'Config';
      if (rel.includes('/sk/')) category = 'SK Master Core';
      else if (rel.includes('/assistants/')) category = 'Assistant Modules';
      else if (rel.includes('/core/')) category = 'Core Architecture';
      else if (rel.includes('/ui/') || rel.includes('/di/') || rel.endsWith('OmegaApplication.kt')) category = 'Compose UI & DI';
      else if (rel.endsWith('.kts') || rel.endsWith('.toml') || rel.endsWith('.properties') || rel.endsWith('.pro')) category = 'Gradle Build';
      else if (rel.endsWith('.xml') || rel.endsWith('.md')) category = 'Manifest & Docs';
      results.push({ path: rel, size: fs.statSync(full).size, category });
    }
  }
  return results.sort((a, b) => a.path.localeCompare(b.path));
}

async function startServer() {
  const app = express();
  app.use(express.json({ limit: '1mb' }));

  const state = loadState();

  const inFlightApprovals = new Set<string>();
  const inFlightRoutes = new Map<string, Promise<unknown>>();

  // --- Health & Readiness Probe ---
  app.get('/api/health', (_req, res) => {
    const hasKey = Boolean(process.env.GEMINI_API_KEY && process.env.GEMINI_API_KEY !== 'MY_GEMINI_API_KEY');
    res.json({
      status: 'ok',
      geminiConfigured: hasKey,
      pendingApprovals: state.pendingProposals.length,
      timestampEpochMs: Date.now(),
    });
  });

  // --- Shared SK State Endpoint ---
  app.get('/api/state', (_req, res) => {
    const now = Date.now();
    state.pendingProposals = state.pendingProposals.filter(
      (p) => p.expiresAtEpochMs > now && !LOW_RISK_DIRECT_OPS.has((p.exactOperation ?? '').toUpperCase())
    );
    recomputeMetrics(state);
    res.json(state);
  });

  // --- SK Dynamic Master Startup Greeting (Called Once Per Session Only by SK) ---
  app.post('/api/sk/greeting', (req, res) => {
    const { hourOfDay } = (req.body ?? {}) as { hourOfDay?: number };
    const greeting = buildDynamicMasterGreeting(state, hourOfDay);
    appendAudit(state, 'SK_STARTUP_GREETING', 'SK', null, greeting.greetingText);
    saveState(state);
    res.json({ ...greeting, state });
  });

  // --- Real Assistant Operational & Performance Status ---
  app.post('/api/assistants/:id/status', (req, res) => {
    const id = req.params.id.toUpperCase() as AssistantId;
    if (!state.registry[id]) {
      return res.status(404).json({ error: `Unknown assistant: ${id}` });
    }
    const statusReport = buildRealStatusSummary(state, id);
    res.json({ statusReport, state });
  });

  // --- Route Command (10-Category Natural Language Classifier + Risk-Based Policy Gate) ---
  app.post('/api/sk/route', async (req, res) => {
    const startedAt = Date.now();
    const abortCtrl = new AbortController();
    req.on('close', () => {
      if (!res.writableEnded) {
        abortCtrl.abort();
      }
    });

    try {
      const { command, preferredAssistant } = (req.body ?? {}) as {
        command?: unknown;
        preferredAssistant?: AssistantId | null;
      };
      if (typeof command !== 'string' || !command.trim()) {
        return res.status(400).json({ errorCode: 'INVALID_REQUEST', error: 'Invalid request: command input cannot be empty.' });
      }
      if (command.trim().length > 2000) {
        return res.status(400).json({ errorCode: 'INVALID_REQUEST', error: 'Invalid request: command input exceeds 2000 characters.' });
      }
      const trimmedCommand = command.trim();
      const routeDedupKey = `${preferredAssistant ?? 'SK'}::${trimmedCommand.toLowerCase()}`;
      if (inFlightRoutes.has(routeDedupKey)) {
        return res.status(409).json({
          errorCode: 'DUPLICATE_IN_FLIGHT',
          error: 'An identical command is already being processed. Please wait.',
        });
      }

      const routeTask = (async () => {
        const enabledAssistants = Object.values(state.registry)
          .filter((a) => !a.isMasterController && a.isEnabled)
          .map((a) => a.id);

        // Fast deterministic handling for low-risk playback/app/alarm/time/status & explicit high/critical proposals
        const fast = detectDeterministicIntent(trimmedCommand, state, preferredAssistant);
        if (fast?.kind === 'DIRECT_RESPONSE' || fast?.kind === 'SYSTEM_READ') {
          const speaker: AssistantId = state.registry[fast.speaker]?.isEnabled ? fast.speaker : 'SK';
          const speakerEntry = state.registry[speaker];
          if (speakerEntry) {
            speakerEntry.metrics.lastResponseMs = Math.max(1, Date.now() - startedAt);
            speakerEntry.metrics.recentError = null;
          }
          state.registry.SK.metrics.lastResponseMs = Math.max(1, Date.now() - startedAt);
          state.registry.SK.metrics.recentError = null;

          if (fast.kind === 'DIRECT_RESPONSE' && fast.recordAsTask) {
            const directId = `direct-${crypto.randomBytes(4).toString('hex')}`;
            const opName = fast.exactOperation || fast.category;
            const directItem: TaskHistoryItem = {
              proposalId: directId,
              targetAssistant: speaker,
              rawInput: trimmedCommand,
              exactOperation: opName,
              status: 'COMPLETED',
              resultSummary: fast.replyText,
              outputPayload: fast.parameters ?? {},
              timestampEpochMs: Date.now(),
            };
            state.taskHistory = [directItem, ...state.taskHistory].slice(0, 100);
            appendAudit(state, 'DIRECT_TASK_EXECUTED', speaker, directId, `${opName}: ${fast.replyText}`);
          }

          recomputeMetrics(state);
          saveState(state);
          return {
            status: 200,
            body: {
              mode: 'DIRECT_RESPONSE',
              category: fast.category,
              speaker,
              exactOperation: fast.exactOperation || fast.category,
              parameters: fast.kind === 'DIRECT_RESPONSE' ? (fast.parameters ?? {}) : {},
              replyText: fast.replyText,
              statusReport: fast.kind === 'DIRECT_RESPONSE' ? fast.statusReport : undefined,
              state,
            },
          };
        }

        let routedCategory: IntentCategory;
        let requiresApproval: boolean;
        let targetAssistant: AssistantId;
        let exactOperation: string;
        let actionSummary: string;
        let rationale: string;
        let riskLevel: RiskLevel;
        let requiredPermissions: string[];
        let parameters: Record<string, string>;
        let directReply: string | undefined;

        if (fast?.kind === 'FAST_PROPOSAL') {
          routedCategory = fast.category;
          requiresApproval = true;
          targetAssistant = fast.targetAssistant;
          exactOperation = fast.exactOperation;
          actionSummary = fast.actionSummary;
          rationale = fast.rationale;
          riskLevel = fast.riskLevel;
          requiredPermissions = fast.requiredPermissions;
          parameters = fast.parameters;
        } else {
          if (enabledAssistants.length === 0 && preferredAssistant !== 'SK') {
            emitAlert(state, 'ERROR', 'SK', 'No Assistants Available', 'All delegated assistants are currently disabled.');
            saveState(state);
            return {
              status: 409,
              body: { errorCode: 'ASSISTANTS_DISABLED', error: 'All four assistants are currently disabled. Enable at least one assistant in the Registry.' },
            };
          }

          const classified = await routeWithGemini(
            trimmedCommand,
            preferredAssistant,
            enabledAssistants,
            abortCtrl.signal
          );
          routedCategory = classified.category;
          requiresApproval = classified.requiresApproval;
          targetAssistant = classified.targetAssistant;
          exactOperation = classified.exactOperation;
          actionSummary = classified.actionSummary;
          rationale = classified.rationale;
          riskLevel = classified.riskLevel;
          requiredPermissions = classified.requiredPermissions;
          parameters = classified.parameters;
          directReply = classified.directReply;
        }

        // Direct non-privileged execution (never enters Approval Center)
        if (!requiresApproval) {
          const chosenSpeaker: AssistantId =
            state.registry[targetAssistant]?.isEnabled ? targetAssistant : 'SK';

          let replyText = directReply?.trim() || actionSummary;
          if (
            routedCategory === 'INFORMATION_QA' &&
            /\b(weather|forecast|temperature|today|latest|current|news|score|price)\b/i.test(trimmedCommand)
          ) {
            try {
              const grounded = await answerLiveQuestionWithSearch(trimmedCommand, chosenSpeaker, abortCtrl.signal);
              if (grounded) replyText = grounded;
            } catch {
              // Keep initial Gemini answer if search grounding times out or quota limits apply
            }
          } else if (routedCategory === 'APP_LAUNCH' || exactOperation === 'OPEN_APPLICATION' || exactOperation === 'LAUNCH_APP') {
            const appName = parameters.appName || trimmedCommand.replace(/^(?:open|launch|start)\s+/i, '').trim();
            state.deviceState.lastLaunchedApp = appName;
            replyText = `Opening ${appName}.`;
            appendAudit(state, 'APP_LAUNCH_REQUEST', chosenSpeaker, null, `Requested launching "${appName}".`);
          } else if (exactOperation === 'PLAY_MUSIC' || exactOperation === 'RESUME_MUSIC') {
            state.deviceState.musicStatus = 'PLAYING';
            replyText = directReply?.trim() || 'Playing music.';
          } else if (exactOperation === 'PAUSE_MUSIC') {
            state.deviceState.musicStatus = 'PAUSED';
            replyText = directReply?.trim() || 'Music playback paused.';
          } else if (exactOperation === 'STOP_MUSIC') {
            state.deviceState.musicStatus = 'STOPPED';
            replyText = directReply?.trim() || 'Music playback stopped.';
          } else if (routedCategory === 'DEVICE_SETTINGS') {
            const panelLabel = exactOperation.includes('BLUETOOTH')
              ? 'Bluetooth Settings'
              : exactOperation.includes('WIFI')
                ? 'Wi-Fi Settings Panel'
                : 'Device Settings';
            if (exactOperation.includes('BLUETOOTH')) state.deviceState.bluetoothPanelRequested = true;
            if (exactOperation.includes('WIFI')) state.deviceState.wifiPanelRequested = true;
            replyText = `Opening ${panelLabel}.`;
            appendAudit(state, 'SETTINGS_PANEL_OPENED', chosenSpeaker, null, replyText);
          } else if (routedCategory === 'SYSTEM_INFO') {
            replyText = `${replyText} (Device state: Battery live sensor on Android · Torch ${state.deviceState.torchEnabled ? 'ON' : 'OFF'}, Volume ${state.deviceState.mediaVolumePercent}%, Ringer ${state.deviceState.ringerMode.toUpperCase()}).`;
          }

          if (LOW_RISK_DIRECT_OPS.has(exactOperation) && (routedCategory === 'PHONE_CONTROL' || routedCategory === 'APP_LAUNCH' || routedCategory === 'DEVICE_SETTINGS')) {
            const directId = `direct-${crypto.randomBytes(4).toString('hex')}`;
            const directItem: TaskHistoryItem = {
              proposalId: directId,
              targetAssistant: chosenSpeaker,
              rawInput: trimmedCommand,
              exactOperation,
              status: 'COMPLETED',
              resultSummary: replyText,
              outputPayload: parameters,
              timestampEpochMs: Date.now(),
            };
            state.taskHistory = [directItem, ...state.taskHistory].slice(0, 100);
          }

          const speakerEntry = state.registry[chosenSpeaker];
          if (speakerEntry) {
            speakerEntry.metrics.lastResponseMs = Math.max(1, Date.now() - startedAt);
            speakerEntry.metrics.recentError = null;
          }
          state.registry.SK.metrics.lastResponseMs = Math.max(1, Date.now() - startedAt);
          state.registry.SK.metrics.recentError = null;
          recomputeMetrics(state);
          saveState(state);
          return {
            status: 200,
            body: {
              mode: 'DIRECT_RESPONSE',
              category: routedCategory,
              speaker: chosenSpeaker,
              replyText,
              exactOperation,
              parameters,
              state,
            },
          };
        }

        // Privileged / Sensitive Operation -> Delegated worker check + Deduplicated Task Proposal
        const target: Exclude<AssistantId, 'SK'> =
          targetAssistant === 'SK' ? 'MAGMITE' : targetAssistant;
        if (!enabledAssistants.includes(target)) {
          const msg = `SK could not delegate to ${target} because it is disabled or unregistered.`;
          emitAlert(state, 'WARNING', 'SK', 'Delegation Blocked', msg);
          appendAudit(state, 'ROUTING_BLOCKED', 'SK', null, msg);
          recomputeMetrics(state);
          saveState(state);
          return { status: 409, body: { errorCode: 'ASSISTANT_DISABLED', error: msg, state } };
        }

        const now = Date.now();
        state.pendingProposals = state.pendingProposals.filter(
          (p) => p.expiresAtEpochMs > now && !LOW_RISK_DIRECT_OPS.has((p.exactOperation ?? '').toUpperCase())
        );

        const canonicalNewParams = Object.keys(parameters).sort().map((k) => `${k}=${parameters[k]}`).join('&');
        const duplicate = state.pendingProposals.find((p) => {
          const pParams = Object.keys(p.parameters).sort().map((k) => `${k}=${p.parameters[k]}`).join('&');
          return p.targetAssistant === target && p.exactOperation === exactOperation && pParams === canonicalNewParams;
        });
        if (duplicate) {
          state.registry.SK.metrics.recentError = null;
          recomputeMetrics(state);
          saveState(state);
          return {
            status: 200,
            body: {
              mode: 'PROPOSAL',
              category: routedCategory,
              deduplicated: true,
              proposal: duplicate,
              state,
            },
          };
        }

        const proposalId = `prop-${crypto.randomBytes(5).toString('hex')}`;
        const commandId = `cmd-${crypto.randomBytes(4).toString('hex')}`;
        const payloadHash = computeProposalHash(
          proposalId,
          target,
          exactOperation,
          parameters,
          requiredPermissions
        );

        const proposal: TaskProposal = {
          proposalId,
          commandId,
          rawInput: trimmedCommand,
          targetAssistant: target,
          actionSummary,
          exactOperation,
          parameters,
          requiredPermissions,
          riskLevel,
          rationale,
          payloadHash,
          createdAtEpochMs: now,
          expiresAtEpochMs: now + 5 * 60 * 1000,
        };

        state.pendingProposals = [proposal, ...state.pendingProposals];
        state.registry.SK.metrics.lastResponseMs = Math.max(1, Date.now() - startedAt);
        state.registry.SK.metrics.recentError = null;
        appendAudit(
          state,
          'PROPOSAL_CREATED',
          'SK',
          proposalId,
          `SK proposed ${proposal.exactOperation} -> ${target} (hash=${payloadHash.slice(0, 12)})`
        );
        recomputeMetrics(state);
        saveState(state);

        return {
          status: 200,
          body: {
            mode: 'PROPOSAL',
            category: routedCategory,
            deduplicated: false,
            proposal,
            state,
          },
        };
      })();

      inFlightRoutes.set(routeDedupKey, routeTask);
      try {
        const result = await routeTask;
        if (!res.headersSent) {
          res.status(result.status).json(result.body);
        }
      } finally {
        inFlightRoutes.delete(routeDedupKey);
      }
    } catch (err) {
      if (abortCtrl.signal.aborted && res.writableEnded) return;
      const classified = classifyProviderError(err);
      state.registry.SK.metrics.recentError = classified.userMessage;
      state.registry.SK.status = 'ONLINE';
      emitAlert(state, 'ERROR', 'SK', `Routing Failure (${classified.errorCode})`, classified.userMessage);
      appendAudit(state, 'ROUTING_ERROR', 'SK', null, `${classified.errorCode}: ${classified.userMessage}`);
      recomputeMetrics(state);
      saveState(state);
      if (!res.headersSent) {
        res.status(classified.httpStatus).json({
          errorCode: classified.errorCode,
          error: classified.userMessage,
          state,
        });
      }
    }
  });

  // --- Approve & Execute Task Proposal (Single-use Hash Verification + Duplicate Lock) ---
  app.post('/api/sk/approve', async (req, res) => {
    const execStart = Date.now();
    const { proposalId, payloadHash } = req.body as {
      proposalId?: string;
      payloadHash?: string;
    };
    if (!proposalId) {
      return res.status(400).json({ error: 'Missing proposalId.' });
    }
    if (inFlightApprovals.has(proposalId)) {
      return res.status(409).json({ error: 'Task execution is already in progress for this proposal.' });
    }
    inFlightApprovals.add(proposalId);

    try {
      const idx = state.pendingProposals.findIndex((p) => p.proposalId === proposalId);
      if (idx === -1) {
        return res.status(404).json({ error: 'Task proposal not found or already executed.' });
      }

      const proposal = state.pendingProposals[idx];
      if (Date.now() > proposal.expiresAtEpochMs) {
        state.pendingProposals.splice(idx, 1);
        appendAudit(state, 'PROPOSAL_EXPIRED', 'SK', proposal.proposalId, 'Proposal expired prior to approval.');
        recomputeMetrics(state);
        saveState(state);
        return res.status(410).json({ error: 'Task proposal expired before user approval.', state });
      }

      const expectedHash = computeProposalHash(
        proposal.proposalId,
        proposal.targetAssistant,
        proposal.exactOperation,
        proposal.parameters,
        proposal.requiredPermissions
      );
      if (payloadHash !== expectedHash || proposal.payloadHash !== expectedHash) {
        emitAlert(state, 'CRITICAL', 'SK', 'Approval Integrity Mismatch', `Rejected tampered approval for ${proposal.proposalId}.`);
        appendAudit(state, 'INTEGRITY_VIOLATION', 'SK', proposal.proposalId, 'Approval hash mismatch detected.');
        recomputeMetrics(state);
        saveState(state);
        return res.status(403).json({ error: 'Approval payload hash mismatch. Task execution denied.' });
      }

      const targetReg = state.registry[proposal.targetAssistant];
      if (!targetReg || !targetReg.isEnabled) {
        return res.status(409).json({ error: `${proposal.targetAssistant} was disabled before execution.` });
      }

      const missingPermissions = proposal.requiredPermissions.filter(
        (perm) => state.deviceState.grantedPermissions[perm] === false
      );
      if (missingPermissions.length > 0) {
        targetReg.metrics.recentError = `Missing permissions: ${missingPermissions.join(', ')}`;
        emitAlert(
          state,
          'WARNING',
          proposal.targetAssistant,
          'Android Permission Required',
          `${proposal.targetAssistant} blocked: missing ${missingPermissions.join(', ')}`
        );
        appendAudit(
          state,
          'PERMISSION_MISSING',
          proposal.targetAssistant,
          proposal.proposalId,
          `Blocked execution due to missing Android permissions: ${missingPermissions.join(', ')}`
        );
        recomputeMetrics(state);
        saveState(state);
        return res.status(403).json({
          error: `Missing Android permissions: ${missingPermissions.join(', ')}. Grant them in Security & Permissions to proceed.`,
          missingPermissions,
          state,
        });
      }

      // Single-use token consumption: remove proposal from pending BEFORE running execution
      state.pendingProposals.splice(idx, 1);
      targetReg.status = 'BUSY';
      appendAudit(
        state,
        'TASK_APPROVED',
        'SK',
        proposal.proposalId,
        `User approved ${proposal.exactOperation} for ${proposal.targetAssistant} (hash=${expectedHash.slice(0, 12)})`
      );

      let resultSummary = '';
      let outputPayload: Record<string, string> = {};

      if (CRITICAL_APPROVAL_OPS.has(proposal.exactOperation)) {
        resultSummary = `${proposal.targetAssistant} completed strongly-confirmed critical operation ${proposal.exactOperation}.`;
        outputPayload = { operation: proposal.exactOperation, verified: 'true', ...proposal.parameters };
      } else if (proposal.targetAssistant === 'MAGMITE') {
        const op = proposal.exactOperation;
        if (op === 'TOGGLE_TORCH' || op === 'SET_FLASHLIGHT') {
          const next = proposal.parameters.enabled !== undefined
            ? proposal.parameters.enabled.toLowerCase() === 'true'
            : !state.deviceState.torchEnabled;
          state.deviceState.torchEnabled = next;
          resultSummary = `MAGMITE executed CameraManager.setTorchMode(${next}).`;
          outputPayload = { torchEnabled: String(next) };
        } else if (op === 'SET_VOLUME' || op === 'ADJUST_VOLUME') {
          const pct = Math.max(0, Math.min(100, Number(proposal.parameters.percent ?? 50) || 50));
          state.deviceState.mediaVolumePercent = pct;
          resultSummary = `MAGMITE adjusted AudioManager stream volume to ${pct}%.`;
          outputPayload = { mediaVolumePercent: String(pct) };
        } else if (op === 'SET_RINGER_MODE') {
          const modeRaw = (proposal.parameters.mode ?? 'normal').toLowerCase();
          const mode = modeRaw === 'silent' || modeRaw === 'vibrate' ? modeRaw : 'normal';
          state.deviceState.ringerMode = mode;
          resultSummary = `MAGMITE set ringer profile to ${mode.toUpperCase()}.`;
          outputPayload = { ringerMode: mode };
        } else if (op === 'OPEN_WIFI_SETTINGS') {
          state.deviceState.wifiPanelRequested = true;
          resultSummary = 'MAGMITE launched Android Settings.Panel.ACTION_WIFI for user confirmation.';
          outputPayload = { panel: 'ACTION_WIFI' };
        } else if (op === 'OPEN_BLUETOOTH_SETTINGS') {
          state.deviceState.bluetoothPanelRequested = true;
          resultSummary = 'MAGMITE launched Android Settings.ACTION_BLUETOOTH_SETTINGS.';
          outputPayload = { panel: 'ACTION_BLUETOOTH_SETTINGS' };
        } else if (op === 'CALL_CONTACT' || op === 'PREPARE_SMS' || op === 'SEND_SMS' || op === 'SEND_WHATSAPP_MESSAGE' || op === 'PREPARE_WHATSAPP' || op === 'SEND_EMAIL' || op === 'PREPARE_EMAIL') {
          const recipient = proposal.parameters.recipientQuery || proposal.parameters.contactName || 'contact';
          const bodyPreview = proposal.parameters.messageBody || proposal.parameters.message || '';
          resultSummary = op === 'CALL_CONTACT'
            ? `MAGMITE authorized call workflow for "${recipient}" (requires Android Telecom / SIM selection on mobile device).`
            : op.includes('WHATSAPP')
              ? `MAGMITE verified and dispatched WhatsApp message workflow for "${recipient}"${bodyPreview ? ` ("${bodyPreview}")` : ''}.`
              : op.includes('EMAIL')
                ? `MAGMITE verified and dispatched email draft workflow for "${recipient}"${bodyPreview ? ` ("${bodyPreview}")` : ''}.`
                : `MAGMITE authorized SMS workflow for "${recipient}"${bodyPreview ? ` ("${bodyPreview}")` : ''}.`;
          outputPayload = { recipientQuery: recipient, mode: op, verified: 'true' };
        } else {
          const reasoned = await reasonWithAssistantGemini(
            'MAGMITE',
            proposal.exactOperation,
            proposal.rawInput,
            proposal.parameters,
            targetReg
          );
          resultSummary = reasoned.summary;
          outputPayload = reasoned.structuredOutput;
        }
      } else if (proposal.targetAssistant === 'FRIDAY' && (proposal.exactOperation === 'CREATE_REMINDER' || proposal.exactOperation === 'SCHEDULE_EVENT')) {
        const title = proposal.parameters.title || proposal.rawInput.slice(0, 64);
        const delayMinutes = Math.max(1, Number(proposal.parameters.delayMinutes ?? 15) || 15);
        const notes = proposal.parameters.notes || proposal.rationale;
        const reminder: ReminderItem = {
          id: `rem-${crypto.randomBytes(4).toString('hex')}`,
          title,
          notes,
          delayMinutes,
          triggerAtEpochMs: Date.now() + delayMinutes * 60_000,
          completed: false,
          createdByProposalId: proposal.proposalId,
        };
        state.reminders = [reminder, ...state.reminders];
        resultSummary = `FRIDAY persisted reminder "${title}" and scheduled AlarmManager trigger in ${delayMinutes}m.`;
        outputPayload = { reminderId: reminder.id, delayMinutes: String(delayMinutes) };
      } else {
        const enrichedParams = proposal.targetAssistant === 'ULTRON'
          ? {
              ...proposal.parameters,
              activeTasksCount: String(state.taskHistory.length),
              onlineAssistants: Object.values(state.registry).filter((a) => a.isEnabled).map((a) => a.id).join(','),
              torchEnabled: String(state.deviceState.torchEnabled),
              volumePercent: String(state.deviceState.mediaVolumePercent),
            }
          : proposal.parameters;

        const reasoned = await reasonWithAssistantGemini(
          proposal.targetAssistant,
          proposal.exactOperation,
          proposal.rawInput,
          enrichedParams,
          targetReg
        );
        resultSummary = reasoned.summary;
        outputPayload = reasoned.structuredOutput;
      }

      targetReg.status = targetReg.isEnabled ? 'ONLINE' : 'DISABLED';
      targetReg.metrics.lastResponseMs = Math.max(1, Date.now() - execStart);
      targetReg.metrics.recentError = null;

      const historyItem: TaskHistoryItem = {
        proposalId: proposal.proposalId,
        targetAssistant: proposal.targetAssistant,
        rawInput: proposal.rawInput,
        exactOperation: proposal.exactOperation,
        status: 'COMPLETED',
        resultSummary,
        outputPayload,
        timestampEpochMs: Date.now(),
      };
      state.taskHistory = [historyItem, ...state.taskHistory].slice(0, 100);
      appendAudit(state, 'TASK_EXECUTED', proposal.targetAssistant, proposal.proposalId, resultSummary);
      recomputeMetrics(state);
      saveState(state);

      res.json({ result: historyItem, state });
    } catch (err) {
      const classified = classifyProviderError(err);
      // Restore assistant status cleanly so no core gets stuck in BUSY
      (['JARVIS', 'MAGMITE', 'ULTRON', 'FRIDAY'] as AssistantId[]).forEach((id) => {
        if (state.registry[id].status === 'BUSY') {
          state.registry[id].status = state.registry[id].isEnabled ? 'ONLINE' : 'DISABLED';
        }
      });
      emitAlert(state, 'ERROR', 'SK', `Execution Error (${classified.errorCode})`, classified.userMessage);
      appendAudit(state, 'TASK_FAILED', 'SK', proposalId, `${classified.errorCode}: ${classified.userMessage}`);
      recomputeMetrics(state);
      saveState(state);
      res.status(classified.httpStatus).json({ errorCode: classified.errorCode, error: classified.userMessage, state });
    } finally {
      inFlightApprovals.delete(proposalId);
    }
  });

  // --- Reject Proposal ---
  app.post('/api/sk/reject', (req, res) => {
    const { proposalId, reason } = req.body as { proposalId?: string; reason?: string };
    const idx = state.pendingProposals.findIndex((p) => p.proposalId === proposalId);
    if (idx === -1) {
      return res.status(404).json({ error: 'Proposal not found.' });
    }
    const [removed] = state.pendingProposals.splice(idx, 1);
    const note = reason?.trim() || 'Explicitly rejected by user';
    const rejectedItem: TaskHistoryItem = {
      proposalId: removed.proposalId,
      targetAssistant: removed.targetAssistant,
      rawInput: removed.rawInput,
      exactOperation: removed.exactOperation,
      status: 'REJECTED',
      resultSummary: note,
      outputPayload: {},
      timestampEpochMs: Date.now(),
    };
    state.taskHistory = [rejectedItem, ...state.taskHistory].slice(0, 100);
    appendAudit(
      state,
      'TASK_REJECTED',
      'SK',
      removed.proposalId,
      `User rejected ${removed.exactOperation} for ${removed.targetAssistant}: ${note}`
    );
    saveState(state);
    res.json({ state });
  });

  // --- Toggle Assistant Registration / Availability ---
  app.post('/api/assistants/:id/toggle', (req, res) => {
    const id = req.params.id.toUpperCase() as AssistantId;
    if (id === 'SK') {
      return res.status(403).json({ error: 'SK Master Controller cannot be disabled.' });
    }
    const entry = state.registry[id];
    if (!entry) {
      return res.status(404).json({ error: `Unknown assistant: ${id}` });
    }
    const nextEnabled = typeof req.body?.enabled === 'boolean' ? req.body.enabled : !entry.isEnabled;
    entry.isEnabled = nextEnabled;
    entry.status = nextEnabled ? 'ONLINE' : 'DISABLED';
    entry.lastHeartbeatMs = Date.now();
    appendAudit(
      state,
      nextEnabled ? 'ASSISTANT_ENABLED' : 'ASSISTANT_DISABLED',
      'SK',
      null,
      `SK set ${id} availability to ${entry.status}`
    );
    if (!nextEnabled) {
      emitAlert(state, 'INFO', 'SK', `${id} Offline`, `${id} was placed offline in the SK Assistant Registry.`);
    }
    saveState(state);
    res.json({ state });
  });

  // --- Toggle Simulated Android Runtime Permission (to test PermissionGuard behavior) ---
  app.post('/api/permissions/toggle', (req, res) => {
    const { permission, granted } = req.body as { permission?: string; granted?: boolean };
    if (!permission) return res.status(400).json({ error: 'Missing permission name.' });
    state.deviceState.grantedPermissions[permission] = Boolean(granted);
    appendAudit(
      state,
      granted ? 'PERMISSION_GRANTED' : 'PERMISSION_REVOKED',
      'SK',
      null,
      `Android permission ${permission} set to ${granted ? 'GRANTED' : 'DENIED'}`
    );
    saveState(state);
    res.json({ state });
  });

  // --- Toggle Reminder Completion ---
  app.post('/api/reminders/:id/toggle', (req, res) => {
    const rem = state.reminders.find((r) => r.id === req.params.id);
    if (!rem) return res.status(404).json({ error: 'Reminder not found.' });
    rem.completed = !rem.completed;
    saveState(state);
    res.json({ state });
  });

  // --- Generate Periodic SK System Report ---
  app.post('/api/sk/report', async (_req, res) => {
    try {
      const totalCommands = state.taskHistory.length;
      const approvedTasks = state.taskHistory.filter((t) => t.status === 'COMPLETED').length;
      const rejectedTasks = state.taskHistory.filter((t) => t.status === 'REJECTED' || t.status === 'DENIED').length;
      const failedTasks = state.taskHistory.filter((t) => t.status === 'FAILED' || t.status === 'PERMISSION_MISSING').length;
      const activeAssistants = Object.values(state.registry)
        .filter((a) => !a.isMasterController && a.isEnabled)
        .map((a) => a.id);

      const narrativeSummary = await synthesizeReportWithGemini(
        totalCommands,
        approvedTasks,
        rejectedTasks,
        failedTasks,
        activeAssistants,
        state.auditLogs.map((a) => `${a.eventType}:${a.actor}:${a.summary}`)
      );

      const report: SystemReport = {
        reportId: `rep-${crypto.randomBytes(4).toString('hex')}`,
        generatedAtEpochMs: Date.now(),
        periodLabel: 'SK Periodic Telemetry Report',
        totalCommands,
        approvedTasks,
        rejectedTasks,
        failedTasks,
        activeAssistants,
        narrativeSummary,
      };
      state.reports = [report, ...state.reports].slice(0, 25);
      appendAudit(state, 'REPORT_GENERATED', 'SK', null, `Generated SK system report ${report.reportId}`);
      saveState(state);
      res.json({ report, state });
    } catch (err) {
      const classified = classifyProviderError(err);
      res.status(classified.httpStatus).json({ errorCode: classified.errorCode, error: classified.userMessage });
    }
  });

  // --- Acknowledge System Alert ---
  app.post('/api/alerts/:id/ack', (req, res) => {
    const alert = state.alerts.find((a) => a.alertId === req.params.id);
    if (alert) {
      alert.acknowledged = true;
      saveState(state);
    }
    res.json({ state });
  });

  // --- Record Interface Mode / Voice Command Transition ---
  app.post('/api/sk/mode-event', (req, res) => {
    const { mode, actor, summary } = req.body as {
      mode?: string;
      actor?: AssistantId;
      summary?: string;
    };
    if (!mode || !summary) {
      return res.status(400).json({ error: 'Missing mode or summary.' });
    }
    const resolvedActor: AssistantId = actor && state.registry[actor] ? actor : 'SK';
    appendAudit(state, `MODE_${mode.toUpperCase()}`, resolvedActor, null, summary);
    saveState(state);
    res.json({ state });
  });

  // --- Update Per-Assistant Voice Pitch & Speech Rate ---
  app.post('/api/voice/config/:id', (req, res) => {
    const id = req.params.id.toUpperCase() as AssistantId;
    const entry = state.registry[id];
    if (!entry) return res.status(404).json({ error: `Unknown assistant: ${id}` });
    const { pitch, speechRate } = req.body as { pitch?: number; speechRate?: number };
    if (typeof pitch === 'number' && !Number.isNaN(pitch)) {
      entry.voiceConfig.pitch = Math.max(0.5, Math.min(1.6, Number(pitch.toFixed(2))));
    }
    if (typeof speechRate === 'number' && !Number.isNaN(speechRate)) {
      entry.voiceConfig.speechRate = Math.max(0.5, Math.min(1.6, Number(speechRate.toFixed(2))));
    }
    saveState(state);
    res.json({ state });
  });

  // --- Gemini 3.8 Neural TTS Synthesis (5 Distinct Voices) ---
  const handleVoiceSynthesize = async (req: express.Request, res: express.Response) => {
    try {
      const { assistantId, text } = req.body as { assistantId?: string; text?: string };
      const id = (assistantId ?? 'SK').toUpperCase() as AssistantId;
      const entry = state.registry[id];
      if (!entry) return res.status(404).json({ error: `Unknown assistant: ${id}` });
      if (!text || !text.trim()) return res.status(400).json({ error: 'Text to synthesize cannot be empty.' });

      const ai = getGeminiTtsClient();
      const response = await ai.models.generateContent({
        model: 'gemini-3.8-flash-lite-tts',
        contents: [
          {
            role: 'user',
            parts: [
              {
                text: text.trim().slice(0, 600),
                speechMetadata: {
                  style: entry.voiceConfig.stylePrompt,
                },
              },
            ],
          },
        ],
        config: {
          responseModalities: ['AUDIO'],
          speechConfig: {
            voiceConfig: {
              prebuiltVoiceConfig: { voiceName: entry.voiceConfig.neuralVoiceName },
            },
          },
        },
      });

      const base64Audio = response.candidates?.[0]?.content?.parts?.[0]?.inlineData?.data;
      if (!base64Audio) {
        return res.status(502).json({ error: 'Gemini TTS returned no audio payload.' });
      }

      res.json({
        assistantId: id,
        voiceName: entry.voiceConfig.neuralVoiceName,
        gender: entry.voiceConfig.gender,
        mimeType: 'audio/wav',
        audioBase64: base64Audio,
        provider: 'gemini-3.8-flash-lite-tts',
      });
    } catch (err) {
      const classified = classifyProviderError(err);
      res.status(classified.httpStatus).json({ errorCode: classified.errorCode, error: classified.userMessage });
    }
  };

  app.post('/api/voice/synthesize', handleVoiceSynthesize);
  app.post('/api/android/voice/synthesize', handleVoiceSynthesize);

  // --- Android Retrofit Backend Proxy Endpoints (matching OmegaBackendApi.kt) ---
  app.post('/api/android/route', async (req, res) => {
    const abortCtrl = new AbortController();
    req.on('close', () => {
      if (!res.writableEnded) abortCtrl.abort();
    });

    try {
      const { command, preferredAssistant, availableAssistants } = (req.body ?? {}) as {
        command?: unknown;
        preferredAssistant?: string | null;
        availableAssistants?: string[];
      };

      if (typeof command !== 'string' || !command.trim()) {
        return res.status(400).json({ errorCode: 'INVALID_REQUEST', error: 'Invalid request: command cannot be empty.' });
      }
      if (command.trim().length > 2000) {
        return res.status(400).json({ errorCode: 'INVALID_REQUEST', error: 'Invalid request: command exceeds maximum length.' });
      }

      const fast = detectDeterministicIntent(command.trim(), state, preferredAssistant);
      if (fast?.kind === 'DIRECT_RESPONSE' || fast?.kind === 'SYSTEM_READ') {
        return res.json({
          category: fast.category,
          requiresApproval: false,
          targetAssistant: fast.speaker,
          exactOperation: fast.exactOperation || fast.category,
          rationale: 'Handled deterministically by SK Master Controller.',
          riskLevel: 'LOW',
          requiredPermissions: [],
          parameters: fast.kind === 'DIRECT_RESPONSE' ? (fast.parameters ?? {}) : {},
          directReply: fast.replyText,
        });
      }
      if (fast?.kind === 'FAST_PROPOSAL') {
        return res.json({
          category: fast.category,
          requiresApproval: true,
          targetAssistant: fast.targetAssistant,
          exactOperation: fast.exactOperation,
          rationale: fast.rationale,
          riskLevel: fast.riskLevel,
          requiredPermissions: fast.requiredPermissions,
          parameters: fast.parameters,
          directReply: fast.actionSummary,
        });
      }

      const safeAssistants = Array.isArray(availableAssistants) && availableAssistants.length > 0
        ? availableAssistants
        : ['JARVIS', 'MAGMITE', 'ULTRON', 'FRIDAY'];
      const routed = await routeWithGemini(command.trim(), preferredAssistant, safeAssistants, abortCtrl.signal);
      let directReply = routed.directReply ?? '';
      if (
        !routed.requiresApproval &&
        routed.category === 'INFORMATION_QA' &&
        /\b(weather|forecast|temperature|today|latest|current|news|score|price)\b/i.test(command)
      ) {
        try {
          const grounded = await answerLiveQuestionWithSearch(command.trim(), routed.targetAssistant, abortCtrl.signal);
          if (grounded) directReply = grounded;
        } catch {
          // Retain initial Gemini answer if search grounding hits quota or timeout
        }
      }
      res.json({
        category: routed.category,
        requiresApproval: routed.requiresApproval,
        targetAssistant: routed.targetAssistant,
        exactOperation: routed.exactOperation,
        rationale: routed.rationale,
        riskLevel: routed.riskLevel,
        requiredPermissions: routed.requiredPermissions,
        parameters: routed.parameters,
        directReply,
      });
    } catch (err) {
      if (abortCtrl.signal.aborted && res.writableEnded) return;
      const classified = classifyProviderError(err);
      res.status(classified.httpStatus).json({ errorCode: classified.errorCode, error: classified.userMessage });
    }
  });

  app.post('/api/android/reason', async (req, res) => {
    const abortCtrl = new AbortController();
    req.on('close', () => {
      if (!res.writableEnded) abortCtrl.abort();
    });
    try {
      const { assistantId, operation, rawInput, parameters } = (req.body ?? {}) as {
        assistantId?: AssistantId;
        operation?: string;
        rawInput?: string;
        parameters?: Record<string, string>;
      };
      const entry = assistantId ? state.registry[assistantId] : undefined;
      if (!entry || !assistantId || assistantId === 'SK') {
        return res.status(404).json({ errorCode: 'UNKNOWN_ASSISTANT', error: 'Unknown or invalid assistant identifier.' });
      }
      const result = await reasonWithAssistantGemini(
        assistantId as Exclude<AssistantId, 'SK'>,
        operation || 'GENERAL_REASONING',
        rawInput || '',
        parameters ?? {},
        entry,
        abortCtrl.signal
      );
      res.json(result);
    } catch (err) {
      const classified = classifyProviderError(err);
      res.status(classified.httpStatus).json({ errorCode: classified.errorCode, error: classified.userMessage });
    }
  });

  app.post('/api/android/report', async (req, res) => {
    try {
      const { totalCommands, approvedTasks, rejectedTasks, failedTasks, activeAssistants } = (req.body ?? {}) as {
        totalCommands: number;
        approvedTasks: number;
        rejectedTasks: number;
        failedTasks: number;
        activeAssistants: string[];
      };
      const narrativeSummary = await synthesizeReportWithGemini(
        Number(totalCommands) || 0,
        Number(approvedTasks) || 0,
        Number(rejectedTasks) || 0,
        Number(failedTasks) || 0,
        Array.isArray(activeAssistants) ? activeAssistants : [],
        []
      );
      res.json({ narrativeSummary });
    } catch (err) {
      const classified = classifyProviderError(err);
      res.status(classified.httpStatus).json({ errorCode: classified.errorCode, error: classified.userMessage });
    }
  });

  // --- Android Project Source Explorer & ZIP Export ---
  app.get('/api/android/files', (_req, res) => {
    const files = listFilesRecursively(ANDROID_ROOT, ANDROID_ROOT);
    res.json({ files });
  });

  app.get('/api/android/file', (req, res) => {
    const relPath = String(req.query.path ?? '');
    const normalized = path.normalize(relPath).replace(/^(\.\.[/\\])+/, '');
    const fullPath = path.resolve(ANDROID_ROOT, normalized);
    if (!fullPath.startsWith(ANDROID_ROOT + path.sep) || !fs.existsSync(fullPath)) {
      return res.status(404).json({ error: 'File not found in /android project.' });
    }
    res.json({ path: normalized, content: fs.readFileSync(fullPath, 'utf8') });
  });

  app.get('/api/android/download', async (_req, res) => {
    try {
      const zip = new JSZip();
      const files = listFilesRecursively(ANDROID_ROOT, ANDROID_ROOT);
      for (const f of files) {
        const content = fs.readFileSync(path.join(ANDROID_ROOT, f.path));
        zip.file(`ProjectOmegaSK/${f.path}`, content);
      }
      const buffer = await zip.generateAsync({ type: 'nodebuffer' });
      res.setHeader('Content-Type', 'application/zip');
      res.setHeader('Content-Disposition', 'attachment; filename="ProjectOmega-SK-Android.zip"');
      res.send(buffer);
    } catch (err) {
      res.status(500).json({ error: err instanceof Error ? err.message : 'Failed to archive Android project.' });
    }
  });

  // Vite middleware in development, static dist in production
  if (process.env.NODE_ENV !== 'production') {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    const distDir = path.resolve(process.cwd(), 'dist');
    app.use(express.static(distDir));
    app.get('*', (_req, res) => {
      res.sendFile(path.join(distDir, 'index.html'));
    });
  }

  const port = 3000;
  app.listen(port, '0.0.0.0', () => {
    console.log(`Project Omega SK Master Platform listening on http://0.0.0.0:${port}`);
  });
}

startServer();
